#include <stdio.h>
#include <stdlib.h>   
#include <time.h>    // time()


double ranran(int k);

int main(void){
  int i,k, tt,imax;
  double moi,mea,iimax;
  imax = 1000000;

  iimax = imax*1.0;
  mea = 0.0;
  // srand((unsigned int)time(NULL));
   srand48((unsigned int)time(NULL));

   
  for (i = 0 ; i < imax ; i++){
    /*srand((unsigned int)time(NULL)*(i+1)*10);*/
    /* moi = (double)rand()/(double)RAND_MAX;   
       srand((unsigned int)time(NULL)*moi);*/
   
    // for (k = 0 ; k < 100 ; k++){
      moi = ranran(k);
      /*moi = (double)rand()/(double)RAND_MAX; */

      mea += moi;
      
      // }
      printf("i %d %e \n",i,moi);
    
  }
  
  printf("mean %e \n",mea/iimax);
  
}

double ranran(int k){
  double moi;
  //moi = (double)rand()/(double)RAND_MAX;
     moi = (double)drand48(); 
  return(moi);
  
}
