#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#define _LARGEFILE_SOURCE
#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for unlink() */
#include <stddef.h>
#include <string.h>
#ifdef HAVE_MALLOC_H
#include <malloc.h>
#endif
#include <assert.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>

#ifdef HAVE_SYS_PARAM_H
#include <sys/param.h> /* for MAXHOSTNAMELEN, if available */
#endif
#include <rpc/types.h>
#include <rpc/xdr.h>
#include <inttypes.h>

#include "master.h"
#include "tipsydefs.h"
#include "outtype.h"
#include "smoothfcn.h"
#ifdef USE_HDF5
#include "io.h"
#endif
#include "../analysis/ssio.h"

#ifdef BSC
#include "mpitrace_user_events.h"
#endif

#define LOCKFILE ".lockfile"	/* for safety lock */
#define STOPFILE "STOP"			/* for user interrupt */

#define NEWTIME
#ifdef NEWTIME 
double msrTime() {
    struct timeval tv;
    struct timezone tz;

    tz.tz_minuteswest=0; 
    tz.tz_dsttime=0;
    gettimeofday(&tv,NULL);
    return (tv.tv_sec+(tv.tv_usec*1e-6));
    }
#else
double msrTime() {
    return (1.0*time(0));
    }
#endif

void _msrLeader(void) {
    puts("pkdgrav2 Joachim Stadel June 6, 2005");
    puts("USAGE: pkdgrav2 [SETTINGS | FLAGS] [SIM_FILE]");
    puts("SIM_FILE: Configuration file of a particular simulation, which");
    puts("          includes desired settings and relevant input and");
    puts("          output files. Settings specified in this file override");
    puts("          the default settings.");
    puts("SETTINGS");
    puts("or FLAGS: Command line settings or flags for a simulation which");
    puts("          will override any defaults and any settings or flags");
    puts("          specified in the SIM_FILE.");
    }


void _msrTrailer(void)
    {
    puts("(see man page for more information)");
    }


void _msrExit(MSR msr,int status)
    {
    MDL mdl=msr->mdl;

    msrFinish(msr);
    mdlFinish(mdl);
    exit(status);
    }


void
_msrMakePath(const char *dir,const char *base,char *path)
    {
    /*
    ** Prepends "dir" to "base" and returns the result in "path". It is the
    ** caller's responsibility to ensure enough memory has been allocated
    ** for "path".
    */

    if (!path) return;
    path[0] = 0;
    if (dir) {
	strcat(path,dir);
	strcat(path,"/");
	}
    if (!base) return;
    strcat(path,base);
    }


void msrInitialize(MSR *pmsr,MDL mdl,int argc,char **argv)
    {
    MSR msr;
    int i,j,ret;
    int id,nDigits;
    struct inSetAdd inAdd;
    struct inLevelize inLvl;
    struct inGetMap inGM;

    msr = (MSR)malloc(sizeof(struct msrContext));
    assert(msr != NULL);
    msr->mdl = mdl;
    msr->pst = NULL;
    msr->lcl.pkd = NULL;
    *pmsr = msr;
    csmInitialize(&msr->param.csm);
    /*
    ** Now setup for the input parameters.
    **
    ** NOTE: nThreads & bDiag are parsed here, but the actual values are
    ** read from the command line via mdlInitialize(). This means the
    ** values of nThreads & bDiag read by prmAddParam() are ignored!
    */
    prmInitialize(&msr->prm,_msrLeader,_msrTrailer);
    msr->param.nThreads = 1;
    prmAddParam(msr->prm,"nThreads",1,&msr->param.nThreads,sizeof(int),"sz",
		"<nThreads>");
    msr->param.bDiag = 0;
    prmAddParam(msr->prm,"bDiag",0,&msr->param.bDiag,sizeof(int),"d",
		"enable/disable per thread diagnostic output");
    msr->param.bOverwrite = 0;
    prmAddParam(msr->prm,"bOverwrite",0,&msr->param.bOverwrite,sizeof(int),
		"overwrite","enable/disable overwrite safety lock = +overwrite");
    msr->param.bVWarnings = 1;
    prmAddParam(msr->prm,"bVWarnings",0,&msr->param.bVWarnings,sizeof(int),
		"vwarnings","enable/disable warnings = +vwarnings");
    msr->param.bVStart = 1;
    prmAddParam(msr->prm,"bVStart",0,&msr->param.bVStart,sizeof(int),
		"vstart","enable/disable verbose start = +vstart");
    msr->param.bVStep = 1;
    prmAddParam(msr->prm,"bVStep",0,&msr->param.bVStep,sizeof(int),
		"vstep","enable/disable verbose step = +vstep");
    msr->param.bVRungStat = 1;
    prmAddParam(msr->prm,"bVRungStat",0,&msr->param.bVRungStat,sizeof(int),
		"vrungstat","enable/disable rung statistics = +vrungstat");
    msr->param.bVDetails = 0;
    prmAddParam(msr->prm,"bVDetails",0,&msr->param.bVDetails,sizeof(int),
		"vdetails","enable/disable verbose details = +vdetails");
    nDigits = 5;
    prmAddParam(msr->prm,"nDigits",1,&nDigits,sizeof(int),"nd",
		"<number of digits to use in output filenames> = 5");
    msr->param.bPeriodic = 0;
    prmAddParam(msr->prm,"bPeriodic",0,&msr->param.bPeriodic,sizeof(int),"p",
		"periodic/non-periodic = -p");
    msr->param.bParaRead = 1;
    prmAddParam(msr->prm,"bParaRead",0,&msr->param.bParaRead,sizeof(int),"par",
		"enable/disable parallel reading of files = +par");
    msr->param.bParaWrite = 1;
    prmAddParam(msr->prm,"bParaWrite",0,&msr->param.bParaWrite,sizeof(int),"paw",
		"enable/disable parallel writing of files = +paw");
    msr->param.bCannonical = 1;
    prmAddParam(msr->prm,"bCannonical",0,&msr->param.bCannonical,sizeof(int),"can",
		"enable/disable use of cannonical momentum = +can");
    msr->param.bDoDensity = 1;
    prmAddParam(msr->prm,"bDoDensity",0,&msr->param.bDoDensity,sizeof(int),
		"den","enable/disable density outputs = +den");
    msr->param.bDodtOutput = 0;
    prmAddParam(msr->prm,"bDodtOutput",0,&msr->param.bDodtOutput,sizeof(int),
		"dtout","enable/disable dt outputs = -dtout");
    msr->param.nBucket = 8;
    prmAddParam(msr->prm,"nBucket",1,&msr->param.nBucket,sizeof(int),"b",
		"<max number of particles in a bucket> = 8");
    msr->param.iStartStep = 0;
    prmAddParam(msr->prm,"iStartStep",4,&msr->param.iStartStep,
		sizeof(uint64_t),"nstart","<initial step numbering> = 0");
    msr->param.nSteps = 0;
    prmAddParam(msr->prm,"nSteps",4,&msr->param.nSteps,sizeof(uint64_t),"n",
		"<number of timesteps> = 0");
    msr->param.iOutInterval = 0;
    prmAddParam(msr->prm,"iOutInterval",1,&msr->param.iOutInterval,sizeof(int),
		"oi","<number of timesteps between snapshots> = 0");
    strcpy(msr->param.achOutTypes,"rvmsp");
    prmAddParam(msr->prm,"achOutTypes",3,msr->param.achOutTypes,256,"ot",
		"<output types for snapshort> = \"rvmso\"");
    msr->param.iCheckInterval = 0;
    prmAddParam(msr->prm,"iCheckInterval",1,&msr->param.iCheckInterval,sizeof(int),
		"oc","<number of timesteps between checkpoints> = 0");
    strcpy(msr->param.achCheckTypes,"RVMSP");
    prmAddParam(msr->prm,"achCheckTypes",3,msr->param.achCheckTypes,256,"ct",
		"<output types for checkpoints> = \"RVMSO\"");
    msr->param.iLogInterval = 10;
    prmAddParam(msr->prm,"iLogInterval",1,&msr->param.iLogInterval,sizeof(int),
		"ol","<number of timesteps between logfile outputs> = 10");
    msr->param.bEwald = 1;
    prmAddParam(msr->prm,"bEwald",0,&msr->param.bEwald,sizeof(int),"ewald",
		"enable/disable Ewald correction = +ewald");
    msr->param.bEwaldKicking = 0;
    prmAddParam(msr->prm,"bEwaldKicking",0,&msr->param.bEwaldKicking,sizeof(int),"ewaldkick",
		"enable/disable Ewald correction kicking = -ewaldkick");
    msr->param.iEwOrder = 4;
    prmAddParam(msr->prm,"iEwOrder",1,&msr->param.iEwOrder,sizeof(int),"ewo",
		"<Ewald multipole expansion order: 1, 2, 3 or 4> = 4");
    msr->param.nReplicas = 0;
    prmAddParam(msr->prm,"nReplicas",1,&msr->param.nReplicas,sizeof(int),"nrep",
		"<nReplicas> = 0 for -p, or 1 for +p");
    msr->param.dSoft = 0.0;
    prmAddParam(msr->prm,"dSoft",2,&msr->param.dSoft,sizeof(double),"e",
		"<gravitational softening length> = 0.0");
    msr->param.dSoftMax = 0.0;
    prmAddParam(msr->prm,"dSoftMax",2,&msr->param.dSoftMax,sizeof(double),"eMax",
		"<maximum comoving gravitational softening length (abs or multiplier)> = 0.0");
    msr->param.bPhysicalSoft = 0;
    prmAddParam(msr->prm,"bPhysicalSoft",0,&msr->param.bPhysicalSoft,sizeof(int),"PhysSoft",
		"<Physical gravitational softening length> -PhysSoft");
    msr->param.bSoftMaxMul = 1;
    prmAddParam(msr->prm,"bSoftMaxMul",0,&msr->param.bSoftMaxMul,sizeof(int),"SMM",
		"<Use maximum comoving gravitational softening length as a multiplier> +SMM");
    msr->param.bVariableSoft = 0;
    prmAddParam(msr->prm,"bVariableSoft",0,&msr->param.bVariableSoft,sizeof(int),"VarSoft",
		"<Variable gravitational softening length> -VarSoft");
    msr->param.nSoftNbr = 32;
    prmAddParam(msr->prm,"nSoftNbr",1,&msr->param.nSoftNbr,sizeof(int),"VarSoft",
		"<Neighbours for Variable gravitational softening length> 32");
    msr->param.bSoftByType = 1;
    prmAddParam(msr->prm,"bSoftByType",0,&msr->param.bSoftByType,sizeof(int),"SBT",
		"<Variable gravitational softening length by Type> +SBT");
    msr->param.bDoSoftOutput = 0;
    prmAddParam(msr->prm,"bDoSoftOutput",0,&msr->param.bDoSoftOutput,sizeof(int),
		"softout","enable/disable soft outputs = -softout");
    msr->param.bDoRungOutput = 0;
    prmAddParam(msr->prm,"bDoRungOutput",0,&msr->param.bDoRungOutput,sizeof(int),
		"rungout","enable/disable rung outputs = -rungout");
    msr->param.dDelta = 0.0;
    prmAddParam(msr->prm,"dDelta",2,&msr->param.dDelta,sizeof(double),"dt",
		"<time step>");
    msr->param.dEta = 0.1;
    prmAddParam(msr->prm,"dEta",2,&msr->param.dEta,sizeof(double),"eta",
		"<time step criterion> = 0.1");
    msr->param.bGravStep = 0;
    prmAddParam(msr->prm,"bGravStep",0,&msr->param.bGravStep,sizeof(int),
		"gs","<Gravity timestepping according to iTimeStep Criterion>");
    msr->param.bEpsAccStep = 0;
    prmAddParam(msr->prm,"bEpsAccStep",0,&msr->param.bEpsAccStep,sizeof(int),
		"ea", "<Sqrt(Epsilon on a) timestepping>");
    msr->param.bSqrtPhiStep = 0;
    prmAddParam(msr->prm,"bSqrtPhiStep",0,&msr->param.bSqrtPhiStep,sizeof(int),
		"sphi", "<Sqrt(Phi) on a timestepping>");
    msr->param.bDensityStep = 0;
    prmAddParam(msr->prm,"bDensityStep",0,&msr->param.bDensityStep,sizeof(int),
		"isrho", "<Sqrt(1/Rho) timestepping>");
    msr->param.iTimeStepCrit = 0;
    prmAddParam(msr->prm,"iTimeStepCrit",1,&msr->param.iTimeStepCrit,sizeof(int),
		"tsc", "<Criteria for dynamical time-stepping>");
    msr->param.nPartRhoLoc = 32;
    prmAddParam(msr->prm,"nPartRhoLoc",1,&msr->param.nPartRhoLoc,sizeof(int),
		"nprholoc", "<Number of particles for local density in dynamical time-stepping>");
    msr->param.dPreFacRhoLoc = 4.0*M_PI/3.0;
    prmAddParam(msr->prm,"dPreFacRhoLoc",2,&msr->param.dPreFacRhoLoc,sizeof(double),
		"nprholoc", "<Pre-factor for local density in dynamical time-stepping>");
    msr->param.nPartColl = 0;
    prmAddParam(msr->prm,"nPartColl",1,&msr->param.nPartColl,sizeof(int),
		"npcoll", "<Number of particles in collisional regime>");
    msr->param.nTruncateRung = 0;
    prmAddParam(msr->prm,"nTruncateRung",1,&msr->param.nTruncateRung,sizeof(int),"nTR",
		"<number of MaxRung particles to delete MaxRung> = 0");
    msr->param.iMaxRung = 1;
    prmAddParam(msr->prm,"iMaxRung",1,&msr->param.iMaxRung,sizeof(int),
		"mrung", "<maximum timestep rung>");
    msr->param.nRungVeryActive = 31;
    prmAddParam(msr->prm,"nRungVeryActive",1,&msr->param.nRungVeryActive,
		sizeof(int), "nvactrung", "<timestep rung to use very active timestepping>");
    msr->param.nPartVeryActive = 0;
    prmAddParam(msr->prm,"nPartVeryActive",1,&msr->param.nPartVeryActive,
		sizeof(int), "nvactpart", "<number of particles to use very active timestepping>");
    msr->param.dEwCut = 2.6;
    prmAddParam(msr->prm,"dEwCut",2,&msr->param.dEwCut,sizeof(double),"ew",
		"<dEwCut> = 2.6");
    msr->param.dEwhCut = 2.8;
    prmAddParam(msr->prm,"dEwhCut",2,&msr->param.dEwhCut,sizeof(double),"ewh",
		"<dEwhCut> = 2.8");
    msr->param.dTheta = 0.8;
    msr->param.dTheta2 = msr->param.dTheta;
    prmAddParam(msr->prm,"dTheta",2,&msr->param.dTheta,sizeof(double),"theta",
		"<Barnes opening criterion> = 0.8");
    prmAddParam(msr->prm,"dTheta2",2,&msr->param.dTheta2,sizeof(double),
		"theta2","<Barnes opening criterion for a >= daSwitchTheta> = 0.8");
    msr->param.daSwitchTheta = 1./3.;
    prmAddParam(msr->prm,"daSwitchTheta",2,&msr->param.daSwitchTheta,sizeof(double),"aSwitchTheta",
		"<a to switch theta at> = 1./3.");
    msr->param.dPeriod = 1.0;
    prmAddParam(msr->prm,"dPeriod",2,&msr->param.dPeriod,sizeof(double),"L",
		"<periodic box length> = 1.0");
    msr->param.dxPeriod = 1.0;
    prmAddParam(msr->prm,"dxPeriod",2,&msr->param.dxPeriod,sizeof(double),"Lx",
		"<periodic box length in x-dimension> = 1.0");
    msr->param.dyPeriod = 1.0;
    prmAddParam(msr->prm,"dyPeriod",2,&msr->param.dyPeriod,sizeof(double),"Ly",
		"<periodic box length in y-dimension> = 1.0");
    msr->param.dzPeriod = 1.0;
    prmAddParam(msr->prm,"dzPeriod",2,&msr->param.dzPeriod,sizeof(double),"Lz",
		"<periodic box length in z-dimension> = 1.0");
    msr->param.achInFile[0] = 0;
    prmAddParam(msr->prm,"achInFile",3,msr->param.achInFile,256,"I",
		"<input file name> (file in TIPSY binary format)");
    strcpy(msr->param.achOutName,"pkdgrav");
    prmAddParam(msr->prm,"achOutName",3,msr->param.achOutName,256,"o",
		"<output name for snapshots and logfile> = \"pkdgrav\"");
    strcpy(msr->param.achOutPath,"");
    prmAddParam(msr->prm,"achOutPath",3,msr->param.achOutPath,256,"op",
		"<output path for snapshots and logfile> = \"\"");
    msr->param.csm->bComove = 0;
    prmAddParam(msr->prm,"bComove",0,&msr->param.csm->bComove,sizeof(int),
		"cm", "enable/disable comoving coordinates = -cm");
    msr->param.csm->dHubble0 = 0.0;
    prmAddParam(msr->prm,"dHubble0",2,&msr->param.csm->dHubble0, 
		sizeof(double),"Hub", "<dHubble0> = 0.0");
    msr->param.csm->dOmega0 = 1.0;
    prmAddParam(msr->prm,"dOmega0",2,&msr->param.csm->dOmega0,
		sizeof(double),"Om", "<dOmega0> = 1.0");
    msr->param.csm->dLambda = 0.0;
    prmAddParam(msr->prm,"dLambda",2,&msr->param.csm->dLambda,
		sizeof(double),"Lambda", "<dLambda> = 0.0");
    msr->param.csm->dOmegaRad = 0.0;
    prmAddParam(msr->prm,"dOmegaRad",2,&msr->param.csm->dOmegaRad,
		sizeof(double),"Omrad", "<dOmegaRad> = 0.0");
    msr->param.csm->dOmegab = 0.0;
    prmAddParam(msr->prm,"dOmegab",2,&msr->param.csm->dOmegab,
		sizeof(double),"Omb", "<dOmegab> = 0.0");
    strcpy(msr->param.achDataSubPath,".");
    prmAddParam(msr->prm,"achDataSubPath",3,msr->param.achDataSubPath,256,
		NULL,NULL);
    msr->param.dExtraStore = 0.1;
    prmAddParam(msr->prm,"dExtraStore",2,&msr->param.dExtraStore,
		sizeof(double),NULL,NULL);
    msr->param.nSmooth = 64;
    prmAddParam(msr->prm,"nSmooth",1,&msr->param.nSmooth,sizeof(int),"s",
		"<number of particles to smooth over> = 64");
    msr->param.bStandard = 0;
    prmAddParam(msr->prm,"bStandard",0,&msr->param.bStandard,sizeof(int),"std",
		"output in standard TIPSY binary format = -std");
    msr->param.bHDF5 = 0;
    prmAddParam(msr->prm,"bHDF5",0,&msr->param.bHDF5,sizeof(int),"hdf5",
		"output in HDF5 format = -hdf5");
    msr->param.bDoublePos = 0;
    prmAddParam(msr->prm,"bDoublePos",0,&msr->param.bDoublePos,sizeof(int),"dp",
		"input/output double precision positions (standard format only) = -dp");
    msr->param.dRedTo = 0.0;	
    prmAddParam(msr->prm,"dRedTo",2,&msr->param.dRedTo,sizeof(double),"zto",
		"specifies final redshift for the simulation");
    msr->param.nGrowMass = 0;
    prmAddParam(msr->prm,"nGrowMass",1,&msr->param.nGrowMass,sizeof(int),
		"gmn","<number of particles to increase mass> = 0");
    msr->param.dGrowDeltaM = 0.0;
    prmAddParam(msr->prm,"dGrowDeltaM",2,&msr->param.dGrowDeltaM,
		sizeof(double),"gmdm","<Total growth in mass/particle> = 0.0");
    msr->param.dGrowStartT = 0.0;
    prmAddParam(msr->prm,"dGrowStartT",2,&msr->param.dGrowStartT,
		sizeof(double),"gmst","<Start time for growing mass> = 0.0");
    msr->param.dGrowEndT = 1.0;
    prmAddParam(msr->prm,"dGrowEndT",2,&msr->param.dGrowEndT,
		sizeof(double),"gmet","<End time for growing mass> = 1.0");
    msr->param.dFracNoTreeSqueeze = 0.005;
    prmAddParam(msr->prm,"dFracNoTreeSqueeze",2,&msr->param.dFracNoTreeSqueeze,
		sizeof(double),"fnts",
		"<Fraction of Active Particles for no Tree Squeeze> = 0.005");
    msr->param.dFracNoDomainDecomp = 0.002;
    prmAddParam(msr->prm,"dFracNoDomainDecomp",2,&msr->param.dFracNoDomainDecomp,
		sizeof(double),"fndd",
		"<Fraction of Active Particles for no new DD> = 0.002");
    msr->param.dFracNoDomainDimChoice = 0.1;
    prmAddParam(msr->prm,"dFracNoDomainDimChoice",2,&msr->param.dFracNoDomainDimChoice,
		sizeof(double),"fnddc",
		"<Fraction of Active Particles for no new DD dimension choice> = 0.1");
    msr->param.bDoGravity = 1;
    prmAddParam(msr->prm,"bDoGravity",0,&msr->param.bDoGravity,sizeof(int),"g",
		"enable/disable interparticle gravity = +g");
    msr->param.bRungDD = 0;
    prmAddParam(msr->prm,"bRungDomainDecomp",0,&msr->param.bRungDD,sizeof(int),
		"RungDD","<Rung Domain Decomp> = 0");
    msr->param.dRungDDWeight = 1.0;
    prmAddParam(msr->prm,"dRungDDWeight",2,&msr->param.dRungDDWeight,sizeof(int),
		"RungDDWeight","<Rung Domain Decomp Weight> = 1.0");
#ifdef HERMITE
    msr->param.bHermite = 0;
    prmAddParam(msr->prm,"bHermite",0,&msr->param.bHermite,
		sizeof(int),"hrm","<Hermite integratot>");
    msr->param.bAarsethStep = 0;
    prmAddParam(msr->prm,"bAarsethStep",0,&msr->param.bAarsethStep,sizeof(int),
				"aas","<Aarseth timestepping>");
#endif
    msr->param.iWallRunTime = 0;
    prmAddParam(msr->prm,"iWallRunTime",1,&msr->param.iWallRunTime,
		sizeof(int),"wall",
		"<Maximum Wallclock time (in minutes) to run> = 0 = infinite");
    msr->param.bAntiGrav = 0;
    prmAddParam(msr->prm,"bAntiGrav",0,&msr->param.bAntiGrav,sizeof(int),"antigrav",
		"reverse gravity making it repulsive = -antigrav");
    msr->param.nFindGroups = 0;
    prmAddParam(msr->prm,"nFindGroups",1,&msr->param.nFindGroups,sizeof(int),
		"nFindGroups","<number of iterative FOFs> = 0");
    msr->param.nMinMembers = 16;
    prmAddParam(msr->prm,"nMinMembers",1,&msr->param.nMinMembers,sizeof(int),
		"nMinMembers","<minimum number of group members> = 16");
    msr->param.dTau = 0.164;
    prmAddParam(msr->prm,"dTau",2,&msr->param.dTau,sizeof(double),"dTau",
		"<linking lenght for first FOF in units of mean particle separation> = 0.164");
    msr->param.bTauAbs = 0;
    prmAddParam(msr->prm,"bTauAbs",0,&msr->param.bTauAbs,sizeof(int),"bTauAbs",
		"<if 1 use simulation units for dTau, not mean particle separation> = 0");
    msr->param.nBins = 0;
    prmAddParam(msr->prm,"nBins",1,&msr->param.nBins,sizeof(int),"nBins",
		"<number of bin in profiles, no profiles if 0 or negative> = 0");
    msr->param.bUsePotmin = 0;
    prmAddParam(msr->prm,"bUsePotmin",0,&msr->param.bUsePotmin,sizeof(int),"bUsePotmin",
		"<if 1 use minima of pot. instead of com for fist FOF level profiles> = 0");
    msr->param.nMinProfile = 2000;
    prmAddParam(msr->prm,"nMinProfile",1,&msr->param.nMinProfile,sizeof(int),"nMinProfile",
		"<minimum number of particles in a group to make a profile> = 2000");
    msr->param.fBinsRescale = 1.0;
    prmAddParam(msr->prm,"fBinsRescale",2,&msr->param.fBinsRescale,sizeof(double),"fBinsRescale",
		"<if bigger than one, nMinProfile gets smaller in recursive fofs> = 1.0");
    msr->param.fContrast = 10.0;
    prmAddParam(msr->prm,"fContrast",2,&msr->param.fContrast,sizeof(double),"fContrast",
		"<the density contrast used for recursive fofs> = 10.0");
    msr->param.Delta = 200.0;
    prmAddParam(msr->prm,"Delta",2,&msr->param.Delta,sizeof(double),"Delta",
		"<the density contrast whitin the virial radius over simulation unit density> = 200.0");
    msr->param.binFactor = 3.0;
    prmAddParam(msr->prm,"binFactor",2,&msr->param.binFactor,sizeof(double),"binFactor",
		"<ratio of largest spherical bin to fof determined group radius> = 3.0");
    msr->param.bLogBins = 0;
    prmAddParam(msr->prm,"bLogBins",0,&msr->param.bLogBins,
		sizeof(int),"bLogBins","use logaritmic bins instead of linear = -bLogBins");
#ifdef RELAXATION
    msr->param.bTraceRelaxation = 0;
    prmAddParam(msr->prm,"bTraceRelaxation",0,&msr->param.bTraceRelaxation,sizeof(int),
		"rtrace","<enable/disable relaxation tracing> = -rtrace");
#endif /* RELAXATION */

#ifdef PLANETS 
    /* itype 0: 0 or 1, 1: int, 2: double, 3: char, 4: long int */ 
    msr->param.bCollision = 0;
	prmAddParam(msr->prm,"bCollision",0,&msr->param.bCollision,
		    sizeof(int),"bCollision","<Collisions>");
    msr->param.bHeliocentric = 0;
	prmAddParam(msr->prm,"bHeliocentric",0,&msr->param.bHeliocentric,
		    sizeof(int),"bHeliocentric","use/don't use Heliocentric coordinates = -hc");  
    msr->param.dCentMass = 1.0;
    // dCentMass is unused now 
    prmAddParam(msr->prm,"dCentMass",2,&msr->param.dCentMass,sizeof(double),
		"dCentMass","specifies the central mass for Keplerian orbits");
    msr->param.iGravDirect = 0;
	prmAddParam(msr->prm,"iGravDirect",1,&msr->param.iGravDirect,
		    sizeof(int),"iGravDirect"," Direct NN Gravity calculation");
    msr->param.bBodySupply = 0;
	prmAddParam(msr->prm,"bBodySupply",0,&msr->param.bBodySupply,
		    sizeof(int),"bBodySupply","Body supply boundary condition");
    msr->param.dain = 1.0;
	prmAddParam(msr->prm,"dain",2,&msr->param.dain,
		    sizeof(double),"dain","Inner semimajor axis");
    msr->param.daout = 2.0;
	prmAddParam(msr->prm,"daout",2,&msr->param.daout,
		    sizeof(double),"daout","Outer semimajor axis");
    msr->param.dRSunc = 0.2;
	prmAddParam(msr->prm,"dRSunc",2,&msr->param.dRSunc,
		    sizeof(double),"dRSunc","Sun's radius for semimajor axis");

#ifdef SYMBA
    msr->param.bSymba = 1;
    prmAddParam(msr->prm,"bSymba",0,&msr->param.bSymba,sizeof(int),
		"bSymba","use Symba integrator");
    msr->param.N0 = 10000;
    prmAddParam(msr->prm,"N0",1,&msr->param.N0,sizeof(int),
		"N0","Initial number of particles");

#endif 

/* collision stuff */
	msr->param.iCollLogOption = 0;
	prmAddParam(msr->prm,"iCollLogOption",1,&msr->param.iCollLogOption,
				sizeof(int),"clog","<Collision log option> = 0");	
	msr->param.CP.iOutcomes = BOUNCE;
	prmAddParam(msr->prm,"iOutcomes",1,&msr->param.CP.iOutcomes,
				sizeof(int),"outcomes","<Allowed collision outcomes> = 0");    
	msr->param.CP.dBounceLimit = 1.0;
	prmAddParam(msr->prm,"dBounceLimit",2,&msr->param.CP.dBounceLimit,
				sizeof(double),"blim","<Bounce limit> = 1.0");
	msr->param.CP.iBounceOption = ConstEps;
	prmAddParam(msr->prm,"iBounceOption",1,&msr->param.CP.iBounceOption,
				sizeof(int),"bopt","<Bounce option> = 0");
	msr->param.CP.dEpsN = 1.0;
	prmAddParam(msr->prm,"dEpsN",2,&msr->param.CP.dEpsN,
				sizeof(double),"epsn","<Coefficient of restitution> = 1");
	msr->param.CP.dEpsT = 1.0;
	prmAddParam(msr->prm,"dEpsT",2,&msr->param.CP.dEpsT,
				sizeof(double),"epst","<Coefficient of surface friction> = 1");
	msr->param.CP.dDensity = 0.0;
	prmAddParam(msr->prm,"dDensity",2,&msr->param.CP.dDensity,
				sizeof(double),"density","<Merged particle density> = 0");
	msr->param.CP.bFixCollapse = 0;
	prmAddParam(msr->prm,"bFixCollapse",0,&msr->param.CP.bFixCollapse,
				sizeof(int),"overlap","enable/disable overlap fix = -overlap");

	/* gas disk stuff */
	msr->param.GP.iGasModel = 1;
	prmAddParam(msr->prm,"iGasModel",1,&msr->param.GP.iGasModel,sizeof(int),
		    "iGasModel","1: uniform 2: inside-out 3: Stepinski");	
	msr->param.GP.dTau_diss = 0.0;
	prmAddParam(msr->prm,"dTau_diss",2,&msr->param.GP.dTau_diss,sizeof(double),
		    "dTau_diss"," gas disspation time in yr");	
	msr->param.GP.dGasp = 1.0;
	prmAddParam(msr->prm,"dGasp",2,&msr->param.GP.dGasp,sizeof(double),
		    "dGasp","power for gas surface density");	
	msr->param.GP.dSigma10 = 0.0;
	prmAddParam(msr->prm,"dSigma10",2,&msr->param.GP.dSigma10,sizeof(double),
		    "dSigma10","initial gas surface density at 1 AU in g/cm^2");
	msr->param.GP.dGasq = 1.0;
	prmAddParam(msr->prm,"dGasq",2,&msr->param.GP.dGasq,sizeof(double),
		    "dGasp","power for gas temperature");	
	msr->param.GP.dTemp1 = 0.0;
	prmAddParam(msr->prm,"dTemp1",2,&msr->param.GP.dTemp1,sizeof(double),
		    "dTemp1","gas temperature (K) at 1 AU");
	msr->param.GP.dalpha = 0.0;
	prmAddParam(msr->prm,"dalpha",2,&msr->param.GP.dalpha,sizeof(double),
		    "dalpha","viscosity parameter for alpha disk models");
	msr->param.GP.dS0 = 1.0;
	prmAddParam(msr->prm,"dS0",2,&msr->param.GP.dS0,sizeof(double),
		    "dS0","initial radius of outer edge of Stepinski's disk in AU");	
	msr->param.GP.dMd0 = 0.0;
	prmAddParam(msr->prm,"dMd0",2,&msr->param.GP.dMd0,sizeof(double),
		    "dMd0","initial mass of Stepinski's disk in solar mass");
	msr->param.GP.bWind = 1;
	prmAddParam(msr->prm,"bWind",0,&msr->param.GP.bWind,sizeof(int),
		    "bWind","Rapid dispersal for Stepinski's disk");
	msr->param.GP.bDragEnhance = 0;
	prmAddParam(msr->prm,"bDragEnhance",0,&msr->param.GP.bDragEnhance,sizeof(int),
		    "bDragEnhance","gas drag force is enhanced");
	msr->param.GP.iTypeI = 1;
	prmAddParam(msr->prm,"iTypeI",1,&msr->param.GP.iTypeI,sizeof(int),
		    "iTypeI","TypeI migration");
	msr->param.GP.fTI = 1.0;
	prmAddParam(msr->prm,"fTI",2,&msr->param.GP.fTI,sizeof(double),
		    "fTI","Factor for TypeI migration rate");
	msr->param.GP.rcon = 1.0;
	prmAddParam(msr->prm,"rcon",2,&msr->param.GP.rcon,sizeof(double),
		    "rcon","Converging radius");
	msr->param.GP.iGasTable = 1;
	prmAddParam(msr->prm,"iGasTable",1,&msr->param.GP.iGasTable,sizeof(int),
		    "iGasTable","Table for calculation of global disk potential");
	msr->param.GP.dkappa = 0.01;
	prmAddParam(msr->prm,"dkappa",2,&msr->param.GP.dkappa,sizeof(double),
		    "dkappa","Atmospheric opacity");

	
        /* hy stuff */
	msr->param.HY.fMt0 = 1.E-8;
	prmAddParam(msr->prm,"fMt0",2,&msr->param.HY.fMt0,sizeof(double),
		    "fMt0","minimum mass of a sub-embryo");
	msr->param.HY.fff = 100.0;
	prmAddParam(msr->prm,"fff",2,&msr->param.HY.fff,sizeof(double),
		    "fff","mass factor for a full");	
	msr->param.HY.ffdr = 1.0;
	prmAddParam(msr->prm,"ffdr",2,&msr->param.HY.ffdr,sizeof(double),
		    "ffdr","factor for radial grid width");
	msr->param.HY.fdtheta = 0.5;
	prmAddParam(msr->prm,"fdtheta",2,&msr->param.HY.fdtheta,sizeof(double),
		    "fdtheta","azimuthal grid width in pi");
	msr->param.HY.iTRGRAV = 1;
	prmAddParam(msr->prm,"iTRGRAV",1,&msr->param.HY.iTRGRAV,sizeof(int),
		    "iTRGRAV","Gravity of tracers");
	msr->param.HY.fDt = 30.0;
	prmAddParam(msr->prm,"fDt",2,&msr->param.HY.fDt,sizeof(double),
		    "fDt","timestep for statistical routine in orbital timestep");
	
	msr->param.HY.iPebbleSupply = 0;
	prmAddParam(msr->prm,"iPebbleSupply",1,&msr->param.HY.iPebbleSupply,sizeof(int),
		    "iPebbleSupply","Pebble Supply at dout?");
	msr->param.HY.dM_peb = 0.0;
	prmAddParam(msr->prm,"dM_peb",2,&msr->param.HY.dM_peb,sizeof(double),
		    "dM_peb","Total mass of supplied pebbles");
	msr->param.HY.dTau_peb = 1000000.0;
	prmAddParam(msr->prm,"dTau_peb",2,&msr->param.HY.dTau_peb,sizeof(double),
		    "dTau_peb","Decay time of pebble supply");
	msr->param.HY.dMr_peb = 0.0999;
	prmAddParam(msr->prm,"dMr_peb",2,&msr->param.HY.dMr_peb,sizeof(double),
		    "dMr_peb","Mass of a pebble tracer relative to dMt0");
	msr->param.HY.dSt_min = 0.0;
	prmAddParam(msr->prm,"dSt_min",2,&msr->param.HY.dSt_min,sizeof(double),
		    "dSt_min","Minimum Stokes number");
	msr->param.HY.iPbGrow = 0;
	prmAddParam(msr->prm,"iPbGrow",1,&msr->param.HY.iPbGrow,
		    sizeof(int),"iPbGrow","Pebble growth option");	
	msr->param.HY.iPlForm = 0;
	prmAddParam(msr->prm,"iPlForm",1,&msr->param.HY.iPlForm,
		    sizeof(int),"iPlForm","Planetesimal formation from pebbles");
	msr->param.HY.iGasAcc2Planet = 0;
	prmAddParam(msr->prm,"iGasAcc2Planet",1,&msr->param.HY.iGasAcc2Planet,
		    sizeof(int),"iGasAcc2Planet","Gas accretion to planet");
	
	msr->param.HY.dapin = 4.0;
        prmAddParam(msr->prm,"dapin",2,&msr->param.HY.dapin,
		    sizeof(double),"dapin","Inner radius of planetesimal formation zone");
	msr->param.HY.dzmet = 0.01;
        prmAddParam(msr->prm,"dzmet",2,&msr->param.HY.dzmet,
		    sizeof(double),"dzmet","Initial Metallicity");
	msr->param.HY.dmpl = 1.e-10;
	prmAddParam(msr->prm,"dmpl",2,&msr->param.HY.dmpl,
		    sizeof(double),"dmpl","Planetesimal mass");	
	msr->param.HY.dcpl = 100.0;
	prmAddParam(msr->prm,"dcpl",2,&msr->param.HY.dcpl,
		    sizeof(double),"dcpl","Planetesimal formation time scale normalized by h/vr");
	msr->param.HY.dtau_em = 0.0;
	prmAddParam(msr->prm,"dtau_em",2,&msr->param.HY.dtau_em,
		    sizeof(double),"dtau_em","Embryo formation time scale in yr");	
	msr->param.HY.ded = 0.5;
	prmAddParam(msr->prm,"ded",2,&msr->param.HY.ded,
		    sizeof(double),"ded","Dust sticking efficiency");
	
#endif /* PLANETS */
	
/*
** Set the box center to (0,0,0) for now!
*/
    for (j=0;j<3;++j) msr->fCenter[j] = 0.0;
    /*
    ** Define any "LOCAL" parameters (LCL)
    */
    msr->lcl.pszDataPath = getenv("PTOOLS_DATA_PATH");
    /*
    ** Process command line arguments. 
    ** (actual parameters read from the param file are set here)
    */ 
    ret = prmArgProc(msr->prm,argc,argv);
    if (!ret) {
	_msrExit(msr,1);
	}

    if (nDigits < 1 || nDigits > 11) {
	(void) fprintf(stderr,"Unreasonable number of filename digits.\n");
	_msrExit(msr,1);
	}

    (void) sprintf(msr->param.achDigitMask,"%%s.%%0%i"PRIu64,nDigits);
    /*
    ** Make sure that we have some setting for nReplicas if bPeriodic is set.
    */
    if (msr->param.bPeriodic && !prmSpecified(msr->prm,"nReplicas")) {
	msr->param.nReplicas = 1;
	}
    /*
    ** Warn that we have a setting for nReplicas if bPeriodic NOT set.
    */
    if (!msr->param.bPeriodic && msr->param.nReplicas != 0) {
	printf("WARNING: nReplicas set to non-zero value for non-periodic!\n");
	}

    if (!msr->param.achInFile[0]) {
	puts("ERROR: no input file specified");
	_msrExit(msr,1);
	}

    if (msr->param.dTheta <= 0) {
	if (msr->param.dTheta == 0 && msr->param.bVWarnings)
	    fprintf(stderr,"WARNING: Zero opening angle may cause numerical problems\n");
	else if (msr->param.dTheta < 0) {
	    fprintf(stderr,"ERROR: Opening angle must be non-negative\n");
	    _msrExit(msr,1);
	    }
	}
   
    msr->nThreads = mdlThreads(mdl);
	
    /*
    ** Always set bCannonical = 1 if bComove == 0
    */
    if (!msr->param.csm->bComove) {
	if (!msr->param.bCannonical)
	    printf("WARNING: bCannonical reset to 1 for non-comoving (bComove == 0)\n");
	msr->param.bCannonical = 1;
	} 
    /* 
     * Softening 
     */
	
    if (msr->param.bPhysicalSoft || msr->param.bVariableSoft) {
	if (msr->param.bPhysicalSoft && !msrComove(msr)) {
	    printf("WARNING: bPhysicalSoft reset to 0 for non-comoving (bComove == 0)\n");
	    msr->param.bPhysicalSoft = 0;
	    }
#ifndef CHANGESOFT
	fprintf(stderr,"ERROR: You must compile with -DCHANGESOFT to use changing softening options\n");
	_msrExit(msr,1);
#endif
	if (msr->param.bVariableSoft && !prmSpecified(msr->prm,"bDoSoftOutput")) msr->param.bDoSoftOutput=1;
  
	if (msr->param.bPhysicalSoft && msr->param.bVariableSoft) {
	    fprintf(stderr,"ERROR: You may only choose one of Physical or Variable softening\n");
	    _msrExit(msr,1);
	    }
	}
    /*
    ** Determine the period of the box that we are using.
    ** Set the new d[xyz]Period parameters which are now used instead
    ** of a single dPeriod, but we still want to have compatibility
    ** with the old method of setting dPeriod.
    */
    if (prmSpecified(msr->prm,"dPeriod") && 
	!prmSpecified(msr->prm,"dxPeriod")) {
	msr->param.dxPeriod = msr->param.dPeriod;
	}
    if (prmSpecified(msr->prm,"dPeriod") && 
	!prmSpecified(msr->prm,"dyPeriod")) {
	msr->param.dyPeriod = msr->param.dPeriod;
	}
    if (prmSpecified(msr->prm,"dPeriod") && 
	!prmSpecified(msr->prm,"dzPeriod")) {
	msr->param.dzPeriod = msr->param.dPeriod;
	}
    /*
    ** Periodic boundary conditions can be disabled along any of the
    ** x,y,z axes by specifying a period of zero for the given axis.
    ** Internally, the period is set to infinity (Cf. pkdBucketWalk()
    ** and pkdDrift(); also the INTERSECT() macro in smooth.h).
    */
    if (msr->param.dPeriod  == 0) msr->param.dPeriod  = FLOAT_MAXVAL;
    if (msr->param.dxPeriod == 0) msr->param.dxPeriod = FLOAT_MAXVAL;
    if (msr->param.dyPeriod == 0) msr->param.dyPeriod = FLOAT_MAXVAL;
    if (msr->param.dzPeriod == 0) msr->param.dzPeriod = FLOAT_MAXVAL;
    /*
    ** Determine opening type.
    */

    msr->dCrit = msr->param.dTheta;
    if (!prmSpecified(msr->prm,"dTheta2")) 
	msr->param.dTheta2 = msr->param.dTheta;
    /*
    ** Initialize comove variables.
    */
    msr->nMaxOuts = 100;
    msr->pdOutTime = malloc(msr->nMaxOuts*sizeof(double));
    assert(msr->pdOutTime != NULL);
    msr->nOuts = 0;

    /*
    ** Check timestepping.
    */

    if (msr->param.iMaxRung < 1) {
	msr->param.iMaxRung = 1;
	if (msr->param.bVWarnings)
	    (void) fprintf(stderr,"WARNING: iMaxRung set to 1\n");
	}

    if (msr->param.bGravStep && !msr->param.bDoGravity) {
	puts("ERROR: need gravity to use gravity stepping...");
	_msrExit(msr,1);
	}
    if (msr->param.bEpsAccStep || msr->param.bSqrtPhiStep) {
	msr->param.bAccelStep = 1;
	}
    if (msr->param.bGravStep) {
	msr->param.bEpsAccStep = 0;   /* we must do this because the meaning of Eta is different */
	}
   

    pstInitialize(&msr->pst,msr->mdl,&msr->lcl);
  
    pstAddServices(msr->pst,msr->mdl);
    /*
    ** Create the processor subset tree.
    */
    for (id=1;id<msr->nThreads;++id) {
	if (msr->param.bVDetails) printf("Adding %d to the pst\n",id);
	inAdd.id = id;
	pstSetAdd(msr->pst,&inAdd,sizeof(inAdd),NULL,NULL);
	}
    if (msr->param.bVDetails) printf("\n");
    /*
    ** Levelize the PST.
    */
    inLvl.iLvl = 0;
    pstLevelize(msr->pst,&inLvl,sizeof(inLvl),NULL,NULL);
    /*
    ** Create the processor mapping array for the one-node output
    ** routines.
    */
    msr->pMap = malloc(msr->nThreads*sizeof(int));
    assert(msr->pMap != NULL);
    inGM.nStart = 0;
    pstGetMap(msr->pst,&inGM,sizeof(inGM),msr->pMap,NULL);
    msr->iCurrMaxRung = 0;
    /*
    ** Mark the Domain Decompositon as not done
    */
    msr->bDoneDomainDecomp = 0;
    msr->iLastRungDD = -1;
    msr->iLastRungSD = -1;
    msr->nRung = (int *) malloc( (msr->param.iMaxRung+1)*sizeof(int) );
    assert(msr->nRung != NULL);
    for (i=0;i<=msr->param.iMaxRung;++i) msr->nRung[i] = 0;

    msr->iRungVeryActive = msr->param.iMaxRung; /* No very active particles */
    msr->bSavePending = 0;                      /* There is no pending save */


#ifdef PLANETS
    if(msr->param.bCollision){
	  if(!(msr->param.iCollLogOption & (COLL_LOG_VERBOSE | COLL_LOG_TERSE))){
	       puts("ERROR: Invalid collision log option");
		_msrExit(msr,1);
	  }
	  
	  if(msr->param.iCollLogOption & COLL_LOG_VERBOSE){
	    (void) strcpy(msr->param.achCollLog,COLL_LOG_TXT);
	    if (msr->param.bVStart)
	      printf("Collision log: \"%s\"\n",msr->param.achCollLog);
	  }

	  if(msr->param.iCollLogOption & COLL_LOG_TERSE	){	  
	    (void) strcpy(msr->param.achCollLog2,COLL_LOG_BIN);
	    if (msr->param.bVStart)
	      printf("Collision log: \"%s\"\n",msr->param.achCollLog2);
	  }

	  /*	COLLISION_PARAMS *CP = &msr->param.CP;*/
		if (!(msr->param.CP.iOutcomes & (MERGE | BOUNCE | FRAG))) {
			puts("ERROR: must specify one of MERGE/BOUNCE/FRAG");
			_msrExit(msr,1);
			}
    }

	  msr->dEcoll = 0.0;
	  msr->dEgas = 0.0;

	  if(msr->param.iGravDirect==2){
	    assert(msr->nThreads == 1);
	  }

	/*062513  In PBHYB
	  fMt0: The transition mass from a tracer to a subembryo
	  fMt0*fff: The transition mass from a subembryo to a fullembryo
	  fh1: the reduced hill radius for a minimum full embryo
	  fff = 100.0 is recommended by L12
	*/

#ifdef sm2d
	  if(msr->param.iGravDirect >= 3){ /* fh1 used in potential calculation*/
	  msr->param.HY.fh0 = cbrt(msr->param.HY.fMt0/3.0);
 	  msr->param.HY.fh1 = cbrt(msr->param.HY.fMt0*msr->param.HY.fff/3.0);
	  msr->param.HY.fdtheta *= M_PI;

	  // radial grid width should not be too small 
	  assert(msr->param.HY.ffdr > msr->param.HY.fh0/msr->param.HY.fh1);

	  printf("Reduced hill of fullembryo %g and subembryo %g \n",msr->param.HY.fh1,msr->param.HY.fh0);

	  msr->dDstir = msr->param.HY.fDt*msrDelta(msr);
	}
#endif


	  GASDISK_PARAMS *GP = &msr->param.GP;
	  double s0 = GP->dS0; 
	  double alpha = GP->dalpha;
	  
	  if(msr->param.HY.iPebbleSupply >= 1){//011317 added
	    double dapin = msr->param.HY.dapin;
	    double dzmet = msr->param.HY.dzmet;
	    double dGasp = GP->dGasp;
	    double dGasq = GP->dGasq;
	    double dSigma10 = GP->dSigma10*fsig;
	    double Temp1 = msr->param.GP.dTemp1;
	    double St_min = msr->param.HY.dSt_min;
	    double h2,t_drift;	 
	    double ed = msr->param.HY.ded; //sticking efficiency test

	    
	    //dSigma10 = 0.1*dSigma10; //test 022117
	    
	    // total pebble mass beyond dapin 
	    msr->param.HY.dM_peb = 2.0*M_PI*dzmet*dSigma10*(pow(s0,2.0-dGasp)-pow(dapin,2.0-dGasp))/(2.0-dGasp);
	    // pebble decay time at 1 AU
	    msr->param.HY.dTau_peb = 40.0/sqrt(3.0)/dzmet/ed/(2.0*M_PI);

	    if(msr->param.HY.iPebbleSupply == 2){// for test outputs
	      msr->param.HY.dM_peb = 3.00374E-4; // 100 m_earth
	      msr->param.HY.dTau_peb = 1.e6;
	    }
	    
	    // msr->param.HY.dTau_peb = 40.0/sqrt(3.0)/dzmet*pow(s0,1.5)/(2.0*M_PI);
	    
	    h2 = 0.033560233*0.033560233*(Temp1/280.0); // square of scale height at 1 AU
	    
	    // t_drift = s0/(0.5*(dGasp+1.5+0.5*dGasq)*h2*pow(s0,-0.5*dGasq))/(2.0*M_PI);	    
	    // drift time at 1 AU; not necessary now  
	    t_drift = 1.0/(0.5*(dGasp+1.5+0.5*dGasq)*h2)/(2.0*M_PI);
	    t_drift *= 0.5*(1.0 + St_min*St_min)/St_min;
	    // if(t_drift > msr->param.HY.dTau_peb)msr->param.HY.dTau_peb = t_drift;
	    	    
	    printf("Total pebble mass %g (m_sun), Pebble decay time 1AU and disk edge (yr) %g %g, t_drift %g \n",msr->param.HY.dM_peb,msr->param.HY.dTau_peb,msr->param.HY.dTau_peb*s0*sqrt(s0),t_drift);	    
	  }
	  
	  if(GP->iGasModel==0) GP->dTau_diss = 0.0;
	 	
	  if(GP->iGasModel == 3){/* stepinski's disk*/	    
	     double md0 = GP->dMd0;	   
	     double alj1, alj2, jd;
	     double s45,s34,s23,s12;
	     double t5,t4,t3,t2,t1,t45,t34,t23,t12;

	     printf("Stepinski's disk model chosen \n");

	     jd = sqrt(s0/0.021)*md0;
	     GP->jd = jd;
	     printf("Disk angumar momentum %g 10^52 g cm^2 s^-1\n",jd);
	     alj1 = pow(alpha*jd*jd,2.0/13.0);
	     alj2 = pow(alpha,-12.0/13.0)*pow(jd,2.0/13.0);
	    
	     s45 = 8.62*alj1;
	     s34 = 21.57*alj1;
	     s23 = 27.31*alj1;
	     /*  s12 = 50.45*alj1; this is the one in the Stepinski's paper, but probably incorrect */
	     s12 = 44.48*pow(alpha*alpha*jd*jd*jd*jd*jd/tauc,2.0/31.0);
	     printf("scaling radii s45 %g, s34 %g, s23 %g, s12 %g \n",s45,s34,s23,s12);

	     if(s0 < s45){
	       GP->inepo = 5;
	       t5 = 0.39*pow(alpha,-18.0/17.0)*pow(jd,28.0/17.0)*pow(md0,-30.0/17.0);
	       t45 = t5*(pow(s45/s0,15.0/17.0)-1.0);
	       t4 = 35.44*alj2;
	       t34 = t45 + 5.079053818505533*t4; 
	       t3 = 172.0*alj2;
	       t23 = t34 + 0.7762167454255013*t3;
	       t2 = 170.0*alj2;
	       t12 = t23 + (pow(s12/s23,43.0/10.0)-1.0)*t2; 
	       t1 = 1.34E4*alj2;
	     }else if(s0 >= s45 && s0 < s34){
	       GP->inepo = 4;
	       t4 = 2.55E-4*pow(alpha,-38.0/31.0)*pow(jd,108.0/31.0)*pow(md0,-122.0/31.0);
	       t34 = t4*(pow(s34/s0,61.0/31.0)-1.0); 
	       t3 = 172.0*alj2;
	       t23 = t34 + 0.7762167454255013*t3;
	       t2 = 170.0*alj2;
	       t12 = t23 + (pow(s12/s23,43.0/10.0)-1.0)*t2; 
	       t1 = 1.34E4*alj2;
	     }else if(s0 >= s34 && s0 < s23){
	       GP->inepo = 3;
	       t3 = 8.0E-6*pow(alpha,-109.0/84.0)*pow(jd,265.0/62.0)*pow(md0,-112.0/23.0);
	       t23 = t3*(pow(s23/s0,56.0/23.0)-1.0);
	       t2 = 170.0*alj2;
	       t12 = t23 + (pow(s12/s23,43.0/10.0)-1.0)*t2; 
	       t1 = 1.34E4*alj2;
	     }else if(s0 >= s23 && s0 < s12){
	       GP->inepo = 2;
	       t2 = 7.17E-12*pow(alpha,-103.0/65.0)*pow(jd,483.0/65.0)*pow(md0,-86.0/10.0);
	       t12 = t2*(pow(s12/s0,43.0/10.0)-1.0);
	       t1 = 1.34E4*alj2;
	     }else if(s0 >= s12){	       
	       GP->inepo = 1;
	       t1 = 26.55*pow(alpha,-68.0/65.0)*pow(jd,98.0/65.0)*pow(md0,-8.0/5.0);
	     }

	     printf("Initial epoch is %d \n",GP->inepo);
	     	   	   
	     GP->f = pow(alpha,-2.0/39.0)*pow(jd,2.0/65.0)*pow(tauc,-2.0/15.0);

	     GP->sij[0] = s12;
	     GP->sij[1] = s23; 
	     GP->sij[2] = s34;
	     GP->sij[3] = s45;
	     GP->tij[0] = t12;
	     GP->tij[1] = t23; 
	     GP->tij[2] = t34;
	     GP->tij[3] = t45;	     
	     GP->ti[0] = t1;
	     GP->ti[1] = t2; 
	     GP->ti[2] = t3;
	     GP->ti[3] = t4;
	     GP->ti[4] = t5;

	     if(GP->bWind){
	       double Sigma_cr = 300.0;
	       double t_l, t_h, t_m, Sigma;
	       STEPINSKI *ST, ST0;

	       t_l = 0.0;
	       t_h = 1.E8;   
	       ST = &ST0;

	       msrGetStepinski(msr, GP, t_l, ST, 0);
	       GetSigma(GP, ST, t_l, 0.1, ST->rij, &Sigma);
	       assert(Sigma > Sigma_cr);
	       
	       msrGetStepinski(msr, GP, t_h, ST, 0);
	       GetSigma(GP, ST, t_h, 0.1, ST->rij, &Sigma);
	       assert(Sigma < Sigma_cr);

	       for(i = 1; i <= 200; i++){
		 t_m =  (t_l+t_h)/2.0;
		msrGetStepinski(msr,GP, t_m, ST, 0);
		GetSigma(GP, ST, t_m, 0.1, ST->rij, &Sigma); 
		 /*printf("t_m= %g, Sigma = %g, rout = %g \n",t_m,Sigma,DS->rout);*/
		 if(Sigma > Sigma_cr){
		   t_l = t_m;
		 }else{
		   t_h = t_m;
		 }  
		 if(fabs((t_h-t_l)) < 1.E-3) break;
	       }
	       GP->t_trans = t_m;
	       GP->s_trans = ST->rout;
	       printf("s_trans = %g, t_trans = %g \n",GP->s_trans, GP->t_trans);
	     }
	     

	  } /* end Stepinski's model */

#ifdef gastable
	  /* GasTable option is available for single power-law disk in this version */
	  if(GP->iGasTable ==1) assert(GP->iGasModel == 1);
	  if(GP->iGasTable ==2) assert(GP->iGasModel == 2);
#endif

#ifdef SYMBA
	  msr->param.bHeliocentric = 0;
#endif 	
#endif /* PLANETS */


    }

void msrLogParams(MSR msr,FILE *fp)
    {
    double z;
    int i;

#ifdef __DATE__
#ifdef __TIME__
    fprintf(fp,"# Compiled: %s %s\n",__DATE__,__TIME__);
#endif
#endif
    fprintf(fp,"# Preprocessor macros:");
#ifdef CHANGESOFT
    fprintf(fp," CHANGESOFT");
#endif
#ifdef DEBUG
    fprintf(fp," DEBUG");
#endif
#ifdef RELAXATION
    fprintf(fp,"RELAXATION");
#endif
#ifdef _REENTRANT
    fprintf(fp," _REENTRANT");
#endif
#if defined(MAXHOSTNAMELEN) && defined(HAVE_GETHOSTNAME)
	{
	char hostname[MAXHOSTNAMELEN];
	fprintf(fp,"\n# Master host: ");
	if (gethostname(hostname,MAXHOSTNAMELEN))
	    fprintf(fp,"unknown");
	else
	    fprintf(fp,"%s",hostname);
	}
#endif
	fprintf(fp,"\n# N: %d",msr->N);
	fprintf(fp," nThreads: %d",msr->param.nThreads);
	fprintf(fp," bDiag: %d",msr->param.bDiag);
	fprintf(fp," Verbosity flags: (%d,%d,%d,%d,%d)",msr->param.bVWarnings,
		msr->param.bVStart,msr->param.bVStep,msr->param.bVRungStat,
		msr->param.bVDetails);
	fprintf(fp,"\n# bPeriodic: %d",msr->param.bPeriodic);
	fprintf(fp," bComove: %d",msr->param.csm->bComove);
	fprintf(fp,"\n# bParaRead: %d",msr->param.bParaRead);
	fprintf(fp," bParaWrite: %d",msr->param.bParaWrite);
	fprintf(fp," bCannonical: %d",msr->param.bCannonical);
	fprintf(fp," bStandard: %d",msr->param.bStandard);
	fprintf(fp," bHDF5: %d",msr->param.bHDF5);
	fprintf(fp," nBucket: %d",msr->param.nBucket);
	fprintf(fp," iOutInterval: %d",msr->param.iOutInterval);
	fprintf(fp," iCheckInterval: %d",msr->param.iCheckInterval);
	fprintf(fp," iLogInterval: %d",msr->param.iLogInterval);
	fprintf(fp," iEwOrder: %d",msr->param.iEwOrder);
	fprintf(fp," nReplicas: %d",msr->param.nReplicas);
	fprintf(fp,"\n# dEwCut: %f",msr->param.dEwCut);
	fprintf(fp," dEwhCut: %f",msr->param.dEwhCut);
	fprintf(fp,"\n# iStartStep: %"PRIu64,msr->param.iStartStep);
	fprintf(fp," nSteps: %"PRIu64,msr->param.nSteps);
	fprintf(fp," nSmooth: %d",msr->param.nSmooth);
	fprintf(fp," dExtraStore: %f",msr->param.dExtraStore);
	if (prmSpecified(msr->prm,"dSoft"))
	    fprintf(fp," dSoft: %g",msr->param.dSoft);
	else
	    fprintf(fp," dSoft: input");
	fprintf(fp,"\n# bPhysicalSoft: %d",msr->param.bPhysicalSoft);
	fprintf(fp," bVariableSoft: %d",msr->param.bVariableSoft);
	fprintf(fp," nSoftNbr: %d",msr->param.nSoftNbr);
	fprintf(fp," bSoftByType: %d",msr->param.bSoftByType);
	fprintf(fp," bSoftMaxMul: %d",msr->param.bSoftMaxMul);
	fprintf(fp," dSoftMax: %g",msr->param.dSoftMax);
	fprintf(fp," bDoSoftOutput: %d",msr->param.bDoSoftOutput);
	fprintf(fp,"\n# dDelta: %g",msr->param.dDelta);
	fprintf(fp," dEta: %g",msr->param.dEta);
	fprintf(fp," iMaxRung: %d",msr->param.iMaxRung);
	fprintf(fp," nRungVeryActive: %d",msr->param.nRungVeryActive);
	fprintf(fp," bDoRungOutput: %d",msr->param.bDoRungOutput);
	fprintf(fp,"\n# bGravStep: %d",msr->param.bGravStep);
	fprintf(fp," bEpsAccStep: %d",msr->param.bEpsAccStep);
	fprintf(fp," bSqrtPhiStep: %d",msr->param.bSqrtPhiStep);
	fprintf(fp," bDensityStep: %d",msr->param.bDensityStep);
	fprintf(fp," nTruncateRung: %d",msr->param.nTruncateRung);
	fprintf(fp,"\n# iTimeStepCrit: %d",msr->param.iTimeStepCrit);
	fprintf(fp," nPartRhoLoc: %d", msr->param.nPartRhoLoc);
	fprintf(fp," dPreFacRhoLoc: %g", msr->param.dPreFacRhoLoc);
	fprintf(fp," nPartColl: %d", msr->param.nPartColl);
	fprintf(fp,"\n# bDoGravity: %d",msr->param.bDoGravity);
#ifdef HERMITE
	fprintf(fp," bHermite: %d",msr->param.bHermite);
	fprintf(fp," bAarsethStep: %d",msr->param.bAarsethStep);
#endif
	fprintf(fp,"\n# dFracNoTreeSqueeze: %g",msr->param.dFracNoTreeSqueeze);
	fprintf(fp,"\n# dFracNoDomainDecomp: %g",msr->param.dFracNoDomainDecomp);
	fprintf(fp," dFracNoDomainDimChoice: %g",msr->param.dFracNoDomainDimChoice);
	fprintf(fp," bRungDD: %d",msr->param.bRungDD);
	fprintf(fp," dRungDDWeight: %g ",msr->param.dRungDDWeight);
	fprintf(fp,"\n# nTruncateRung: %d",msr->param.nTruncateRung);
	fprintf(fp,"\n# nGrowMass: %d",msr->param.nGrowMass);
	fprintf(fp," dGrowDeltaM: %g",msr->param.dGrowDeltaM);
	fprintf(fp," dGrowStartT: %g",msr->param.dGrowStartT);
	fprintf(fp," dGrowEndT: %g",msr->param.dGrowEndT);
	fprintf(fp,"\n# Group Find: nFindGroups: %d",msr->param.nFindGroups);
	fprintf(fp," dTau: %g",msr->param.dTau);
	fprintf(fp," bTauAbs: %d",msr->param.bTauAbs);
	fprintf(fp," nMinMembers: %d",msr->param.nMinMembers);	
	fprintf(fp," nBins: %d",msr->param.nBins);
	fprintf(fp," bUsePotmin: %d",msr->param.bUsePotmin);
	fprintf(fp," nMinProfile: %d",msr->param.nMinProfile);
	fprintf(fp," fBinsRescale: %g",msr->param.fBinsRescale);
	fprintf(fp," fContrast: %g",msr->param.fContrast);
	fprintf(fp," Delta: %g",msr->param.Delta);
	fprintf(fp," binFactor: %g",msr->param.binFactor);
	fprintf(fp," bLogBins: %d",msr->param.bLogBins);
#ifdef RELAXATION
	fprintf(fp,"\n# Relaxation estimate: bTraceRelaxation: %d",msr->param.bTraceRelaxation);	
#endif
#ifdef PLANETS
#ifdef SYMBA
	fprintf(fp," bSymba: %d",msr->param.bSymba);
#endif	
	fprintf(fp," bCollision: %d",msr->param.bCollision);
	fprintf(fp," bHeliocentric: %d",msr->param.bHeliocentric);
	fprintf(fp," dCentMass: %g",msr->param.dCentMass);
	fprintf(fp," iGravDirect: %d",msr->param.iGravDirect);

	fprintf(fp,"\n# Collisions...");
	fprintf(fp," iCollLogOption: %d",msr->param.iCollLogOption);
	fprintf(fp,"\n# iOutcomes: %d",msr->param.CP.iOutcomes);   
	fprintf(fp," dBounceLimit: %g",msr->param.CP.dBounceLimit);
	fprintf(fp," dEpsN: %g",msr->param.CP.dEpsN);
	fprintf(fp," dEpsT: %g",msr->param.CP.dEpsT);
	fprintf(fp," dDensity: %g",msr->param.CP.dDensity);
	fprintf(fp,"\n# bFixCollapse: %d",msr->param.CP.bFixCollapse);

	fprintf(fp,"\n# Gasdisk...");
	fprintf(fp,"\n# iGasModel: %d",msr->param.GP.iGasModel);
	fprintf(fp,"\n# dTau_diss: %g",msr->param.GP.dTau_diss);
	fprintf(fp," dGasp: %g",msr->param.GP.dGasp);
	fprintf(fp," dSigma10: %g",msr->param.GP.dSigma10);
	fprintf(fp," dGasq: %g",msr->param.GP.dGasq);
	fprintf(fp," dTemp1: %g",msr->param.GP.dTemp1);
	fprintf(fp,"\n# dalpha: %g",msr->param.GP.dalpha);
	fprintf(fp," dS0: %g",msr->param.GP.dS0);
	fprintf(fp," dMd0: %g",msr->param.GP.dMd0);
	fprintf(fp," bWind: %d",msr->param.GP.bWind);
	fprintf(fp,"\n# bDragEnhance: %d",msr->param.GP.bDragEnhance);
	fprintf(fp,"\n# iTypeI: %d",msr->param.GP.iTypeI);
	fprintf(fp," fTI: %g",msr->param.GP.fTI);
	fprintf(fp,"\n# rcon: %g",msr->param.GP.rcon);
	fprintf(fp,"\n# iGasTable: %d",msr->param.GP.iGasTable);
	fprintf(fp,"\n# dkappa: %g",msr->param.GP.dkappa);
	
	fprintf(fp,"\n# Hybrid...");
	fprintf(fp," fMt0: %g",msr->param.HY.fMt0);
	fprintf(fp," fff: %g",msr->param.HY.fff);
	fprintf(fp," ffdr: %g",msr->param.HY.ffdr);
	fprintf(fp," fdtheta: %g",msr->param.HY.fdtheta);
	fprintf(fp," iTRGRAV: %d",msr->param.HY.iTRGRAV);
	fprintf(fp," fDt: %g",msr->param.HY.fDt);

	fprintf(fp," iPebbleSupply: %d",msr->param.HY.iPebbleSupply);
	fprintf(fp," dM_peb: %g",msr->param.HY.dM_peb);
	fprintf(fp," dTau_peb: %g",msr->param.HY.dTau_peb);
	fprintf(fp," dMr_peb: %g",msr->param.HY.dMr_peb);
	fprintf(fp," dSt_min: %g",msr->param.HY.dSt_min);
	
#endif /* PLANETS */

	fprintf(fp," dTheta: %f",msr->param.dTheta);
	fprintf(fp,"\n# dPeriod: %g",msr->param.dPeriod);
	fprintf(fp," dxPeriod: %g",
		msr->param.dxPeriod >= FLOAT_MAXVAL ? 0 : msr->param.dxPeriod);
	fprintf(fp," dyPeriod: %g",
		msr->param.dyPeriod >= FLOAT_MAXVAL ? 0 : msr->param.dyPeriod);
	fprintf(fp," dzPeriod: %g",
		msr->param.dzPeriod >= FLOAT_MAXVAL ? 0 : msr->param.dzPeriod);
	fprintf(fp,"\n# dHubble0: %g",msr->param.csm->dHubble0);
	fprintf(fp," dOmega0: %g",msr->param.csm->dOmega0);
	fprintf(fp," dLambda: %g",msr->param.csm->dLambda);
	fprintf(fp," dOmegaRad: %g",msr->param.csm->dOmegaRad);
	fprintf(fp," dOmegab: %g",msr->param.csm->dOmegab);
	fprintf(fp,"\n# achInFile: %s",msr->param.achInFile);
	fprintf(fp,"\n# achOutName: %s",msr->param.achOutName); 
	fprintf(fp,"\n# achOutPath: %s",msr->param.achOutPath); 
	fprintf(fp,"\n# achDataSubPath: %s",msr->param.achDataSubPath);
	if (msr->param.csm->bComove) {
	    fprintf(fp,"\n# RedOut:");
	    if (msr->nOuts == 0) fprintf(fp," none");
	    for (i=0;i<msr->nOuts;i++) {
		if (i%5 == 0) fprintf(fp,"\n#   ");
		z = 1.0/csmTime2Exp(msr->param.csm, msr->pdOutTime[i]) - 1.0;
		fprintf(fp," %f",z);
		}
	    fprintf(fp,"\n");
	    }
	else {
	    fprintf(fp,"\n# TimeOut:");
	    if (msr->nOuts == 0) fprintf(fp," none");
	    for (i=0;i<msr->nOuts;i++) {
		if (i%5 == 0) fprintf(fp,"\n#   ");
		fprintf(fp," %f",msr->pdOutTime[i]);
		}
	    fprintf(fp,"\n");
	    }
    }

int
msrGetLock(MSR msr)
    {
    /*
    ** Attempts to lock run directory to prevent overwriting. If an old lock
    ** is detected with the same achOutName, an abort is signaled. Otherwise
    ** a new lock is created. The bOverwrite parameter flag can be used to
    ** suppress lock checking.
    */

    FILE *fp = NULL;
    char achTmp[256],achFile[256];

    _msrMakePath(msr->param.achDataSubPath,LOCKFILE,achTmp);
    _msrMakePath(msr->lcl.pszDataPath,achTmp,achFile);
    if (!msr->param.bOverwrite && (fp = fopen(achFile,"r"))) {
	(void) fscanf(fp,"%s",achTmp);
	(void) fclose(fp);
	if (!strcmp(msr->param.achOutName,achTmp)) {
	    (void) printf("ABORT: %s detected.\nPlease ensure data is safe to "
			  "overwrite. Delete lockfile and try again.\n",achFile);
	    return 0;
	    }
	}
    if (!(fp = fopen(achFile,"w"))) {
	if (msr->param.bOverwrite && msr->param.bVWarnings) {
	    (void) printf("WARNING: Unable to create %s...ignored.\n",achFile);
	    return 1;
	    }
	else {
	    (void) printf("Unable to create %s\n",achFile);
	    return 0;
	    }
	}
    (void) fprintf(fp,"%s\n",msr->param.achOutName);
    (void) fclose(fp);
    return 1;
    }

int
msrCheckForStop(MSR msr)
    {
    /*
    ** Checks for existence of STOPFILE in run directory. If found, the file
    ** is removed and the return status is set to 1, otherwise 0.
    */

    static char achFile[256];
    static int first_call = 1;

    FILE *fp = NULL;

    if (first_call) {
	char achTmp[256];
	_msrMakePath(msr->param.achDataSubPath,STOPFILE,achTmp);
	_msrMakePath(msr->lcl.pszDataPath,achTmp,achFile);
	first_call = 0;
	}
    if ((fp = fopen(achFile,"r"))) {
	(void) printf("User interrupt detected.\n");
	(void) fclose(fp);
	(void) unlink(achFile);
	return 1;
	}
    return 0;
    }

void msrFinish(MSR msr)
    {
#ifndef USE_MDL_IO
    int id;
#endif

    /*
    ** It is possible that a previous save is still pending on the I/O processor.  Wait for it.
    */
#ifdef USE_MDL_IO
    if ( msr->bSavePending ) {
	mdlSetComm(msr->mdl,1);
	mdlGetReply(msr->mdl,0,NULL,NULL);
	mdlSetComm(msr->mdl,0);
    }
#endif

#ifdef USE_MDL_IO
    mdlStop(msr->mdl);
#else
    for (id=1;id<msr->nThreads;++id) {
	if (msr->param.bVDetails) printf("Stopping thread %d\n",id);		
	mdlReqService(msr->mdl,id,SRV_STOP,NULL,0);
	mdlGetReply(msr->mdl,id,NULL,NULL);
	}
#endif
    pstFinish(msr->pst);
    csmFinish(msr->param.csm);
    /*
    ** finish with parameter stuff, deallocate and exit.
    */
    prmFinish(msr->prm);
    free(msr->pMap);
    free(msr);

    }

void msrOneNodeReadTipsy(MSR msr, struct inReadTipsy *in)
    {
    int i,id;
    int *nParts;				/* number of particles for each processor */
    int nStart;
    PST pst0;
    LCL *plcl;
    char achInFile[PST_FILENAME_SIZE];
    char achOutName[PST_FILENAME_SIZE];
    int nid;
    int inswap;
    struct inSetParticleTypes intype;
#ifdef USE_HDF5
    hid_t fileID;
    IOHDF5 io;
#endif

    nParts = malloc(msr->nThreads*sizeof(*nParts));
    for (id=0;id<msr->nThreads;++id) {
	nParts[id] = -1;
	}

    pstOneNodeReadInit(msr->pst, in, sizeof(*in), nParts, &nid);
    assert(nid == msr->nThreads*sizeof(*nParts));
    for (id=0;id<msr->nThreads;++id) {
	assert(nParts[id] > 0);
	}

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    /*
    ** Add the local Data Path to the provided filename.
    */
    _msrMakePath(plcl->pszDataPath,in->achInFile,achInFile);
    _msrMakePath(plcl->pszDataPath,in->achOutName,achOutName);

#ifdef USE_HDF5xz
    if ( in->bStandard == 2 ) {
	fileID=H5Fopen(achInFile, H5F_ACC_RDONLY, H5P_DEFAULT);
	io = ioHDF5Initialize( fileID, 32768, IOHDF5_DOUBLE );
	ioHDF5ReadAttribute( io, "dTime", H5T_NATIVE_DOUBLE, &in->dTime );
	msrSaveParameters(msr,io);
	pkdWriteHDF5(plcl->pkd, io, in->dvFac );
    }
#endif

    nStart = nParts[0];
    assert(msr->pMap[0] == 0);
    for (i=1;i<msr->nThreads;++i) {
	id = msr->pMap[i];
	/* 
	 * Read particles into the local storage.
	 */
	assert(plcl->pkd->nStore >= nParts[id]);
	pkdReadTipsy(plcl->pkd,achInFile,achOutName,nStart,nParts[id],
		     in->bStandard,in->dvFac,in->bDoublePos);
	nStart += nParts[id];
	/* 
	 * Now shove them over to the remote processor.
	 */
	inswap = 0;
	mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	pkdSwapAll(plcl->pkd, id);
	mdlGetReply(pst0->mdl,id,NULL,NULL);
    	}
    assert(nStart == msr->N);
    /* 
     * Now read our own particles.
     */
    pkdReadTipsy(plcl->pkd,achInFile,achOutName,0,nParts[0],in->bStandard,in->dvFac,
		 in->bDoublePos);
    pstSetParticleTypes(msr->pst,&intype,sizeof(intype),NULL,NULL);
    }

int xdrHeader(XDR *pxdrs,struct dump *ph)
    {
    int pad = 0;
	
    if (!xdr_double(pxdrs,&ph->time)) return 0;
    if (!xdr_int(pxdrs,&ph->nbodies)) return 0;
    if (!xdr_int(pxdrs,&ph->ndim)) return 0;
    if (!xdr_int(pxdrs,&ph->nsph)) return 0;
    if (!xdr_int(pxdrs,&ph->ndark)) return 0;
    if (!xdr_int(pxdrs,&ph->nstar)) return 0;
    if (!xdr_int(pxdrs,&pad)) return 0;
    return 1;
    }


static double _msrReadTipsy(MSR msr, const char *achFilename)
    {
    FILE *fp;
    struct dump h;
    double dExpansion;
    struct inReadTipsy in;
    char achInFile[PST_FILENAME_SIZE];
    LCL *plcl = msr->pst->plcl;
    double dTime,aTo,tTo,z;
    struct inSetParticleTypes intype;

    strcpy(in.achInFile,achFilename);


    /* Add local Data Path. */
    _msrMakePath(plcl->pszDataPath,achFilename,achInFile);

	
    fp = fopen(achInFile,"r");
    
    if (!fp) {
	printf("Could not open InFile:%s\n",achInFile);
	_msrExit(msr,1);
    }

    /*
    ** Assume tipsy format for now, and dark matter only.
    */
    if (msr->param.bStandard) {
	XDR xdrs;

	xdrstdio_create(&xdrs,fp,XDR_DECODE);
	xdrHeader(&xdrs,&h);
	xdr_destroy(&xdrs);
	}
    else {
	fread(&h,sizeof(struct dump),1,fp);
	}
    fclose(fp);
    msr->N = h.nbodies;
    msr->nDark = h.ndark;
    msr->nGas = h.nsph;
    msr->nStar = h.nstar;
    dExpansion = h.time;


    msr->nMaxOrder = msr->N - 1;
    msr->nMaxOrderGas = msr->nGas - 1;
    msr->nMaxOrderDark = msr->nGas + msr->nDark - 1;
    assert(msr->N == msr->nDark+msr->nGas+msr->nStar);
    if (msr->param.csm->bComove) {
	if(msr->param.csm->dHubble0 == 0.0) {
	    printf("No hubble constant specified\n");
	    _msrExit(msr,1);
	    }
	dTime = csmExp2Time(msr->param.csm,dExpansion);
	z = 1.0/dExpansion - 1.0;
	if (msr->param.bVStart)
	    printf("Input file, Time:%g Redshift:%g Expansion factor:%g iStartStep:%llu\n",
		   dTime,z,dExpansion,msr->param.iStartStep);
	if (prmSpecified(msr->prm,"dRedTo")) {
	  if (msr->param.dRedTo <= -1.0) {
	    printf("Badly specified final redshift (zTo <= -1.0), check -zto parameter.\n");
	    _msrExit(msr,1);
	  }
	    if (!prmArgSpecified(msr->prm,"nSteps") &&
		prmArgSpecified(msr->prm,"dDelta")) {
		aTo = 1.0/(msr->param.dRedTo + 1.0);
		tTo = csmExp2Time(msr->param.csm,aTo);
		if (msr->param.bVStart)
		    printf("Simulation to Time:%g Redshift:%g Expansion factor:%g\n",
			   tTo,1.0/aTo-1.0,aTo);
		if (tTo < dTime) {
		    printf("Badly specified final redshift, check -zto parameter.\n");
		    _msrExit(msr,1);
		    }
		msr->param.nSteps = (uint64_t)ceil((tTo-dTime)/msr->param.dDelta);
		msr->param.dDelta =
		  (tTo-dTime)/(msr->param.nSteps -
			       msr->param.iStartStep);
		}
	    else if (!prmArgSpecified(msr->prm,"dDelta") &&
		     prmArgSpecified(msr->prm,"nSteps")) {
		aTo = 1.0/(msr->param.dRedTo + 1.0);
		tTo = csmExp2Time(msr->param.csm,aTo);
		if (msr->param.bVStart)
		    printf("Simulation to Time:%g Redshift:%g Expansion factor:%g\n",
			   tTo,1.0/aTo-1.0,aTo);
		if (tTo < dTime) {
		    printf("Badly specified final redshift, check -zto parameter.\n");	
		    _msrExit(msr,1);
		    }
		if(msr->param.nSteps != 0)
		    msr->param.dDelta =
			(tTo-dTime)/(msr->param.nSteps -
				     msr->param.iStartStep);
				
		else
		    msr->param.dDelta = 0.0;
		}
	    else if (!prmSpecified(msr->prm,"nSteps") &&
		     prmFileSpecified(msr->prm,"dDelta")) {
		aTo = 1.0/(msr->param.dRedTo + 1.0);
		tTo = csmExp2Time(msr->param.csm,aTo);
		if (msr->param.bVStart)
		    printf("Simulation to Time:%g Redshift:%g Expansion factor:%g\n",
			   tTo,1.0/aTo-1.0,aTo);
		if (tTo < dTime) {
		    printf("Badly specified final redshift, check -zto parameter.\n");
		    _msrExit(msr,1);
		    }
		msr->param.nSteps = (uint64_t)ceil((tTo-dTime)/msr->param.dDelta);
		msr->param.dDelta =
		  (tTo-dTime)/(msr->param.nSteps -
			       msr->param.iStartStep);
		}
	    else if (!prmSpecified(msr->prm,"dDelta") &&
		     prmFileSpecified(msr->prm,"nSteps")) {
		aTo = 1.0/(msr->param.dRedTo + 1.0);
		tTo = csmExp2Time(msr->param.csm,aTo);
		if (msr->param.bVStart)
		    printf("Simulation to Time:%g Redshift:%g Expansion factor:%g\n",
			   tTo,1.0/aTo-1.0,aTo);
		if (tTo < dTime) {
		    printf("Badly specified final redshift, check -zto parameter.\n");	
		    _msrExit(msr,1);
		    }
		if(msr->param.nSteps != 0)
		    msr->param.dDelta =	(tTo-dTime)/(msr->param.nSteps
						     - msr->param.iStartStep);
		else
		    msr->param.dDelta = 0.0;
		}
	    }
	else {
	    tTo = dTime + msr->param.nSteps*msr->param.dDelta;
	    aTo = csmTime2Exp(msr->param.csm,tTo);
	    if (msr->param.bVStart)
		printf("Simulation to Time:%g Redshift:%g Expansion factor:%g\n",
		       tTo,1.0/aTo-1.0,aTo);
	    }
	if (msr->param.bVStart)
	    printf("Reading file...\nN:%d nDark:%d nGas:%d nStar:%d\n",msr->N,
		   msr->nDark,msr->nGas,msr->nStar);
	if (msr->param.bCannonical) {
	    in.dvFac = dExpansion*dExpansion;
	    }
	else {
	    in.dvFac = 1.0;
	    }
	}
    else {
	dTime = dExpansion;
	if (msr->param.bVStart) printf("Input file, Time:%g iStartStep:%"PRIu64"\n",dTime,msr->param.iStartStep);
	tTo = dTime + (msr->param.nSteps - msr->param.iStartStep)*msr->param.dDelta;
	if (msr->param.bVStart) {
	    printf("Simulation to Time:%g\n",tTo);
	    printf("Reading file...\nN:%d nDark:%d nGas:%d nStar:%d Time:%g\n",
		   msr->N,msr->nDark,msr->nGas,msr->nStar,dTime);
	    }
	in.dvFac = 1.0;
	}
    in.nFileStart = 0;
    in.nFileEnd = msr->N - 1;
    in.nBucket = msr->param.nBucket;
    in.nDark = msr->nDark;
    in.nGas = msr->nGas;
    in.nStar = msr->nStar;
    in.bStandard = msr->param.bStandard;
    in.bDoublePos = msr->param.bDoublePos;
    strcpy(in.achOutName,msr->param.achOutName);    
    /*
    ** Since pstReadTipsy causes the allocation of the local particle
    ** store, we need to tell it the percentage of extra storage it
    ** should allocate for load balancing differences in the number of
    ** particles.
    */
    in.fExtraStore = msr->param.dExtraStore;
    /*
    ** Provide the period.
    */
    in.fPeriod[0] = msr->param.dxPeriod;
    in.fPeriod[1] = msr->param.dyPeriod;
    in.fPeriod[2] = msr->param.dzPeriod;

    if(msr->param.bParaRead)
	pstReadTipsy(msr->pst,&in,sizeof(in),NULL,NULL);
    else
	msrOneNodeReadTipsy(msr, &in);
    pstSetParticleTypes(msr->pst, &intype, sizeof(intype), NULL, NULL);
    if (msr->param.bVDetails) puts("Input file has been successfully read.");
    /*
    ** Now read in the output points, passing the initial time.
    ** We do this only if nSteps is not equal to zero.
    */
    if (msrSteps(msr) > 0) msrReadOuts(msr,dTime);
    /*
    ** Set up the output counter.
    */

    for (msr->iOut=0;msr->iOut<msr->nOuts;++msr->iOut) {
	if (dTime < msr->pdOutTime[msr->iOut]) break;
	}
    return(dTime);
    }


#ifdef USE_MDL_IO
void msrIOWrite(MSR msr, const char *achOutName, double dTime, int bCheckpoint)
{
    //struct inFindIOS inFind;
    struct outFindIOS outFind;
    int nFind;
    int i;
    struct inStartIO inStart;
    struct inStartSave save;


    //printf( "Finding number of particles\n" );

    /* Find the number of particles to expect for each I/O processor */
    //inFind.nLower = 0;
    //inFind.N = msr->N;
    //pstFindIOS( msr->pst, &inFind, sizeof(inFind), &outFind, &nFind );

//    if (msr->param.bVDetails) {
//	printf("Particle distribution on I/O nodes:\n");
//	for( i=0; i<mdlIO(msr->mdl); i++ ) {
//	    printf( "%4d: %d\n", i, outFind.nCount[i]);
//	}
//    }

    /* Ask the I/O processors to start a save operation */
    save.dTime = dTime;
    save.N = msr->N;
    strcpy(save.achOutName,achOutName); 
    mdlSetComm(msr->mdl,1);
    if ( msr->bSavePending )
	mdlGetReply(msr->mdl,0,NULL,NULL);
    mdlReqService(msr->mdl,0,IO_START_SAVE,&save,sizeof(save));
    msr->bSavePending = 1;
    mdlSetComm(msr->mdl,0);

    /* Execute a save operation on the worker processors */

    if (msr->param.csm->bComove) {
	inStart.dTime = csmTime2Exp(msr->param.csm,dTime);
	if (msr->param.bCannonical) {
	    inStart.dvFac = 1.0/(inStart.dTime*inStart.dTime);
	    }
	else {
	    inStart.dvFac = 1.0;
	    }
	}
    else {
	inStart.dTime = dTime;
	inStart.dvFac = 1.0;
	}
    inStart.bDoublePos = msr->param.bDoublePos;
    inStart.N = msr->N;
    strcpy(inStart.achOutName,achOutName);

    //_msrMakePath(plcl->pszDataPath,in->achOutFile,achOutFile);


    /*char achOutFile[PST_FILENAME_SIZE];*/
    pstStartIO( msr->pst, &inStart, sizeof(inStart), NULL, NULL );

#if 0
    /* Get the reply from the I/O processor */
    mdlSetComm(msr->mdl,1);
    mdlGetReply(msr->mdl,0,NULL,NULL);
    mdlSetComm(msr->mdl,0);
#endif
}
#endif

#ifdef USE_HDF5
/*
** This function saves all of the input parameters, as well as single-variable
** state information.
*/
void msrSaveParameters(MSR msr, IOHDF5 io)
{
    ioHDF5WriteAttribute( io, "nThreads", H5T_NATIVE_INT, &msr->param.nThreads );
    ioHDF5WriteAttribute( io, "bDiag", H5T_NATIVE_INT, &msr->param.bDiag );
    ioHDF5WriteAttribute( io, "bOverwrite", H5T_NATIVE_INT, &msr->param.bOverwrite );
    ioHDF5WriteAttribute( io, "bVWarnings", H5T_NATIVE_INT, &msr->param.bVWarnings );
    ioHDF5WriteAttribute( io, "bVStart", H5T_NATIVE_INT, &msr->param.bVStart );
    ioHDF5WriteAttribute( io, "bVStep", H5T_NATIVE_INT, &msr->param.bVStep );
    ioHDF5WriteAttribute( io, "bVRungStat", H5T_NATIVE_INT, &msr->param.bVRungStat );
    ioHDF5WriteAttribute( io, "bVDetails", H5T_NATIVE_INT, &msr->param.bVDetails );
    ioHDF5WriteAttribute( io, "bPeriodic", H5T_NATIVE_INT, &msr->param.bPeriodic );
    ioHDF5WriteAttribute( io, "bParaRead", H5T_NATIVE_INT, &msr->param.bParaRead );
    ioHDF5WriteAttribute( io, "bParaWrite", H5T_NATIVE_INT, &msr->param.bParaWrite );
    ioHDF5WriteAttribute( io, "bCannonical", H5T_NATIVE_INT, &msr->param.bCannonical );
    ioHDF5WriteAttribute( io, "bStandard", H5T_NATIVE_INT, &msr->param.bStandard );
    ioHDF5WriteAttribute( io, "bDoublePos", H5T_NATIVE_INT, &msr->param.bDoublePos );
    ioHDF5WriteAttribute( io, "bGravStep", H5T_NATIVE_INT, &msr->param.bGravStep );
    ioHDF5WriteAttribute( io, "bEpsAccStep", H5T_NATIVE_INT, &msr->param.bEpsAccStep );
    ioHDF5WriteAttribute( io, "bSqrtPhiStep", H5T_NATIVE_INT, &msr->param.bSqrtPhiStep );
    ioHDF5WriteAttribute( io, "bAccelStep", H5T_NATIVE_INT, &msr->param.bAccelStep );
    ioHDF5WriteAttribute( io, "bDensityStep", H5T_NATIVE_INT, &msr->param.bDensityStep );
    ioHDF5WriteAttribute( io, "iTimeStepCrit", H5T_NATIVE_INT, &msr->param.iTimeStepCrit );
    ioHDF5WriteAttribute( io, "nPColl", H5T_NATIVE_INT, &msr->param.nPColl );
    ioHDF5WriteAttribute( io, "nTruncateRung", H5T_NATIVE_INT, &msr->param.nTruncateRung );
    ioHDF5WriteAttribute( io, "bDoDensity", H5T_NATIVE_INT, &msr->param.bDoDensity );
    ioHDF5WriteAttribute( io, "bDodtOutput", H5T_NATIVE_INT, &msr->param.bDodtOutput );
    ioHDF5WriteAttribute( io, "bDoRungOutput", H5T_NATIVE_INT, &msr->param.bDoRungOutput );
    ioHDF5WriteAttribute( io, "bDoGravity", H5T_NATIVE_INT, &msr->param.bDoGravity );
    ioHDF5WriteAttribute( io, "bAntiGrav", H5T_NATIVE_INT, &msr->param.bAntiGrav );
    ioHDF5WriteAttribute( io, "nBucket", H5T_NATIVE_INT, &msr->param.nBucket );
    ioHDF5WriteAttribute( io, "iOutInterval", H5T_NATIVE_INT, &msr->param.iOutInterval );
    ioHDF5WriteAttribute( io, "iCheckInterval", H5T_NATIVE_INT, &msr->param.iCheckInterval );
    ioHDF5WriteAttribute( io, "iLogInterval", H5T_NATIVE_INT, &msr->param.iLogInterval );
    ioHDF5WriteAttribute( io, "iOrder", H5T_NATIVE_INT, &msr->param.iOrder );
    ioHDF5WriteAttribute( io, "bEwald", H5T_NATIVE_INT, &msr->param.bEwald );
    ioHDF5WriteAttribute( io, "iEwOrder", H5T_NATIVE_INT, &msr->param.iEwOrder );
    ioHDF5WriteAttribute( io, "nReplicas", H5T_NATIVE_INT, &msr->param.nReplicas );
    ioHDF5WriteAttribute( io, "iStartStep", H5T_NATIVE_INT, &msr->param.iStartStep );
    ioHDF5WriteAttribute( io, "nSteps", H5T_NATIVE_INT, &msr->param.nSteps );
    ioHDF5WriteAttribute( io, "nSmooth", H5T_NATIVE_INT, &msr->param.nSmooth );
    ioHDF5WriteAttribute( io, "iMaxRung", H5T_NATIVE_INT, &msr->param.iMaxRung );
    ioHDF5WriteAttribute( io, "nRungVeryActive", H5T_NATIVE_INT, &msr->param.nRungVeryActive );
    ioHDF5WriteAttribute( io, "nPartVeryActive", H5T_NATIVE_INT, &msr->param.nPartVeryActive );
    ioHDF5WriteAttribute( io, "nGrowMass", H5T_NATIVE_INT, &msr->param.nGrowMass );
    ioHDF5WriteAttribute( io, "iWallRunTime", H5T_NATIVE_INT, &msr->param.iWallRunTime );
    ioHDF5WriteAttribute( io, "bPhysicalSoft", H5T_NATIVE_INT, &msr->param.bPhysicalSoft );  
    ioHDF5WriteAttribute( io, "bSoftMaxMul", H5T_NATIVE_INT, &msr->param.bSoftMaxMul );
    ioHDF5WriteAttribute( io, "bVariableSoft", H5T_NATIVE_INT, &msr->param.bVariableSoft );
    ioHDF5WriteAttribute( io, "nSoftNbr", H5T_NATIVE_INT, &msr->param.nSoftNbr );
    ioHDF5WriteAttribute( io, "bSoftByType", H5T_NATIVE_INT, &msr->param.bSoftByType );
    ioHDF5WriteAttribute( io, "bDoSoftOutput", H5T_NATIVE_INT, &msr->param.bDoSoftOutput );

    ioHDF5WriteAttribute( io, "dEta", H5T_NATIVE_DOUBLE, &msr->param.dEta );
    ioHDF5WriteAttribute( io, "dExtraStore", H5T_NATIVE_DOUBLE, &msr->param.dExtraStore );
    ioHDF5WriteAttribute( io, "dSoft", H5T_NATIVE_DOUBLE, &msr->param.dSoft );
    ioHDF5WriteAttribute( io, "dSoftMax", H5T_NATIVE_DOUBLE, &msr->param.dSoftMax );
    ioHDF5WriteAttribute( io, "dDelta", H5T_NATIVE_DOUBLE, &msr->param.dDelta );
    ioHDF5WriteAttribute( io, "dEwCut", H5T_NATIVE_DOUBLE, &msr->param.dEwCut );
    ioHDF5WriteAttribute( io, "dEwhCut", H5T_NATIVE_DOUBLE, &msr->param.dEwhCut );
    ioHDF5WriteAttribute( io, "dTheta", H5T_NATIVE_DOUBLE, &msr->param.dTheta );
    ioHDF5WriteAttribute( io, "dTheta2", H5T_NATIVE_DOUBLE, &msr->param.dTheta2 );
    ioHDF5WriteAttribute( io, "daSwitchTheta", H5T_NATIVE_DOUBLE, &msr->param.daSwitchTheta );
    ioHDF5WriteAttribute( io, "dPeriod", H5T_NATIVE_DOUBLE, &msr->param.dPeriod );
    ioHDF5WriteAttribute( io, "dxPeriod", H5T_NATIVE_DOUBLE, &msr->param.dxPeriod );
    ioHDF5WriteAttribute( io, "dyPeriod", H5T_NATIVE_DOUBLE, &msr->param.dyPeriod );
    ioHDF5WriteAttribute( io, "dzPeriod", H5T_NATIVE_DOUBLE, &msr->param.dzPeriod );
    ioHDF5WriteAttribute( io, "bComove", H5T_NATIVE_INT, &msr->param.csm->bComove );
    ioHDF5WriteAttribute( io, "dHubble0", H5T_NATIVE_DOUBLE, &msr->param.csm->dHubble0 );
    ioHDF5WriteAttribute( io, "dOmega0", H5T_NATIVE_DOUBLE, &msr->param.csm->dOmega0 );
    ioHDF5WriteAttribute( io, "dLambda", H5T_NATIVE_DOUBLE, &msr->param.csm->dLambda );
    ioHDF5WriteAttribute( io, "dOmegaRad", H5T_NATIVE_DOUBLE, &msr->param.csm->dOmegaRad );
    ioHDF5WriteAttribute( io, "dOmegab", H5T_NATIVE_DOUBLE, &msr->param.csm->dOmegab );
    ioHDF5WriteAttribute( io, "dRedTo", H5T_NATIVE_DOUBLE, &msr->param.dRedTo );
    ioHDF5WriteAttribute( io, "dCentMass", H5T_NATIVE_DOUBLE, &msr->param.dCentMass );
    ioHDF5WriteAttribute( io, "dGrowDeltaM", H5T_NATIVE_DOUBLE, &msr->param.dGrowDeltaM );
    ioHDF5WriteAttribute( io, "dGrowStartT", H5T_NATIVE_DOUBLE, &msr->param.dGrowStartT );
    ioHDF5WriteAttribute( io, "dGrowEndT", H5T_NATIVE_DOUBLE, &msr->param.dGrowEndT );
    ioHDF5WriteAttribute( io, "dFracNoTreeSqueeze", H5T_NATIVE_DOUBLE, &msr->param.dFracNoTreeSqueeze );
    ioHDF5WriteAttribute( io, "dFracNoDomainDecomp", H5T_NATIVE_DOUBLE, &msr->param.dFracNoDomainDecomp );
    ioHDF5WriteAttribute( io, "dFracNoDomainDimChoice", H5T_NATIVE_DOUBLE, &msr->param.dFracNoDomainDimChoice );
    ioHDF5WriteAttribute( io, "bRungDD", H5T_NATIVE_INT, &msr->param.bRungDD );
    ioHDF5WriteAttribute( io, "dRungDDWeight", H5T_NATIVE_DOUBLE, &msr->param.dRungDDWeight );

    /* Restart information */
    ioHDF5WriteAttribute( io, "dEcosmo", H5T_NATIVE_DOUBLE, &msr->dEcosmo );
    ioHDF5WriteAttribute( io, "dTimeOld", H5T_NATIVE_DOUBLE, &msr->dTimeOld );
    ioHDF5WriteAttribute( io, "dUOld", H5T_NATIVE_DOUBLE, &msr->dUOld );
}
#endif

/*
** This function makes some DANGEROUS assumptions!!!
** Main problem is that it calls pkd level routines, bypassing the
** pst level. It uses plcl pointer which is not desirable.
*/
void msrOneNodeWriteTipsy(MSR msr, struct inWriteTipsy *in, int bCheckpoint)
    {
    int i,id;
    int nStart;
    PST pst0;
    LCL *plcl;
    char achOutFile[PST_FILENAME_SIZE];
    int inswap;
#ifdef USE_HDF5
    hid_t fileID;
    IOHDF5 io;
#endif

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    /*
    ** Add the local Data Path to the provided filename.
    */
    _msrMakePath(plcl->pszDataPath,in->achOutFile,achOutFile);

    /* 
     * First write our own particles.
     */
#ifdef USE_HDF5
    if ( in->bStandard == 2 ) {
	printf( "Writing HDF5 format file to %s\n", achOutFile );
	fileID=H5Fcreate(achOutFile, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
	if ( fileID < 0 ) {
	    fprintf(stderr,"Unable to create %s\n", achOutFile);
	    H5assert(fileID);
	}
	io = ioHDF5Initialize( fileID, 32768, bCheckpoint );
	ioHDF5WriteAttribute( io, "dTime", H5T_NATIVE_DOUBLE, &in->dTime );
	msrSaveParameters(msr,io);
	pkdWriteHDF5(plcl->pkd, io, in->dvFac );
    }
    else
#endif
    {
	pkdWriteTipsy(plcl->pkd,achOutFile,plcl->nWriteStart,in->bStandard,
		  in->dvFac,in->bDoublePos); 
    }
    nStart = plcl->pkd->nLocal;
    assert(msr->pMap[0] == 0);
    for (i=1;i<msr->nThreads;++i) {
	id = msr->pMap[i];
	/* 
	 * Swap particles with the remote processor.
	 */
	inswap = 0;
	mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	pkdSwapAll(plcl->pkd, id);
	mdlGetReply(pst0->mdl,id,NULL,NULL);
	/* 
	 * Write the swapped particles.
	 */
#ifdef USE_HDF5
	if ( in->bStandard == 2 ) {
	    pkdWriteHDF5(plcl->pkd, io, in->dvFac);
	}
	else
#endif
	{
	    pkdWriteTipsy(plcl->pkd,achOutFile,nStart, in->bStandard,
			  in->dvFac, in->bDoublePos); 
	}
	nStart += plcl->pkd->nLocal;
	/* 
	 * Swap them back again.
	 */
	inswap = 0;
	mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	pkdSwapAll(plcl->pkd, id);
	mdlGetReply(pst0->mdl,id,NULL,NULL);
    	}

#ifdef USE_HDF5
	if ( in->bStandard == 2 ) {
	    ioHDF5Finish(io);
	    H5assert(H5Fflush(fileID,H5F_SCOPE_GLOBAL));
	    H5assert(H5Fclose(fileID));
	}
#endif

    assert(nStart == msr->N);
    }


void msrCalcWriteStart(MSR msr) 
    {
    struct outSetTotal out;
    struct inSetWriteStart in;

    pstSetTotal(msr->pst,NULL,0,&out,NULL);
    assert(out.nTotal == msr->N);
    in.nWriteStart = 0;
    pstSetWriteStart(msr->pst,&in,sizeof(in),NULL,NULL);
    }


void _msrWriteTipsy(MSR msr,char *pszFileName,double dTime,int bCheckpoint)
    {
    FILE *fp;
    struct dump h;
    struct inWriteTipsy in;
    char achOutFile[PST_FILENAME_SIZE];
    LCL *plcl = msr->pst->plcl;
    /*
    ** Calculate where to start writing.
    ** This sets plcl->nWriteStart.
    */
    msrCalcWriteStart(msr);
    /*
    ** Add Data Subpath for local and non-local names.
    */
    _msrMakePath(msr->param.achDataSubPath,pszFileName,in.achOutFile);
    /*
    ** Add local Data Path.
    */
    _msrMakePath(plcl->pszDataPath,in.achOutFile,achOutFile);

    in.bStandard = msr->param.bStandard;
    in.bDoublePos = msr->param.bDoublePos;
    /*
    ** Assume tipsy format for now.
    */
    h.nbodies = msr->N;
    h.ndark = msr->nDark;
    h.nsph = msr->nGas;
    h.nstar = msr->nStar;
    if (msr->param.csm->bComove) {
	in.dTime = csmTime2Exp(msr->param.csm,dTime);
	if (msr->param.bCannonical) {
	    in.dvFac = 1.0/(in.dTime*in.dTime);
	    }
	else {
	    in.dvFac = 1.0;
	    }
	}
    else {
	in.dTime = dTime;
	in.dvFac = 1.0;
	}
    h.ndim = 3;
    h.time = in.dTime;
    if (msr->param.bVDetails) {
	if (msr->param.csm->bComove) {
	    printf("Writing file...\nTime:%g Redshift:%g\n",
		   dTime,(1.0/h.time - 1.0));
	    }
	else {
	    printf("Writing file...\nTime:%g\n",dTime);
	    }
	}

#ifdef USE_HDF5
    if ( msr->param.bHDF5 ) {
	in.bStandard = 2;
	msrOneNodeWriteTipsy(msr, &in,bCheckpoint);
    }
    else
#endif
    {
	fp = fopen(achOutFile,"w");
	if (!fp) {
	    printf("Could not open OutFile:%s\n",achOutFile);
	    _msrExit(msr,1);
	}
	if (in.bStandard) {
	    XDR xdrs;
	    
	    xdrstdio_create(&xdrs,fp,XDR_ENCODE);
	    xdrHeader(&xdrs,&h);
	    xdr_destroy(&xdrs);
	}
	else {
	    fwrite(&h,sizeof(struct dump),1,fp);
	}
	fclose(fp);
	
	if(msr->param.bParaWrite)
	    pstWriteTipsy(msr->pst,&in,sizeof(in),NULL,NULL);
	else
	    msrOneNodeWriteTipsy(msr, &in, bCheckpoint);
    }

    if (msr->param.bVDetails)
	puts("Output file has been successfully written.");
    }


void msrWriteTipsy(MSR msr,char *pszFileName,double dTime, int bCheckpoint )
{
#ifdef USE_MDL_IO
    /* If we are using I/O processors, then we do it totally differently */
    if ( mdlIO(msr->mdl) ) {
	msrIOWrite(msr,pszFileName,dTime,bCheckpoint);
    }
    else
#endif
    {
	_msrWriteTipsy(msr,pszFileName,dTime,bCheckpoint);
    }
}



void msrSetSoft(MSR msr,double dSoft)
    {
    struct inSetSoft in;
  
    if (msr->param.bVDetails) printf("Set Softening...\n");
    in.dSoft = dSoft;
    pstSetSoft(msr->pst,&in,sizeof(in),NULL,NULL);
    }


void msrDomainDecomp(MSR msr,int iRung,int bGreater,int bSplitVA) {
    struct inDomainDecomp in;
    struct outCalcBound outcb;
    int j;
    double sec,dsec;

    int iRungDD,iRungSD,nActive;


    in.bDoRootFind = 1;
    in.bDoSplitDimFind = 1;
    in.nBndWrap[0] = 0;
    in.nBndWrap[1] = 0;
    in.nBndWrap[2] = 0;

    /*
    ** If we are dealing with a nice periodic volume in all
    ** three dimensions then we can set the initial bounds
    ** instead of calculating them.
    */
    if (msr->param.bPeriodic && 
	msr->param.dxPeriod < FLOAT_MAXVAL &&
	msr->param.dyPeriod < FLOAT_MAXVAL && 
	msr->param.dzPeriod < FLOAT_MAXVAL) {
	for (j=0;j<3;++j) {
	    in.bnd.fCenter[j] = msr->fCenter[j];
	    }
	in.bnd.fMax[0] = 0.5*msr->param.dxPeriod;
	in.bnd.fMax[1] = 0.5*msr->param.dyPeriod;
	in.bnd.fMax[2] = 0.5*msr->param.dzPeriod;
	}
    else {
	pstCalcBound(msr->pst,NULL,0,&outcb,NULL);
	in.bnd = outcb.bnd;
	}

    nActive=0;
    if (bGreater) {
	iRungDD=msr->iCurrMaxRung+1; 
	while (iRungDD > iRung) {
	    iRungDD--;
	    nActive+=msr->nRung[iRungDD];
	    }
	while(iRungDD > 0 && nActive < msr->N*msr->param.dFracNoDomainDecomp) {
	    iRungDD--;
	    nActive+=msr->nRung[iRungDD];
	    }
	iRungSD = iRungDD;
	while(iRungSD > 0 && nActive < msr->N*msr->param.dFracNoDomainDimChoice) {
	    iRungSD--;
	    nActive+=msr->nRung[iRungSD];
	    }
	}
    else {
	iRungDD = iRung;
	while(iRungDD > 0 && msr->nRung[iRungDD] < msr->N*msr->param.dFracNoDomainDecomp) {
	    iRungDD--;
	    }
	iRungSD = iRungDD;
	while(iRungSD > 0 && msr->nRung[iRungSD] < msr->N*msr->param.dFracNoDomainDimChoice) {
	    iRungSD--;
	    }
	}

    if (msr->nActive < msr->N*msr->param.dFracNoDomainDecomp) {
	if (msr->bDoneDomainDecomp && msr->iLastRungDD >= iRungDD) {
	    if (msr->param.bVRungStat) printf("Skipping Root Finder (nActive = %d/%d, iRung %d/%d/%d)\n",msr->nActive,msr->N,iRung,iRungDD,msr->iLastRungDD);
	    in.bDoRootFind = 0;
	    in.bDoSplitDimFind = 0;
	    }
	}
    else iRungDD = iRung;

    if (msr->bDoneDomainDecomp && msr->iLastRungDD == iRungDD) {
	    if (msr->param.bVRungStat) printf("Skipping Root Finder (nActive = %d/%d, iRung %d/%d/%d)\n",msr->nActive,msr->N,iRung,iRungDD,msr->iLastRungDD);
	    in.bDoRootFind = 0;
	    in.bDoSplitDimFind = 0;
	    }
	
    if (in.bDoRootFind && msr->bDoneDomainDecomp && iRungDD > iRungSD && msr->iLastRungSD >= iRungSD) {
	if (msr->param.bVRungStat) printf("Skipping Split Dim Finding (nActive = %d/%d, iRung %d/%d/%d/%d)\n",msr->nActive,msr->N,iRung,iRungDD,iRungSD,msr->iLastRungSD);
	in.bDoSplitDimFind = 0;
	}

    if (iRungDD < iRung) 
	msrActiveRung(msr,iRungDD,bGreater); 

    in.nActive = msr->nActive;
    in.nTotal = msr->N;

    if (msr->param.bRungDD) {
	struct inRungDDWeight inRDD;
	inRDD.iMaxRung = msr->iCurrMaxRung;
	inRDD.dWeight = msr->param.dRungDDWeight;
	pstRungDDWeight(msr->pst,&inRDD,sizeof(struct inRungDDWeight),NULL,NULL);
	}

#ifdef BSC
    MPItrace_event(10000, 0 );
#endif
    if (msr->param.bVDetails) {
	printf("Domain Decomposition: nActive (Rung %d) %d\n",iRungDD,msr->nActive);
	printf("Domain Decomposition... \n");
	sec = msrTime();
	}

    in.bSplitVA = bSplitVA;
    /*if (bSplitVA) {
	printf("*** Splitting very active particles!\n");	
	}*/
    pstDomainDecomp(msr->pst,&in,sizeof(in),NULL,NULL);
    msr->bDoneDomainDecomp = 1; 

#ifdef BSC
    MPItrace_event(10001, 2 );
#endif
    if (msr->param.bVDetails) {
	dsec = msrTime() - sec;
	printf("Domain Decomposition complete, Wallclock: %f secs\n\n",dsec);
	}

    if (in.bDoSplitDimFind) {
	msr->iLastRungSD = iRungDD;
	}
    if (in.bDoRootFind) {
	msr->iLastRungDD = iRungDD;
	}

    if (iRungDD < iRung) {
	/* Restore Active data */
	msrActiveRung(msr,iRung,bGreater);
	}
}

/*
** This the meat of the tree build, but will be called by differently named
** functions in order to implement special features without recoding...
*/
void _BuildTree(MSR msr,double dMass,double dTimeStamp,int bExcludeVeryActive) {
    struct inBuildTree in;
    struct ioCalcRoot root;
    KDN *pkdn;
    int iDum,nCell;

    if (msr->param.bVDetails) printf("Building local trees...\n\n");

    in.nBucket = msr->param.nBucket;
    in.diCrit2 = 1/(msr->dCrit*msr->dCrit);
    nCell = 1<<(1+(int)ceil(log((double)msr->nThreads)/log(2.0)));
    pkdn = malloc(nCell*sizeof(KDN));
    assert(pkdn != NULL);
    in.iCell = ROOT;
    in.nCell = nCell;
    in.bTreeSqueeze = (msr->nActive > msr->N*msr->param.dFracNoTreeSqueeze);
    in.bExcludeVeryActive = bExcludeVeryActive;
    in.dTimeStamp = dTimeStamp;
    if (msr->param.bVDetails) {
	double sec,dsec;
	sec = msrTime();
	pstBuildTree(msr->pst,&in,sizeof(in),pkdn,&iDum);
	printf("Done pstBuildTree\n");
	dsec = msrTime() - sec;
	printf("Tree built, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstBuildTree(msr->pst,&in,sizeof(in),pkdn,&iDum);
	}
    pstDistribCells(msr->pst,pkdn,nCell*(int)sizeof(KDN),NULL,NULL);
    free(pkdn);
    if (!bExcludeVeryActive) {
	/*
	** For simplicity we will skip calculating the Root for all particles 
	** with exclude very active since there are missing particles which 
	** could add to the mass and because it probably is not important to 
	** update the root so frequently.
	*/
	pstCalcRoot(msr->pst,NULL,0,&root,&iDum);
	pstDistribRoot(msr->pst,&root,sizeof(struct ioCalcRoot),NULL,NULL);
	}
    }

void msrBuildTree(MSR msr,double dMass,double dTime) {
  _BuildTree(msr,dMass,dTime,0);
    }

void msrBuildTreeExcludeVeryActive(MSR msr,double dMass,double dTime) {
  _BuildTree(msr,dMass,dTime,1);
    }


#ifdef GASOLINE
void msrCalcBoundBall(MSR msr,double fBallFactor)
    {
    struct inCalcBoundBall in;
    BND *pbnd;
    int iDum,nCell;

    in.fBallFactor = fBallFactor;
    nCell = 1<<(1+(int)ceil(log((double)msr->nThreads)/log(2.0)));
    pbnd = malloc(nCell*sizeof(BND));
    assert(pbnd != NULL);
    in.iCell = ROOT;
    in.nCell = nCell;
    pstCalcBoundBall(msr->pst,&in,sizeof(in),pbnd,&iDum);
    pstDistribBoundBall(msr->pst,pbnd,nCell*sizeof(BND),NULL,NULL);
    free(pbnd);
    }
#endif

void msrReorder(MSR msr)
    {
    struct inDomainOrder in;

    in.iMaxOrder = msrMaxOrder(msr);
    if (msr->param.bVDetails) {
	double sec,dsec;
	printf("Ordering...\n");
	sec = msrTime();
	pstDomainOrder(msr->pst,&in,sizeof(in),NULL,NULL);
	pstLocalOrder(msr->pst,NULL,0,NULL,NULL);
	dsec = msrTime() - sec;
	printf("Order established, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstDomainOrder(msr->pst,&in,sizeof(in),NULL,NULL);
	pstLocalOrder(msr->pst,NULL,0,NULL,NULL);
	}
    /*
    ** Mark domain decomp as not done.
    */
    msr->bDoneDomainDecomp = 0;
    }


void msrOutArray(MSR msr,char *pszFile,int iType)
    {
    struct inOutArray in;
    char achOutFile[PST_FILENAME_SIZE];
    LCL *plcl;
    PST pst0;
    FILE *fp;
    int id,i;
    int inswap;

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    if (pszFile) {
	/*
	** Add Data Subpath for local and non-local names.
	*/
	_msrMakePath(msr->param.achDataSubPath,pszFile,in.achOutFile);
	/*
	** Add local Data Path.
	*/
	_msrMakePath(plcl->pszDataPath,in.achOutFile,achOutFile);
	fp = fopen(achOutFile,"w");

	if (!fp) {
	    printf("Could not open Array Output File:%s\n",achOutFile);
	    _msrExit(msr,1);
	    }
	}
    else {
	printf("No Array Output File specified\n");
	_msrExit(msr,1);
	return;
	}
    /*
    ** Write the Header information and close the file again.
    */
    fprintf(fp,"%d\n",msr->N);
    fclose(fp);
    /* 
     * First write our own particles.
     */
    assert(msr->pMap[0] == 0);
    pkdOutArray(plcl->pkd,achOutFile,iType); 
    for (i=1;i<msr->nThreads;++i) {
	id = msr->pMap[i];
	/* 
	 * Swap particles with the remote processor.
	 */
	inswap = 0;
	mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	pkdSwapAll(plcl->pkd, id);
	mdlGetReply(pst0->mdl,id,NULL,NULL);
	/* 
	 * Write the swapped particles.
	 */
	pkdOutArray(plcl->pkd,achOutFile,iType); 
	/* 
	 * Swap them back again.
	 */
	inswap = 0;
	mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	pkdSwapAll(plcl->pkd, id);
	mdlGetReply(pst0->mdl,id,NULL,NULL);
	}
    }


void msrOutVector(MSR msr,char *pszFile,int iType)
    {
    struct inOutVector in;
    char achOutFile[PST_FILENAME_SIZE];
    LCL *plcl;
    PST pst0;
    FILE *fp;
    int id,i;
    int inswap;
    int iDim;

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    if (pszFile) {
	/*
	** Add Data Subpath for local and non-local names.
	*/
	_msrMakePath(msr->param.achDataSubPath,pszFile,in.achOutFile);
	/*
	** Add local Data Path.
	*/
	_msrMakePath(plcl->pszDataPath,in.achOutFile,achOutFile);
	fp = fopen(achOutFile,"w");

	if (!fp) {
	    printf("Could not open Vector Output File:%s\n",achOutFile);
	    _msrExit(msr,1);
	    }
	}
    else {
	printf("No Vector Output File specified\n");
	_msrExit(msr,1);
	return;
	}
    /*
    ** Write the Header information and close the file again.
    */
    fprintf(fp,"%d\n",msr->N);
    fclose(fp);

    /* 
     * First write our own particles.
     */
    assert(msr->pMap[0] == 0);
    for (iDim=0;iDim<3;++iDim) {
	pkdOutVector(plcl->pkd,achOutFile,iDim,iType); 
	for (i=1;i<msr->nThreads;++i) {
	    id = msr->pMap[i];
	    /* 
	     * Swap particles with the remote processor.
	     */
	    inswap = 0;
	    mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	    pkdSwapAll(plcl->pkd, id);
	    mdlGetReply(pst0->mdl,id,NULL,NULL);
	    /* 
	     * Write the swapped particles.
	     */
	    pkdOutVector(plcl->pkd,achOutFile,iDim,iType); 
	    /* 
	     * Swap them back again.
	     */
	    inswap = 0;
	    mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
	    pkdSwapAll(plcl->pkd,id);
	    mdlGetReply(pst0->mdl,id,NULL,NULL);
	    }
	}
    }


void msrSmooth(MSR msr,double dTime,int iSmoothType,int bGasOnly,
	       int bSymmetric, int eParticleTypes)
    {
    struct inSmooth in;

    /*
    ** Make sure that the type of tree is a density binary tree!
    */
    in.nSmooth = msr->param.nSmooth;
    in.bGasOnly = bGasOnly;
    in.bPeriodic = msr->param.bPeriodic;
    in.bSymmetric = bSymmetric;
    in.iSmoothType = iSmoothType;
    in.eParticleTypes = eParticleTypes;
#ifdef sm2d
    in.smf.TYPE_PBHYB = msr->TYPE_PBHYB;
    in.smf.dDPBHYB = msr->dDPBHYB;
#endif
    if (msrComove(msr)) {
	in.smf.H = csmTime2Hub(msr->param.csm,dTime);
	in.smf.a = csmTime2Exp(msr->param.csm,dTime);
	}
    else {
	in.smf.H = 0.0;
	in.smf.a = 1.0;
	}
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("Smoothing...\n");
	sec = msrTime();
	pstSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	dsec = msrTime() - sec;
	printf("Smooth Calculated, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	}
    }


void msrReSmooth(MSR msr,double dTime,int iSmoothType,int bGasOnly,
		 int bSymmetric,int eParticleTypes)
    {
    struct inReSmooth in;

    /*
    ** Make sure that the type of tree is a density binary tree!
    */
    in.nSmooth = msr->param.nSmooth;
    in.bGasOnly = bGasOnly;
    in.bPeriodic = msr->param.bPeriodic;
    in.bSymmetric = bSymmetric;
    in.iSmoothType = iSmoothType;
    in.eParticleTypes = eParticleTypes;
    if (msrComove(msr)) {
	in.smf.H = csmTime2Hub(msr->param.csm,dTime);
	in.smf.a = csmTime2Exp(msr->param.csm,dTime);
	}
    else {
	in.smf.H = 0.0;
	in.smf.a = 1.0;
	}
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("ReSmoothing...\n");
	sec = msrTime();
	pstReSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	dsec = msrTime() - sec;
	printf("ReSmooth Calculated, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstReSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	}
    }

void msrUpdateSoft(MSR msr,double dTime) {
#ifdef CHANGESOFT
    if (!(msr->param.bPhysicalSoft || msr->param.bVariableSoft)) return;
    if (msr->param.bPhysicalSoft) {
	struct inPhysicalSoft in;

	in.dFac = 1./csmTime2Exp(msr->param.csm,dTime);
	in.bSoftMaxMul = msr->param.bSoftMaxMul;
	in.dSoftMax = msr->param.dSoftMax;

	if (msr->param.bSoftMaxMul && in.dFac > in.dSoftMax) in.dFac = in.dSoftMax;

	pstPhysicalSoft(msr->pst,&in,sizeof(in),NULL,NULL);
	}
    else {
	struct inPostVariableSoft inPost;
	int bSymmetric = 0;
	int bGasOnly;

	pstPreVariableSoft(msr->pst,NULL,0,NULL,NULL);

	if (msr->param.bSoftByType) {
	    if (msr->nDark) {
		msrBuildTree(msr,-1.0,dTime);
		bGasOnly = 0;
		assert(0); /* can't do this yet! */
		msrSmooth(msr,dTime,SMX_NULL,bGasOnly,bSymmetric,TYPE_DARK);
		}
	    if (msr->nGas) {
		msrBuildTree(msr,-1.0,dTime);
		bGasOnly = 1;
		msrSmooth(msr,dTime,SMX_NULL,bGasOnly,bSymmetric,TYPE_GAS);
		}
	    if (msr->nStar) {
		msrBuildTree(msr,-1.0,dTime);
		bGasOnly = 0;
		assert(0); /* can't do this yet! */
		msrSmooth(msr,dTime,SMX_NULL,bGasOnly,bSymmetric,TYPE_STAR);
		}
	    }
	else {
	    msrBuildTree(msr,-1.0,dTime);
	    bGasOnly = 0;
	    msrSmooth(msr,dTime,SMX_NULL,bGasOnly,bSymmetric,TYPE_ALL);
	    }

	inPost.dSoftMax = msr->param.dSoftMax;
	inPost.bSoftMaxMul = msr->param.bSoftMaxMul;
	pstPostVariableSoft(msr->pst,&inPost,sizeof(inPost),NULL,NULL);
	}
#endif
    }

#define PRINTGRID(FRM,VAR) {\
    printf("      % 8d % 8d % 8d % 8d % 8d % 8d % 8d % 8d % 8d % 8d\n",0,1,2,3,4,5,6,7,8,9);\
    for (i=0;i<msr->nThreads/10;++i) {\
	printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
	       out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR,\
	       out[i*10+5].VAR,out[i*10+6].VAR,out[i*10+7].VAR,out[i*10+8].VAR,out[i*10+9].VAR);\
	}\
    switch (msr->nThreads%10) {\
    case 0: break;\
    case 1: printf("%4d: "FRM"\n",i*10,\
		   out[i*10+0].VAR); break;\
    case 2: printf("%4d: "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR); break;\
    case 3: printf("%4d: "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR); break;\
    case 4: printf("%4d: "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR); break;\
    case 5: printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR); break;\
    case 6: printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR,\
		   out[i*10+5].VAR); break;\
    case 7: printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR,\
		   out[i*10+5].VAR,out[i*10+6]); break;\
    case 8: printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR,\
		   out[i*10+5].VAR,out[i*10+6].VAR,out[i*10+7].VAR); break;\
    case 9: printf("%4d: "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM" "FRM"\n",i*10,\
		   out[i*10+0].VAR,out[i*10+1].VAR,out[i*10+2].VAR,out[i*10+3].VAR,out[i*10+4].VAR,\
		   out[i*10+5].VAR,out[i*10+6].VAR,out[i*10+7].VAR,out[i*10+8].VAR); break;\
    }\
}

void msrGravity(MSR msr,double dTime,double dStep,int bEwald,int bEwaldKick,
		int *piSec,double *pdWMax,double *pdIMax,
		double *pdEMax,int *pnActive) {
    struct inGravity in;
    struct outGravity *out;
    int i,id,iDum;
    double sec,dsec,dTotFlop;

    if (msr->param.bVStep) printf("Calculating Gravity, Step:%f\n",dStep);
    in.dTime = dTime;
    in.nReps = msr->param.nReplicas;
    in.bPeriodic = msr->param.bPeriodic;
    in.bEwald = bEwald;
    in.bEwaldKick = bEwaldKick;
    in.dEwCut = msr->param.dEwCut;
    in.dEwhCut = msr->param.dEwhCut;

    out = malloc(msr->nThreads*sizeof(struct outGravity));
    assert(out != NULL);
    
    sec = msrTime();
    pstGravity(msr->pst,&in,sizeof(in),out,&iDum);
    dsec = msrTime() - sec;

    *piSec = dsec;
    if (msr->param.bVStep) {
	/*
	** Output some info...
	*/
	dTotFlop = 0.0;
	for (id=0;id<msr->nThreads;++id) {
	    dTotFlop += out[id].dFlop;
	    if (out[id].nActive > 0) {
		out[id].dPartSum /= out[id].nActive;
		out[id].dCellSum /= out[id].nActive;
	    }
	}

	if(dsec > 0.0) {
	    double dGFlops = dTotFlop/dsec*1e-9;
	    printf("Gravity Calculated, Wallclock: %f secs, GFlops:%.1f, Flop:%.3g\n",
		   dsec,dGFlops,dTotFlop);
	}
	else {
	    printf("Gravity Calculated, Wallclock: %f secs, GFlops:unknown, Flop:%.3g\n",
		   dsec,dTotFlop);
	}
	/*
	** Now comes the really verbose output for each processor.
	*/
	//111116
	/*	printf("Walk Timings:\n");
	PRINTGRID("% 8.2f",dWalkTime);
	printf("Number of Active:\n");
	PRINTGRID("% 8d",nActive);
	printf("Average Number of P-P per Active Particle:\n");
	PRINTGRID("% 8.1f",dPartSum);
	printf("Average Number of P-C per Active Particle:\n");
	PRINTGRID("% 8.1f",dCellSum);*/
    }
    free(out);
}


void msrCalcEandL(MSR msr,int bFirst,double dTime,double *E,double *T,
		  double *U,double *Eth,double L[])
    {
    struct outCalcEandL out;
    double a;
    int k;

    pstCalcEandL(msr->pst,NULL,0,&out,NULL);
    *T = out.T;
    *U = out.U;
    *Eth = out.Eth;
    for (k=0;k<3;k++) L[k] = out.L[k];
    /*
    ** Do the comoving coordinates stuff.
    ** Currently L is not adjusted for this. Should it be?
    */
    a = csmTime2Exp(msr->param.csm,dTime);
    if (!msr->param.bCannonical) *T *= pow(a,4.0);
    /*
     * Estimate integral (\dot a*U*dt) over the interval.
     * Note that this is equal to integral (W*da) and the latter
     * is more accurate when a is changing rapidly.
     */
    if (msr->param.csm->bComove && !bFirst) {
	msr->dEcosmo += 0.5*(a - csmTime2Exp(msr->param.csm, msr->dTimeOld))
	    *((*U) + msr->dUOld);
	}
    else {
	msr->dEcosmo = 0.0;
	}
    msr->dTimeOld = dTime;
    msr->dUOld = *U;
    *U *= a;
    *E = (*T) + (*U) - msr->dEcosmo + a*a*(*Eth);
    }


void msrDrift(MSR msr,double dTime,double dDelta)
    {
    struct inDrift in;
    int j;

    if (msr->param.bCannonical) {
	in.dDelta = csmComoveDriftFac(msr->param.csm,dTime,dDelta);
	}
    else {
	in.dDelta = dDelta;
	}
    for (j=0;j<3;++j) {
	in.fCenter[j] = msr->fCenter[j];
	}
    in.bPeriodic = msr->param.bPeriodic;
    in.fCentMass = msr->param.dCentMass;
#ifdef PLANETS
    in.fCentMass = msr->dSunMass;
#endif

    in.dTime = dTime;
    pstDrift(msr->pst,&in,sizeof(in),NULL,NULL);
    }

void msrDriftInactive(MSR msr,double dTime,double dDelta)
    {
    struct inDrift in;
    int j;

    if (msr->param.bCannonical) {
	in.dDelta = csmComoveDriftFac(msr->param.csm,dTime,dDelta);
	}
    else {
	in.dDelta = dDelta;
	}
    for (j=0;j<3;++j) {
	in.fCenter[j] = msr->fCenter[j];
	}
    in.dTime = dTime;
    in.bPeriodic = msr->param.bPeriodic;
    in.fCentMass = msr->param.dCentMass;
#ifdef PLANETS
    in.fCentMass = msr->dSunMass;
#endif
    pstDriftInactive(msr->pst,&in,sizeof(in),NULL,NULL);
    }

/*
 * For gasoline, updates predicted velocities to beginning of timestep.
 */
void msrKickKDKOpen(MSR msr,double dTime,double dDelta)
    {
    double H,a;
    struct inKick in;
    struct outKick out;
	
    if (msr->param.bCannonical) {
	in.dvFacOne = 1.0;		/* no hubble drag, man! */
	in.dvFacTwo = csmComoveKickFac(msr->param.csm,dTime,dDelta);
	}
    else {
	/*
	** Careful! For non-cannonical we want H and a at the 
	** HALF-STEP! This is a bit messy but has to be special
	** cased in some way.
	*/
	dTime += dDelta/2.0;
	a = csmTime2Exp(msr->param.csm,dTime);
	H = csmTime2Hub(msr->param.csm,dTime);
	in.dvFacOne = (1.0 - H*dDelta)/(1.0 + H*dDelta);
	in.dvFacTwo = dDelta/pow(a,3.0)/(1.0 + H*dDelta);
	}
    if (msr->param.bAntiGrav) {
	in.dvFacTwo = -in.dvFacTwo;
	in.dvPredFacTwo = -in.dvPredFacTwo;
	}
    pstKick(msr->pst,&in,sizeof(in),&out,NULL);
    if (msr->param.bVDetails)
	printf("KickOpen: Avg Wallclock %f, Max Wallclock %f\n",
	       out.SumTime/out.nSum,out.MaxTime);
    }

/*
 * For gasoline, updates predicted velocities to end of timestep.
 */
void msrKickKDKClose(MSR msr,double dTime,double dDelta)
    {
    double H,a;
    struct inKick in;
    struct outKick out;
	
    if (msr->param.bCannonical) {
	in.dvFacOne = 1.0; /* no hubble drag, man! */
	in.dvFacTwo = csmComoveKickFac(msr->param.csm,dTime,dDelta);
	}
    else {
	/*
	** Careful! For non-cannonical we want H and a at the 
	** HALF-STEP! This is a bit messy but has to be special
	** cased in some way.
	*/
	dTime += dDelta/2.0;
	a = csmTime2Exp(msr->param.csm,dTime);
	H = csmTime2Hub(msr->param.csm,dTime);
	in.dvFacOne = (1.0 - H*dDelta)/(1.0 + H*dDelta);
	in.dvFacTwo = dDelta/pow(a,3.0)/(1.0 + H*dDelta);
	}
    if (msr->param.bAntiGrav) {
	in.dvFacTwo = -in.dvFacTwo;
	in.dvPredFacTwo = -in.dvPredFacTwo;
	}
    pstKick(msr->pst,&in,sizeof(in),&out,NULL);
    if (msr->param.bVDetails)
	printf("KickClose: Avg Wallclock %f, Max Wallclock %f\n",
	       out.SumTime/out.nSum,out.MaxTime);
    }


void msrEwaldKick(MSR msr,double dTime,double dDelta)
    {
    double H,a;
    struct inEwaldKick in;
	
    if (msr->param.bCannonical) {
	in.dvFacOne = 1.0;		/* no hubble drag, man! */
	in.dvFacTwo = csmComoveKickFac(msr->param.csm,dTime,dDelta);
	}
    else {
	/*
	** Careful! For non-cannonical we want H and a at the 
	** HALF-STEP! This is a bit messy but has to be special
	** cased in some way.
	*/
	dTime += dDelta/2.0;
	a = csmTime2Exp(msr->param.csm,dTime);
	H = csmTime2Hub(msr->param.csm,dTime);
	in.dvFacOne = (1.0 - H*dDelta)/(1.0 + H*dDelta);
	in.dvFacTwo = dDelta/pow(a,3.0)/(1.0 + H*dDelta);
	}
    pstEwaldKick(msr->pst,&in,sizeof(in),NULL,NULL);
    }


int msrOutTime(MSR msr,double dTime)
    {	
    if (msr->iOut < msr->nOuts) {
	if (dTime >= msr->pdOutTime[msr->iOut]) {
	    ++msr->iOut;
	    return(1);
	    }
	else return(0);
	}
    else return(0);
    }


int cmpTime(const void *v1,const void *v2) 
    {
    double *d1 = (double *)v1;
    double *d2 = (double *)v2;

    if (*d1 < *d2) return(-1);
    else if (*d1 == *d2) return(0);
    else return(1);
    }

void msrReadOuts(MSR msr,double dTime)
    {
    char achFile[PST_FILENAME_SIZE];
    char ach[PST_FILENAME_SIZE];
    LCL *plcl = &msr->lcl;
    FILE *fp;
    int i,ret;
    double z,a,n;
    char achIn[80];
	
    /*
    ** Add Data Subpath for local and non-local names.
    */
    achFile[0] = 0;
    sprintf(achFile,"%s/%s.red",msr->param.achDataSubPath,
	    msr->param.achOutName);
    /*
    ** Add local Data Path.
    */
    if (plcl->pszDataPath) {
	strcpy(ach,achFile);
	sprintf(achFile,"%s/%s",plcl->pszDataPath,ach);
	}
    fp = fopen(achFile,"r");
    if (!fp) {
	msr->nOuts = 0;
	return;
	}
    i = 0;
    while (1) {
	if (!fgets(achIn,80,fp)) goto NoMoreOuts;
	switch (achIn[0]) {
	case 'z':
	    ret = sscanf(&achIn[1],"%lf",&z);
	    if (ret != 1) goto NoMoreOuts;
	    a = 1.0/(z+1.0);
	    msr->pdOutTime[i] = csmExp2Time(msr->param.csm,a);
	    break;
	case 'a':
	    ret = sscanf(&achIn[1],"%lf",&a);
	    if (ret != 1) goto NoMoreOuts;
	    msr->pdOutTime[i] = csmExp2Time(msr->param.csm,a);
	    break;
	case 't':
	    ret = sscanf(&achIn[1],"%lf",&msr->pdOutTime[i]);
	    if (ret != 1) goto NoMoreOuts;
	    break;
	case 'n':
	    ret = sscanf(&achIn[1],"%lf",&n);
	    if (ret != 1) goto NoMoreOuts;
	    msr->pdOutTime[i] = dTime + (n-0.5)*msrDelta(msr);
	    break;
	default:
	    ret = sscanf(achIn,"%lf",&z);
	    if (ret != 1) goto NoMoreOuts;
	    a = 1.0/(z+1.0);
	    msr->pdOutTime[i] = csmExp2Time(msr->param.csm,a);
	    }
	++i;
	if(i > msr->nMaxOuts) {
	    msr->nMaxOuts *= 2;
	    msr->pdOutTime = realloc(msr->pdOutTime,
				     msr->nMaxOuts*sizeof(double));
	    assert(msr->pdOutTime != NULL);
	    }
	}
    NoMoreOuts:
    msr->nOuts = i;
    /*
    ** Now sort the array of output times into ascending order.
    */
    qsort(msr->pdOutTime,msr->nOuts,sizeof(double),cmpTime);
    fclose(fp);
    }


uint64_t msrSteps(MSR msr)
    {
    return(msr->param.nSteps);
    }

char *msrOutName(MSR msr)
    {
    return(msr->param.achOutName);
    }


char *msrBuildName(MSR msr,char *achFile,uint64_t iStep)
{
    char achOutPath[256], *p;
    int n;

    if ( msr->param.achOutPath[0] ) {
	strcpy( achOutPath, msr->param.achOutPath );
	p = strstr( achOutPath, "&N" );
	if ( p ) {
	    n = p - achOutPath;
	    strcpy( p, msrOutName(msr) );
	    strcat( p+2, msr->param.achOutPath + n + 2 );
	}
    }
    else {
	strcpy(achOutPath,msrOutName(msr));
    }

    p = strstr( achOutPath, "&S" );
    if ( p ) {
	n = p - achOutPath;
	strncpy( achFile, achOutPath, n );
	achFile += n;
	sprintf( achFile, "%"PRIu64, iStep );
	strcat( achFile, p+2 );
    }
    else {
	sprintf(achFile,msr->param.achDigitMask,msrOutName(msr),iStep);
    }
    return achFile;
}

double msrDelta(MSR msr)
    {
    return(msr->param.dDelta);
    }


int msrLogInterval(MSR msr)
    {
    return(msr->param.iLogInterval);
    }


int msrOutInterval(MSR msr)
    {
    return(msr->param.iOutInterval);
    }


const char *msrOutTypes(MSR msr)
    {
    return(msr->param.achOutTypes);
    }


int msrCheckInterval(MSR msr)
    {
    return(msr->param.iCheckInterval);
    }


const char *msrCheckTypes(MSR msr)
    {
    return(msr->param.achCheckTypes);
    }


int msrComove(MSR msr)
    {
    return(msr->param.csm->bComove);
    }


double msrSoft(MSR msr)
    {
    return(msr->param.dSoft);
    }


void msrSwitchTheta(MSR msr,double dTime)
    {
    double a;

    a = csmTime2Exp(msr->param.csm,dTime);
    if (a >= msr->param.daSwitchTheta) msr->dCrit = msr->param.dTheta2; 
    }


void
msrInitStep(MSR msr) {
    struct inSetRung insr;
    struct inInitStep in;

    /*
    ** Here we can pass down all parameters of the simulation
    ** before any timestepping takes place. This should happen 
    ** just after the file has been read and the PKD structure
    ** initialized for each processor.
    */
    in.param = msr->param;
    in.csm = *msr->param.csm;
    pstInitStep(msr->pst, &in, sizeof(in), NULL, NULL);
    
    /*
    ** Initialize particles to lowest rung. (what for?)
    */
    // insr.iRung = msr->param.iMaxRung - 1; modified to 0 021417
    insr.iRung = 0;
    pstSetRung(msr->pst, &insr, sizeof(insr), NULL, NULL);
    msr->iCurrMaxRung = insr.iRung;

#ifdef PLANETS
    struct outGetnMaxOrgIdx outg;  
    pstGetnMaxOrgIdx(msr->pst, NULL, 0, &outg,NULL); 
    msr->nMaxOrgIdx = outg.nMaxOrgIdx;
    printf("N = %d MaxOrgIdx %d \n",msr->N,msr->nMaxOrgIdx);
#endif

#ifdef gaptable

   GASDISK_PARAMS *GP = &msr->param.GP;	 
   if(GP->iGasModel == 5){/* read gap table*/
     FILE *fgap;
     int ng;	  
     GAP_TABLE GT;
     double ju1; /*unused */
     struct inGapTable ing;
    
     fgap = fopen("nu4.dat","r");
     
     for(ng=0; ng<1746; ng++){	      
       fscanf(fgap, "%lf %lf %lf %lf\n",&(GT.r[ng]),&ju1,&(GT.rsig[ng]),&(GT.p[ng]));
       /*printf("ng %d, %e %e %e \n",ng, GT.r[ng],GT.rsig[ng],GT.p[ng]);*/
     }
         
     ing.GT = GT;        
     pstGapTable(msr->pst, &ing, sizeof(ing), NULL, NULL);     
 
   }
#endif

    }


void
msrSetRung(MSR msr, int iRung)
    {
    struct inSetRung in;

    in.iRung = iRung;
    pstSetRung(msr->pst, &in, sizeof(in), NULL, NULL);
    msr->iCurrMaxRung = in.iRung;
    }


int msrMaxRung(MSR msr)
    {
    return msr->param.iMaxRung;
    }


int msrCurrMaxRung(MSR msr)
    {
    return msr->iCurrMaxRung;
    }


double msrEta(MSR msr)
    {
    return msr->param.dEta;
    }

/*
 * bGreater = 1 => activate all particles at this rung and greater.
 */
void msrActiveRung(MSR msr, int iRung, int bGreater) {
    struct inActiveRung in;

    in.iRung = iRung;
    in.bGreater = bGreater;
    pstActiveRung(msr->pst, &in, sizeof(in), NULL, NULL);

    if ( iRung==0 && bGreater )
	msr->nActive = msr->N;
    else {
	int i;

	assert( msr->nRung != NULL );

	msr->nActive = 0;
	for( i=iRung; i<= (bGreater?msr->param.iMaxRung:iRung); i++ )
	    msr->nActive += msr->nRung[i];
    }
}

void msrActiveOrder(MSR msr)
    {
    pstActiveOrder(msr->pst,NULL,0,&(msr->nActive),NULL);
    }

void msrSetRungVeryActive(MSR msr, int iRung) 
    {
    struct inSetRung in;

    msr->iRungVeryActive = iRung;

    in.iRung = iRung;
    pstSetRungVeryActive(msr->pst,&in,sizeof(in),NULL,NULL);
    }

int msrCurrRung(MSR msr, int iRung)
    {
    struct inCurrRung in;
    struct outCurrRung out;

    in.iRung = iRung;
    pstCurrRung(msr->pst, &in, sizeof(in), &out, NULL);
    return out.iCurrent;
    }

void
msrGravStep(MSR msr,double dTime)
    {
    struct inGravStep in;
    double expand;

    in.dEta = msrEta(msr);
    expand = csmTime2Exp(msr->param.csm,dTime);
    in.dRhoFac = 1.0/(expand*expand*expand);
    pstGravStep(msr->pst,&in,sizeof(in),NULL,NULL);
    }

void
msrAccelStep(MSR msr,double dTime)
    {
    struct inAccelStep in;
    double a;

    in.dEta = msrEta(msr);
    a = csmTime2Exp(msr->param.csm,dTime);
    if (msr->param.bCannonical) {
	in.dVelFac = 1.0/(a*a);
	}
    else {
	in.dVelFac = 1.0;
	}
    in.dAccFac = 1.0/(a*a*a);
    in.bDoGravity = msrDoGravity(msr);
    in.bEpsAcc = msr->param.bEpsAccStep;
    in.bSqrtPhi = msr->param.bSqrtPhiStep;
    pstAccelStep(msr->pst,&in,sizeof(in),NULL,NULL);
    }

void
msrDensityStep(MSR msr,double dTime,int eParticleTypes)
    {
    struct inDensityStep in;
    double expand;
    int bGasOnly,bSymmetric;

    if (msr->param.bVDetails) printf("Calculating Rung Densities...\n");
    bGasOnly = 0;
    bSymmetric = 0;
    msrSmooth(msr,dTime,SMX_DENSITY,bGasOnly,bSymmetric,eParticleTypes);
    in.dEta = msrEta(msr);
    expand = csmTime2Exp(msr->param.csm,dTime);
    in.dRhoFac = 1.0/(expand*expand*expand);
    pstDensityStep(msr->pst,&in,sizeof(in),NULL,NULL);
    }

void
msrInitDt(MSR msr)
    {
    struct inInitDt in;
    
    in.dDelta = msrDelta(msr);
    pstInitDt(msr->pst,&in,sizeof(in),NULL,NULL);
    }

/*
** Returns the Very Active rung based on the number of very active particles desired,
** or the fixed rung that was specified in the parameters.
*/
int msrDtToRung(MSR msr, int iRung, double dDelta, int bAll) {
    struct inDtToRung in;
    struct outDtToRung out;
    int iTempRung,iOutMaxRung,iRungVeryActive,sum;
    char c;

    in.iRung = iRung;
    in.dDelta = dDelta;
    in.iMaxRung = msrMaxRung(msr);
    in.bAll = bAll;

    pstDtToRung(msr->pst, &in, sizeof(in), &out, NULL);

    iTempRung =msrMaxRung(msr)-1;
    while (out.nRungCount[iTempRung] == 0 && iTempRung > 0) --iTempRung;
    iOutMaxRung = iTempRung;

    while (out.nRungCount[iOutMaxRung] <= msr->param.nTruncateRung && iOutMaxRung > iRung) {
	if (msr->param.bVDetails) printf("n_CurrMaxRung = %d  (iCurrMaxRung = %d):  Promoting particles to iCurrMaxrung = %d\n",
					 out.nRungCount[iOutMaxRung],iOutMaxRung,iOutMaxRung-1);

	in.iMaxRung = iOutMaxRung; /* Note this is the forbidden rung so no -1 here */
	pstDtToRung(msr->pst, &in, sizeof(in), &out, NULL);

	iTempRung =msrMaxRung(msr)-1;
	while (out.nRungCount[iTempRung] == 0 && iTempRung > 0) --iTempRung;
	iOutMaxRung = iTempRung;
	}
    /*
    ** Now copy the rung distribution to the msr structure!
    */
    for (iTempRung=0;iTempRung < msrMaxRung(msr);++iTempRung) msr->nRung[iTempRung] = out.nRungCount[iTempRung];
    /*
    ** Now we want to make a suggestion for the current very active rung based on the number of 
    ** particles in the deepest rungs.
    */
    if (msr->param.nPartVeryActive > 0) {
	iRungVeryActive = msrMaxRung(msr);
	sum = 0;
	while (sum < msr->param.nPartVeryActive && iRungVeryActive > 0) {
	    sum += out.nRungCount[--iRungVeryActive];
	    }
	}
    else {
	iRungVeryActive = msr->param.nRungVeryActive;
	}
	
    msr->iCurrMaxRung = iOutMaxRung;

    if (msr->param.bVRungStat) {
    	printf("Rung distribution:\n");
	for (iTempRung=0;iTempRung <= msr->iCurrMaxRung;++iTempRung) {
	    if (out.nRungCount[iTempRung] == 0) continue;
	    if (iTempRung > iRungVeryActive) c = 'v';
	    else c = ' ';
	    printf(" %c rung:%d %d\n",c,iTempRung,out.nRungCount[iTempRung]);
	    }
	printf("\n");
	}
    
    /*
     * Set VeryActive particles
     */
    msrSetRungVeryActive(msr, iRungVeryActive);
    return(iRungVeryActive);
    }


void msrTopStepKDK(MSR msr,
		   double dStep,	/* Current step */
		   double dTime,	/* Current time */
		   double dDelta,	/* Time step */
		   int iRung,		/* Rung level */
		   int iKickRung,	/* Gravity on all rungs from iRung
					   to iKickRung */
		   int iRungVeryActive,  /* current setting for iRungVeryActive */
		   /*
		   ** Note that iRungVeryActive is one less than the first rung with VA particles!
		   */
		   int iAdjust,		/* Do an adjust? */
		   double *pdActiveSum,
		   double *pdWMax,
		   double *pdIMax,
		   double *pdEMax,
		   int *piSec)
    {
    double dMass = -1.0;
    int nActive;
    int bSplitVA;
    int bEwald;
    int bEwaldKick;

    if(iAdjust && (iRung < msrMaxRung(msr)-1)) {
	if (msr->param.bVDetails) {
	    printf("%*cAdjust, iRung: %d\n",2*iRung+2,' ',iRung);
	    }
	msrActiveRung(msr, iRung, 1);
	msrInitDt(msr);
	if (msr->param.bGravStep) {
	    msrGravStep(msr,dTime);
	    }
	if (msr->param.bAccelStep) {
	    msrAccelStep(msr,dTime);
	    }
	if (msr->param.bDensityStep) {
	    bSplitVA = 0;
	    msrDomainDecomp(msr,iRung,1,bSplitVA);
	    msrActiveRung(msr,iRung,1);
	    msrBuildTree(msr,dMass,dTime);
	    msrDensityStep(msr,dTime,TYPE_ALL);
	    }
	iRungVeryActive = msrDtToRung(msr,iRung,dDelta,1);
	}
    if (msr->param.bVDetails) {
	printf("%*cmsrKickOpen  at iRung: %d 0.5*dDelta: %g\n",
	       2*iRung+2,' ',iRung,0.5*dDelta);
	}
    msrActiveRung(msr,iRung,0); /* EXACT */
    msrKickKDKOpen(msr,dTime,0.5*dDelta);
    if ((msrCurrMaxRung(msr) > iRung) && (iRungVeryActive > iRung)) {
	/*
	** Recurse.
	*/
	msrTopStepKDK(msr,dStep,dTime,0.5*dDelta,iRung+1,iRung+1,iRungVeryActive,0,
		      pdActiveSum,pdWMax,pdIMax,pdEMax,piSec);
	dTime += 0.5*dDelta;
	dStep += 1.0/(2 << iRung);
	msrActiveRung(msr,iRung,0); /* EXACT */
	msrTopStepKDK(msr,dStep,dTime,0.5*dDelta,iRung+1,iKickRung,iRungVeryActive,1,
		      pdActiveSum,pdWMax,pdIMax,pdEMax,piSec);
	}
    else if(msrCurrMaxRung(msr) == iRung) {
	/* This Drifts everybody */
	if (msr->param.bVDetails) {
	    printf("%*cDrift, iRung: %d\n",2*iRung+2,' ',iRung);
	    }
	msrDrift(msr,dTime,dDelta);
	dTime += dDelta;
	dStep += 1.0/(1 << iRung);

	msrActiveRung(msr,iKickRung,1);
	bSplitVA = 0;
	msrDomainDecomp(msr,iKickRung,1,bSplitVA);

	if(msrDoGravity(msr)) {
	    msrActiveRung(msr,iKickRung,1);
	    msrUpdateSoft(msr,dTime);
	    if (msr->param.bVDetails) {
		printf("%*cGravity, iRung: %d to %d\n",2*iRung+2,' ',iKickRung,iRung);
		}
	    msrBuildTree(msr,dMass,dTime);
	    /*
	    ** The following code decides how the periodic BCs should be handled.
	    ** If bEwaldKicking is set then the code does an efficient strategy to 
	    ** incorporate periodic boundaries for volume renormalized runs.
	    */
	    if (msr->param.bEwaldKicking) {
		if (iKickRung == 0) {
		    bEwaldKick = 1;
		    bEwald = 1;
		}
		else {
		    bEwaldKick = 0;
		    bEwald = 0;
		}
	    }
	    else {
		bEwaldKick = 0;
		bEwald = msr->param.bEwald;
	    }

	    msrGravity(msr,dTime,dStep,bEwald,bEwaldKick,piSec,pdWMax,pdIMax,pdEMax,&nActive);
	    *pdActiveSum += (double)nActive/msr->N;
	    }

#ifdef PLANETS
	/* Sun's direct and indirect gravity */
	if(msr->param.bHeliocentric) {
	  msrGravSun(msr);
	    }
#endif
	/*
	 * move time back to 1/2 step so that KickClose can integrate
	 * from 1/2 through the timestep to the end.
	 */
	dTime -= 0.5*dDelta;
	}
    else {
	double dDeltaTmp;
	int i;
	
	/*
	 * We have more rungs to go, but we've hit the very active limit.
	 */
	/*
	 * Activate VeryActives
	 */
	msrActiveRung(msr,msr->iRungVeryActive+1,1);

	/*
	 * Drift the non-VeryActive particles forward 1/2 timestep
	 */
	if (msr->param.bVDetails) {
	    printf("%*cInActiveDrift at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	msrDriftInactive(msr, dTime, 0.5*dDelta);
	/*
	 * Build a tree out of them for use by the VeryActives
	 */
	if(msrDoGravity(msr)) {
	    msrUpdateSoft(msr,dTime + 0.5*dDelta);
	    /*
	    ** Domain decomposition for parallel exclude very active is going to be 
	    ** placed here shortly.
	    */
	    bSplitVA = 1;
	    msrDomainDecomp(msr,iRung,1,bSplitVA);

	    if (msr->param.bVDetails) {
		printf("%*cBuilding exclude very active tree: iRung: %d\n",
		       2*iRung+2,' ',iRung);
		}
	    msrBuildTreeExcludeVeryActive(msr,dMass,dTime + 0.5*dDelta);
	    }
	/*
	 * Perform timestepping on individual processors.
	 */
	msrStepVeryActiveKDK(msr, dStep, dTime, dDelta, iRung);
	dTime += dDelta;
	dStep += 1.0/(1 << iRung);
	/*
	 * Move Inactives to the end of the step.
	 */
	if (msr->param.bVDetails) {
	    printf("%*cInActiveDrift at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	msrActiveRung(msr,msr->iRungVeryActive+1,1);
	/* 
	** The inactives are half time step behind the actives. 
	** Move them a half time step ahead to synchronize everything again.
	*/
	msrDriftInactive(msr, dTime - 0.5*dDelta, 0.5*dDelta);

	/*
	 * Regular Tree gravity
	 */
	msrActiveRung(msr,iKickRung,1);
	bSplitVA = 0;
	msrDomainDecomp(msr,iKickRung,1,bSplitVA);

	if(msrDoGravity(msr)) {
	    msrActiveRung(msr,iKickRung,1);
	    msrUpdateSoft(msr,dTime);
	    if (msr->param.bVDetails) {
		printf("%*cGravity, iRung: %d to %d\n",
		       2*iRung+2,' ',iKickRung,msrCurrMaxRung(msr));
		}
	    msrBuildTree(msr,dMass,dTime);
	    /*
	    ** The following code decides how the periodic BCs should be handled.
	    ** If bEwaldKicking is set then the code does an efficient strategy to 
	    ** incorporate periodic boundaries for volume renormalized runs.
	    */
	    if (msr->param.bEwaldKicking) {
		if (iKickRung == 0) {
		    bEwaldKick = 1;
		    bEwald = 1;
		}
		else {
		    bEwaldKick = 0;
		    bEwald = 0;
		}
	    }
	    else {
		bEwaldKick = 0;
		bEwald = msr->param.bEwald;
	    }

	    msrGravity(msr,dTime,dStep,bEwald,bEwaldKick,piSec,pdWMax,pdIMax,pdEMax,&nActive);
	    *pdActiveSum += (double)nActive/msr->N;
	    }

#ifdef PLANETS
	/* Sun's direct and indirect gravity */
	if(msr->param.bHeliocentric) {
	  msrGravSun(msr);
	    }
#endif

	dDeltaTmp = dDelta;
	for(i = msrCurrMaxRung(msr); i > iRung; i--)
	    dDeltaTmp *= 0.5;
	
	for(i = msrCurrMaxRung(msr); i > iRung; i--) { /* close off all
							 the VeryActive Kicks
						      */
	    if (msr->param.bVDetails) {
		printf("%*cVeryActive msrKickClose at iRung: %d, 0.5*dDelta: %g\n",
		       2*iRung+2,' ',i, 0.5*dDeltaTmp);
		}
	    msrActiveRung(msr,i,0); /* EXACT */
	    msrKickKDKClose(msr,dTime - 0.5*dDeltaTmp,0.5*dDeltaTmp);
	    dDeltaTmp *= 2.0;
	    }
	/*
	 * move time back to 1/2 step so that KickClose can integrate
	 * from 1/2 through the timestep to the end.
	 */
	dTime -= 0.5*dDelta;
	}
    
    if (msr->param.bVDetails) {
	printf("%*cKickClose, iRung: %d, 0.5*dDelta: %g\n",
	       2*iRung+2,' ',iRung, 0.5*dDelta);
	}
    msrActiveRung(msr,iRung,0); /* EXACT */
    msrKickKDKClose(msr,dTime,0.5*dDelta);
    }

void
msrStepVeryActiveKDK(MSR msr, double dStep, double dTime, double dDelta,
		     int iRung)
    {
    struct inStepVeryActive in;
    struct outStepVeryActive out;
    
#ifdef PLANETS
    struct inSunIndirect ins;
    struct outSunIndirect outs;

    if(msr->param.bHeliocentric){
      int k;        

      ins.iFlag = 2; /* for inactive particles */ 
      pstSunIndirect(msr->pst,&ins,sizeof(ins),&outs,NULL); 
	for (k=0;k<3;k++){ 
        in.aSunInact[k] = outs.aSun[k];
	in.adSunInact[k] = outs.adSun[k];
	}
      }
#endif

    in.dStep = dStep;
    in.dTime = dTime;
    in.dDelta = dDelta;
    in.iRung = iRung;
    in.diCrit2 = 1/(msr->dCrit*msr->dCrit);   /* could set a stricter opening criterion here */
    in.nMaxRung = msrCurrMaxRung(msr);
#ifdef PLANETS 
    in.dSunMass = msr->dSunMass;
#endif
    /*
     * Start Particle Cache on all nodes (could be done as part of
     * tree build)
     */
    pstROParticleCache(msr->pst, NULL, 0, NULL, NULL);
    
    pstStepVeryActiveKDK(msr->pst, &in, sizeof(in), &out, NULL);
    /*
     * Finish Particle Cache on all nodes
     */
    pstParticleCacheFinish(msr->pst, NULL, 0, NULL, NULL);
    msr->iCurrMaxRung = out.nMaxRung;
    }

#ifdef HERMITE
void msrTopStepHermite(MSR msr,
				   double dStep,	/* Current step */
				   double dTime,	/* Current time */
				   double dDelta,	/* Time step */
				   int iRung,		/* Rung level */
				   int iKickRung,	/* Gravity on all rungs from iRung
									   to iKickRung */
		                   int iRungVeryActive,  /* current setting for iRungVeryActive */
				   int iAdjust,		/* Do an adjust? */
				   double *pdActiveSum,
				   double *pdWMax,
				   double *pdIMax,
				   double *pdEMax,
				   int *piSec)
{
    double dMass = -1.0;
    int nActive;
    int bSplitVA;

    if(iAdjust && (iRung < msrMaxRung(msr)-1)) {
        if (msr->param.bVDetails) {
	  printf("%*cAdjust, iRung: %d\n",2*iRung+2,' ',iRung);
           }
	msrActiveRung(msr, iRung, 1);
	msrInitDt(msr);
	if (msr->param.bGravStep) {
	    msrGravStep(msr,dTime);
	    }
	if (msr->param.bAarsethStep) {
	    msrAarsethStep(msr);
	    }
	if (msr->param.bAccelStep) {
	    msrAccelStep(msr,dTime);
	    }
	if (msr->param.bDensityStep) {
	    bSplitVA = 0;
	    msrDomainDecomp(msr,iRung,1,bSplitVA);
	    msrActiveRung(msr,iRung,1);
	    msrBuildTree(msr,dMass,dTime);
	    msrDensityStep(msr,dTime,TYPE_ALL);
	    }
	iRungVeryActive = msrDtToRung(msr,iRung,dDelta,1);
    }
	
    if ((msrCurrMaxRung(msr) > iRung) && (iRungVeryActive > iRung)) 
      {
		/*
		 ** Recurse.
		 */
		msrTopStepHermite(msr,dStep,dTime,0.5*dDelta,iRung+1,iRung+1,iRungVeryActive,0,
					  pdActiveSum,pdWMax,pdIMax,pdEMax,piSec);
		dTime += 0.5*dDelta;
		dStep += 1.0/(2 << iRung);
		/*msrActiveRung(msr,iRung,0);*/
		msrTopStepHermite(msr,dStep,dTime,0.5*dDelta,iRung+1,iKickRung,iRungVeryActive,1,
					  pdActiveSum,pdWMax,pdIMax,pdEMax,piSec);
		}
    else if(msrCurrMaxRung(msr) == iRung) {
   
                dTime += dDelta;
		dStep += 1.0/(1 << iRung);

         /* 
           This Predicts everybody 
           dt = dTime - dTime0(pkd)     
           x = x0 + v0*dt + 0.5*a0*dt*dt+ ad0*dt*dt*dt/6.0
           v = v0 + a0*dt + 0.5*ad0*dt*dt
          */
		if (msr->param.bVDetails){
		  printf("%*cPredict, iRung: %d\n",2*iRung+2,' ',iRung);                          
		}
                msrActiveRung(msr,0,1);/* activate everybody*/
                msrPredictor(msr,dTime);     
            
		msrActiveRung(msr,iKickRung,1);
		bSplitVA = 0;
		msrDomainDecomp(msr,iKickRung,1,bSplitVA);
	
		if(msrDoGravity(msr)) {
		  msrActiveRung(msr,iKickRung,1);
		  msrUpdateSoft(msr,dTime);
		  if (msr->param.bVDetails) {
		    printf("%*cGravity, iRung: %d to %d\n",2*iRung+2,' ',iKickRung,iRung);
		  }
		  msrBuildTree(msr,dMass,dTime);
		  msrGravity(msr,dTime,dStep,0,0,piSec,pdWMax,pdIMax,pdEMax,&nActive);
		  *pdActiveSum += (double)nActive/msr->N;
		}
#ifdef PLANETS
		/* Sun's direct and indirect gravity */
		if(msr->param.bHeliocentric) {
		  msrGravSun(msr);
		}
#endif                               
		 msrActiveRung(msr,iKickRung,1); /*just in case*/
		/* 
		  Corrector step 
		    (see Kokubo and Makino 2004 for the optimal coefficients) 
		     add = -6.D0*(a0-a)/(dt*dt)-2.0*(2.0*ad0+ad)/dt
                    addd = 12.0*(a0-a)/(dt*dt*dt)+6.0*(ad0+ad)/(dt*dt) 
		     x = x + add*dt**4/24.0+addd*dt**5*alpha/120.0 
		     v = v + add*dt**3/6.0+addd*dt**4/24.0 
	        */
		 msrCorrector(msr,dTime);    
 
		 if (msr->param.bVDetails){
		  printf("%*cCorrect, iRung: %d\n",2*iRung+2,' ',iRung);                          
		}
#ifdef PLANETS
                if(msr->param.bHeliocentric){                      		
		/*
		Here is a step for correcting the Sun's direct gravity.
		a is recalculated using the correctors' position and 
		velocity.  
		*/          
		int nite = 0;
                int nitemax = 3; 
                /* number of interation for correcting the Sun's gravity 
                   P(EC)'^(nitemax) scheme (see Kokubo et al 1998)*/           
                do{    
                nite += 1;
                msrSunCorrector(msr,dTime);  		
                }while(nite < nitemax);
                }
		if(msr->param.bCollision){   
		  msrDoCollision(msr,dTime,dDelta);  
		  }
#endif 
		/* 
		Copy the present values of activated particles as the initial values 
		x_0 = x, v_0 = v, a_0 = a, dTime0 = dTime
		*/ 
                msrCopy0(msr,dTime); 
    }

else {        
   	double dDeltaTmp;
	int i;

	/*printf("iRungVeryActive: %d CurrMaxrung: %d  iRung: %d, 0.5*dDelta: %g n/",iRungVeryActive, msrCurrMaxRung(msr),iRung,0.5*dDelta);*/

	/*
	 * We have more rungs to go, but we've hit the very active limit.
	 */
	/*
	 * Activate VeryActives
	 */
	msrActiveRung(msr,msr->iRungVeryActive+1,1);
	/*
	 * Predict the non-VeryActive particles forward 1/2 timestep
	 */
	if (msr->param.bVDetails)
	  	if (msr->param.bVDetails) {
	    printf("%*cInActivePredict at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	    
	msrPredictorInactive(msr, dTime + 0.5*dDelta);
	/*
	 * Build a tree out of them for use by the VeryActives
	 */
	if(msrDoGravity(msr)) {
	    msrUpdateSoft(msr,dTime + 0.5*dDelta);
	    /*
	    ** Domain decomposition for parallel exclude very active is going to be 
	    ** placed here shortly.
	    */
	    bSplitVA = 1;
	    msrDomainDecomp(msr,iRung,1,bSplitVA);

	    if (msr->param.bVDetails) {
		printf("%*cBuilding exclude very active tree: iRung: %d\n",
		       2*iRung+2,' ',iRung);
		}
	    msrBuildTreeExcludeVeryActive(msr,dMass,dTime + 0.5*dDelta);
	    }
	/*
	 * Perform timestepping on individual processors.
	 */
	if (msr->param.bVDetails)
	    printf("VeryActive at iRung: %d\n", iRung);
	msrStepVeryActiveHermite(msr, dStep, dTime, dDelta, iRung);
	dTime += dDelta;
	dStep += 1.0/(1 << iRung);
	/*
	 * Move Inactives to the end of the step.
	 */
	if (msr->param.bVDetails) {
	    printf("%*cInActivePredictor at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	msrActiveRung(msr,msr->iRungVeryActive+1,1);
	/* 
	** The inactives are half time step behind the actives. 
	** Move them a half time step ahead to synchronize everything again.
	*/	
	msrPredictorInactive(msr, dTime);

	/*
	 * Regular Tree gravity
	 */
	msrActiveRung(msr,iKickRung,1);
	bSplitVA = 0;
	msrDomainDecomp(msr,iKickRung,1,bSplitVA);

	if(msrDoGravity(msr)) {
	    msrActiveRung(msr,iKickRung,1);
	    msrUpdateSoft(msr,dTime);
	    if (msr->param.bVDetails) {
		printf("%*cGravity, iRung: %d to %d\n",
		       2*iRung+2,' ',iKickRung,msrCurrMaxRung(msr));
		}
	    msrBuildTree(msr,dMass,dTime);
	    msrGravity(msr,dTime,dStep,0,0,piSec,pdWMax,pdIMax,pdEMax,&nActive);
	    *pdActiveSum += (double)nActive/msr->N;
	    }
#ifdef PLANETS
	/* Sun's direct and indirect gravity */
		if(msr->param.bHeliocentric) {
		  msrGravSun(msr);
		}
#endif 
	if (msr->param.bVDetails) {
		printf("%*cVeryActive msrCorrector at iRung: %d, 0.5*dDelta: %g\n",
		       2*iRung+2,' ',i, 0.5*dDeltaTmp);
		}	
	        msrCorrector(msr,dTime);   

#ifdef PLANETS         
                if(msr->param.bHeliocentric){          		
		int nite = 0;
                int nitemax = 3;                                                     
                do{    
                nite += 1;
                msrSunCorrector(msr,dTime);  		
                }while(nite < nitemax);
                }
		if(msr->param.bCollision){   
		  msrDoCollision(msr,dTime,dDelta);  
		}
#endif
                msrCopy0(msr,dTime);
          }
}

void
msrStepVeryActiveHermite(MSR msr, double dStep, double dTime, double dDelta,
		     int iRung)
    {
    struct inStepVeryActiveH in;
    struct outStepVeryActiveH out;    
 
#ifdef PLANETS
    if(msr->param.bHeliocentric){
      int k;        
      struct inSunIndirect ins;
      struct outSunIndirect outs;

      ins.iFlag = 2; /* for inactive particles */ 
      pstSunIndirect(msr->pst,&ins,sizeof(ins),&outs,NULL); 
	for (k=0;k<3;k++){ 
        in.aSunInact[k] = outs.aSun[k];
	in.adSunInact[k] = outs.adSun[k];
	}
      }
#endif

    in.dStep = dStep;
    in.dTime = dTime;
    in.dDelta = dDelta;
    in.iRung = iRung;
    in.diCrit2 = 1/(msr->dCrit*msr->dCrit);   /* could set a stricter opening criterion here */
    in.nMaxRung = msrCurrMaxRung(msr);
#ifdef PLANETS 
    in.dSunMass = msr->dSunMass;
#endif
    /*
     * Start Particle Cache on all nodes (could be done as part of
     * tree build)
     */
    pstROParticleCache(msr->pst, NULL, 0, NULL, NULL);
    
    pstStepVeryActiveHermite(msr->pst, &in, sizeof(in), &out, NULL);

#ifdef PLANETS 
/* maybe we should use collision flag to determine if we call 
   the following function.  */
    if(msr->param.bCollision){
    struct outGetVariableVeryActive outGet;
    pstGetVariableVeryActive(msr->pst, NULL, 0, &outGet, NULL);
    msr->dEcoll += outGet.dDeltaEcoll;
    outGet.dDeltaEcoll = 0.0;/*just in case */
    }
#endif
    /*
     * Finish Particle Cache on all nodes
     */
    pstParticleCacheFinish(msr->pst, NULL, 0, NULL, NULL);
    msr->iCurrMaxRung = out.nMaxRung;
    }

void msrCopy0(MSR msr,double dTime)
{
	struct inCopy0 in;

	in.dTime = dTime;
	pstCopy0(msr->pst,&in,sizeof(in),NULL,NULL);
	}

void msrPredictor(MSR msr,double dTime)
{
	struct inPredictor in;
	
	in.dTime = dTime;
	pstPredictor(msr->pst,&in,sizeof(in),NULL,NULL);
	}

void msrCorrector(MSR msr,double dTime)
{
	struct inCorrector in;

	in.dTime = dTime;
	pstCorrector(msr->pst,&in,sizeof(in),NULL,NULL);
	}

#ifdef PLANETS 
void msrSunCorrector(MSR msr,double dTime)
{
	struct inSunCorrector in;
	
	in.dTime = dTime;
	in.dSunMass = msr->dSunMass;
	pstSunCorrector(msr->pst,&in,sizeof(in),NULL,NULL);
	}
#endif

void msrPredictorInactive(MSR msr,double dTime)
{
	struct inPredictorInactive in;
	
	in.dTime = dTime;
	pstPredictorInactive(msr->pst,&in,sizeof(in),NULL,NULL);
	}

void
msrAarsethStep(MSR msr)
{
    struct inAarsethStep in;

    in.dEta = msrEta(msr);
    pstAarsethStep(msr->pst,&in,sizeof(in),NULL,NULL);
    }

void
msrFirstDt(MSR msr)
{  
    pstFirstDt(msr->pst,NULL,0,NULL,NULL);
    }

#endif /* Hermite*/

int
msrMaxOrder(MSR msr)
    {
    return msr->nMaxOrder;
    }

void
msrAddDelParticles(MSR msr)
    {
    struct outColNParts *pColNParts;
    int *pNewOrder;
    struct inSetNParts in;
    struct inSetParticleTypes intype;
#ifdef PLANETS
    int *pNewOrgIdx;
    struct inHandSunMass inh;
#endif
    int iOut;
    int i;
    
    pColNParts = malloc(msr->nThreads*sizeof(*pColNParts));
    pstColNParts(msr->pst, NULL, 0, pColNParts, &iOut);
    /*
     * Assign starting numbers for new particles in each processor.
     */
    pNewOrder = malloc(msr->nThreads*sizeof(*pNewOrder));
#ifdef PLANETS
    pNewOrgIdx = malloc(msr->nThreads*sizeof(*pNewOrgIdx));
#endif
    
    for(i=0;i<msr->nThreads;i++) {
	/*
	 * Detect any changes in particle number, and force a tree
	 * build.
	 */
     if (pColNParts[i].nNew != 0 || pColNParts[i].nDeltaGas != 0 ||
	    pColNParts[i].nDeltaDark != 0 || pColNParts[i].nDeltaStar != 0) {
	  /*printf("Particle assignments have changed!\n");
	    printf("need to rebuild tree, code in msrAddDelParticles()\n");
	    printf("needs to be updated. Bailing out for now...\n");
	   
	    exit(-1); */

        printf("Par Num changed n %d nnew %d, dn %d \n",msr->N,pColNParts[i].nNew,pColNParts[i].nDeltaDark);
        pNewOrder[i] = msr->nMaxOrder + 1;
        msr->nMaxOrder += pColNParts[i].nNew;
#ifdef PLANETS
	pNewOrgIdx[i] = msr->nMaxOrgIdx + 1;
	msr->nMaxOrgIdx += pColNParts[i].nNew;
#endif
	msr->nGas += pColNParts[i].nDeltaGas;
	msr->nDark += pColNParts[i].nDeltaDark;
	msr->nStar += pColNParts[i].nDeltaStar;     

     }
     }
    msr->N = msr->nGas + msr->nDark + msr->nStar;

    msr->nMaxOrderDark = msr->nMaxOrder;

    pstNewOrder(msr->pst,pNewOrder,(int)sizeof(*pNewOrder)*msr->nThreads,NULL,NULL);
  
#ifdef PLANETS
    pstNewOrgIdx(msr->pst,pNewOrgIdx,(int)sizeof(*pNewOrgIdx)*msr->nThreads,NULL,NULL);
#endif

    

    if (msr->param.bVDetails)
	printf("New numbers of particles: %d gas %d dark %d star\n",
	       msr->nGas, msr->nDark, msr->nStar);

    in.nGas = msr->nGas;
    in.nDark = msr->nDark;
    in.nStar = msr->nStar;
    in.nMaxOrderGas = msr->nMaxOrderGas;
    in.nMaxOrderDark = msr->nMaxOrderDark;    
    pstSetNParts(msr->pst,&in,sizeof(in),NULL,NULL);
    pstSetParticleTypes(msr->pst,&intype,sizeof(intype),NULL,NULL);


#ifdef PLANETS
    inh.dSunMass = msr->dSunMass;
    pstHandSunMass(msr->pst,&inh,sizeof(inh),NULL,NULL);
    free(pNewOrgIdx);
#endif
    free(pNewOrder);
    free(pColNParts);
    }

int msrDoDensity(MSR msr)
    {
    return(msr->param.bDoDensity);
    }

int msrDoGravity(MSR msr)
    {
    return(msr->param.bDoGravity);
    }

void msrInitTimeSteps(MSR msr,double dTime,double dDelta) 
    {
    double dMass = -1.0;

    msrActiveRung(msr,0,1); /* Activate all particles */
    msrInitDt(msr);
    if (msr->param.bGravStep) {
	msrGravStep(msr,dTime);
	}
    if (msr->param.bAccelStep) {
	msrAccelStep(msr,dTime);
	}
    if (msr->param.bDensityStep) {
	msrDomainDecomp(msr,0,1,0);
	msrActiveRung(msr,0,1); /* Activate all particles */
	msrBuildTree(msr,dMass,dTime);
	msrDensityStep(msr,dTime,TYPE_ALL);
	}
    msrDtToRung(msr,0,dDelta,1);
    }


void msrFof(MSR msr,int nFOFsDone,int iSmoothType,int bSymmetric,int eParticleTypes)
    {
    struct inFof in;
    in.nFOFsDone = nFOFsDone;
    in.nSmooth = msr->param.nSmooth;
    in.bPeriodic = msr->param.bPeriodic;
    in.bSymmetric = bSymmetric;
    in.iSmoothType = iSmoothType;
    in.eParticleTypes = eParticleTypes;
    in.smf.dTau2 = msr->param.dTau * msr->param.dTau;
    if(msr->param.bTauAbs==0) in.smf.dTau2 *= pow(msr->param.csm->dOmega0,-0.6666);
    in.smf.bTauAbs = msr->param.bTauAbs;
    in.smf.nMinMembers = msr->param.nMinMembers;
    in.smf.fContrast = msr->param.fContrast;
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("Doing FOF...\n");
	sec = msrTime();
	pstFof(msr->pst,&in,sizeof(in),NULL,NULL);
	dsec = msrTime() - sec;
	printf("FOF Calculated, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstFof(msr->pst,&in,sizeof(in),NULL,NULL);
	}
    }

void msrGroupMerge(MSR msr)
    {
    struct inGroupMerge in;
    int nGroups;
    in.bPeriodic = msr->param.bPeriodic;
    in.smf.nMinMembers = msr->param.nMinMembers;
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("Doing GroupMerge...\n");
	sec = msrTime();
	pstGroupMerge(msr->pst,&in,sizeof(in),&nGroups,NULL);
	dsec = msrTime() - sec;
	printf("GroupMerge done, Wallclock: %f secs\n",dsec);
	}
    else {
	pstGroupMerge(msr->pst,&in,sizeof(in),&nGroups,NULL);
	}
    msr->nGroups = nGroups;
    printf("MASTER: TOTAL groups: %i \n" ,nGroups);
    }

void msrGroupProfiles(MSR msr,int nFOFsDone,int iSmoothType,int bSymmetric,int eParticleTypes)
    {
    int nBins;
    struct inGroupProfiles in;
    in.bPeriodic = msr->param.bPeriodic;
    in.nTotalGroups = msr->nGroups;
    in.nSmooth = msr->param.nSmooth;
    in.bSymmetric = bSymmetric;
    in.iSmoothType = iSmoothType;
    in.eParticleTypes = eParticleTypes;
    in.nFOFsDone = nFOFsDone;
    in.smf.nMinMembers = msr->param.nMinMembers;
    in.smf.nBins = msr->param.nBins;
    in.smf.nMinProfile = msr->param.nMinProfile/pow(msr->param.fBinsRescale, nFOFsDone);	
    in.bLogBins = msr->param.bLogBins;
    in.smf.bUsePotmin = msr->param.bUsePotmin;
    in.smf.Delta = msr->param.Delta;
    in.smf.binFactor = msr->param.binFactor;
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("Doing GroupProfiles...\n");
	sec = msrTime();
	pstGroupProfiles(msr->pst,&in,sizeof(in),&nBins,NULL);
	dsec = msrTime() - sec;
	printf("GroupProfiles done, Wallclock: %f secs\n",dsec);
	}
    else {
	pstGroupProfiles(msr->pst,&in,sizeof(in),&nBins,NULL);
	}
    msr->nBins = nBins;
    printf("MASTER: TOTAL bins: %i TOTAL groups: %i \n" ,nBins,msr->nGroups);
    }

void msrOutGroups(MSR msr,char *pszFile,int iOutType, double dTime){

    struct inOutArray in;
    char achOutFile[PST_FILENAME_SIZE];
    LCL *plcl;
    PST pst0;
    FILE *fp;
    double dvFac,time;
   
    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    if (pszFile) {
	/*
	** Add Data Subpath for local and non-local names.
	*/
	_msrMakePath(msr->param.achDataSubPath,pszFile,in.achOutFile);
	/*
	** Add local Data Path.
	*/
	_msrMakePath(plcl->pszDataPath,in.achOutFile,achOutFile);

	fp = fopen(achOutFile,"w");
	if (!fp) {
	    printf("Could not open Group Output File:%s\n",achOutFile);
	    _msrExit(msr,1);
	    }
	}
    else {
	printf("No Group Output File specified\n");
	_msrExit(msr,1);
	return;
	}
    if (msrComove(msr)) {
	time = csmTime2Exp(msr->param.csm,dTime);
	if (msr->param.bCannonical) {
	    dvFac = 1.0/(time*time);
	    }
	else {
	    dvFac = 1.0;
	    }
	}
    else {
	time = dTime;
	dvFac = 1.0;
	}

    if(iOutType == OUT_GROUP_TIPSY_NAT || iOutType == OUT_GROUP_TIPSY_STD){
	/*
	** Write tipsy header.
	*/
	struct dump h;
	h.nbodies = msr->nGroups;
	h.ndark = 0;
	h.nsph = 0;
	h.nstar = msr->nGroups;
	h.time = time;
	h.ndim = 3;

	if (msrComove(msr)) {
	    printf("Writing file...\nTime:%g Redshift:%g\n",
		   dTime,(1.0/h.time - 1.0));
	    }
	else {
	    printf("Writing file...\nTime:%g\n",dTime);
	    }
		
	if (iOutType == OUT_GROUP_TIPSY_STD) {
	    XDR xdrs;
	    xdrstdio_create(&xdrs,fp,XDR_ENCODE);
	    xdrHeader(&xdrs,&h);
	    xdr_destroy(&xdrs);
	    }
	else {
	    fwrite(&h,sizeof(struct dump),1,fp);
	    }	
	}	
    fclose(fp);	
    /* 
     * Write the groups.
     */
    assert(msr->pMap[0] == 0);
    pkdOutGroup(plcl->pkd,achOutFile,iOutType,0,dvFac);
    }

void msrDeleteGroups(MSR msr){

    LCL *plcl;
    PST pst0;
   
    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
	pst0 = pst0->pstLower;
    plcl = pst0->plcl;

    if(plcl->pkd->groupData)free(plcl->pkd->groupData); 
    if(plcl->pkd->groupBin)free(plcl->pkd->groupBin);
    plcl->pkd->nBins = 0;
    plcl->pkd->nGroups = 0;
    }
#ifdef RELAXATION
void msrInitRelaxation(MSR msr)
    {
    pstInitRelaxation(msr->pst,NULL,0,NULL,NULL);
    }	
void msrRelaxation(MSR msr,double dTime,double deltaT,int iSmoothType,int bSymmetric,int eParticleTypes)
    {
    struct inSmooth in;
    in.nSmooth = msr->param.nSmooth;
    in.bPeriodic = msr->param.bPeriodic;
    in.bSymmetric = bSymmetric;
    in.iSmoothType = iSmoothType;
    in.eParticleTypes = eParticleTypes;
    in.dfBall2OverSoft2 = (msr->param.bLowerSoundSpeed ? 0 :
			   4.0*msr->param.dhMinOverSoft*msr->param.dhMinOverSoft);
    if (msrComove(msr)) {
	in.smf.H = csmTime2Hub(msr->param.csm,dTime);
	in.smf.a = csmTime2Exp(msr->param.csm,dTime);
	}
    else {
	in.smf.H = 0.0;
	in.smf.a = 1.0;
	}
    in.smf.dDeltaT = deltaT;
    if (msr->param.bVStep) {
	double sec,dsec;
	printf("Smoothing for relaxation...dDeltaT = %f \n",deltaT);
	sec = msrTime();
	pstSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	dsec = msrTime() - sec;
	printf("Relaxation Calculated, Wallclock: %f secs\n\n",dsec);
	}
    else {
	pstSmooth(msr->pst,&in,sizeof(in),NULL,NULL);
	}
    }
#endif /* RELAXATION */

#ifdef PLANETS 
void
msrOneNodeReadSS(MSR msr,struct inReadSS *in)
{
    int i,id;
    int *nParts;
    int nStart;
    PST pst0;
    LCL *plcl;
    char achInFile[PST_FILENAME_SIZE];
    int nid;
    int inswap;

    nParts = malloc(msr->nThreads*sizeof(*nParts));
    for (id=0;id<msr->nThreads;++id) {
		nParts[id] = -1;
		}

    pstOneNodeReadInit(msr->pst,in,sizeof(*in),nParts,&nid);
    assert(nid == msr->nThreads*sizeof(*nParts));
    for (id=0;id<msr->nThreads;++id) {
		assert(nParts[id] > 0);
		}

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
		pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    /*
     ** Add the local Data Path to the provided filename.
     */
	_msrMakePath(plcl->pszDataPath,in->achInFile,achInFile);

    nStart = nParts[0];
	assert(msr->pMap[0] == 0);
    for (i=1;i<msr->nThreads;++i) {
		id = msr->pMap[i];
		/* 
		 * Read particles into the local storage.
		 */
		assert(plcl->pkd->nStore >= nParts[id]);
		pkdReadSS(plcl->pkd,achInFile,nStart,nParts[id]);
		nStart += nParts[id];
		/* 
		 * Now shove them over to the remote processor.
		 */
		inswap = 0;
		mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
		pkdSwapAll(plcl->pkd, id);
		mdlGetReply(pst0->mdl,id,NULL,NULL);
    	}
    assert(nStart == msr->N);
    /* 
     * Now read our own particles.
     */
    pkdReadSS(plcl->pkd,achInFile,0,nParts[0]);
    }

double
msrReadSS(MSR msr)
{
	SSIO ssio;
	SSHEAD head;
	struct inReadSS in;
	struct inHandSunMass inh;
	struct outGetnMaxOrgIdx outg;

	struct inSetParticleTypes intype;
	char achInFile[PST_FILENAME_SIZE];
	LCL *plcl = msr->pst->plcl;
	double dTime;

	if (msr->param.achInFile[0]) {
		/*
		 ** Add Data Subpath for local and non-local names.
		 */
		_msrMakePath(msr->param.achDataSubPath,msr->param.achInFile,in.achInFile);
		/*
		 ** Add local Data Path.
		 */
		_msrMakePath(plcl->pszDataPath,in.achInFile,achInFile);

		if (ssioOpen(achInFile,&ssio,SSIO_READ)) {
			printf("Could not open InFile:%s\n",achInFile);
			_msrExit(msr,1);
			}
		}
	else {
		printf("No input file specified\n");
		_msrExit(msr,1);
		}

	/* Read header */

	if (ssioHead(&ssio,&head)) {
		printf("Could not read header of InFile:%s\n",achInFile);
		_msrExit(msr,1);
		}
	if (ssioClose(&ssio)) {
		printf("Could not close InFile:%s\n",achInFile);
		_msrExit(msr,1);
		}

	msr->N = msr->nDark = head.n_data;
	msr->nGas = msr->nStar = 0;
	msr->nMaxOrder = msr->N - 1;
	msr->nMaxOrderGas = msr->nGas - 1; /* always -1 */
	msr->nMaxOrderDark = msr->nDark - 1;

        /*msr->nPlanets = head.n_planets;*/        
	msr->dEcoll = head.dEcoll;        
	msr->dEgas = head.dEgas;  
      	msr->dEstir = head.dEstir;  
        msr->dSunMass = head.dSunMass;        

	dTime = head.time;
	if (msr->param.bVStart) {
		double tTo;
		printf("Input file...N=%i,Time=%g\n",msr->N,dTime);
		tTo = dTime + msr->param.nSteps*msr->param.dDelta;
		printf("Simulation to Time:%g\n",tTo);
		}

	in.nFileStart = 0;
	in.nFileEnd = msr->N - 1;
	in.nBucket = msr->param.nBucket;
	in.nDark = msr->nDark;
	in.nGas = msr->nGas;	/* always zero */
	in.nStar = msr->nStar;	/* always zero */
	in.iOrder = msr->param.iOrder;
	in.N0 = msr->param.N0; // 122316 added
	
	/*
	 ** Since pstReadSS causes the allocation of the local particle
	 ** store, we need to tell it the percentage of extra storage it
	 ** should allocate for load balancing differences in the number of
	 ** particles.
	 */
	in.fExtraStore = msr->param.dExtraStore;

	in.fPeriod[0] = msr->param.dxPeriod;
	in.fPeriod[1] = msr->param.dyPeriod;
	in.fPeriod[2] = msr->param.dzPeriod;

	if (msr->param.bParaRead)
	    pstReadSS(msr->pst,&in,sizeof(in),NULL,NULL);
	else
	    msrOneNodeReadSS(msr,&in);
	pstSetParticleTypes(msr->pst,&intype,sizeof(intype),NULL,NULL);
	if (msr->param.bVDetails) puts("Input file successfully read.");

	inh.dSunMass = msr->dSunMass;       
	pstHandSunMass(msr->pst,&inh,sizeof(inh),NULL,NULL);

	/*	printf("start pstGetnMaxOrgIdx \n");
		pstGetnMaxOrgIdx(msr->pst, NULL, 0, &outg,NULL); 
		msr->nMaxOrgIdx = outg.nMaxOrgIdx;
		msr->nMaxOrgIdx = 300;
		printf("N = %d MaxOrgIdx %d \n",msr->N,msr->nMaxOrgIdx);*/

	/*
	 ** Now read in the output points, passing the initial time.
	 ** We do this only if nSteps is not equal to zero.
	 */
	if (msrSteps(msr) > 0) msrReadOuts(msr,dTime);
	/*
	 ** Set up the output counter.
	 */
	for (msr->iOut=0;msr->iOut<msr->nOuts;++msr->iOut) {
		if (dTime < msr->pdOutTime[msr->iOut]) break;
		}
	return(dTime);
	}

void
msrOneNodeWriteSS(MSR msr,struct inWriteSS *in)
{
    int i,id;
    int nStart;
    PST pst0;
    LCL *plcl;
    char achOutFile[PST_FILENAME_SIZE];
    int inswap;

    pst0 = msr->pst;
    while(pst0->nLeaves > 1)
		pst0 = pst0->pstLower;
    plcl = pst0->plcl;
    /*
     ** Add the local Data Path to the provided filename.
     */
	_msrMakePath(plcl->pszDataPath,in->achOutFile,achOutFile);

    /* 
     * First write our own particles.
     */
    pkdWriteSS(plcl->pkd,achOutFile,plcl->nWriteStart);
    nStart = plcl->pkd->nLocal;
	assert(msr->pMap[0] == 0);
    for (i=1;i<msr->nThreads;++i) {
		id = msr->pMap[i];
		/* 
		 * Swap particles with the remote processor.
		 */
		inswap = 0;
		mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
		pkdSwapAll(plcl->pkd,id);
		mdlGetReply(pst0->mdl,id,NULL,NULL);
		/* 
		 * Write the swapped particles.
		 */
		pkdWriteSS(plcl->pkd,achOutFile,nStart);
		nStart += plcl->pkd->nLocal;
		/* 
		 * Swap them back again.
		 */
		inswap = 0;
		mdlReqService(pst0->mdl,id,PST_SWAPALL,&inswap,sizeof(inswap));
		pkdSwapAll(plcl->pkd, id);
		mdlGetReply(pst0->mdl,id,NULL,NULL);
    	}
    assert(nStart == msr->N);
    }

void
msrWriteSS(MSR msr,char *pszFileName,double dTime)
{
	SSIO ssio;
	SSHEAD head;
	struct inWriteSS in;
	char achOutFile[PST_FILENAME_SIZE];
	LCL *plcl = msr->pst->plcl;

	/*
	 ** Calculate where each processor should start writing.
	 ** This sets plcl->nWriteStart.
	 */
	msrCalcWriteStart(msr);
	/*
	 ** Add Data Subpath for local and non-local names.
	 */
	_msrMakePath(msr->param.achDataSubPath,pszFileName,in.achOutFile);
	/*
	 ** Add local Data Path.
	 */
	_msrMakePath(plcl->pszDataPath,in.achOutFile,achOutFile);
	
	if (ssioOpen(achOutFile,&ssio,SSIO_WRITE)) {
		printf("Could not open OutFile:%s\n",achOutFile);
		_msrExit(msr,1);
		}

	/* Write header */

	head.time = dTime;
	head.n_data = msr->N;
	/* head.n_planets = msr->nPlanets;*/
	head.dEcoll = msr->dEcoll;
	head.dEgas = msr->dEgas;
	head.dEstir = msr->dEstir;
	head.dSunMass = msr->dSunMass;

	if (ssioHead(&ssio,&head)) {
		printf("Could not write header of OutFile:%s\n",achOutFile);
		_msrExit(msr,1);
		}
	if (ssioClose(&ssio)) {
		printf("Could not close OutFile:%s\n",achOutFile);
		_msrExit(msr,1);
		}

	if(msr->param.bParaWrite)
	    pstWriteSS(msr->pst,&in,sizeof(in),NULL,NULL);
	else
		msrOneNodeWriteSS(msr,&in);

	if (msr->param.bVDetails) puts("Output file successfully written.");
	}

void msrGravSun(MSR msr)
{
	struct inGravSun in;

	struct inSunIndirect ins;
	struct outSunIndirect outs;

	int j;

	/* Calculate Sun's indirect gravity */
	ins.iFlag = 0;	/* for all particles */
	pstSunIndirect(msr->pst,&ins,sizeof(ins),&outs,NULL); 
	for (j=0;j<3;++j){ 
                in.aSun[j] = outs.aSun[j];
		in.adSun[j] = outs.adSun[j];
		}
	/* printf("asun = %e %e %e adsun = %e %e %e \n",in.aSun[0],in.aSun[1],in.aSun[2],in.adSun[0],in.adSun[1],in.adSun[2]); */

	in.dSunMass = msr->dSunMass;

	pstGravSun(msr->pst,&in,sizeof(in),NULL,NULL);

}

static char *
_msrParticleLabel(MSR msr,int iColor)
{
	switch (iColor) {
	case SUN:
		return "SUN";
	case GIANT:
		return "GIANT";
	case PLANETESIMAL:
		return "PLANETESIMAL";
	case TEST:
		return "TEST";
	default:
		return "UNKNOWN";
		}
	}

#ifdef sm2d
void msrCalcElem(MSR msr){
  // msrDemotoHel(msr);
  pstCalcElem(msr->pst,NULL,0,NULL,NULL);
  // msrHeltoDemo(msr); 
  
}

void msrResetKick(MSR msr){
  /* This is for PBHYB kick not for Symba routine */
  pstResetKick(msr->pst, NULL, 0, NULL, NULL);
}

void msrDeletoKick(MSR msr,double dTime,double dDPBHYB){
 
  struct inDeletoKick inD;
  struct outDeletoKick outD;

  inD.dDPBHYB = dDPBHYB;
  inD.dTime = dTime;

  pstDeletoKick(msr->pst, &inD, sizeof(inD), &outD, NULL);
  
  // msr->dDstir = 0.1*(outD.tsmin+msr->dDstir); /* timestep for PBHYB  */
  //  if(msr->dDstir < 10.0*msrDelta(msr))
  //msr->dDstir = 30.0*msrDelta(msr); //no need to updata as it is defined in marinitial...
}

void
msrDoCollisionPBHYB(MSR msr,double dTime,double dDelta)
{
  struct outNextCollision next;
  struct inGetColliderInfo inGet;
  struct outGetColliderInfo outGet;
  struct inDoCollisionL inDo;
  struct outDoCollisionL outDo;
  struct inSplitTracerL ins;
  struct outSplitTracerL outs;

  COLLIDER *c1 = &inDo.Collider1,*c2 = &inDo.Collider2,*c;

  do{	
    pstNextCollision(msr->pst,NULL,0,&next,NULL);
    /*printf("next %i,%i\n",next.iOrder1,next.iOrder2);*/
    
    /* process the collision */
    if (COLLISION(next.dt)) {
      
      assert(next.iOrder1 >= 0);
      assert(next.iOrder2 >= 0);
      
      inDo.dt = next.dt;
      inGet.iOrder = next.iOrder1;
      pstGetColliderInfo(msr->pst,&inGet,sizeof(inGet),&outGet,NULL);
      *c1 = outGet.Collider; /* struct copy */
      
      assert(c1->id.iOrder == inGet.iOrder);
      assert(c1->iColor >= SUBEMBRYO);
      
      inGet.iOrder = next.iOrder2;
      pstGetColliderInfo(msr->pst,&inGet,sizeof(inGet),&outGet,NULL);
      *c2 = outGet.Collider;
      
      assert(c2->id.iOrder == inGet.iOrder);
      assert(c2->iColor >= SUBEMBRYO);
      
      inDo.CP = msr->param.CP; /* copy collisional parmas */

      if(msr->N > msr->param.N0){ 
	inDo.iexcess = 1; /* the new particle is not created after the collision if idel = 1 and inexcess =1 */
      }else{
	inDo.iexcess = 0; 
      }
      inDo.dTime = dTime;

      pstDoCollisionPBHYB(msr->pst,&inDo,sizeof(inDo),&outDo,NULL);
      
      msr->dEcoll += outDo.dT; /* account for kinetic energy loss + (potential)*/
      
      /* log here */

    } 
  }while (COLLISION(next.dt));	

  /* split a tracer into two new tracers if mt >= 2mt0 */

  ins.dTime = dTime;
  pstSplitTracerPBHYB(msr->pst,&ins,sizeof(ins),&outs,NULL);
  msr->dEcoll += outs.dT; 

  msrAddDelParticles(msr); /* clean up any deletions */
}


void msrPBHYBCollStirDirect(MSR msr, double dTime, int TYPE_PBHYB, double dDPBHYB){
  pkdPBHYBCollStirDirect(msr->pst->plcl->pkd,dTime,TYPE_PBHYB,dDPBHYB);
}
 
void msrTrPotTable(MSR msr, double dTime){
  pkdTrPotTable(msr->pst->plcl->pkd,dTime);
}

void msrPebble2Planetesimal(MSR msr,double dTime,int iPlForm,double dDPBHYB){
  pkdPebble2Planetesimal(msr->pst->plcl->pkd,&msr->param.GP,dTime,iPlForm,dDPBHYB);
}

void msrGasAcc2Planet(MSR msr,double dTime,int iGasAcc2Planet,double dDPBHYB){
  pkdGasAcc2Planet(msr->pst->plcl->pkd,&msr->param.GP,dTime,iGasAcc2Planet,dDPBHYB);
}




// this function calls pst but not really parallelized
void msrTrPotAcc(MSR msr, double dTime){
  struct inTrPotAcc in;
  in.dTime = dTime;
  pstTrPotAcc (msr->pst, &in, sizeof(in), NULL, NULL);
}

void msrDmdt(MSR msr,double dTime){
  pkdDmdt(msr->pst->plcl->pkd,dTime);
}

void msrPebbleSupply(MSR msr,double dTime,double dDelta){
  int new_flag = 0;
  double mt_new,v_new[3];
  struct inCorrectHelioDist inCo;
  struct outCorrectHelioDist outCo;
  struct outMomCent outm;
  int k;
    
  pkdPebbleSupply(msr->pst->plcl->pkd,dTime,dDelta,&msr->param.GP,&new_flag,&mt_new,v_new);
  
  if(new_flag){
    msrAddDelParticles(msr); // copy new pointa to structure

    // velocity correction to keep the momentum of the system zero
    // for simplicity of coding, we also give a kick to the new particle
    // 111916
    inCo.tag = 2;
    pstMomCent(msr->pst,NULL,0,&outm,NULL); 
    for (k=0;k<3;k++){
      inCo.vd[k] = -mt_new*v_new[k]/(msr->dSunMass + outm.mCent);
    }
    inCo.dSM = 0.0;			    
    pstCorrectHelioDist(msr->pst,&inCo,sizeof(inCo),&outCo,NULL);
  } 

}


#endif //sm2d


void
msrDoCollision(MSR msr,double dTime,double dDelta)
{

	struct outNextCollision next;
	struct inGetColliderInfo inGet;
	struct outGetColliderInfo outGet;
	struct inDoCollision inDo;
	struct outDoCollision outDo;
	struct outCheckHelioDist outCh;
	struct inCheckHelioDist inCh;
	struct inCorrectHelioDist inCo;
	struct outCorrectHelioDist outCo;
	struct outMomCent outm;
	
	int k, nowrite;

	COLLIDER *c1 = &inDo.Collider1,*c2 = &inDo.Collider2,*c;
	double sec;
	unsigned int nCol=0,nMis=0,nMrg=0,nBnc=0,nFrg=0;
		 
        inDo.bPeriodic = msr->param.bPeriodic;

	/* we first check heliocentric distance */
	inCh.dTime = dTime;
	pstCheckHelioDist(msr->pst,&inCh,sizeof(inCh),&outCh,NULL);
	if(outCh.dT != 0.0){ /* if a particle is deleted */
	  /*printf("coll dT %e vd = %e %e %e, m = %e \n",outCh.dT, outCh.vd[0],outCh.vd[1],outCh.vd[2], outCh.md);*/
	    msr->dEcoll += outCh.dT;
	    
	    if(outCh.dSM != 0.0){ /* Collision with Sun */ 
		inCo.tag = 1;
		msr->dSunMass += outCh.dSM;
		/* the product of the position and the ratio of the 
		   the mass of the deleted particle to the solar mass 
		   after the collision */
		
		for (k=0;k<3;k++){
		    inCo.rd[k] = outCh.md*outCh.rd[k]/msr->dSunMass;
#ifndef SYMBA
		    inCo.vd[k] = outCh.md*outCh.vd[k]/msr->dSunMass;
#endif	
		}		
		inCo.dSM = outCh.dSM;
	    }else{/* Escape */ 
		inCo.tag = 2;
#ifdef SYMBA
		/* the momentum of the deleted particle divided by the total mass 
		   after the deltetion */	
		pstMomCent(msr->pst,NULL,0,&outm,NULL); 
		for (k=0;k<3;k++){
		    inCo.vd[k] = outCh.md*outCh.vd[k]/(msr->dSunMass + outm.mCent);
		}
		inCo.dSM = 0.0;		
#endif
	    }	    
	    pstCorrectHelioDist(msr->pst,&inCo,sizeof(inCo),&outCo,NULL);
	    msr->dEcoll += outCo.dT; 
	    printf("potential change due to increase of the central star's mass and its position change %e\n",outCo.dT);
	}
	assert(msr->N > 0);

	
	/* the following procedure can be removed as collisions are handled in pkddocollisionveryactive */
	/* remove from here ?*/
	do{	
	    pstNextCollision(msr->pst,NULL,0,&next,NULL);
	    /*printf("%i,%i\n",next.iOrder1,next.iOrder2);*/
	    
	    /* process the collision */
	    if (COLLISION(next.dt)) {
		assert(next.iOrder1 >= 0);
		assert(next.iOrder2 >= 0);
		
		inDo.dt = next.dt;
		inGet.iOrder = next.iOrder1;
		pstGetColliderInfo(msr->pst,&inGet,sizeof(inGet),&outGet,NULL);
		*c1 = outGet.Collider; /* struct copy */
		
		/*printf("%i,%i\n",c1->id.iOrder,inGet.iOrder);*/
		
		assert(c1->id.iOrder == inGet.iOrder);
		
		inGet.iOrder = next.iOrder2;
		pstGetColliderInfo(msr->pst,&inGet,sizeof(inGet),&outGet,NULL);
		*c2 = outGet.Collider;
		/*printf("%i,%i\n",c2->id.iOrder,inGet.iOrder);*/
		assert(c2->id.iOrder == inGet.iOrder);
		inDo.CP = msr->param.CP; /* copy collisional parmas */
			
		pstDoCollision(msr->pst,&inDo,sizeof(inDo),&outDo,NULL);
		
		msr->dEcoll += outDo.dT; /* account for kinetic energy loss + (potential)*/
		
		++nCol;
		switch (outDo.iOutcome) {
		    case MISS:
			++nMis;
			--nCol;
			break;
		    case MERGE:
			++nMrg;
			break;
		    case BOUNCE:
			++nBnc;
			break;
		    case FRAG:
			++nFrg;
			break;
		    default:
			assert(0); /* unknown outcome */
		}	
		
#ifdef IGNORE_FOR_NOW/*DEBUG*/
		if (outDo.iOutcome & FRAG) {
		    /* see Zoe's version */
		}
#endif
		
		nowrite = 0;
		//if((msr->param.iCollLogOption & TESTTESTEXCL) && (c1->iColor == TEST) && (c2->iColor == TEST)){
		//	  nowrite = 1;
		//	}


		if(msr->param.iCollLogOption & COLL_LOG_VERBOSE && nowrite == 0){			    
		  FILE *fp;
		  int i;
		  
		  fp = fopen(msr->param.achCollLog,"a");
		  assert(fp != NULL);
		  
		  /* for (i=0;i<3;i++) {
		     c1->r[i] += c1->v[i]*next.dt;
		     c2->r[i] += c2->v[i]*next.dt;
		     } */
		  
		  fprintf(fp,"%s-%s COLLISION:T=%e\n",
			  _msrParticleLabel(msr,c1->iColor),
			  _msrParticleLabel(msr,c2->iColor),dTime);
		  
		  fprintf(fp,"***1:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
			  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
			  c1->id.iPid,c1->id.iOrder,c1->id.iIndex,c1->id.iOrgIdx,
			  c1->fMass,c1->fRadius,c1->dt,c1->iRung,
			  c1->r[0],c1->r[1],c1->r[2],
			  c1->v[0],c1->v[1],c1->v[2],
			  c1->w[0],c1->w[1],c1->w[2]);
		  
		  fprintf(fp,"***2:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
			  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
			  c2->id.iPid,c2->id.iOrder,c2->id.iIndex,c2->id.iOrgIdx,
			  c2->fMass,c2->fRadius,c2->dt,c2->iRung,
			  c2->r[0],c2->r[1],c2->r[2],
			  c2->v[0],c2->v[1],c2->v[2],
			  c2->w[0],c2->w[1],c2->w[2]);
		  fprintf(fp,"***OUTCOME=%s dT=%e\n",
			  outDo.iOutcome == MISS ? "MISS" :
			  outDo.iOutcome == MERGE ? "MERGE" :
			  outDo.iOutcome == BOUNCE ? "BOUNCE" :
			  outDo.iOutcome == FRAG ? "FRAG" : "UNKNOWN",outDo.dT);
			for (i=0;i<(outDo.nOut < MAX_NUM_FRAG ? outDo.nOut : MAX_NUM_FRAG);i++) {
			  c = &outDo.Out[i];
			  
			  fprintf(fp,"***out%i:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,rung=%i,"
				  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",i,
				  c->id.iPid,c->id.iOrder,c->id.iIndex,c->id.iOrgIdx,
				  c->fMass,c->fRadius,c->iRung,
				  c->r[0],c->r[1],c->r[2],
				  c->v[0],c->v[1],c->v[2],
				  c->w[0],c->w[1],c->w[2]);
			}
			fclose(fp);		
		}
		
		if(msr->param.iCollLogOption & COLL_LOG_TERSE && nowrite == 0){		  	
		  /*
		  ** FORMAT: For each event, time (double), collider 1 iOrgIdx
		  ** (int), collider 2 iOrgIdx (int), number of post-collision
		  ** particles (int), iOrgIdx for each of these (n * int).
		  */
		  
		  FILE *fp2;
		  XDR xdrs;		       
		  int i;
		  
		  /* if (outDo.iOutcome != MERGE && outDo.iOutcome != FRAG)
		    break;  only care when particle indices change */
		  fp2 = fopen(msr->param.achCollLog2,"a");
		  assert(fp2 != NULL);
		  xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
		  
		  (void) xdr_double(&xdrs,&dTime);
		  /* MERGE =1, BOUNCE =2*/
		  (void) xdr_int(&xdrs,&outDo.iOutcome); 
		  
		  CollisionData(&xdrs, c1, c2);
				  
		  xdr_destroy(&xdrs);
		  (void) fclose(fp2);		     
		}		
	    } /* if collision */
	} while (COLLISION(next.dt));	
	/* remove down to here ?*/
	
	/*if(adflag) info of pkddelete should be included later */
	  msrAddDelParticles(msr); /* clean up any deletions */
	
	if (msr->param.bVStep) {
	    double dsec = msrTime() - sec;
	    printf("%i collision%s: %i miss%s, %i merger%s, %i bounce%s, %i frag%s\n",
		   nCol,nCol==1?"":"s",nMis,nMis==1?"":"es",nMrg,nMrg==1?"":"s",
		   nBnc,nBnc==1?"":"s",nFrg,nFrg==1?"":"s");
	    printf("Collision search completed, time = %g sec\n",dsec);
	}
}

void msrCollInitial(MSR msr,double dTime_Start){
  FILE *fp, *fp2;
  XDR xdrs, xdrs2;
  COLLIDER *c1,*c2;
  COLLIDER c1out,c2out;

 
  double dTime;
  int iOutcome;
 
  /*printf("enter msrCollInitial, dTime_Start = %e \n",dTime_Start);*/
 
  /* we move ss.coll.bin to ss.coll.bin_old in the beginning of the run, 
     thus ss.coll.bin should not exist */
  fp2 = fopen(msr->param.achCollLog2,"r");
  assert(fp2 == NULL);
  fp = fopen("ss.coll.bin_old","r");
  if(fp == NULL) return; /* no collision so far */    
  xdrstdio_create(&xdrs,fp,XDR_DECODE);

  fp2 = fopen(msr->param.achCollLog2,"a");
  assert(fp2 != NULL);
  xdrstdio_create(&xdrs2,fp2,XDR_ENCODE);

  do{
      if (!xdr_double(&xdrs,&dTime) || dTime > dTime_Start) {
	  xdr_destroy(&xdrs);
	  (void) fclose(fp);
	  xdr_destroy(&xdrs2);
	  (void) fclose(fp2);
	  /* printf("exit msrCollInitial \n");*/
	  return;
      }
      
      /*printf("dTime = %e \n", dTime);*/
      
      (void) xdr_int(&xdrs,&iOutcome); 
      CollisionData(&xdrs, &c1out, &c2out);
      c1 = &c1out;
      c2 = &c2out;
      
      (void)xdr_double(&xdrs2,&dTime);
      (void) xdr_int(&xdrs2,&iOutcome); 
      CollisionData(&xdrs2, c1, c2);
      
  }while(1);   

}

void msrCollInitialPBHYB(MSR msr,double dTime_Start){
  FILE *fp, *fp2;
  XDR xdrs, xdrs2;
  COLLIDER c1in,c2in;
  COLLIDER c1out,c2out;
  int n,nsp,nin,nout,iorg1,iorg2;
  double dTime,nd;
  
 
  // printf("enter msrCollInitial, dTime_Start = %e \n",dTime_Start);
 
  /* we move ss.coll.bin to ss.coll.bin_old in the beginning of the run, 
     thus ss.coll.bin should not exist */

  fp2 = fopen(COLL_LOG_PBHYB_BIN,"r");
  assert(fp2 == NULL);
  // xdr_destroy(&xdrs2);
  //(void) fclose(fp2);

  fp = fopen("ss.coll_PBHYB.bin_old","r");
  if(fp == NULL) return; /* no collision so far */    
  xdrstdio_create(&xdrs,fp,XDR_DECODE);

  fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
  assert(fp2 != NULL);
  xdrstdio_create(&xdrs2,fp2,XDR_ENCODE);

  do{
    
      if (!xdr_int(&xdrs,&nsp)) break;
      (void) xdr_double(&xdrs,&dTime);
      if (dTime > dTime_Start) break; 	

      (void) xdr_int(&xdrs2,&nsp);
	       
      /*printf("dTime = %e \n", dTime);*/


      /* header read */
      for(n=0;n<nsp;++n){ 
	if(n>0)(void) xdr_double(&xdrs,&dTime);
	(void) xdr_int(&xdrs,&nin);
	(void) xdr_int(&xdrs,&nout);
	(void) xdr_double(&xdrs,&nd);
	
	/* header write */
	(void) xdr_double(&xdrs2,&dTime);
	(void) xdr_int(&xdrs2,&nin);
	(void) xdr_int(&xdrs2,&nout);
	(void) xdr_double(&xdrs2,&nd);
	
	/* particle data read */
	CollisionDataPBHYB(&xdrs,&c1in);
	if(nin ==2) CollisionDataPBHYB(&xdrs,&c2in);
	CollisionDataPBHYB(&xdrs,&c1out);
	if(nout ==2) CollisionDataPBHYB(&xdrs,&c2out);
	
	/* particle data write */
	CollisionDataPBHYB(&xdrs2,&c1in);
	if(nin ==2) CollisionDataPBHYB(&xdrs2,&c2in);
	CollisionDataPBHYB(&xdrs2,&c1out);
	if(nout ==2) CollisionDataPBHYB(&xdrs2,&c2out);	
      }

      if(nin == 1 && nout ==2){
	for(n=0;n<nsp;++n){
	  /* read */
	  (void) xdr_int(&xdrs,&iorg2);
	  (void) xdr_int(&xdrs,&iorg1);
	  /* write */
	  (void) xdr_int(&xdrs2,&iorg2);
	  (void) xdr_int(&xdrs2,&iorg1);
	}
      }

  }while(1);   

  xdr_destroy(&xdrs);
  (void) fclose(fp);
  xdr_destroy(&xdrs2);
  (void) fclose(fp2);
  
  printf("msrCollInitialPBHYB done \n");
}


void msrGasAccel(MSR msr, double dTime, double dDelta){
    struct inGasAccel in;
    struct outGasAccel out;

    GASDISK_PARAMS *GP = &msr->param.GP;
    int i;
    // temporary ST and aj comment out 110516
    // STEPINSKI ST;

    //   if(msr->param.GP.iGasModel == 3)  msrGetStepinski(msr, &msr->param.GP, dTime/(2.0*M_PI)+msr->param.GP.dTau_diss, &ST, msr->param.GP.bWind);
    //  if(msr->param.GP.iGasModel == 5) msrGetJupiter(msr,&aj);

    // get params of gap-opening planets
    struct inGetJupiter inj;
    struct outGetJupiter outj;
    GP->npgap = 0; // since we get only h from getGasDisk in calling pstGetJupiter
    inj.GP = msr->param.GP;
    pstGetJupiter(msr->pst, &inj, sizeof(inj), &outj, NULL);
    GP->npgap = outj.npgap;
    for (i=0;i<outj.npgap;++i){
      GP->apgap[i] = outj.apgap[i];
      GP->k1[i] = outj.k1[i];
      GP->k2[i] = outj.k2[i];
    }
    
    /* should be sorted ??*/
   
   
    in.dTime = dTime;
    in.dDelta = dDelta;
    in.GP = msr->param.GP;
    // in.ST = ST;
    // in.aj = aj;

    pstGasAccel(msr->pst, &in, sizeof(in), &out, NULL);
    /*printf("master dEgas %e \n", out.dT);*/
    msr->dEgas +=out.dT;
}

// not used
void msrGetJupiter(MSR msr, double *paj){
  struct outGetJupiter out;
  
  pstGetJupiter(msr->pst, NULL, 0, &out, NULL);
  // *paj = out.aj;
  // assert(*paj > 0.0);
}

void msrGetStepinski(MSR msr, GASDISK_PARAMS *GP, double t, STEPINSKI * ST, int bWind){
 /* t is in units of 1 yr,  s in units of 1 AU */
  double s, ss, jd, ij, jd13, al23;
  double s45,s34,s23,s12;
  double t5,t4,t3,t2,t1,t45,t34,t23,t12;
  int epoch;
  double alpha = GP->dalpha;
  double s0 = GP->dS0;

  s12 = GP->sij[0];
  s23 = GP->sij[1]; 
  s34 = GP->sij[2];
  s45 = GP->sij[3];
  t12 = GP->tij[0];
  t23 = GP->tij[1]; 
  t34 = GP->tij[2];
  t45 = GP->tij[3];	     
  t1 = GP->ti[0];
  t2 = GP->ti[1]; 
  t3 = GP->ti[2];
  t4 = GP->ti[3];
  t5 = GP->ti[4];

  /* calculate the radius of the disk outer edge, s */
  switch (GP->inepo){
  case 5:   
    if(t < t45){
      epoch = 5; /* SIGSOR */
      s = s0*pow((1.0+t/t5),17.0/15.0);  
    }else{      
      if(t < t34){
	epoch = 4; /* SIGOR */
	s = s45*pow((1.0+(t-t45)/t4),31.0/61.0);
      }else{
	if(t < t23){
	epoch = 3; /* IGSOR */
	s = s34*pow((1.0+(t-t34)/t3),23.0/56.0);
	}else{	 
	  if(t < t12){
	    epoch = 2; /* IGOR */
	    s = s23*pow((1.0+(t-t23)/t2),10.0/43.0);	   
	  }else{	 
	    epoch = 1; /* MOTOR */
	    s = s12*pow((1.0+(t-t12)/t1),5.0/4.0);
	  }
	}
      } 
    }
    break;
  case (4):
    if(t < t34){
      epoch = 4; /* SIGOR */
      s = s0*pow((1.0+t/t4),31.0/61.0);  
    }else{  
      if(t < t23){
	epoch = 3; /* IGSOR */
	s = s34*pow((1.0+(t-t34)/t3),23.0/56.0);
      }else{
	if(t < t12){
	  epoch = 2; /* IGOR */
	  s = s23*pow((1.0+(t-t23)/t2),10.0/43.0);		 
	}else{
	  epoch = 1; /* MOTOR */
	  s = s12*pow((1.0+(t-t12)/t1),5.0/4.0);
	}
      }
    }
    break;
  case(3):
    if(t < t23){
      epoch = 3; /* IGSOR */
      s = s0*pow((1.0+t/t3),23.0/56.0);
    }else{
      if(t < t12){
	epoch = 2; /* IGOR */
	s = s23*pow((1.0+(t-t23)/t2),10.0/43.0);		 
      }else{
	epoch = 1; /* MOTOR */
	s = s12*pow((1.0+(t-t12)/t1),5.0/4.0);
      }
    }
    break;
  case(2):
    if(t < t12){
      epoch = 2; /* IGOR */
      s = s0*pow((1.0+t/t2),10.0/43.0);		 
    }else{     
      epoch = 1; /* MOTOR */
      s = s12*pow((1.0+(t-t12)/t1),5.0/4.0);
    }
    break;
  case(1):
    epoch = 1;  
    s = s0*pow((1.0+t/t1),5.0/4.0);
  }
  
  if(bWind && (t > GP->t_trans) && epoch == 1){
    double t_trans = GP->t_trans;
    double s_trans = GP->s_trans; 
    s = s_trans*exp((t-t_trans)/2.E5);
  }
  
  switch(epoch){
  case(5):  
    ss = s/s45;
    ij = 4.4892*pow(ss,-104.0/51.0);
    break;
  case(4):
    ss = s/s45;
    ij = 27.984 + ss*(-46.193 + ss*(31.246 + ss*(-9.6873 + ss*1.1403)));
    break;
  case(3):
    ss = s/s34;
    ij = -1.124*ss + 2.0876;
    break;
  case(2):
    ss = s/s23;
    ij = 3.7253 + (ss*(-5.7326 + ss*(3.3154-ss*0.6435)));  
    break;
  case(1):
    ss = pow(s/s12,-31.0/15.0);   
    ij =ss*(0.4084*GP->f+ss*ss*(0.3923-0.4084*GP->f)); 
    break;
  }

  jd = GP->jd/ij;  
  
  al23 = pow(alpha, 2.0/3.0);
  jd13 = cbrt(jd); 
  
  ST->rij[0] = 6.89E7*al23*jd13*jd13*jd/cbrt(tauc)*pow(s,-25.0/6.0);
  jd13 *= jd*al23*pow(s, -10.0/3.0);
  ST->rij[1] = 9.72E5*jd13;
  ST->rij[2] = 5.74E5*jd13;
  ST->rij[3] = 8.38E4*jd13;
  
  /* in g cm^-2 */ 
  ST->fSigma[0] = 4.02E14*pow(alpha,4.0/5.0)*jd*jd*jd*pow(tauc,-2.0/5.0)*pow(s,-15.0/2.0);
  ST->fSigma[1] = 1.58E5*jd*pow(s,-5.0/2.0);
  ST->fSigma[2] = 1.28E12*pow(alpha,10.0/13.0)*pow(jd,33.0/13.0)*pow(s,-165.0/26.0);
  ST->fSigma[3] = 1.01E8*pow(alpha,5.0/17.0)*pow(jd,27.0/17.0)*pow(s,-135.0/34.0);
  ST->fSigma[4] = 1.12E12*pow(alpha,16.0/19.0)*pow(jd,51.0/19.0)*pow(s,-255.0/38.0);
  
  ST->fTemp[0] = 56.51*pow(alpha,1.0/5.0)*pow(tauc,2.0/5.0);
  ST->fTemp[1] = 1.44E11*alpha*jd*jd*pow(s,-5);
  al23 = alpha*jd*jd/(s*s*s*s*s);
  ST->fTemp[2] = 1.77E4*pow(al23,3.0/13.0);
  ST->fTemp[3] = 2.26E8*pow(al23,12.0/17.0);
  ST->fTemp[4] = 2.02E4*pow(al23,3.0/19.0);

  ST->rout = s;
}

void GetSigma(GASDISK_PARAMS *GP, STEPINSKI *ST, double t, double r, double *rij, double *pSigma){
   double Sigma, Gasp, Gasq;
   double rin = 0.1;
   double rout = ST->rout;
   double *fSigma = ST->fSigma;
  
  if(r > rij[0]){/* MOTOR */
      Gasp = 6.0/5.0;
      Gasq = 3.0/10.0;
      Sigma = fSigma[0]*pow(r,-Gasp);    
    }else if (r <= rij[0] && r > rij[1]){/* IGOR */
      Gasp = 0.0;
      Gasq = 3.0/2.0;
      Sigma = fSigma[1];   
    }else if (r <= rij[1] && r > rij[2]){/* IGSOR */
      Gasp = 15.0/13.0;
      Gasq = 9.0/26.0;
      Sigma = fSigma[2]*pow(r,-Gasp);   
    }else if (r <= rij[2] && r > rij[3]){/* SIGOR */
      Gasp = 15.0/34.0;
      Gasq = 18.0/17.0;
      Sigma = fSigma[3]*pow(r,-Gasp);  
    }else if (r <= rij[3]){/* SIGSOR */
      Gasp = 24.0/19.0;
      Gasq = 9.0/38.0;
      Sigma = fSigma[4]*pow(r,-Gasp); 
    }

  if(r < rin || r > rout){
    Sigma = 0.0;
  }

  
  *pSigma = Sigma;
 
}


void msrGravDirect(MSR msr){
    pkdGravDirect(msr->pst->plcl->pkd, msr->N);
}

#ifdef gastable
void msrGasTable(MSR msr, double dTime){
  /* calcilate nebular potential */
  /* Eq.(31) of Nagasawa et al. (2000) */
    struct inGasTable in;
    GASDISK_TABLE GD;
    /* iGasModel = 1: uniform, 2: inside-out */
    int iGasModel = msr->param.GP.iGasModel;
    double Gasp = msr->param.GP.dGasp;
    double Gasq = msr->param.GP.dGasq;
    double Sigma10 = msr->param.GP.dSigma10; // fsig missing?
    double dTemp1 = msr->param.GP.dTemp1;
    double Sigma, h, ro;
    int i,j,ig,jg;
    double ii,jj,iig,jjg;
    int nrmax_g = 189;
    int nzmax_g = 50;
    int nrmax_p = 150;
    int nzmax_p = 51;
    double dr1 = 0.1;
    double dr2 = 0.5;
    double rg[nrmax_g], zg[nrmax_g][nzmax_g];
    double rho_gas[nrmax_g][nzmax_g];
    double rp, zp, ar, az, drg, dzg, rin, zh;
    double temp, rpzm, rmzm, k2, ellf, elle;
    double rgas, zgas;
  
    if(iGasModel == 2) rin = 0.1 + dTime/(2.0*M_PI*msr->param.GP.dTau_diss); /* time scale for the inner egde to move 1AU*/ 

    /* 
       grid making for gas
       r direction:0.15au-14.95 au with 0.1au interval 15.25-34.75au 
       0.5au interval -->149 + 40 grids 
       z direction z/r 0.005-0.505 with 0.01 interval --> 50 grids 
 
       grids for particles 
       r dirction: 0.1 - 15au with 0.1 au -->150 grid
       z direction: z/r 0.0-1.5 with 0.03 -->51 grid
    */

    for(ig=0;ig<nrmax_g;ig++){
      iig = ig;
      if(ig<149){
	  drg = dr1;
	  rg[ig] = 0.15 + drg*iig;
      }else{
	  drg = dr2;
	  rg[ig] = 15.25 + (iig-149.0)*drg;	
      }
      
      h = 0.002*sqrt(dTemp1)*pow(rg[ig],(-0.5*Gasq+1.5));
      Sigma = Sigma10*pow(rg[ig],-Gasp);
      if(iGasModel == 2){
	  ro = rg[ig]+ 0.5*drg; /* ro: radius of the outer cel boundary */   
	  if(rin > ro){
	    Sigma = 0;
	  }else if(fabs(rin-rg[ig])<0.5*drg){
	    assert((ro-rin) <= drg);	    
	    Sigma *= (ro-rin)/drg;
	  }
      }   
      
      for(jg=0;jg<nzmax_g;jg++){
	jjg = jg;
	zg[ig][jg] = 0.01*(0.5+jjg)*rg[ig];  
	zh = zg[ig][jg]/h;
	rho_gas[ig][jg] = facrho*(Sigma/h)*exp(-0.5*zh*zh);
      }
    }
    
 
    /* calculation of ar az */       
    for(i=0;i<nrmax_p;i++){
      ii = i;
      rp = 0.1 + dr1*ii;

      h = 0.002*sqrt(dTemp1)*pow(rp,(-0.5*Gasq+1.5));
      Sigma = Sigma10*pow(rp,-Gasp);
      if(iGasModel == 2){
	  ro = rp + 0.5*dr1; /* ro: radius of the outer cel boundary */   
	  if(rin > rp+0.5*dr1){
	      Sigma = 0;
	  }else if(fabs(rin-rp)<0.5*dr1){
	      assert((ro-rin) <= dr1);
	      Sigma *= (ro-rin)/dr1;
	  }
      }   

      GD.Sigma[i] = Sigma;
      GD.h[i] = h; 
      GD.rr[i] = rp;

      for(j=0;j<nzmax_p;j++){
	jj = j;
	zp = (0.03*jj)*rp;        
	ar = 0.0;
	az = 0.0;
	temp = 0.0;
	for(ig=0;ig<nrmax_g;ig++){
	  
	    if(ig<150) drg = dr1;
	    else drg = dr2;
	    rgas = rg[ig];
	    dzg = 0.03*rgas;

	  for(jg=0;jg<nzmax_g;jg++){
	    zgas = zg[ig][jg];
	    rpzm = (zp-zgas)*(zp-zgas);
	    rmzm = rpzm + (rp-rgas)*(rp-rgas);
	    rpzm += (rp+rgas)*(rp+rgas);
	   
	    k2 = (4.0*rp*rgas)/rpzm;	     
	    ellf = rf(0.0,1.0-k2,1.0); /* first kind of elliptical integral */
	    elle = rf(0.0,1.0-k2,1.0)-k2*rd(0.0,1.0-k2,1.0)/3.0; /* second kind */

	    temp = -2.0*(rho_gas[ig][jg]/sqrt(rpzm))*rgas*drg*dzg;
	    elle /= rmzm; 

	    ar += (temp/rp)*(elle*(rp*rp-rgas*rgas - (zp-zgas)*(zp-zgas)) + ellf);
	    az += 2.0*temp*(zp-zgas)*elle;

	    zgas = -zgas;
	    rpzm = (zp-zgas)*(zp-zgas);
	    rmzm = rpzm + (rp-rgas)*(rp-rgas);
	    rpzm += (rp+rgas)*(rp+rgas);
	   
	    k2 = (4.0*rp*rgas)/rpzm;	     
	    ellf = rf(0.0,1.0-k2,1.0); /* first kind of elliptical integral */
	    elle = rf(0.0,1.0-k2,1.0)-k2*rd(0.0,1.0-k2,1.0)/3.0; /* second kind */

	    temp = -2.0*(rho_gas[ig][jg]/sqrt(rpzm))*rgas*drg*dzg;
	    elle /= rmzm; 

	    ar += (temp/rp)*(elle*(rp*rp-rgas*rgas - (zp-zgas)*(zp-zgas)) + ellf);
	    az += 2.0*temp*(zp-zgas)*elle;

	  }
	}
	GD.ar[i][j] = ar;
	GD.az[i][j] = az;
	GD.zz[i][j] = zp;

      }
      /*printf("r %e, ar15 %e, az15 %e, Sigma %e, ellf %e, elle %e\n", GD.rr[i],GD.ar[i][15],GD.az[i][15],GD.Sigma[i],ellf,elle);*/
    }
    
    GD.dTime = dTime;
    in.GD = GD;
    pstGasTable(msr->pst, &in, sizeof(in), NULL, NULL);
}

#endif

double rf(double x, double y, double z)
{/* the first kind elliptical integral, rf: from Numerical Recipe */
    double alamb, ave, delx, dely, delz, e2,e3,sqrtx,sqrty,sqrtz,xt,yt,zt;
    double errtol = 0.008;
    double tiny = 1.5e-38;
    double big = 3.0e37;
    double third = 1.0/3.0;
    double c1 = 1.0/24.0;
    double c2 = 0.1;
    double c3 = 3.0/44.0;
    double c4 = 1.0/14.0;  

    if(MIN(MIN(x,y),z) < 0.0 || MIN(MIN(x+y,x+z),y+z) < tiny || MAX(MAX(x,y),z) > big)
      {
	(void) fprintf(stderr,"x %e, y %e, z %e \n",x,y,z);
	(void) fprintf(stderr,"invalid arguments in rf \n");
	assert(0);
      }
 
    xt = x;
    yt = y;
    zt = z;
    do{
	sqrtx = sqrt(xt);
	sqrty = sqrt(yt);
	sqrtz = sqrt(zt);
	alamb = sqrtx*(sqrty+sqrtz)+sqrty*sqrtz;
	xt = 0.25*(xt+alamb);
   	yt = 0.25*(yt+alamb);
  	zt = 0.25*(zt+alamb);
	ave = third*(xt+yt+zt);
	delx = (ave-xt)/ave;
	dely = (ave-yt)/ave;
	delz = (ave-zt)/ave;
    }while(MAX(MAX(fabs(delx),fabs(dely)),fabs(delz)) > errtol);
    e2 = delx*dely-delz*delz;
    e3 = delx*dely*delz;
    return (1.0+(c1*e2-c2-c3*e3)*e2+c4*e3)/sqrt(ave);
}

double rd(double x, double y, double z)
{/* the second kind elliptical integral, rd: from Numerical Recipe */
    double alamb, ave, delx, dely, delz, ea,eb,ec,ed,ee,fac;
    double sqrtx,sqrty,sqrtz,sum, xt,yt,zt;
    double errtol = 0.005;
    double tiny = 1.0e-25;
    double big = 4.5e21;
    double c1 = 3.0/14.0;
    double c2 = 1.0/6.0;
    double c3 = 9.0/22.0;
    double c4 = 3.0/26.0;
    double c5 = 0.25*c3;
    double c6 = 1.5*c4;

    if(MIN(x,y) < 0.0 || MIN(x+y,z) < tiny || 
       MAX(MAX(x,y),z) > big){
	(void) fprintf(stderr,"invalid arguments in rd \n");
	assert(0);
    }
    xt = x;
    yt = y;
    zt = z;
    sum = 0.0;
    fac = 1.0;
    do{
	sqrtx = sqrt(xt);
	sqrty = sqrt(yt);
	sqrtz = sqrt(zt);
	alamb = sqrtx*(sqrty+sqrtz)+sqrty*sqrtz;
	sum += fac/(sqrtz*(zt+alamb));
	fac = 0.25*fac;
	xt = 0.25*(xt+alamb);
   	yt = 0.25*(yt+alamb);
  	zt = 0.25*(zt+alamb);
	ave = 0.2*(xt+yt+3.0*zt);
	delx = (ave-xt)/ave;
	dely = (ave-yt)/ave;
	delz = (ave-zt)/ave;
    }while(MAX(MAX(fabs(delx),fabs(dely)),fabs(delz)) > errtol);
    ea = delx*dely;
    eb = delz*delz;
    ec = ea - eb;
    ed = ea -6.0*eb;
    ee = ed + ec + ec;
    return 3.0*sum+fac*(1.0+ed*(-c1+c5*ed-c6*delz*ee)
	+ delz*(c2*ee+delz*(-c3*ec+delz*c4*ea)))/(ave*sqrt(ave));
}   


#ifdef SYMBA
void msrTopStepSymba(MSR msr,
		     double dStep,	/* Current step */
		     double dTime,	/* Current time */
		     double dDelta,	/* Time step */
		     int iRung,		/* Rung level */
		     int iKickRung,	/* Gravity on all rungs from iRung
					   to iKickRung */
		     int iRungVeryActive,  /* current setting for iRungVeryActive */
		     int iAdjust,		/* Do an adjust? */
		     double *pdActiveSum,
		     double *pdWMax,
		     double *pdIMax,
		     double *pdEMax,
		     int *piSec)
{
    double dMass = -1.0;
    int nActive;
    int bSplitVA;
    double tempdEcoll;
    int i, hillflag;
    int iGasModel = msr->param.GP.iGasModel;
    double dDcoll;

    msrActiveRung(msr,0,1); /* activate all particles */    

    /* F_0 for particles at iRung = 0 and 1 */		
    msrKickKDKOpen(msr,dTime,0.5*dDelta);   

    /*	
    ** drift all particles to the end of time step
    */
    if (msr->param.bVDetails) puts("keplerdrift starts");
    msrKeplerDrift(msr, dDelta);
    if (msr->param.bVDetails) puts("keplerdrift ends");
    /*printf("msrKeplerDrift  \n");*/
    /*
     * check min.distance (drmin2) during drift 
     */ 
    if(msr->param.iGravDirect <=2){
      if (msr->param.iGravDirect ==2 || (msr->param.iGravDirect ==1 && msr->N<nDirect)){
	msrSearchDirect(msr);
      }else{
	msrBuildTree(msr,dMass,dTime); 
	msrSmooth(msr,dTime,SMX_SYMBA,0,1,TYPE_ALL); /* bSymmetric = 1 */
      }
    }
 
    if(msr->param.iGravDirect >=3) msrSearchPlanets(msr);
    if (msr->param.bVDetails) puts("msrsearch in topstepsymba ends");


    /*
     * Determine p->iRung from p->drmin 
     ** If drmin2 < 3Hill, (but drmin > 3Hill), this interacting pair 
     ** is sent to iRung = 1. Positions and velocities before the drift 
     ** are retrived (x = xb, v = vb) for particles with p_iRung >=1
     */ 
   
    msrDrminToRung(msr,iRung);
    if (msr->param.bVDetails) printf("msrDrmintoRung done \n");

    /*
     * Activate VeryActives
     */
    msrActiveRung(msr,1,1); /* msr->iRungVeryActive+1 = 1 */
    tempdEcoll = msr->dEcoll;

    if(msr->nActive){ /* if any particles in close encounters */
      /*printf("nVA %d\n", msr->nActive);*/
    if(msrDoGravity(msr)) {	   
      /*
      ** Domain decomposition for parallel exclude very active is going to be 
      ** placed here shortly.
      */
	
      if (msr->nThreads > 1){
	    bSplitVA = 1;
	    msrDomainDecomp(msr,iRung,1,bSplitVA);
	}
    }
    
    /*
     * Perform timestepping of particles in close encounters on 
     * individual processors.
     */
    if (msr->param.bVDetails) puts("msrstepveryactive starts");
    msrStepVeryActiveSymba(msr,dStep,dTime, dDelta, iRung);
    if (msr->param.bVDetails) puts("msrstepveryactive ends");
    }
    
    dTime += dDelta;
    dStep += 1.0;

    /* 
       Here mainly heliocentric distance check and delte particles.
       Actual collisions are mostly handled in msrStepVeryActiveSymba
       (a flag would be more effcient here) 
     */
    if(msr->param.bCollision) msrDoCollision(msr,dTime,dDelta);     
    if (msr->param.bVDetails) printf("msrDoCollision done \n");

#ifdef sm2d
    if(msr->param.HY.iPebbleSupply) msrPebbleSupply(msr,dTime,dDelta);     
   
    //goto skipst; //test
 /* PBHYB */
    if(msr->param.iGravDirect >=4){
      msr->TYPE_PBHYB = 0; /* reset */
      msrActiveRung(msr,iKickRung,1); /* iKickRung = 0 */ 
      bSplitVA = 0;
      /*get random number RN first */
      /*dDstir = msr->RN*2.0*100.0*dDelta;*/
      /*msr->dDstir = 100.0*dDelta;*/

      /*printf("dTime %g dDstir %g \n",dTime,dDstir);*/

      /* PBHYB collisions*/
      if(msr->param.bCollision && ((dTime-msr->dTcoll0) > 1.1*msr->dDstir)){
      if (msr->param.bVDetails) printf("dTime %g PBHYB collision \n",dTime);

	msr->dDPBHYB = dTime-msr->dTcoll0;
	msr->TYPE_PBHYB = 1; /* for collision */
	/*calculate orbital elements (in democratic coordinate)*/
	msrCalcElem(msr);


	/* serach collisions using the statistical approach */
	if (msr->param.iGravDirect >= 6 || (msr->param.iGravDirect ==5 && msr->N<nDirect)){
	  msrPBHYBCollStirDirect(msr,dTime,msr->TYPE_PBHYB,msr->dDPBHYB);
	}else{	  	 
	  msrDomainDecomp(msr,iKickRung,1,bSplitVA);
	  msrBuildTree(msr,dMass,dTime);    
	  msrSmooth(msr,dTime,SMX_PBHYBCOLLSTIR,0,1,TYPE_ALL); /* bSymmetric = 1*/
	}


	/* Do colliions and split if necessary*/
	msrDoCollisionPBHYB(msr,dTime,dDelta);        

	if(msr->param.HY.iPlForm >=1){
	  msrPebble2Planetesimal(msr,dTime,msr->param.HY.iPlForm,msr->dDPBHYB);
	}

	if(msr->param.HY.iGasAcc2Planet >=1){
	  msrGasAcc2Planet(msr,dTime,msr->param.HY.iGasAcc2Planet,msr->dDPBHYB);
	}
		
	msr->dTcoll0 = dTime; /* reset time for collision */
	/* msrCalcHill(msr,dDelta,1);  orbital elements (a,e^2,i^2) are recalculated */ 

      }
      
      if(msr->param.HY.iTRGRAV==0)msr->TYPE_PBHYB = 1; // skip stirring for non-grav test

      
      /* PBHYB stirring*/
      if((dTime-msr->dTstir0) > msr->dDstir && msr->TYPE_PBHYB != 1){
        if (msr->param.bVDetails)printf("dTime %g dTstir0 %g dDstir %g PBHYB stirring \n",dTime,msr->dTstir0,msr->dDstir);
	msr->dDPBHYB = dTime-msr->dTstir0;
	msr->TYPE_PBHYB = 2; /* for stirring */
	msrCalcElem(msr);
	msrResetKick(msr);

	if (msr->param.iGravDirect >=6 || (msr->param.iGravDirect ==5 && msr->N<nDirect)){	 
	  msrPBHYBCollStirDirect(msr,dTime,msr->TYPE_PBHYB,msr->dDPBHYB);  
	}else{	 
	  msrDomainDecomp(msr,iKickRung,1,bSplitVA);
	  msrBuildTree(msr,dMass,dTime);    
	  msrSmooth(msr,dTime,SMX_PBHYBCOLLSTIR,0,1,TYPE_ALL); /* bSymmetric = 1*/
	}

	msrDeletoKick(msr,dTime,msr->dDPBHYB); /* dDstir is determined here */	

	/*msrCalcElem(msr); for test outputs*/

	msr->dTstir0 = dTime; /* reset time for stirring */

	/* printf("PBHYB stirring done \n");*/
      }    

      if(msr->TYPE_PBHYB > 0) msrCalcHill(msr,dDelta,1); 
    }

    // skipst:
# endif /* sm2d */

    /* accelaration is NOT reset if msrDoGravity = 0. So far we always use msrDoGravity = 1. 
       May need correction for future */

    if(msrDoGravity(msr)) {    
      msrActiveRung(msr,iKickRung,1); /* iKickRung = 0 */ 
      msrCalcHill(msr,dDelta,0); /* orbital elements are calculated  */

       if (msr->param.bVDetails) puts("msrcalchill ends");

      if (msr->param.iGravDirect <=2){
	if (msr->param.iGravDirect ==2 || (msr->param.iGravDirect ==1 && msr->N< nDirect)){
	  msrGravDirect(msr);
	}else{
	  
	  /*
	   * Regular Tree gravity
	   */
	  bSplitVA = 0;
	  msrDomainDecomp(msr,iKickRung,1,bSplitVA);
	  msrActiveRung(msr,iKickRung,1);	   
	  if (msr->param.bVDetails) {
	      printf("%*cGravity, iRung: %d to %d\n",
		     2*iRung+2,' ',iKickRung,msrCurrMaxRung(msr));
	  }
	  msrBuildTree(msr,dMass,dTime);    
	  msrGravity(msr,dTime,dStep,0,0,piSec,pdWMax,pdIMax,pdEMax,&nActive);
	  *pdActiveSum += (double)nActive/msr->N;	 	    	 	  
	}
      }
      if(msr->param.iGravDirect >=3){	  
	msrGravPlanets(msr);	
      }     
    }  

    msrActiveRung(msr,iRung,1);	
 
    if(iGasModel){
      if((iGasModel == 1 && dTime > 15*(2.0*M_PI)*msr->param.GP.dTau_diss) ||  /* exp(-15)=3*10^{-7}*/
         (iGasModel == 2 && dTime > 30*(2.0*M_PI)*msr->param.GP.dTau_diss) ||
	 (iGasModel == 3 && msr->param.GP.bWind && dTime > (2.0*M_PI)*(1.E6 + msr->param.GP.t_trans))){
      }else{
	msrGasAccel(msr,dTime-0.5*dDelta,0.5*dDelta);// dDelta not used
      } 
    }

#ifdef sm2d
    // we turn off the tracers potential as it causes unfavable radial motion/migration... 11/21/2016
    // This was found to be due to incompatibility with dynamical friction in the statistical routine.
    // The problem has been resolved on 120516 !! We now use orbital elements that takes into account
    // all gravitational forces (central star, global gravity of tracers, and embryos' gravity )
    
    if(msr->param.HY.iTRGRAV)msrTrPotAcc(msr,dTime-0.5*dDelta); 
#endif

    msrKickKDKClose(msr,dTime-0.5*dDelta,0.5*dDelta);
    
    /* linear shifts due to Sun's velocity. 
       The next half-step shifts are included   
    */

    // only when embryos exist (081115) if(msr->nPL)
    // This option was introduced to handle very small eccentiricites with small
    // number of tracers, but removed on 112016
    
    if(msr->nPL)msrDriftSun(msr,dTime-0.5*dDelta,dDelta);      
    
}

void
msrStepVeryActiveSymba(MSR msr, double dStep, double dTime, double dDelta,
		     int iRung){
    struct inStepVeryActiveS in;
    struct outStepVeryActiveS out;    
   
    if (msr->param.bVDetails) printf("%d VeryActiveSymba\n",2*iRung+2);
    
    in.dStep = dStep;
    in.dTime = dTime;
    in.dDelta = dDelta;
    in.iRung = iRung;
    /* could set a stricter opening criterion here */
    in.diCrit2 = 1/(msr->dCrit*msr->dCrit);  
    in.nMaxRung = msrCurrMaxRung(msr);
    in.dSunMass = msr->dSunMass;
    in.GP = msr->param.GP; // added 110516
    
    pstStepVeryActiveSymba(msr->pst, &in, sizeof(in), &out, NULL);

    if (msr->param.bVDetails) printf("%d pstVeryActiveSymba ends \n",2*iRung+2);
     
    if(msr->param.bCollision){
    struct outGetVariableVeryActive outGet;
    pstGetVariableVeryActive(msr->pst, NULL, 0, &outGet, NULL);
    msr->dEcoll += outGet.dDeltaEcoll;
    outGet.dDeltaEcoll = 0.0;/*just in case */
    }
    msr->iCurrMaxRung = out.nMaxRung;
}

void msrSearchDirect(MSR msr){
    pkdSearchDirect(msr->pst->plcl->pkd,msr->N);
}


void msrSymbaInitial(MSR msr, double dTime){
  pstSymbaInitial(msr->pst, NULL, 0, NULL, NULL);


#ifdef sm2d  

  struct outChecknSmooth outCh;

  msrCalcElem(msr);
  msr->dTstir0 = dTime;
  msr->dTcoll0 = dTime;

  if (msr->param.iGravDirect >=6){
    msr->TYPE_PBHYB = 0; /* 0 for calculating surface density */
    msrPBHYBCollStirDirect(msr,dTime,msr->TYPE_PBHYB,msr->dDPBHYB);
  }

  if (msr->param.iGravDirect ==4){
  
    /* determine msr->param.nSmooth */
    msrDomainDecomp(msr,0,1,0);
    msrBuildTree(msr,0,dTime);    
    
    msr->TYPE_PBHYB = 0; /* 0 for checking nSmooth */
    msrSmooth(msr,dTime,SMX_PBHYBCOLLSTIR,0,1,TYPE_ALL); /* bSymmetric = 1*/
    
    do{
      msr->param.nSmooth *= 1.5;
      //  printf("nSmooth = %d \n",msr->param.nSmooth); 
      msrSmooth(msr,dTime,SMX_PBHYBCOLLSTIR,0,1,TYPE_ALL);
      pstChecknSmooth(msr->pst, NULL, 0, &outCh, NULL);
    }while(outCh.iFlag == 0);
    
    msr->param.nSmooth /= 1.3; /* for safety, we do not use 1.5 */
    
    printf("nSmooth = %d \n",msr->param.nSmooth);
  }



#endif

}

void msrCalcHill(MSR msr, double dDelta, int bIflag){ 
    struct inCalcHill in;

    in.dDelta = dDelta;
    in.bIflag = bIflag;
    pstCalcHill(msr->pst, &in, sizeof(in), NULL, NULL);
}

void msrDrminToRung(MSR msr,int iRung){
  struct inDrminToRung in;
  struct outDrminToRung out;
  int iTempRung,iOutMaxRung;
  char c;
 
  in.iRung = iRung;
  in.iMaxRung = msrMaxRung(msr);

  pstDrminToRung(msr->pst, &in, sizeof(in), &out, NULL);
  iTempRung =msrMaxRung(msr)-1;
  while (out.nRungCount[iTempRung] == 0 && iTempRung > 0) --iTempRung;
  iOutMaxRung = iTempRung;

  /*
    ** Now copy the rung distribution to the msr structure!
    */
  for (iTempRung=0;iTempRung < msrMaxRung(msr);++iTempRung){
    msr->nRung[iTempRung] = out.nRungCount[iTempRung];
  }
  msr->nRung[msrMaxRung(msr)] = 0; /* just for sure */
  msr->iCurrMaxRung = iOutMaxRung;
  
  if (msr->param.bVRungStat) {
    	printf("Rung distribution:\n");
	for (iTempRung=0;iTempRung <= msr->iCurrMaxRung;++iTempRung) {
	    if (out.nRungCount[iTempRung] == 0) continue;
	    if (iTempRung > 0 ) c = 'v'; /* iRungVeryActive = 0*/
	    else c = ' ';
	    printf(" %c rung:%d %d\n",c,iTempRung,out.nRungCount[iTempRung]);
	    }
	printf("\n");
	}
  
  /*
   * Set VeryActive particles
   * Remember, the first very active particle is at iRungVeryActive + 1 
   */
  msrSetRungVeryActive(msr, 0); /* iRungVeryActive = 0*/
}

void msrDriftSun(MSR msr,double dTime,double dDelta){
	struct inDriftSun in;
	struct outMomCent outm;

	int j;
	/* Calculate sum of the momentum */
	pstMomCent(msr->pst,NULL,0,&outm,NULL); 
	
	for (j=0;j<3;++j){ 	    
                in.vSun[j] = -outm.momCent[j]/msr->dSunMass;	
	}
	in.dDelta = dDelta;
	pstDriftSun(msr->pst,&in,sizeof(in),NULL,NULL);

} 

void msrHeltoDemo(MSR msr){
	struct inHeltoDemo in;
	struct outMomCent outm;

	double mt;
	int j;
	/* Calculate sum of the momentum */
	pstMomCent(msr->pst,NULL,0,&outm,NULL); 
	mt = msr->dSunMass + outm.mCent;

	for (j=0;j<3;++j){ 	    
                in.vCent[j] = outm.momCent[j]/mt;	
	}
	
	pstHeltoDemo(msr->pst,&in,sizeof(in),NULL,NULL);
} 

void msrDemotoHel(MSR msr){
	struct inDemotoHel in;
	struct outMomCent outm;

	int j;
	/* Calculate sum of the momentum */
	pstMomCent(msr->pst,NULL,0,&outm,NULL); 

	for (j=0;j<3;++j){ 	    
                in.vSun[j] = -outm.momCent[j]/msr->dSunMass;	
	}
	
	pstDemotoHel(msr->pst,&in,sizeof(in),NULL,NULL);
} 


void msrKeplerDrift(MSR msr,double dDelta){
    struct inKeplerDrift in;
    
    in.dDelta = dDelta;
    in.dSunMass = msr->dSunMass;
    pstKeplerDrift(msr->pst,&in,sizeof(in),NULL,NULL);
	
} 

void msrGravPlanets(MSR msr){
  struct inGravPlanets in;
  struct outGravPlanets out;

  struct outGetPlanets outg;
  struct inHandPlanets inh;

  int i;

  if (msr->param.bVDetails) puts("get planets starts");
  pstGetPlanets(msr->pst,NULL,0,&outg,NULL);
  if (msr->param.bVDetails) printf("get planets ends %d \n", outg.nPL);

  in.nPL = outg.nPL;
  for (i=0;i<outg.nPL;++i){
    in.pp[i] = outg.pp[i];
  }
  msr->nPL = outg.nPL;

  //if(in.nPL || msr->param.GP.iGasModel){ /* now we always call this to reset accelaration */
    if (msr->param.bVDetails) puts("pstgravplanets starts");
    pstGravPlanets(msr->pst,&in,sizeof(in),&out,NULL);  
    if (msr->param.bVDetails) puts("pstgravplanets ends");
    
    inh.nPL = out.nPL;
    for (i=0;i<inh.nPL;++i){
      inh.pp[i] = out.pp[i];
    }
    
    if (msr->param.bVDetails) puts("hand planets starts");
    pstHandPlanets(msr->pst,&inh,sizeof(inh),NULL,NULL);  
    if (msr->param.bVDetails) puts("hand planets ends");
    //}
}

void msrSearchPlanets(MSR msr){
  /* planets are bodies with colors <=5 */
  struct inSearchPlanets in;
  struct outSearchPlanets out;

  struct outGetPlanets outg;
  struct inHandPlanets inh;

  int i;

  pstGetPlanets(msr->pst,NULL,0,&outg,NULL);
 
  in.nPL = outg.nPL;
  for (i=0;i<outg.nPL;++i){
    in.pp[i] = outg.pp[i];
    in.pp2[i] = outg.pp[i]; /* this is for n_VA0 */
  }

  pstSearchPlanets(msr->pst,&in,sizeof(in),&out,NULL);  

  inh.nPL = out.nPL;
  for (i=0;i<inh.nPL;++i){
    inh.pp[i] = out.pp[i];
  }
  
  pstHandPlanets(msr->pst,&inh,sizeof(inh),NULL,NULL);  

}



#endif /* SYMBA */
#endif /* PLANETS*/

void msrWrite(MSR msr,char *pszFileName,double dTime,int bCheckpoint)
{
#ifdef PLANETS 
    msrWriteSS(msr,pszFileName,dTime);
#else
#ifdef USE_MDL_IO
    /* If we are using I/O processors, then we do it totally differently */
    if ( mdlIO(msr->mdl) ) {
	msrIOWrite(msr,pszFileName,dTime,bCheckpoint);
    }
    else
#endif
    {
	_msrWriteTipsy(msr,pszFileName,dTime,bCheckpoint);
    }
#endif
}


double msrRead(MSR msr)
{
#ifdef PLANETS    
    return msrReadSS(msr); /* must use "Solar System" (SS) I/O format... */
#else
    char achFilename[PST_FILENAME_SIZE];

    if ( ! msr->param.achInFile[0] ) {
	printf("No input file specified\n");
	_msrExit(msr,1);
	return -1.0;
    }

    /* Add Data Subpath for local and non-local names. */
    _msrMakePath(msr->param.achDataSubPath,msr->param.achInFile,achFilename);

#ifdef USE_HDF5
    /* We can automatically detect if a given file is in HDF5 format */
    if ( H5Fis_hdf5(achFilename) ) {
    }
    else
#endif
    {
	return _msrReadTipsy(msr,achFilename);
    }
#endif
}
