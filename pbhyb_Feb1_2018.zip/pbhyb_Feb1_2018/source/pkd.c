#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#define _LARGEFILE_SOURCE 
#define _FILE_OFFSET_BITS 64 
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#ifdef HAVE_MALLOC_H
#include <malloc.h>
#endif
#include <math.h>
#include <assert.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h> /* added MZ */

#include <rpc/types.h>
#include <rpc/xdr.h>
#include <inttypes.h>

#include "pkd.h"
#include "ewald.h"
#include "walk.h"
#include "grav.h"
#include "mdl.h"
#include "tipsydefs.h"
#include "collision.h"
#include "smoothfcn.h"
#include "kepler.h"

#include "../analysis/ss.h"
#include "../analysis/ssio.h"
#include "../analysis/helio.h"
#include "../analysis/delaunay.h"

#include "parameters.h"
#include "cosmo.h"

#ifdef USE_HDF5
#include "iohdf5.h"
#endif

#ifdef BSC
#include "mpitrace_user_events.h"
#endif

double Zeit() { /* added MZ */
    struct timeval tv;

    gettimeofday(&tv,NULL);
    return (tv.tv_sec+(tv.tv_usec*1e-6));
    }

double pkdGetTimer(PKD pkd,int iTimer)
    {
    return(pkd->ti[iTimer].sec);
    }

double pkdGetSystemTimer(PKD pkd,int iTimer)
    {
    return(pkd->ti[iTimer].system_sec);
    }

double pkdGetWallClockTimer(PKD pkd,int iTimer)
    {
    return(pkd->ti[iTimer].wallclock_sec);
    }


void pkdClearTimer(PKD pkd,int iTimer)
    {
    int i;

    if (iTimer >= 0) {
	pkd->ti[iTimer].sec = 0.0;
	pkd->ti[iTimer].system_sec = 0.0;
	pkd->ti[iTimer].wallclock_sec = 0.0;
	pkd->ti[iTimer].iActive = 0;
	}
    else {
	for (i=0;i<MAX_TIMERS;++i) {
	    pkd->ti[i].sec = 0.0;
	    pkd->ti[i].system_sec = 0.0;
	    pkd->ti[i].wallclock_sec = 0.0;
	    pkd->ti[i].iActive = 0;
	    }
	}
    }


void pkdStartTimer(PKD pkd,int iTimer)
    {
    struct timeval tv;

    pkd->ti[iTimer].iActive++;

    if (pkd->ti[iTimer].iActive == 1) {
	pkd->ti[iTimer].stamp = mdlCpuTimer(pkd->mdl);
	gettimeofday(&tv,NULL);
	pkd->ti[iTimer].wallclock_stamp = tv.tv_sec + 1e-6*(double) tv.tv_usec;
	    {
	    struct rusage ru;
	    
	    getrusage(0,&ru);
	    pkd->ti[iTimer].system_stamp = (double)ru.ru_stime.tv_sec + 1e-6*(double)ru.ru_stime.tv_usec;
	    }
	}
    }


void pkdStopTimer(PKD pkd,int iTimer)
    {
    double sec;
    struct timeval tv;

    sec = -pkd->ti[iTimer].stamp;
    pkd->ti[iTimer].stamp = mdlCpuTimer(pkd->mdl);
    sec += pkd->ti[iTimer].stamp;
    if (sec < 0.0) sec = 0.0;
    pkd->ti[iTimer].sec += sec;

    sec = -pkd->ti[iTimer].wallclock_stamp;
    gettimeofday( &tv, NULL );
    pkd->ti[iTimer].wallclock_stamp = tv.tv_sec + 1e-6*(double)tv.tv_usec;
    sec += pkd->ti[iTimer].wallclock_stamp;
    if (sec < 0.0) sec = 0.0;
    pkd->ti[iTimer].wallclock_sec += sec;

#ifndef _CRAYMPP
	{
	struct rusage ru;

	sec = -pkd->ti[iTimer].system_stamp;
	getrusage(0,&ru);
	pkd->ti[iTimer].system_stamp = ((double)ru.ru_stime.tv_sec + 1e-6*(double)ru.ru_stime.tv_usec);
	sec += pkd->ti[iTimer].system_stamp;
	if (sec < 0.0) sec = 0.0;
	pkd->ti[iTimer].system_sec += sec;
	}
#endif
	pkd->ti[iTimer].iActive--;
    }


void pkdInitialize(PKD *ppkd,MDL mdl,int nStore,int nBucket,FLOAT *fPeriod,
		   int nDark,int nGas,int nStar) {
    PKD pkd;
    int j;
	
    pkd = (PKD)malloc(sizeof(struct pkdContext));
    mdlassert(mdl,pkd != NULL);
    pkd->mdl = mdl;
    pkd->idSelf = mdlSelf(mdl);
    pkd->nThreads = mdlThreads(mdl);
    pkd->nStore = nStore;
    pkd->nLocal = 0;
    pkd->nDark = nDark;
    pkd->nGas = nGas;
    pkd->nStar = nStar;
    pkd->nMaxOrderGas = nGas - 1;
    pkd->nMaxOrderDark = nGas + nDark - 1;

    pkd->nRejects = 0;
    for (j=0;j<3;++j) {
	pkd->fPeriod[j] = fPeriod[j];
	}

    pkd->uMinRungActive  = 0;
    pkd->uMaxRungActive  = 255;
    pkd->uRungVeryActive = 255;

    /*
    ** Allocate the main particle store.
    ** Need to use mdlMalloc() since the particles will need to be
    ** visible to all other processors thru mdlAquire() later on.
    **
    ** We need one EXTRA storage location at the very end to use for 
    ** calculating acceleration on arbitrary positions in space, for example
    ** determining the force on the sun. The easiest way to do this is to
    ** allocate one hidden particle, which won't interfere with the rest of
    ** the code (hopefully). pkd->pStore[pkd->nStore] is this particle.
    */
    pkd->pStore = mdlMalloc(pkd->mdl,(nStore+1)*sizeof(PARTICLE));
    mdlassert(mdl,pkd->pStore != NULL);
    /*
    ** Now also allocate all node storage here.
    ** We guess that the upper bound is based on the number of particles in 
    ** a bucket. The mean number of particles per bucket is always somewhat 
    ** less than nBucket, and roughly given by nBucket-sqrt(nBucket).
    */
    pkd->nMaxNodes = (int)ceil(3.0*nStore/floor(nBucket - sqrt(nBucket)));
    pkd->kdNodes = mdlMalloc(pkd->mdl,pkd->nMaxNodes*sizeof(KDN));
    mdlassert(mdl,pkd->kdNodes != NULL);
    /*
    ** pLite particles are also allocated and are quicker when sorting particle
    ** type operations such as tree building and domain decomposition are being
    ** performed.
    */
    pkd->pLite = malloc((nStore+1)*sizeof(PLITE));
    mdlassert(mdl,pkd->pLite != NULL);
    pkd->nNodes = 0;
    pkd->kdTop = NULL;
    /*
    ** Ewald stuff!
    */
    pkd->nMaxEwhLoop = 100;
    pkd->ewt = malloc(pkd->nMaxEwhLoop*sizeof(EWT));
    mdlassert(mdl,pkd->ewt != NULL);
    *ppkd = pkd;
    /*
    ** Allocate initial particle pointer arrays for active/inactive particles.
    */
    pkd->nMaxBucketActive = 1000;
    pkd->piActive = malloc(pkd->nMaxBucketActive*sizeof(PARTICLE *));
    mdlassert(mdl,pkd->piActive != NULL);
    pkd->piInactive = malloc(pkd->nMaxBucketActive*sizeof(PARTICLE *));
    mdlassert(mdl,pkd->piInactive != NULL);

#ifdef sm2d
    pkd->PD= malloc(sizeof(TRACERPOT));
    mdlassert(mdl,pkd->PD != NULL);
#endif
    }


void pkdFinish(PKD pkd)
    {
#ifdef sm2d  
      free(pkd->PD);
#endif
    if (pkd->kdNodes) {
	/*
	** Close caching space and free up nodes.
	*/
	mdlFinishCache(pkd->mdl,CID_CELL);
	mdlFree(pkd->mdl,pkd->kdNodes);
	}
    if (pkd->kdTop) free(pkd->kdTop);
    free(pkd->ewt);
    mdlFree(pkd->mdl,pkd->pStore);
    free(pkd->pLite);
    csmFinish(pkd->param.csm);
    free(pkd);
    }


void pkdSeek(PKD pkd,FILE *fp,int nStart,int bStandard,int bDoublePos) {
    off_t MAX_OFFSET = 2147483640;
    long long nStart64 = nStart;
    long long nGas64 = pkd->nGas;
    long long nDark64 = pkd->nDark;
    off_t lStart;
    int iErr;
    /*
    ** Seek according to true XDR size structures when bStandard is true.
    ** This may be a bit dicey, but it should work as long
    ** as no one changes the tipsy binary format!
    */
    if (bStandard) lStart = 32;
    else lStart = sizeof(struct dump);
    if (nStart64 > nGas64) {
	if (bStandard) lStart += nGas64*(bDoublePos?60:48);
	else lStart += nGas64*sizeof(struct gas_particle);
	nStart64 -= nGas64;
	if (nStart64> nDark64) {
	    if (bStandard) lStart += nDark64*(bDoublePos?48:36);
	    else lStart += nDark64*sizeof(struct dark_particle);
	    nStart64 -= nDark64;
	    if (bStandard) lStart += nStart64*(bDoublePos?56:44);
	    else lStart += nStart64*sizeof(struct star_particle);
	    }
	else {
	    if (bStandard) lStart += nStart64*(bDoublePos?48:36);
	    else lStart += nStart64*sizeof(struct dark_particle);
	    }
	} 
    else {
	if (bStandard) lStart += nStart64*(bDoublePos?60:48);
	else lStart += nStart64*sizeof(struct gas_particle);
	}
    
    /*fseek fails for offsets >= 2**31; this is an ugly workaround;*/
    if(lStart > MAX_OFFSET){
	iErr = fseek(fp,0,SEEK_SET);
	if (iErr) {
	    perror("pkdSeek failed");
	    exit(errno);
	    }
	while(lStart > MAX_OFFSET){
	    fseek(fp,MAX_OFFSET,SEEK_CUR);
	    lStart -= MAX_OFFSET;
	    }
	iErr = fseek(fp,lStart,SEEK_CUR);
	if (iErr) {
	    perror("pkdSeek failed");
	    exit(errno);
	    }
	} 
    else { 
	iErr = fseek(fp,lStart,SEEK_SET);
	if (iErr) {
	    perror("pkdSeek failed");
	    exit(errno);
	    }
	}
    }


void IOCheck(int nout) {
    if (nout != 1) {
	perror("IOCheck failed");
	exit(errno);
	}
    }


#ifdef USE_HDF5
void pkdReadHDF5(PKD pkd, IOHDF5 io, double dvFac,
		 int nStart, int nLocal ) {
    PARTICLE *p;
    FLOAT dT1, dT2;
    int i, j;

    pkd->nLocal = nLocal;
    pkd->nActive = nLocal;

    /*
    ** General initialization.
    */
    for (i=0;i<nLocal;++i) {
	p = &pkd->pStore[i];
	TYPEClear(p);
	p->iRung = 0;
	p->fWeight = 1.0;
	p->fDensity = 0.0;
	p->fBall = 0.0;
	}

    /*TODO: add tracker file */

    for (i=0;i<nLocal;++i) {
	p = &pkd->pStore[i];
	p->iOrder = nStart + i;

	if (pkdIsDark(pkd,p)) {
	    ioHDF5GetDark( io, &p->iOrder, p->r, p->v,
			   &p->fMass, &p->fSoft, &p->fPot );
	    for (j=0;j<3;++j) p->v[j] *= dvFac;
#ifdef CHANGESOFT
	    p->fSoft0 = p->fSoft;
#endif
	}
	else if (pkdIsGas(pkd,p)) {
	    ioHDF5GetGas( io, &p->iOrder, p->r, p->v,
			  &p->fMass, &p->fSoft, &p->fPot,
			  &dT1, &dT2 );
	    for (j=0;j<3;++j) p->v[j] *= dvFac;
#ifdef CHANGESOFT
	    p->fSoft0 = p->fSoft;
#endif
	}
	else if (pkdIsStar(pkd,p)) {
	    ioHDF5GetStar( io, &p->iOrder, p->r, p->v,
			   &p->fMass, &p->fSoft, &p->fPot,
			   &dT1, &dT2 );
	    for (j=0;j<3;++j) p->v[j] *= dvFac;
#ifdef CHANGESOFT
	    p->fSoft0 = p->fSoft;
#endif
	}
	else mdlassert(pkd->mdl,0);
	if(p->fSoft < sqrt(2.0e-38)) { /* set minimum softening */
	    p->fSoft = sqrt(2.0e-38);
	}
    }
}
#endif


void pkdReadTipsy(PKD pkd,char *pszFileName, char *achOutName, int nStart,int nLocal,
		  int bStandard,double dvFac,int bDoublePos)
    {
    FILE *fp;
    int i,j;
    PARTICLE *p;
    struct dark_particle dp;
    struct gas_particle gp;
    struct star_particle sp;
    float fTmp;
    double dTmp;
    float mass=0.0;
    /*
    ** Variables for particle tracking
    */
    FILE *fpTrack = NULL;
    char aTrack[256];
    int nBodies,nGas,nStar,iRet;
    int iTracker;	

    pkd->nLocal = nLocal;
    pkd->nActive = nLocal;
    /*
    ** General initialization.
    */
    for (i=0;i<nLocal;++i) {
	p = &pkd->pStore[i];
	TYPEClear(p);
	p->iRung = 0;
	p->fWeight = 1.0;
	p->fDensity = 0.0;
	p->fBall = 0.0;
	}
    /*
    ** Seek past the header and up to nStart.
    */
    fp = fopen(pszFileName,"r");
    mdlassert(pkd->mdl,fp != NULL);
    /*
    ** Seek to right place in file.
    */
    pkdSeek(pkd,fp,nStart,bStandard,bDoublePos);
    /*
    ** See if the user has specified a .track file.
    */
    iTracker = nStart-1;
    sprintf(aTrack,"%s.track",achOutName);
    fpTrack = fopen(aTrack,"r");
    if (fpTrack) {
	/*
	** Get to the right place in the file.
	*/
	iRet = fscanf(fpTrack,"%d %d %d",&nBodies,&nGas,&nStar);
	if (!iRet || iRet == EOF) {
	    fclose(fpTrack);
	    goto SkipCheck;
	    }
	while (1) {
	    iRet = fscanf(fpTrack,"%d",&iTracker);
	    iTracker = iTracker - 1;
	    if (!iRet || iRet == EOF) {
		fclose(fpTrack);
		iTracker = nStart-1;
		break;
		}
	    if (iTracker >= nStart) break;
	    }
	}
SkipCheck:
    /*
    ** Read Stuff!
    */
    if (bStandard) {
	FLOAT vTemp;
	XDR xdrs;
	xdrstdio_create(&xdrs,fp,XDR_DECODE);
	for (i=0;i<nLocal;++i) {
	    p = &pkd->pStore[i];
	    p->iOrder = nStart + i;
	    if (p->iOrder == iTracker) {
		TYPESet(p,TYPE_TRACKER);
		iRet = fscanf(fpTrack,"%d",&iTracker);
		iTracker = iTracker-1;
		if (!iRet || iRet == EOF) {
		    fclose(fpTrack);
		    iTracker = nStart-1;
		    }
		}
	    if (pkdIsDark(pkd,p)) {
		xdr_float(&xdrs,&fTmp);
		p->fMass = fTmp;
		mass += fTmp;
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			xdr_double(&xdrs,&dTmp);
			p->r[j] = dTmp;
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			xdr_float(&xdrs,&fTmp);
			p->r[j] = fTmp;
			}
		    }
		for (j=0;j<3;++j) {
		    xdr_float(&xdrs,&fTmp);
		    vTemp = fTmp;
		    p->v[j] = dvFac*vTemp;			
		    }
		xdr_float(&xdrs,&fTmp);
		p->fSoft = fTmp;
#ifdef CHANGESOFT				
		p->fSoft0 = fTmp;
#endif
		xdr_float(&xdrs,&fTmp);
		p->fPot = fTmp;
		}
	    else if (pkdIsGas(pkd,p)) {
		xdr_float(&xdrs,&fTmp);
		p->fMass = fTmp;
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			xdr_double(&xdrs,&dTmp);
			p->r[j] = dTmp;
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			xdr_float(&xdrs,&fTmp);
			p->r[j] = fTmp;
			}
		    }
		for (j=0;j<3;++j) {
		    xdr_float(&xdrs,&fTmp);
		    vTemp = fTmp;
		    p->v[j] = dvFac*vTemp;			
		    }

		xdr_float(&xdrs,&fTmp);
		xdr_float(&xdrs,&fTmp);
		xdr_float(&xdrs,&fTmp);
		p->fSoft = fTmp;
#ifdef CHANGESOFT
		p->fSoft0 = fTmp;
#endif
		xdr_float(&xdrs,&fTmp);
		xdr_float(&xdrs,&fTmp);
		p->fPot = fTmp;
		}
	    else if (pkdIsStar(pkd,p)) {
		xdr_float(&xdrs,&fTmp);
		p->fMass = fTmp;
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			xdr_double(&xdrs,&dTmp);
			p->r[j] = dTmp;
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			xdr_float(&xdrs,&fTmp);
			p->r[j] = fTmp;
			}
		    }
		for (j=0;j<3;++j) {
		    xdr_float(&xdrs,&fTmp);
		    vTemp = fTmp;
		    p->v[j] = dvFac*vTemp;			
		    }
		xdr_float(&xdrs,&fTmp);
		xdr_float(&xdrs,&fTmp);
		xdr_float(&xdrs,&fTmp);
		p->fSoft = fTmp;
#ifdef CHANGESOFT
		p->fSoft0 = fTmp;
#endif
		xdr_float(&xdrs,&fTmp);
		p->fPot = fTmp;
		}
	    else mdlassert(pkd->mdl,0);
	    if(p->fSoft < sqrt(2.0e-38)) { /* set minimum softening */
		p->fSoft = sqrt(2.0e-38);
		}
	    }
	xdr_destroy(&xdrs);
	}
    else {
	for (i=0;i<nLocal;++i) {
	    p = &pkd->pStore[i];
	    p->iOrder = nStart + i;
	    if (p->iOrder == iTracker) {
		TYPESet(p,TYPE_TRACKER);
		iRet = fscanf(fpTrack,"%d",&iTracker);
		iTracker = iTracker -1;
		if (!iRet || iRet == EOF) {
		    fclose(fpTrack);
		    iTracker = nStart-1;
		    }
		}
	    if (pkdIsDark(pkd,p)) {
		fread(&dp,sizeof(struct dark_particle),1,fp);
		for (j=0;j<3;++j) {
		    p->r[j] = dp.pos[j];
		    p->v[j] = dvFac*dp.vel[j];
		    }
		p->fMass = dp.mass;
		mass += dp.mass;
		p->fSoft = dp.eps;
#ifdef CHANGESOFT
		p->fSoft0 = dp.eps;
#endif
		p->fPot = dp.phi;
		}
	    else if (pkdIsGas(pkd,p)) {
		fread(&gp,sizeof(struct gas_particle),1,fp);
		for (j=0;j<3;++j) {
		    p->r[j] = gp.pos[j];
		    p->v[j] = dvFac*gp.vel[j];
		    }
		p->fMass = gp.mass;
		p->fSoft = gp.hsmooth;
#ifdef CHANGESOFT
		p->fSoft0 = gp.hsmooth;
#endif
		p->fPot = gp.phi;
		}
	    else if (pkdIsStar(pkd,p)) {
		fread(&sp,sizeof(struct star_particle),1,fp);
		for (j=0;j<3;++j) {
		    p->r[j] = sp.pos[j];
		    p->v[j] = dvFac*sp.vel[j];
		    }
		p->fMass = sp.mass;
		p->fSoft = sp.eps;
#ifdef CHANGESOFT
		p->fSoft0 = sp.eps;
#endif
		p->fPot = sp.phi;
		}
	    else mdlassert(pkd->mdl,0);
	    if(p->fSoft < sqrt(2.0e-38)) { /* set minimum softening */
		p->fSoft = sqrt(2.0e-38);
		}
	    }
	}
    fclose(fp);
    }


void pkdCalcBound(PKD pkd,BND *pbnd)
    {
    PARTICLE *p = pkd->pStore;
    FLOAT fMin[3],fMax[3];
    int i = 0;
    int j;

    mdlassert(pkd->mdl,pkd->nLocal > 0);
    for (j=0;j<3;++j) {
	fMin[j] = p[i].r[j];
	fMax[j] = p[i].r[j];
	}
    for (++i;i<pkd->nLocal;++i) {
	for (j=0;j<3;++j) {
	    if (p[i].r[j] < fMin[j]) fMin[j] = p[i].r[j];
	    else if (p[i].r[j] > fMax[j]) fMax[j] = p[i].r[j];
	    }
	}
    for (j=0;j<3;++j) {
	pbnd->fCenter[j] = 0.5*(fMax[j] + fMin[j]);
	pbnd->fMax[j] = 0.5*(fMax[j] - fMin[j]);
	}
    }


void pkdRungDDWeight(PKD pkd, int iMaxRung, double dWeight)
    {
    PARTICLE *p;
    int i;
    float fRungWeight[50],sum;

    mdlassert(pkd->mdl,iMaxRung<50);
    fRungWeight[0]=1.0;
    sum=1.0;
    for (i=1;i<=iMaxRung;i++) {
	sum*=2.0;
	fRungWeight[i] = dWeight* sum + (1-dWeight);
	}
  
    for(i=0;i<pkdLocal(pkd);++i) {
	p = &pkd->pStore[i];
	p->fWeight *= fRungWeight[p->iRung];
	}
    }

/*
** Partition particles between iFrom and iTo into those < fSplit and
** those >= to fSplit.  Find number and weight in each partition.
*/
int pkdWeight(PKD pkd,int d,FLOAT fSplit,int iSplitSide,int iFrom,int iTo,
	      int *pnLow,int *pnHigh,FLOAT *pfLow,FLOAT *pfHigh)
    {
    int i,iPart;
    FLOAT fLower,fUpper;

    /*
    ** First partition the memory about fSplit for particles iFrom to iTo.
    */
    if (iSplitSide) {
	iPart = pkdLowerPart(pkd,d,fSplit,iFrom,iTo);
	*pnLow = pkdLocal(pkd)-iPart;
	*pnHigh = iPart;
	}
    else {
	iPart = pkdUpperPart(pkd,d,fSplit,iFrom,iTo);
	*pnLow = iPart;
	*pnHigh = pkdLocal(pkd)-iPart;
	}
    /*
    ** Calculate the lower weight and upper weight BETWEEN the particles
    ** iFrom to iTo!
    */
    fLower = 0.0;
    for (i=iFrom;i<iPart;++i) {
	fLower += pkd->pStore[i].fWeight;
	}
    fUpper = 0.0;
    for (i=iPart;i<=iTo;++i) {
	fUpper += pkd->pStore[i].fWeight;
	}
    if (iSplitSide) {
	*pfLow = fUpper;
	*pfHigh = fLower;
	}
    else {
	*pfLow = fLower;
	*pfHigh = fUpper;
	}
    return(iPart);
    }


void pkdCountVA(PKD pkd,int d,FLOAT fSplit,int *pnLow,int *pnHigh) {
    int i;

    *pnLow = 0;
    *pnHigh = 0;
    for (i=0;i<pkd->nLocal;++i) {
	if (pkdIsVeryActive(pkd,pkd->pStore+i)) {
	    if (pkd->pStore[i].r[d] < fSplit) *pnLow += 1;
	    else *pnHigh += 1;
	    }
	}
    }


/*
** Partition particles between iFrom and iTo into those < fSplit and
** those >= to fSplit.  Find number and weight in each partition.
*/
int pkdWeightWrap(PKD pkd,int d,FLOAT fSplit,FLOAT fSplit2,int iSplitSide,int iVASplitSide,
		  int iFrom,int iTo,int *pnLow,int *pnHigh) {
    int iPart;

    /*
    ** First partition the memory about fSplit for particles iFrom to iTo.
    */
    if (!iSplitSide) {
	iPart = pkdLowerPartWrap(pkd,d,fSplit,fSplit2,iVASplitSide,iFrom,iTo);
	*pnLow = iPart;
	*pnHigh = pkdLocal(pkd)-iPart;
	}
    else {
	iPart = pkdUpperPartWrap(pkd,d,fSplit,fSplit2,iVASplitSide,iFrom,iTo);
	*pnHigh = iPart;
	*pnLow = pkdLocal(pkd)-iPart;
	}
    return(iPart);
    }


int pkdOrdWeight(PKD pkd,int iOrdSplit,int iSplitSide,int iFrom,int iTo,
		 int *pnLow,int *pnHigh)
    {
    int iPart;
	
    /*
    ** First partition the memory about fSplit for particles iFrom to iTo.
    */
    if (iSplitSide) {
	iPart = pkdLowerOrdPart(pkd,iOrdSplit,iFrom,iTo);
	*pnLow = pkdLocal(pkd)-iPart;
	*pnHigh = iPart;
	}
    else {
	iPart = pkdUpperOrdPart(pkd,iOrdSplit,iFrom,iTo);
	*pnLow = iPart;
	*pnHigh = pkdLocal(pkd)-iPart;
	}
    return(iPart);
    }


int pkdLowerPart(PKD pkd,int d,FLOAT fSplit,int i,int j)
    {
    PARTICLE pTemp;

    PARTITION(pkd->pStore,pTemp,i,j,
	      pkd->pStore[i].r[d] >= fSplit,
	      pkd->pStore[j].r[d] < fSplit);
    return(i);
    }


int pkdUpperPart(PKD pkd,int d,FLOAT fSplit,int i,int j)
    {
    PARTICLE pTemp;

    PARTITION(pkd->pStore,pTemp,i,j,
	      pkd->pStore[i].r[d] < fSplit,
	      pkd->pStore[j].r[d] >= fSplit);
    return(i);
    }


int pkdLowerPartWrap(PKD pkd,int d,FLOAT fSplit1,FLOAT fSplit2,int iVASplitSide,int i,int j) {
    PARTICLE pTemp;

    if (fSplit1 > fSplit2) {
	if (iVASplitSide < 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 || pkd->pStore[i].r[d] >= fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] >= fSplit2 && pkd->pStore[j].r[d] < fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else if (iVASplitSide > 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 || pkd->pStore[i].r[d] >= fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] >= fSplit2 && pkd->pStore[j].r[d] < fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 || pkd->pStore[i].r[d] >= fSplit1),
		      (pkd->pStore[j].r[d] >= fSplit2 && pkd->pStore[j].r[d] < fSplit1));
	    }
	}
    else {
	if (iVASplitSide < 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 && pkd->pStore[i].r[d] >= fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] >= fSplit2 || pkd->pStore[j].r[d] < fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else if (iVASplitSide > 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 && pkd->pStore[i].r[d] >= fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] >= fSplit2 || pkd->pStore[j].r[d] < fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] < fSplit2 && pkd->pStore[i].r[d] >= fSplit1),
		      (pkd->pStore[j].r[d] >= fSplit2 || pkd->pStore[j].r[d] < fSplit1));
	    }
	}
    return(i);
    }


int pkdUpperPartWrap(PKD pkd,int d,FLOAT fSplit1,FLOAT fSplit2,int iVASplitSide,int i,int j) {
    PARTICLE pTemp;

    if (fSplit1 > fSplit2) {
	if (iVASplitSide < 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 && pkd->pStore[i].r[d] < fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] < fSplit2 || pkd->pStore[j].r[d] >= fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else if (iVASplitSide > 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 && pkd->pStore[i].r[d] < fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] < fSplit2 || pkd->pStore[j].r[d] >= fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 && pkd->pStore[i].r[d] < fSplit1),
		      (pkd->pStore[j].r[d] < fSplit2 || pkd->pStore[j].r[d] >= fSplit1));
	    }
	}
    else {
	if (iVASplitSide < 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 || pkd->pStore[i].r[d] < fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] < fSplit2 && pkd->pStore[j].r[d] >= fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else if (iVASplitSide > 0) {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 || pkd->pStore[i].r[d] < fSplit1) &&
		      !pkdIsVeryActive(pkd,pkd->pStore+i),
		      (pkd->pStore[j].r[d] < fSplit2 && pkd->pStore[j].r[d] >= fSplit1) ||
		      pkdIsVeryActive(pkd,pkd->pStore+j));
	    }
	else {
	    PARTITION(pkd->pStore,pTemp,i,j,
		      (pkd->pStore[i].r[d] >= fSplit2 || pkd->pStore[i].r[d] < fSplit1),
		      (pkd->pStore[j].r[d] < fSplit2 && pkd->pStore[j].r[d] >= fSplit1));
	    }
	}
    return(i);
    }


int pkdLowerOrdPart(PKD pkd,int nOrdSplit,int i,int j) {
    PARTICLE pTemp;

    PARTITION(pkd->pStore,pTemp,i,j,
	      pkd->pStore[i].iOrder >= nOrdSplit,
	      pkd->pStore[j].iOrder < nOrdSplit);
    return(i);
    }


int pkdUpperOrdPart(PKD pkd,int nOrdSplit,int i,int j) {
    PARTICLE pTemp;

    PARTITION(pkd->pStore,pTemp,i,j,
	      pkd->pStore[i].iOrder < nOrdSplit,
	      pkd->pStore[j].iOrder >= nOrdSplit);
    return(i);
    }


int pkdActiveOrder(PKD pkd) {
    PARTICLE pTemp;
    int i=0;
    int j=pkdLocal(pkd)-1;

    PARTITION(pkd->pStore,pTemp,i,j,
	      pkdIsActive(pkd,&(pkd->pStore[i])),
	      !pkdIsActive(pkd,&(pkd->pStore[j])));
    return (pkd->nActive = i);
    }


int pkdColRejects_Active_Inactive(PKD pkd,int d,FLOAT fSplit,FLOAT fSplitInactive,
				  int iSplitSide)
    {
    PARTICLE pTemp;
    int nSplit,nSplitInactive,iRejects,i,j;

    mdlassert(pkd->mdl,pkd->nRejects == 0);
    if (iSplitSide) {
	nSplit = pkdLowerPart(pkd,d,fSplit,0,pkdActive(pkd)-1);
	}
    else {
	nSplit = pkdUpperPart(pkd,d,fSplit,0,pkdActive(pkd)-1);
	}
    if (iSplitSide) {
	nSplitInactive = pkdLowerPart(pkd,d,fSplitInactive,
				      pkdActive(pkd),pkdLocal(pkd)-1);
	}
    else {
	nSplitInactive = pkdUpperPart(pkd,d,fSplitInactive,
				      pkdActive(pkd),pkdLocal(pkd)-1);
	}
    /*
      for(i = 0; i < nSplit; ++i)
      mdlassert(pkd->mdl,pkdIsActive(pkd,&(pkd->pStore[i])));
      for(i = pkdActive(pkd); i < nSplitInactive; ++i)
      mdlassert(pkd->mdl,!pkdIsActive(pkd,&(pkd->pStore[i])));
    */

    nSplitInactive -= pkdActive(pkd);
    /*
    ** Now do some fancy rearrangement.
    */
    i = nSplit;
    j = nSplit+nSplitInactive;
    while (j < pkdActive(pkd) + nSplitInactive) {
	pTemp = pkd->pStore[i];
	pkd->pStore[i] = pkd->pStore[j];
	pkd->pStore[j] = pTemp;
	++i; ++j;
	}
    pkd->nRejects = pkdLocal(pkd) - nSplit - nSplitInactive;
    iRejects = pkdFreeStore(pkd) - pkd->nRejects;
    pkd->nActive = nSplit;
    pkd->nLocal = nSplit + nSplitInactive;
    /*
    ** Move rejects to High memory.
    */
    for (i=pkd->nRejects-1;i>=0;--i)
	pkd->pStore[iRejects+i] = pkd->pStore[pkd->nLocal+i];
    return(pkd->nRejects);
    }


int pkdColRejects(PKD pkd,int nSplit)
    {
    int iRejects,i;

    mdlassert(pkd->mdl,pkd->nRejects == 0);

    pkd->nRejects = pkdLocal(pkd) - nSplit;
    iRejects = pkdFreeStore(pkd) - pkd->nRejects;
    pkd->nLocal = nSplit;
    /*
    ** Move rejects to High memory.
    */
    for (i=pkd->nRejects-1;i>=0;--i)
	pkd->pStore[iRejects+i] = pkd->pStore[pkd->nLocal+i];
    return(pkd->nRejects);
    }


int pkdSwapRejects(PKD pkd,int idSwap)
    {
    size_t nBuf;
    size_t nOutBytes,nSndBytes,nRcvBytes;

    if (idSwap != -1) {
	nBuf = (pkdSwapSpace(pkd))*sizeof(PARTICLE);
	nOutBytes = pkd->nRejects*sizeof(PARTICLE);
	mdlassert(pkd->mdl,pkdLocal(pkd) + pkd->nRejects <= pkdFreeStore(pkd));
	mdlSwap(pkd->mdl,idSwap,nBuf,&pkd->pStore[pkdLocal(pkd)],
		nOutBytes,&nSndBytes,&nRcvBytes);
	pkd->nLocal += nRcvBytes/sizeof(PARTICLE);
	pkd->nRejects -= nSndBytes/sizeof(PARTICLE);
	}
    return(pkd->nRejects);
    }

void pkdSwapAll(PKD pkd, int idSwap)
    {
    size_t nBuf;
    size_t nOutBytes,nSndBytes,nRcvBytes;
    int i;
    int iBuf;
    
    /*
    ** Move particles to High memory.
    */
    iBuf = pkdSwapSpace(pkd);
    for (i=pkdLocal(pkd)-1;i>=0;--i)
	pkd->pStore[iBuf+i] = pkd->pStore[i];

    nBuf = pkdFreeStore(pkd)*sizeof(PARTICLE);
    nOutBytes = pkdLocal(pkd)*sizeof(PARTICLE);
    mdlSwap(pkd->mdl,idSwap,nBuf,&pkd->pStore[0], nOutBytes,
	    &nSndBytes, &nRcvBytes);
    mdlassert(pkd->mdl,nSndBytes/sizeof(PARTICLE) == pkdLocal(pkd));
    pkd->nLocal = nRcvBytes/sizeof(PARTICLE);
    }

int pkdSwapSpace(PKD pkd)
    {
    return(pkdFreeStore(pkd) - pkdLocal(pkd));
    }


int pkdFreeStore(PKD pkd)
    {
    return(pkd->nStore);
    }

int pkdActive(PKD pkd)
    {
    return(pkd->nActive);
    }

int pkdInactive(PKD pkd)
    {
    return(pkd->nLocal - pkd->nActive);
    }

int pkdLocal(PKD pkd)
    {
    return(pkd->nLocal);
    }

int pkdNodes(PKD pkd)
    {
    return(pkd->nNodes);
    }


int pkdColOrdRejects(PKD pkd,int nOrdSplit,int iSplitSide)
    {
    int nSplit,iRejects,i;

    if (iSplitSide) nSplit = pkdLowerOrdPart(pkd,nOrdSplit,0,pkdLocal(pkd)-1);
    else nSplit = pkdUpperOrdPart(pkd,nOrdSplit,0,pkdLocal(pkd)-1);
    pkd->nRejects = pkdLocal(pkd) - nSplit;
    iRejects = pkdFreeStore(pkd) - pkd->nRejects;
    pkd->nLocal = nSplit;
    /*
    ** Move rejects to High memory.
    */
    for (i=pkd->nRejects-1;i>=0;--i)
	pkd->pStore[iRejects+i] = pkd->pStore[pkd->nLocal+i];
    return(pkd->nRejects);
    }


int cmpParticles(const void *pva,const void *pvb)
    {
    PARTICLE *pa = (PARTICLE *)pva;
    PARTICLE *pb = (PARTICLE *)pvb;

    return(pa->iOrder - pb->iOrder);
    }


void pkdLocalOrder(PKD pkd)
    {
    qsort(pkd->pStore,pkdLocal(pkd),sizeof(PARTICLE),cmpParticles);
    }


/*
** This routine will pack at most nMax particles into an array of packed
** particles (io).  It scans the particle list from *iIndex to the end
** packing only particles with iOrder in the range [iMinOrder,iMaxOrder).
** When this routine is done, it will return 0 for the number of particles
** packed (and continues to return 0 if called again).
*/
int pkdPackIO(PKD pkd,
	      PIO *io, int nMax,
	      int *iIndex,
	      int iMinOrder, int iMaxOrder )
{
    int nCopied, d, i;

    mdlassert(pkd->mdl,*iIndex<=pkd->nLocal);

    for( i=*iIndex,nCopied=0; nCopied < nMax && i < pkd->nLocal; i++ ) {
	/* Not a particle of interest? */
	if ( pkd->pStore[i].iOrder<iMinOrder || pkd->pStore[i].iOrder>=iMaxOrder)
	    continue;

	/* We should have certain special cases here */
	mdlassert( pkd->mdl, pkdIsDark(pkd,pkd->pStore+i) );

	for( d=0; d<3; d++ ) {
	    io[nCopied].r[d] = pkd->pStore[i].r[d];
	    io[nCopied].v[d] = pkd->pStore[i].v[d];
	}
	io[nCopied].iOrder= pkd->pStore[i].iOrder;
	io[nCopied].fMass = pkd->pStore[i].fMass;
	io[nCopied].fSoft = pkd->pStore[i].fSoft;
	nCopied++;
    }
    *iIndex = i;
    return nCopied;
}

#ifdef USE_HDF5
void pkdWriteHDF5(PKD pkd, IOHDF5 io, double dvFac)
{
    PARTICLE *p;
    FLOAT v[3], fSoft;
    int i;

    for (i=0;i<pkdLocal(pkd);++i) {
	p = &pkd->pStore[i];

	v[0] = p->v[0] * dvFac;
	v[1] = p->v[1] * dvFac;
	v[2] = p->v[2] * dvFac;
#ifdef CHANGESOFT
	fSoft = p->fSoft0;
#else
	fSoft = p->fSoft;
#endif


	if (pkdIsDark(pkd,p)) {
	    ioHDF5AddDark(io,p->iOrder,p->r,v,
			  p->fMass,fSoft,p->fPot );
	}
	else if (pkdIsGas(pkd,p)) {
	    assert(0);
	    /* Why are temp and metals always set to zero? */
	    ioHDF5AddGas( io,p->iOrder,p->r,v,
			  p->fMass,fSoft,p->fPot,0.0,0.0);
	}
	else if (pkdIsStar(pkd,p)) {
	    assert(0);
	    /* Why are metals and tform always set to zero? */
	    ioHDF5AddStar(io, p->iOrder, p->r, v,
			  p->fMass,fSoft,p->fPot,0.0,0.0);
	}
	else mdlassert(pkd->mdl,0);
    }
}


#endif

void pkdWriteTipsy(PKD pkd,char *pszFileName,int nStart,
		   int bStandard,double dvFac,int bDoublePos) {
    PARTICLE *p;
    FILE *fp;
    int i,j;
    struct dark_particle dp;
    struct gas_particle gp;
    struct star_particle sp;
    int nout;
    float fTmp;
    double dTmp;
	
    /*
    ** Seek past the header and up to nStart.
    */
    fp = fopen(pszFileName,"r+");
    mdlassert(pkd->mdl,fp != NULL);
    pkdSeek(pkd,fp,nStart,bStandard,bDoublePos);

    if (bStandard) {
	FLOAT vTemp;
	XDR xdrs;
	/* 
	** Write Stuff!
	*/
	xdrstdio_create(&xdrs,fp,XDR_ENCODE);
	for (i=0;i<pkdLocal(pkd);++i) {
	    p = &pkd->pStore[i];
	    if (pkdIsDark(pkd,p)) {
		fTmp = p->fMass;
		assert(fTmp > 0.0);
		IOCheck(xdr_float(&xdrs,&fTmp));
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			dTmp = p->r[j];
			IOCheck(xdr_double(&xdrs,&dTmp));
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			fTmp = p->r[j];
			IOCheck(xdr_float(&xdrs,&fTmp));
			}
		    }
		for (j=0;j<3;++j) {
		    vTemp = dvFac*p->v[j];			
		    fTmp = vTemp;
		    IOCheck(xdr_float(&xdrs,&fTmp));
		    }
#ifdef CHANGESOFT
		fTmp = p->fSoft0;
#else
		fTmp = p->fSoft;
#endif
		assert(fTmp > 0.0);
		IOCheck(xdr_float(&xdrs,&fTmp));
		fTmp = p->fPot;
		IOCheck(xdr_float(&xdrs,&fTmp));
		}
	    else if (pkdIsGas(pkd,p)) {
		fTmp = p->fMass;
		IOCheck(xdr_float(&xdrs,&fTmp));
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			dTmp = p->r[j];
			IOCheck(xdr_double(&xdrs,&dTmp));
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			fTmp = p->r[j];
			IOCheck(xdr_float(&xdrs,&fTmp));
			}
		    }
		for (j=0;j<3;++j) {
		    vTemp = dvFac*p->v[j];			
		    fTmp = vTemp;
		    IOCheck(xdr_float(&xdrs,&fTmp));
		    }
		fTmp = p->fDensity;
		IOCheck(xdr_float(&xdrs,&fTmp));
		fTmp = 0.0;
		IOCheck(xdr_float(&xdrs,&fTmp));
#ifdef CHANGESOFT
		fTmp = p->fSoft0;
#else
		fTmp = p->fSoft;
#endif
		IOCheck(xdr_float(&xdrs,&fTmp));
		fTmp = 0.0;
		IOCheck(xdr_float(&xdrs,&fTmp));
		fTmp = p->fPot;
		IOCheck(xdr_float(&xdrs,&fTmp));
		}
	    else if (pkdIsStar(pkd,p)) {
		fTmp = p->fMass;
		IOCheck(xdr_float(&xdrs,&fTmp));
		if (bDoublePos) {
		    for (j=0;j<3;++j) {
			dTmp = p->r[j];
			IOCheck(xdr_double(&xdrs,&dTmp));
			}
		    }
		else {
		    for (j=0;j<3;++j) {
			fTmp = p->r[j];
			IOCheck(xdr_float(&xdrs,&fTmp));
			}
		    }
		for (j=0;j<3;++j) {
		    vTemp = dvFac*p->v[j];			
		    fTmp = vTemp;
		    IOCheck(xdr_float(&xdrs,&fTmp));
		    }
		fTmp = 0.0;
		IOCheck(xdr_float(&xdrs,&fTmp));
		IOCheck(xdr_float(&xdrs,&fTmp));
#ifdef CHANGESOFT
		fTmp = p->fSoft0;
#else
		fTmp = p->fSoft;
#endif
		IOCheck(xdr_float(&xdrs,&fTmp));
		fTmp = p->fPot;
		IOCheck(xdr_float(&xdrs,&fTmp));
		}
	    else mdlassert(pkd->mdl,0);
	    }
	xdr_destroy(&xdrs);
	}
    else {
	/* 
	** Write Stuff!
	*/
	for (i=0;i<pkdLocal(pkd);++i) {
	    p = &pkd->pStore[i];
	    if (pkdIsDark(pkd,p)) {
		for (j=0;j<3;++j) {
		    dp.pos[j] = p->r[j];
		    dp.vel[j] = dvFac*p->v[j];
		    }
		dp.mass = p->fMass;
#ifdef CHANGESOFT
		dp.eps = p->fSoft0;
#else
		dp.eps = p->fSoft;
#endif
		dp.phi = p->fPot;
		IOCheck(fwrite(&dp,sizeof(struct dark_particle),1,fp));
		}
	    else if (pkdIsGas(pkd,p)) {
		for (j=0;j<3;++j) {
		    gp.pos[j] = p->r[j];
		    gp.vel[j] = dvFac*p->v[j];
		    }
		gp.mass = p->fMass;
#ifdef CHANGESOFT
		gp.hsmooth = p->fSoft0;
#else
		gp.hsmooth = p->fSoft;
#endif
		gp.phi = p->fPot;
		gp.rho = p->fDensity;
		gp.temp = 0.0;
		gp.metals = 0.0;
		IOCheck(fwrite(&gp,sizeof(struct gas_particle),1,fp));
		}
	    else if (pkdIsStar(pkd,p)) {
		for (j=0;j<3;++j) {
		    sp.pos[j] = p->r[j];
		    sp.vel[j] = dvFac*p->v[j];
		    }
		sp.mass = p->fMass;
#ifdef CHANGESOFT
		sp.eps = p->fSoft0;
#else
		sp.eps = p->fSoft;
#endif
		sp.phi = p->fPot;
		sp.metals = 0.0;
		sp.tform = 0.0;
		IOCheck(fwrite(&sp,sizeof(struct star_particle),1,fp));
		}
	    else mdlassert(pkd->mdl,0);
	    }
	}
    nout = fclose(fp);
    mdlassert(pkd->mdl,nout == 0);
    }


void pkdSetSoft(PKD pkd,double dSoft)
    {
    PARTICLE *p;
    int i,n;

    p = pkd->pStore;
    n = pkdLocal(pkd);
    if(dSoft < sqrt(2.0e-38)) { /* set minimum softening */
	dSoft = sqrt(2.0e-38);
	}
    for (i=0;i<n;++i) {
#ifdef CHANGESOFT
	p[i].fSoft0 = dSoft;
#else
	p[i].fSoft = dSoft;
#endif
	}
    }

#ifdef CHANGESOFT
void pkdPhysicalSoft(PKD pkd,double dSoftMax,double dFac,int bSoftMaxMul)
    {
    PARTICLE *p;
    int i,n;

    p = pkd->pStore;
    n = pkdLocal(pkd);
	
    mdlassert(pkd->mdl,dFac > 0);
    if (bSoftMaxMul) {
	for (i=0;i<n;++i) {
	    mdlassert(pkd->mdl,p[i].fSoft0 > 0);
	    p[i].fSoft = p[i].fSoft0*dFac;
	    mdlassert(pkd->mdl,p[i].fSoft > 0);
	    }
	}
    else {
	mdlassert(pkd->mdl,dSoftMax > 0);
	for (i=0;i<n;++i) {
	    mdlassert(pkd->mdl,p[i].fSoft0 > 0);
	    p[i].fSoft = p[i].fSoft0*dFac;
	    if (p[i].fSoft > dSoftMax) p[i].fSoft = dSoftMax;
	    mdlassert(pkd->mdl,p[i].fSoft > 0);
	    }
	}
    }

void pkdPreVariableSoft(PKD pkd)
    {
    PARTICLE *p;
    int i,n;

    p = pkd->pStore;
    n = pkdLocal(pkd);
	
    for (i=0;i<n;++i) {
	if (pkdIsActive(pkd,&(p[i]))) p[i].fSoft = 0.5*p[i].fBall;
	}
    }

void pkdPostVariableSoft(PKD pkd,double dSoftMax,int bSoftMaxMul)
    {
    PARTICLE *p;
    int i,n;
    double dTmp;

    p = pkd->pStore;
    n = pkdLocal(pkd);
	
    if (bSoftMaxMul) {
	for (i=0;i<n;++i) {
	    if (pkdIsActive(pkd,&(p[i]))) {
		dTmp = 0.5*p[i].fBall;
		p[i].fBall = 2.0*p[i].fSoft;
		p[i].fSoft = (dTmp <= p[i].fSoft0*dSoftMax ? dTmp : p[i].fSoft0*dSoftMax);
		}
	    }
	}
    else {
	for (i=0;i<n;++i) {
	    if (pkdIsActive(pkd,&(p[i]))) {
		dTmp = 0.5*p[i].fBall;
		p[i].fBall = 2.0*p[i].fSoft;
		p[i].fSoft = (dTmp <= dSoftMax ? dTmp : dSoftMax);
		}
	    }
	}	
    }
#endif


void pkdBucketWeight(PKD pkd,int iBucket,FLOAT fWeight)
    {
    KDN *pbuc;
    int pj;
	
    pbuc = &pkd->kdNodes[iBucket];
    for (pj=pbuc->pLower;pj<=pbuc->pUpper;++pj) {
	if (pkdIsActive(pkd,&(pkd->pStore[pj])))
	    pkd->pStore[pj].fWeight = fWeight;
	}
    }


void
pkdGravAll(PKD pkd,double dTime,int nReps,int bPeriodic,int iOrder,int bEwald,
	   int bEwaldKick, double fEwCut,double fEwhCut,int *nActive, 
	   double *pdPartSum, double *pdCellSum,CASTAT *pcs, double *pdFlop)
    {
    int bVeryActive = 0;

    pkdClearTimer(pkd,1);

#ifdef BSC
    MPItrace_event(10000,0);
#endif

    /*
    ** Set up Ewald tables and stuff.
    */
    if (bPeriodic && bEwald) {
	pkdEwaldInit(pkd,fEwhCut,4);	/* ignored in Flop count! */
	}
    /*
    ** Start particle caching space (cell cache already active).
    */
    mdlROcache(pkd->mdl,CID_PARTICLE,pkd->pStore,sizeof(PARTICLE),
	       pkdLocal(pkd));
    /*
    ** Calculate newtonian gravity, including replicas if any.
    */
    *pdFlop = 0.0;
    *pdPartSum = 0.0;
    *pdCellSum = 0.0;
    pkdStartTimer(pkd,1);
    *nActive = pkdGravWalk(pkd,dTime,nReps,bPeriodic && bEwald,bEwaldKick,bVeryActive,fEwCut,pdFlop,pdPartSum,pdCellSum);
    pkdStopTimer(pkd,1);

#ifdef BSC
    /*MPItrace_event(10001, (int)(pkdGetWallClockTimer(pkd,1)*1000000) );*/
    /*MPItrace_event(10001, (int)(pkd->nActive/(pkd->nLocal/100)) );*/
    MPItrace_event(10001, 3 );
#endif

    /*
    ** Get caching statistics.
    */
    pcs->dcNumAccess = mdlNumAccess(pkd->mdl,CID_CELL);
    pcs->dcMissRatio = mdlMissRatio(pkd->mdl,CID_CELL);
    pcs->dcCollRatio = mdlCollRatio(pkd->mdl,CID_CELL);
    pcs->dcMinRatio = mdlMinRatio(pkd->mdl,CID_CELL);
    pcs->dpNumAccess = mdlNumAccess(pkd->mdl,CID_PARTICLE);
    pcs->dpMissRatio = mdlMissRatio(pkd->mdl,CID_PARTICLE);
    pcs->dpCollRatio = mdlCollRatio(pkd->mdl,CID_PARTICLE);
    pcs->dpMinRatio = mdlMinRatio(pkd->mdl,CID_PARTICLE);
    /*
    ** Stop particle caching space.
    */
    mdlFinishCache(pkd->mdl,CID_PARTICLE);
    }


void pkdCalcEandL(PKD pkd,double *T,double *U,double *Eth,double L[])
    {
    /* L is calculated with respect to the origin (0,0,0) */

    PARTICLE *p;
    FLOAT rx,ry,rz,vx,vy,vz;
    int i,n;

    p = pkd->pStore;
    n = pkdLocal(pkd);
    *T = 0.0;
    *U = 0.0;
    *Eth = 0.0;
    L[0] = L[1] = L[2] = 0;
    for (i=0;i<n;++i) {
	rx = p[i].r[0]; ry = p[i].r[1]; rz = p[i].r[2];
	vx = p[i].v[0]; vy = p[i].v[1]; vz = p[i].v[2];
	*T += 0.5*p[i].fMass*(vx*vx + vy*vy + vz*vz);
	*U += 0.5*p[i].fMass*p[i].fPot;
	L[0] += p[i].fMass*(ry*vz - rz*vy);
	L[1] += p[i].fMass*(rz*vx - rx*vz);
	L[2] += p[i].fMass*(rx*vy - ry*vx);
	}
    }


void
pkdDrift(PKD pkd,double dTime,double dDelta,FLOAT fCenter[3],int bPeriodic,int bFandG,
	 FLOAT fCentMass) {

    PARTICLE *p;
    int i,j,n;
    int ipt;
    double px,py,pz,pm;
    double dDeltaM;
    
    mdlDiag(pkd->mdl, "Into pkdDrift\n");
    
    if (dTime >= pkd->param.dGrowStartT && dTime < pkd->param.dGrowEndT) {
	dDeltaM = pkd->param.dGrowDeltaM*dDelta/
	    (pkd->param.dGrowEndT - pkd->param.dGrowStartT);
	}
    else {
	dDeltaM = 0;
	}

#ifdef BSC
    MPItrace_event(10000,0);
#endif
    
    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {
	/*
	** Do the Growmass stuff if needed...
	*/
	if (p[i].iOrder < pkd->param.nGrowMass) {
	    p[i].fMass += dDeltaM;
	    }
	/*
	** Update particle positions
	*/
	for (j=0;j<3;++j) {
	    p[i].r[j] += dDelta*p[i].v[j];
	    if (bPeriodic) {
		if (p[i].r[j] >= fCenter[j] + 0.5*pkd->fPeriod[j]) {
		    p[i].r[j] -= pkd->fPeriod[j];
		    }
		if (p[i].r[j] < fCenter[j] - 0.5*pkd->fPeriod[j]) {
		    p[i].r[j] += pkd->fPeriod[j];
		    }
		}
	    }


	/*
	** Detailed output for particles that are tracked at dTime + dDelta/2
	** Correct positons & mass for dDelta/2 step which is done before the actual update
	*/
	if (TYPETest(&p[i],TYPE_TRACKER) && dDelta != 0) {
      	    px = p[i].r[0] - dDelta/2*p[i].v[0];
	    py = p[i].r[1] - dDelta/2*p[i].v[1];
	    pz = p[i].r[2] - dDelta/2*p[i].v[2];
	    pm = p[i].fMass - dDeltaM/2;
	    ipt = p[i].iOrder + 1; /* to be consistent with Tipsy numbering */
	    printf("PDID %d %g %g %d %g %g %g %g %g %g %g %g %g %g %g %g %g\n",ipt,dTime+dDelta/2,dDelta,
		   p[i].iRung,p[i].dt,px,py,pz,p[i].v[0],p[i].v[1],p[i].v[2],p[i].a[0],p[i].a[1],p[i].a[2],p[i].fPot,pm,p[i].fSoft);
	    }
	}

#ifdef BSC
    MPItrace_event(10001,4);
#endif
    mdlDiag(pkd->mdl, "Out of pkdDrift\n");
    }

void
pkdDriftInactive(PKD pkd,double dTime, double dDelta,FLOAT fCenter[3],int bPeriodic,
		 int bFandG, FLOAT fCentMass) {

    PARTICLE *p;
    int i,j,n;
    int ipt;
    double dDeltaM;
    
    mdlDiag(pkd->mdl, "Into pkdDriftInactive\n");
    
    if (dTime >= pkd->param.dGrowStartT && dTime < pkd->param.dGrowEndT) {
	dDeltaM = pkd->param.dGrowDeltaM*dDelta/
	    (pkd->param.dGrowEndT - pkd->param.dGrowStartT);
	}
    else {
	dDeltaM = 0;
	}
    
    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {
	if (pkdIsActive(pkd,&p[i])) continue;
	/*
	** Do the Growmass stuff if needed...
	*/
	if (p[i].iOrder < pkd->param.nGrowMass) {
	    p[i].fMass += dDeltaM;
	    }
	/*
	** Update particle positions
	*/
	for (j=0;j<3;++j) {
	    p[i].r[j] += dDelta*p[i].v[j];
	    if (bPeriodic) {
		if (p[i].r[j] >= fCenter[j] + 0.5*pkd->fPeriod[j]) {
		    p[i].r[j] -= pkd->fPeriod[j];
		    }
		if (p[i].r[j] < fCenter[j] - 0.5*pkd->fPeriod[j]) {
		    p[i].r[j] += pkd->fPeriod[j];
		    }
		}
	    }
	/*
	** Detailed output for particles that are tracked at dTime + dDelta
	** Inactive Drift => dDelta is already a half step! No correction needed!
	*/
	if (TYPETest(&p[i],TYPE_TRACKER) && dDelta != 0) {
	    ipt = p[i].iOrder + 1; /* to be consistent with Tipsy numbering */
	    printf("PDID %d %g %g %d %g %g %g %g %g %g %g %g %g %g %g %g %g\n",ipt,dTime+dDelta/2,dDelta,
		   p[i].iRung,p[i].dt,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],p[i].a[0],p[i].a[1],p[i].a[2],p[i].fPot,p[i].fMass,p[i].fSoft);
	    }
	}
    mdlDiag(pkd->mdl, "Out of pkdDriftInactive\n");
    }

void
pkdDriftActive(PKD pkd,double dTime,double dDelta) {

    PARTICLE *p;
    int i,j,n;
    int ipt;
    double px,py,pz,pm;
    double dDeltaM;
    
    mdlDiag(pkd->mdl, "Into pkdDriftActive\n");

    if (dTime >= pkd->param.dGrowStartT && dTime < pkd->param.dGrowEndT) {
	dDeltaM = pkd->param.dGrowDeltaM*dDelta/
	    (pkd->param.dGrowEndT - pkd->param.dGrowStartT);
	}
    else {
	dDeltaM = 0;
	}

    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {
	if (!pkdIsActive(pkd,&p[i])) continue;
	/*
	** Do the Growmass stuff if needed...
	*/
	if (p[i].iOrder < pkd->param.nGrowMass) {
	    p[i].fMass += dDeltaM;
	    }
	/*
	** Update particle positions
	*/
	for (j=0;j<3;++j) {
	    p[i].r[j] += dDelta*p[i].v[j];
	    }
	/*
	** Detailed output for particles that are tracked at dTime + dDelta/2
	** Correct positons & mass for dDelta/2 step
	*/
	if (TYPETest(&p[i],TYPE_TRACKER) && dDelta != 0) {
	    px = p[i].r[0] - dDelta/2*p[i].v[0];
	    py = p[i].r[1] - dDelta/2*p[i].v[1];
	    pz = p[i].r[2] - dDelta/2*p[i].v[2];
	    pm = p[i].fMass - dDeltaM/2;
	    ipt = p[i].iOrder + 1; /* to be consistent with Tipsy numbering */
	    printf("PDID %d %g %g %d %g %g %g %g %g %g %g %g %g %g %g %g %g\n",ipt,dTime+dDelta/2,dDelta,
		   p[i].iRung,p[i].dt,px,py,pz,p[i].v[0],p[i].v[1],p[i].v[2],p[i].a[0],p[i].a[1],p[i].a[2],p[i].fPot,pm,p[i].fSoft);
	    }
	}
    mdlDiag(pkd->mdl, "Out of pkdDriftActive\n");
    }

void pkdGravityVeryActive(PKD pkd,double dTime,int bEwald,int nReps,double fEwCut,double dStep) {
    int nActive;
    int bVeryActive = 1;
    double dFlop,dPartSum,dCellSum;

    /*
    ** Calculate newtonian gravity for the very active particles ONLY, including replicas if any.
    */
    dFlop = 0.0;
    dPartSum = 0.0;
    dCellSum = 0.0;
    if (pkd->param.bEwaldKicking) {
	bEwald = 0;
    }
    nActive = pkdGravWalk(pkd,dTime,nReps,bEwald,0,bVeryActive,fEwCut,&dFlop,&dPartSum,&dCellSum);
    }


void
pkdStepVeryActiveKDK(PKD pkd, double dStep, double dTime, double dDelta,
		     int iRung, int iKickRung, int iRungVeryActive,int iAdjust, double diCrit2,
		     int *pnMaxRung, double aSunInact[], double adSunInact[], double dSunMass)
    {
    int nRungCount[256];
    double dDriftFac;
#ifdef PLANETS
    double aSun[3], adSun[3];
    int j;
#endif

    double time1,time2; /* added MZ 1.6.2006 */
    
    if(iAdjust && (iRung < pkd->param.iMaxRung-1)) {
	pkdActiveRung(pkd, iRung, 1);
	pkdInitDt(pkd, pkd->param.dDelta);
	if (pkd->param.bGravStep) {
	    double a = csmTime2Exp(pkd->param.csm,dTime);
	    double dRhoFac = 1.0/(a*a*a);
	    pkdGravStep(pkd,pkd->param.dEta,dRhoFac);
	    }
	if (pkd->param.bAccelStep) {
	    double a = csmTime2Exp(pkd->param.csm,dTime);
	    double dVelFac = 1.0/(a*a);
	    double dAccFac = 1.0/(a*a*a);
	    double dhMinOverSoft = 0;
	    pkdAccelStep(pkd,pkd->param.dEta, dVelFac,dAccFac,pkd->param.bDoGravity,
			 pkd->param.bEpsAccStep,pkd->param.bSqrtPhiStep,dhMinOverSoft);
	    }
	*pnMaxRung = pkdDtToRung(pkd,iRung,dDelta,pkd->param.iMaxRung-1, 1, nRungCount);
    
	if (pkd->param.bVDetails) {
	    printf("%*cAdjust at iRung: %d, nMaxRung:%d nRungCount[%d]=%d\n",
		   2*iRung+2,' ',iRung,*pnMaxRung,*pnMaxRung,nRungCount[*pnMaxRung]);
	}
	
	}
    if(iRung > iRungVeryActive) {	/* skip this if we are
					   entering for the first
					   time: Kick is taken care of
					   in master(). 
					*/
	pkdActiveRung(pkd,iRung,0);
	if (pkd->param.bVDetails) {
	    printf("%*cVeryActive pkdKickOpen  at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	pkdKickKDKOpen(pkd, dTime, 0.5*dDelta);
	}
    if (*pnMaxRung > iRung) {
	/*
	** Recurse.
	*/
	pkdStepVeryActiveKDK(pkd,dStep,dTime,0.5*dDelta,iRung+1,iRung+1,iRungVeryActive,0,
			     diCrit2,pnMaxRung,aSunInact,adSunInact,dSunMass);
	dStep += 1.0/(2 << iRung);
	dTime += 0.5*dDelta;
	pkdActiveRung(pkd,iRung,0);
	pkdStepVeryActiveKDK(pkd,dStep,dTime,0.5*dDelta,iRung+1,iKickRung,iRungVeryActive,1,
			     diCrit2,pnMaxRung,aSunInact,adSunInact,dSunMass);
	}
    else {
	if (pkd->param.bVDetails) {
	    printf("%*cVeryActive Drift at iRung: %d, drifting %d and higher with dDelta: %g\n",
		   2*iRung+2,' ',iRung,iRungVeryActive+1,dDelta);
	    }
	/*
	** This should drift *all* very actives!
	*/
	pkdActiveRung(pkd,iRungVeryActive+1,1);
	/*
	** We need to account for cosmological drift factor here!
	** Normally this is done at the MASTER level in msrDrift.
	** Note that for kicks we have written new "master-like" functions
	** KickOpen and KickClose which do this same job at PKD level.
	*/
	if (pkd->param.bCannonical) {
	    dDriftFac = csmComoveDriftFac(pkd->param.csm,dTime,dDelta);
	    }
	else {
	    dDriftFac = dDelta;
	    }

	pkdDriftActive(pkd,dTime,dDriftFac);
	dTime += dDelta;
	dStep += 1.0/(1 << iRung);

	if(iKickRung > iRungVeryActive) {	/* skip this if we are
						   entering for the first
						   time: Kick is taken care of
						   in master(). 
						*/

	    if(pkd->param.bVDetails) {
		printf("%*cGravityVA: iRung %d Gravity for rungs %d to %d ... ",
		       2*iRung+2,' ',iRung,iKickRung,*pnMaxRung);
		}

	    time1 = Zeit(); /* added MZ 1.6.2006 */

	    pkdActiveRung(pkd,iKickRung,1);
	    pkdVATreeBuild(pkd,pkd->param.nBucket,diCrit2,0,dTime);
	    pkdGravityVeryActive(pkd,dTime,pkd->param.bEwald && pkd->param.bPeriodic,pkd->param.nReplicas,pkd->param.dEwCut,dStep);

#ifdef PLANETS
	    /* Sun's gravity */
	    if(pkd->param.bHeliocentric){
	      /* Sun's indirect gravity due to very active particles*/
	      pkdActiveRung(pkd,iRungVeryActive+1,1);
	      pkdSunIndirect(pkd,aSun,adSun,1); 
	      for (j=0;j<3;++j)
	       	{                 
                 aSun[j] += aSunInact[j];
		 adSun[j] += adSunInact[j];
	       	}
	      pkdActiveRung(pkd,iKickRung,1);
	      pkdGravSun(pkd,aSun,adSun,dSunMass); 
	    }
#endif

	    time2 = Zeit();
	    if(pkd->param.bVDetails)
		printf("Time: %g\n",time2-time1);
	    }
	/*
	 * move time back to 1/2 step so that KickClose can integrate
	 * from 1/2 through the timestep to the end.
	 */
	dTime -= 0.5*dDelta;
	}
    if(iKickRung > iRungVeryActive) {	/* skip this if we are
						   entering for the first
						   time: Kick is taken care of
						   in master(). 
						*/
	pkdActiveRung(pkd,iRung,0);
	if (pkd->param.bVDetails) {
	    printf("%*cVeryActive pkdKickClose at iRung: %d, 0.5*dDelta: %g\n",
		   2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	pkdKickKDKClose(pkd,dTime,0.5*dDelta);
	}
    }

#ifdef HERMITE
void
pkdStepVeryActiveHermite(PKD pkd, double dStep, double dTime, double dDelta,
		     int iRung, int iKickRung, int iRungVeryActive,int iAdjust, double diCrit2,
		     int *pnMaxRung, double aSunInact[], double adSunInact[], double dSunMass)
    {
    int nRungCount[256];
    double dDriftFac;
    int i;

    double aSun[3], adSun[3];
    int j;

    double time1,time2; /* added MZ 1.6.2006 */
    
    if(iAdjust && (iRung < pkd->param.iMaxRung-1)) {
	pkdActiveRung(pkd, iRung, 1);
	pkdInitDt(pkd, pkd->param.dDelta);
	if (pkd->param.bAarsethStep) {
	  pkdAarsethStep(pkd,pkd->param.dEta);
	}
	if (pkd->param.bGravStep) {
	    double a = csmTime2Exp(pkd->param.csm,dTime);
	    double dRhoFac = 1.0/(a*a*a);
	    pkdGravStep(pkd,pkd->param.dEta,dRhoFac);
	    }
	if (pkd->param.bAccelStep) {
	    double a = csmTime2Exp(pkd->param.csm,dTime);
	    double dVelFac = 1.0/(a*a);
	    double dAccFac = 1.0/(a*a*a);
	    double dhMinOverSoft = 0;
	    pkdAccelStep(pkd,pkd->param.dEta, dVelFac,dAccFac,pkd->param.bDoGravity,
			 pkd->param.bEpsAccStep,pkd->param.bSqrtPhiStep,dhMinOverSoft);
	    }
	*pnMaxRung = pkdDtToRung(pkd,iRung,dDelta,pkd->param.iMaxRung-1, 1, nRungCount);
    
	if (pkd->param.bVDetails) {
	    printf("%*cAdjust at iRung: %d, nMaxRung:%d nRungCount[%d]=%d\n",
		   2*iRung+2,' ',iRung,*pnMaxRung,*pnMaxRung,nRungCount[*pnMaxRung]);
	}
	
	}
   
    if (*pnMaxRung > iRung) {
	/*
	** Recurse.
	*/
	pkdStepVeryActiveHermite(pkd,dStep,dTime,0.5*dDelta,iRung+1,iRung+1,iRungVeryActive,0,
			     diCrit2,pnMaxRung,aSunInact,adSunInact,dSunMass);
	dStep += 1.0/(2 << iRung);
	dTime += 0.5*dDelta;
	pkdActiveRung(pkd,iRung,0);
	pkdStepVeryActiveHermite(pkd,dStep,dTime,0.5*dDelta,iRung+1,iKickRung,iRungVeryActive,1,
			     diCrit2,pnMaxRung,aSunInact,adSunInact,dSunMass);
	}
    else {
	if (pkd->param.bVDetails) {
	    printf("%*cVeryActive Predictor at iRung: %d, drifting %d and higher with dDelta: %g\n",
		   2*iRung+2,' ',iRung,iRungVeryActive+1,dDelta);
	    }
	/*
	** This should predict *all* very actives!
	*/
	pkdActiveRung(pkd,iRungVeryActive+1,1);
	/*
	** We need to account for cosmological drift factor here!
	** Normally this is done at the MASTER level in msrDrift.
	** Note that for kicks we have written new "master-like" functions
	** KickOpen and KickClose which do this same job at PKD level.
	*/
	/*if (pkd->param.bCannonical) {
	    dDriftFac = csmComoveDriftFac(pkd->param.csm,dTime,dDelta);
	    }
	else {
	    dDriftFac = dDelta;
	    }*/

	dTime += dDelta;
	dStep += 1.0/(1 << iRung);

	pkdPredictor(pkd,dTime);

	if(iKickRung > iRungVeryActive) {	/* skip this if we are
						   entering for the first
						   time: Kick is taken care of
						   in master(). 
						*/

	    if(pkd->param.bVDetails) {
		printf("%*cGravityVA: iRung %d Gravity for rungs %d to %d ...\n ",
		       2*iRung+2,' ',iRung,iKickRung,*pnMaxRung);
		}

	    time1 = Zeit(); /* added MZ 1.6.2006 */

	    pkdActiveRung(pkd,iKickRung,1);
	    pkdVATreeBuild(pkd,pkd->param.nBucket,diCrit2,0,dTime);
	    pkdGravityVeryActive(pkd,dTime,pkd->param.bEwald && pkd->param.bPeriodic,pkd->param.nReplicas,pkd->param.dEwCut,dStep);


#ifdef PLANETS
	    /* Sun's gravity */
           if(pkd->param.bHeliocentric){
	       /* Sun's indirect gravity due to very active particles*/
	   pkdActiveRung(pkd,iRungVeryActive+1,1);
	   pkdSunIndirect(pkd,aSun,adSun,1); 
           for (j=0;j<3;++j)
	       	{                 
                 aSun[j] += aSunInact[j];
		 adSun[j] += adSunInact[j];
	       	}
	    pkdActiveRung(pkd,iKickRung,1);
	    pkdGravSun(pkd,aSun,adSun,dSunMass); 
           }
#endif

	   if (pkd->param.bVDetails) {
	     printf("%*cVeryActive pkdCorrector at iRung: %d, 0.5*dDelta: %g\n",
		    2*iRung+2,' ',iRung,0.5*dDelta);
	    }
	   pkdCorrector(pkd,dTime);

#ifdef PLANETS
	   if(pkd->param.bHeliocentric){
	     int nite = 0;
	     int nitemax = 3;                                                    
	     do{    
	       nite += 1;
	       pkdSunCorrector(pkd,dTime,dSunMass);  		
	     }while(nite < nitemax);
           }
	   if(pkd->param.bCollision && pkd->iCollisionflag) pkdDoCollisionVeryActive(pkd,dTime); 
#endif
	   pkdCopy0(pkd,dTime); 

	   time2 = Zeit();
	   if(pkd->param.bVDetails)
	     printf("Time: %g\n",time2-time1);
	    
	}
      }   
    }

void
pkdCopy0(PKD pkd,double dTime) 
{  
    PARTICLE *p;
    int i,j,n;
    
    mdlDiag(pkd->mdl, "Into pkdCopy0\n");
            
    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {	
	if (pkdIsActive(pkd,&p[i])) { 			      
	    for (j=0;j<3;++j) {    
		p[i].r0[j] = p[i].r[j];
		p[i].v0[j] = p[i].v[j];
		p[i].a0[j] = p[i].a[j];	         	       
		p[i].ad0[j] = p[i].ad[j];	 
	    }
	    p[i].dTime0 = dTime;
#ifdef PLANETS
	    if(pkd->param.bCollision){
		p[i].iColflag = 0;  /* just in case */
	    }
#endif
	}
    }
    mdlDiag(pkd->mdl, "Out of pkdCopy0\n");
}

void
pkdPredictor(PKD pkd,double dTime) 
{
    PARTICLE *p;
    int i,j,n;
    double dt; /* time since last evaluation of force */
    
    mdlDiag(pkd->mdl, "Into pkdPredictor\n");

    if (pkd->param.bVDetails) printf("Into pkdPredictor\n");      

    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {		
	if (pkdIsActive(pkd,&p[i])) { 	
	    dt =  dTime - p[i].dTime0; 
      /*if (pkd->param.bVDetails)
	{
         printf("Particle=%d iRung=%d dt=%g \n",p[i].iOrder,p[i].iRung,dt);
	 }*/
	    for (j=0;j<3;++j) {                
		p[i].r[j] = p[i].r0[j] + dt*(p[i].v0[j] + 0.5*dt*(p[i].a0[j]+dt*p[i].ad0[j]/3.0));
		p[i].v[j] = p[i].v0[j] + dt*(p[i].a0[j]+0.5*dt*p[i].ad0[j]);   
                p[i].rp[j] = p[i].r[j];
                p[i].vp[j] = p[i].v[j];  	       
		}
           }	    
	}
    mdlDiag(pkd->mdl, "Out of pkdPredictor\n");
    }

void
pkdCorrector(PKD pkd,double dTime) 
{
    PARTICLE *p;
    int i,j,n;
    double dt, add, addd, am; 
    double a0d2, a1d2, a2d2, a3d2, dti, dt2i;
    /*double alpha = 7.0/6.0;*/    

    mdlDiag(pkd->mdl, "Into pkdCorrector\n");

    if (pkd->param.bVDetails) printf("Into pkdCorrector\n");

    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {	
	if (pkdIsActive(pkd,&p[i])) {	
	      dt =  dTime - p[i].dTime0;  
	      if(pkd->param.bAarsethStep){	    
		a0d2  = 0.0;
		a1d2  = 0.0;
		a2d2  = 0.0;
		a3d2  = 0.0;
		dti = 1.0/dt;
		dt2i = dti*dti;
	      }
	      
	    for (j=0;j<3;++j) { 	  
              am = p[i].a0[j]-p[i].a[j];

	      if(pkd->param.bAarsethStep){
	      add = 2.0*(3.0*am*dt2i+(2.0*p[i].ad0[j]+p[i].ad[j])*dti);
	      addd = 6.0*(2.0*am*dti+(p[i].ad0[j]+p[i].ad[j]))*dt2i;
              add += dt*addd; 

              a0d2 += p[i].a[j]*p[i].a[j];
              a1d2 += p[i].ad[j]*p[i].ad[j];
	      a2d2 += add*add;  
              a3d2 += addd*addd;	      
              }

	      add = 16.0*am+(13.0*p[i].ad0[j]+3.0*p[i].ad[j])*dt;
	      addd = 6.0*am+(5.0*p[i].ad0[j]+p[i].ad[j])*dt;
	      p[i].r[j] = p[i].rp[j] - add/120.0*dt*dt;
	      p[i].v[j] = p[i].vp[j] - addd/12.0*dt; 
	
	    }
	    if(pkd->param.bAarsethStep){
	      p[i].dtGrav = (sqrt(a0d2*a2d2)+a1d2)/(sqrt(a1d2*a3d2)+a2d2); 
	    }
	    /*if(p[i].dtGrav <=0.0) p[i].dtGrav = 0.1*(a0d2/a1d2);*/
	    }	   
    }
    mdlDiag(pkd->mdl, "Out of pkdCorrector\n");
}

void
pkdSunCorrector(PKD pkd,double dTime,double dSunMass) 
{
  /* iteratively correct only sun's direct gravity */
    PARTICLE *p;
    int i,j,n;
    double dt;
    double add, addd, r2,r3i,r5i,rv, am;
    /*double alpha = 7.0/6.0;*/   

    mdlDiag(pkd->mdl, "Into pkdSunCorrector\n");
            
    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {	
	if (pkdIsActive(pkd,&p[i])) { 		
	      dt =  dTime - p[i].dTime0;
	      r2  = 0.0;
              rv  = 0.0;  
             for (j=0;j<3;++j) {       
	       r2 += p[i].r[j]*p[i].r[j];
               rv += p[i].r[j]*p[i].v[j];     
	       }              
	     r2 = 1.0/r2;
               r3i = r2*sqrt(r2)*dSunMass;
	       r5i = 3.0*r3i*r2*rv;

	    for (j=0;j<3;++j) {   	   
	      p[i].a[j] = -p[i].r[j]*r3i + p[i].app[j];
	      p[i].ad[j] = -(p[i].v[j]*r3i - p[i].r[j]*r5i) + p[i].adpp[j];
	      am = p[i].a0[j]-p[i].a[j];
	      add = 16.0*am+(13.0*p[i].ad0[j]+3.0*p[i].ad[j])*dt;
	      addd = 6.0*am+(5.0*p[i].ad0[j]+p[i].ad[j])*dt;
		p[i].r[j] = p[i].rp[j] - add/120.0*dt*dt;
		p[i].v[j] = p[i].vp[j] - addd/12.0*dt;     
	                        
		}	    
	    }
	}
    mdlDiag(pkd->mdl, "Out of pkdSunCorrector\n");
    }

void
pkdPredictorInactive(PKD pkd,double dTime) 
{
    PARTICLE *p;
    int i,j,n;
    double dt; /* time since last evaluation of force */
    
    mdlDiag(pkd->mdl, "Into pkdPredictorInactive\n");

    if (pkd->param.bVDetails) printf("Into pkdPredictorInactive\n");      

    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i) {		
	if (pkdIsActive(pkd,&p[i])) continue;	
	dt =  dTime - p[i].dTime0; 
	/*if (pkd->param.bVDetails)
	  {
	  printf("Particle=%d iRung=%d dt=%g \n",p[i].iOrder,p[i].iRung,dt);
	  }*/
	for (j=0;j<3;++j) {                
	    p[i].r[j] = p[i].r0[j] + dt*(p[i].v0[j] + 0.5*dt*(p[i].a0[j]+dt*p[i].ad0[j]/3.0));
	    p[i].v[j] = p[i].v0[j] + dt*(p[i].a0[j]+0.5*dt*p[i].ad0[j]);   
	    p[i].rp[j] = p[i].r[j];
	    p[i].vp[j] = p[i].v[j];  	       
	}	    
    }
    mdlDiag(pkd->mdl, "Out of pkdPredictorInactive\n");
}

void pkdAarsethStep(PKD pkd,double dEta) {
    double dT;
    int i;
    
    for (i=0;i<pkdLocal(pkd);i++) {
	if (pkdIsActive(pkd,&(pkd->pStore[i]))) {
	    mdlassert(pkd->mdl, pkd->pStore[i].dtGrav > 0);
	    dT = dEta*sqrt(pkd->pStore[i].dtGrav);
	    if (dT < pkd->pStore[i].dt)
	    pkd->pStore[i].dt = dT;
	   
	    }
	}
    }

void pkdFirstDt(PKD pkd) {
    int i,j;
    PARTICLE *p ;
    double a0d2,a1d2;
  
    p = pkd->pStore;
    for(i=0;i<pkdLocal(pkd);++i) {
          a0d2 = 0.0;
	  a1d2 = 0.0;
	  if(pkdIsActive(pkd,&p[i]))
	      for (j=0;j<3;++j) { 	                  
		  a0d2 += p[i].a0[j]*p[i].a0[j];
		  a1d2 += p[i].ad0[j]*p[i].ad0[j];
	      }
	  p[i].dtGrav = (a0d2/a1d2);
#ifdef PLANETS
	  if(pkd->param.bCollision){
	      p[i].iColflag = 0; /* initial reset of collision flag */	
	  }
#endif
    }
}
#endif /* Hermite */

/*
 * Stripped down versions of routines from master.c
 */
void pkdKickKDKOpen(PKD pkd,double dTime,double dDelta)
    {
    double H,a;
    double dvFacOne, dvFacTwo;
	
    if (pkd->param.bCannonical) {
	dvFacOne = 1.0;		/* no hubble drag, man! */
	dvFacTwo = csmComoveKickFac(pkd->param.csm,dTime,dDelta);
	}
    else {
	/*
	** Careful! For non-cannonical we want H and a at the 
	** HALF-STEP! This is a bit messy but has to be special
	** cased in some way.
	*/
	dTime += dDelta/2.0;
	a = csmTime2Exp(pkd->param.csm,dTime);
	H = csmTime2Hub(pkd->param.csm,dTime);
	dvFacOne = (1.0 - H*dDelta)/(1.0 + H*dDelta);
	dvFacTwo = dDelta/pow(a,3.0)/(1.0 + H*dDelta);
	}
    pkdKick(pkd, dvFacOne, dvFacTwo, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0);
    }

void pkdKickKDKClose(PKD pkd,double dTime,double dDelta)
    {
    double H,a;
    double dvFacOne, dvFacTwo;
	
    if (pkd->param.bCannonical) {
	dvFacOne = 1.0; /* no hubble drag, man! */
	dvFacTwo = csmComoveKickFac(pkd->param.csm,dTime,dDelta);
	}
    else {
	/*
	** Careful! For non-cannonical we want H and a at the 
	** HALF-STEP! This is a bit messy but has to be special
	** cased in some way.
	*/
	dTime += dDelta/2.0;
	a = csmTime2Exp(pkd->param.csm,dTime);
	H = csmTime2Hub(pkd->param.csm,dTime);
	dvFacOne = (1.0 - H*dDelta)/(1.0 + H*dDelta);
	dvFacTwo = dDelta/pow(a,3.0)/(1.0 + H*dDelta);
	}
    pkdKick(pkd, dvFacOne, dvFacTwo, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0);
    }

void pkdKick(PKD pkd, double dvFacOne, double dvFacTwo, double dvPredFacOne,
	     double dvPredFacTwo, double duDelta, double duPredDelta, int iGasModel,
	     double z, double duDotLimit)
{
    PARTICLE *p;
    int i,j,n;
    double dr, a1, ff, nn;
    double tx,ty,tz,lx,ly,lz;

    pkdClearTimer(pkd,1);
    pkdStartTimer(pkd,1);

    p = pkd->pStore;
    n = pkdLocal(pkd);

    for (i=0;i<n;++i,++p) {
      if (pkdIsActive(pkd,p)){  
	
	//	r  = sqrt(p->r[0]*p->r[0] + p->r[1]*p->r[1] + p->r[2]*p->r[2]);

	/*printf("%d mass = %.10e r= %g, ax %.10e ay %.10e az %.10e x %.10e y %.10e z %.10e, vx %.10e vy %.10e vz %.10e\n",p->iOrgIdx,p->fMass,r,p->a[0],p->a[1],p->a[2],p->r[0],p->r[1],p->r[2],p->v[0],p->v[1],p->v[2]);*/


	for (j=0;j<3;++j) {
	  p->v[j] = p->v[j]*dvFacOne + p->a[j]*dvFacTwo;     	
	}

	if(p->iColor == SUBEMBRYO){	
	  tx =  (p->r[1]*p->ae[2] - p->r[2]*p->ae[1]);
	  ty =  (p->r[2]*p->ae[0] - p->r[0]*p->ae[2]);
	  tz =  (p->r[0]*p->ae[1] - p->r[1]*p->ae[0]);
	  lx =  (p->r[1]*p->v[2] - p->r[2]*p->v[1]);
	  ly =  (p->r[2]*p->v[0] - p->r[0]*p->v[2]);
	  lz =  (p->r[0]*p->v[1] - p->r[1]*p->v[0]);	 
	  tx = (tx*lx+ty*ly+tz*lz)/sqrt(lx*lx+ly*ly+lz*lz);

	  p->dls +=  tx*dvFacTwo;
	}

	if(fabs(p->a[0]) < 100.0 && fabs(p->v[j]) < 100.0){
	}else{
	  printf("bbbb oid=%d, col = %d, rung = %d,(x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), m = %e \n",p->iOrgIdx,p->iColor,p->iRung,p->r[0],p->r[1],p->r[2],p->v[0],p->v[1],p->v[2],p->fMass);
	  assert(0);
	}

      }
    }
    
    /*fclose(fp)*/;
    
    pkdStopTimer(pkd,1);
    mdlDiag(pkd->mdl, "Done pkdkick\n");
}


void pkdEwaldKick(PKD pkd, double dvFacOne, double dvFacTwo) {
    PARTICLE *p;
    int i,j,n;

    p = pkd->pStore;
    n = pkdLocal(pkd);
    for (i=0;i<n;++i,++p) {
	for (j=0;j<3;++j) {
	    p->v[j] = p->v[j]*dvFacOne + p->ae[j]*dvFacTwo;
	}
    }
}


void pkdInitStep(PKD pkd, struct parameters *p, CSM csm) {
    pkd->param = *p;
    /*
    ** Need to be careful to correctly copy the cosmo
    ** parameters. This is very ugly!
    */
    csmInitialize(&pkd->param.csm);
    *pkd->param.csm = *csm;
    }


void pkdSetRung(PKD pkd, int iRung) {
    int i;
    
    for(i=0;i<pkdLocal(pkd);++i) {
	pkd->pStore[i].iRung = iRung;
	}
    }

void pkdActiveRung(PKD pkd, int iRung, int bGreater) {
    pkd->uMinRungActive = iRung;
    pkd->uMaxRungActive = bGreater ? 255 : iRung;
    }

int pkdCurrRung(PKD pkd, int iRung) {
    int i;
    int iCurrent;
    
    iCurrent = 0;
    for(i=0;i<pkdLocal(pkd);++i) {
	if(pkd->pStore[i].iRung == iRung) {
	    iCurrent = 1;
	    break;
	    }
	}
    return iCurrent;
    }

void pkdGravStep(PKD pkd,double dEta,double dRhoFac) {
    double dT;
    int i;
    
    for (i=0;i<pkdLocal(pkd);i++) {
	if (pkdIsActive(pkd,&(pkd->pStore[i]))) {
	    mdlassert(pkd->mdl, pkd->pStore[i].dtGrav > 0);
	    dT = dEta/sqrt(pkd->pStore[i].dtGrav*dRhoFac);
	    if (dT < pkd->pStore[i].dt) {
		pkd->pStore[i].dt = dT;	
	
		  mdlassert(pkd->mdl,dT>0);
	        }
	    }
	}
    }

void pkdAccelStep(PKD pkd,double dEta,double dVelFac,double dAccFac,int bDoGravity,int bEpsAcc,int bSqrtPhi,double dhMinOverSoft) {
    int i;
    double vel;
    double acc;
    int j;
    double dT;

    for (i=0;i<pkdLocal(pkd);++i) {
	if (pkdIsActive(pkd,&(pkd->pStore[i]))) {
	    vel = 0;
	    acc = 0;
	    for (j=0;j<3;j++) {
		vel += pkd->pStore[i].v[j]*pkd->pStore[i].v[j];
		acc += pkd->pStore[i].a[j]*pkd->pStore[i].a[j];
		}
	    mdlassert(pkd->mdl,vel >= 0);
	    vel = sqrt(vel)*dVelFac;
	    mdlassert(pkd->mdl,acc >= 0);
	    acc = sqrt(acc)*dAccFac;
	    mdlassert(pkd->mdl,acc > 0);
	    dT = FLOAT_MAXVAL;
	    if (bEpsAcc && acc>0) {
		dT = dEta*sqrt(pkd->pStore[i].fSoft/acc);
		}
	    if (bSqrtPhi) {
		/*
		** NOTE: The factor of 3.5 keeps this criterion in sync
		** with DensityStep. The nominal value of dEta for both
		** cases is then 0.02-0.03.
		*/
		double dtemp =
		    dEta*3.5*sqrt(dAccFac*fabs(pkd->pStore[i].fPot))/acc;
		if (dtemp < dT)
		    dT = dtemp;
		}
	    if (dT < pkd->pStore[i].dt) {
		pkd->pStore[i].dt = dT;
		mdlassert(pkd->mdl,dT>0);
	        }
	    }
	}
    }


void pkdDensityStep(PKD pkd,double dEta,double dRhoFac) {
    int i;
    double dT;
    
    for (i=0;i<pkdLocal(pkd);++i) {
	if (pkdIsActive(pkd,&(pkd->pStore[i]))) {
	    dT = dEta/sqrt(pkd->pStore[i].fDensity*dRhoFac);
	    if (dT < pkd->pStore[i].dt) {
		pkd->pStore[i].dt = dT;
		mdlassert(pkd->mdl,dT>0);
	        }
	    }
	}
    }

int pkdDtToRung(PKD pkd,int iRung,double dDelta,int iMaxRung,int bAll,int *nRungCount) {
    int i;
    int iTempRung;
    int iSteps;
    
    for (i=0;i<iMaxRung;++i) nRungCount[i] = 0;
    for(i=0;i<pkdLocal(pkd);++i) {
	if(pkd->pStore[i].iRung >= iRung) {
	    mdlassert(pkd->mdl,pkdIsActive(pkd,&(pkd->pStore[i])));
	    if(bAll) {          /* Assign all rungs at iRung and above */
		mdlassert(pkd->mdl,pkd->pStore[i].fSoft > 0);
		mdlassert(pkd->mdl,pkd->pStore[i].dt > 0);
		iSteps = dDelta/pkd->pStore[i].dt;
		/* insure that integer boundary goes
		   to the lower rung. */
		if(fmod(dDelta,pkd->pStore[i].dt) == 0.0)
		    iSteps--;
		iTempRung = iRung;
		if(iSteps < 0)
		    iSteps = 0;
		while(iSteps) {
		    ++iTempRung;
		    iSteps >>= 1;
		    }
		if(iTempRung >= iMaxRung) {
		    iTempRung = iMaxRung-1;
		    printf("Maximum Rung %d overshot for particle %d!\n",iMaxRung-1,pkd->pStore[i].iOrder);
		    }
		pkd->pStore[i].iRung = iTempRung;
		}
	    else {
		if(dDelta <= pkd->pStore[i].dt) {
		    pkd->pStore[i].iRung = iRung;
		    }
		else {
		    pkd->pStore[i].iRung = iRung+1;
		    }
                }
	    }
	/*
	** Now produce a count of particles in rungs.
	*/
	nRungCount[pkd->pStore[i].iRung] += 1;
	}
    iTempRung = iMaxRung-1;
    while (nRungCount[iTempRung] == 0 && iTempRung > 0) --iTempRung;
    return iTempRung;
    }

void pkdInitDt(PKD pkd,double dDelta) {
    int i;
    
    for(i=0;i<pkdLocal(pkd);++i) {
	if(pkdIsActive(pkd,&(pkd->pStore[i]))) {
	    pkd->pStore[i].dt = dDelta;
	    mdlassert(pkd->mdl,dDelta>0);
	    }
	}
    }
    

void pkdDeleteParticle(PKD pkd, PARTICLE *p) {
 

  printf("pkddelete iorder %d color %d mass %e rung %d n_VA %d\n", p->iOrder, p->iColor, p->fMass,p->iRung,p->n_VA);
#ifdef PLANETS
  /* the following operation is an emergent treatment for 
     to-be-deleted VeryActive particles. */

    int j; 
       p->fMass = 0.0;
       /*p->iRung = 0; for three body encounter, this particle still needs to be active.
	Otherwise the VA list for partiles not involved in the collision need to be updated*/
	 if(pkd->param.bGravStep){
	   p->dtGrav = 0.00001;
	 }       
#ifdef HERMITE
        if(pkd->param.bAarsethStep){
	   p->dtGrav = 10000;
       }
#endif
#ifdef SYMBA
	p->drmin = 1000.0;
	p->n_VA=0;      
#endif
       for (j=0;j<3;j++) {
	 p->r[j] = 110.0*(p->iOrder+1.0);
	 p->v[j] = 0.0;     
#ifdef HERMITE
	 p->r0[j] = 100.0*(p->iOrder+1.0);
	 p->v0[j] = 0.0;
	 p->a0[j] =  0.000001;
	 p->ad0[j] = 0.000001;
	 p->a[j] =  0.000001;
	 p->ad[j] = 0.000001;
#endif
       }

#endif

    p->iOrder = -2 - p->iOrder;
    TYPEClearACTIVE(p);
    TYPESet(p, TYPE_DELETED);

    }

void pkdNewParticle(PKD pkd, PARTICLE *p) {
  // in msrinitial we allocate memory of n*(1+dExtrastore)
  if(pkd->nStore <= pkd->nLocal){
    printf("nstore %d nlocal %d \n",pkd->nStore,pkd->nLocal);
    assert(0);
  }
    mdlassert(pkd->mdl,pkd->nLocal < pkd->nStore);    
    pkd->pStore[pkd->nLocal] = *p;
    pkd->pStore[pkd->nLocal].iOrder = -1;
    //#ifdef PLANETS
    //pkd->pStore[pkd->nLocal].iOrgIdx = -1; now new iOrgIdx = -1*iOrgIdx of pi see collision.c 021014
    //#endif    
    pkd->nLocal++;
    }

void pkdColNParts(PKD pkd, int *pnNew, int *nDeltaGas, int *nDeltaDark,
		  int *nDeltaStar) {

  // redistribute particles in the structure
  // 
  
    int pi, pj;
    int nNew;
    int ndGas;
    int ndDark;
    int ndStar;
    int newnLocal;
    PARTICLE *p;
    
    nNew = 0;
    ndGas = 0;
    ndDark = 0;
    ndStar = 0;
    newnLocal = pkdLocal(pkd);
    for(pi = 0, pj = 0; pi < pkdLocal(pkd); pi++) {
	if(pj < pi)
	    pkd->pStore[pj] = pkd->pStore[pi];
	p = &pkd->pStore[pi];
	if(p->iOrder == -1) {
	    ++pj;
	    ++nNew;
	    ++ndDark;
	    if(pkdIsActive(pkd,p))
		++pkd->nActive;
	    continue;
	    }
	else if(p->iOrder < -1){
	    --newnLocal;
	    p->iOrder = -2 - p->iOrder;
	    if(pkdIsGas(pkd, p))
		--ndGas;
	    else if(pkdIsDark(pkd, p))
		--ndDark;
	    else if(pkdIsStar(pkd, p))
		--ndStar;
	    else
		mdlassert(pkd->mdl,0);
	    if(pkdIsActive(pkd,p))
		--pkd->nActive;
	    }
	else {
	    ++pj;
	    }
	}

    *pnNew = nNew;
    *nDeltaGas = ndGas;
    *nDeltaDark = ndDark;
    *nDeltaStar = ndStar;
    pkd->nLocal = newnLocal;
    }

void
pkdNewOrder(PKD pkd,int nStart)
    {
    int pi;
    
    for(pi=0;pi<pkdLocal(pkd);pi++) {
	if(pkd->pStore[pi].iOrder == -1) {
	    pkd->pStore[pi].iOrder = nStart++;
	    }
	}
    }

#ifdef PLANETS
void
pkdNewOrgIdx(PKD pkd,int nStart)
{
  int pi, iorgi;
  PARTICLE *p; 
  p = pkd->pStore;
  FILE *fp, *fp2;
  XDR xdrs;	

  for(pi=0;pi<pkdLocal(pkd);pi++) {
    if(p[pi].iOrgIdx < 0) {
#ifdef sm2d
      iorgi = -(p[pi].iOrgIdx+1); /* iOrgIdx of the splitted openent */ 
#endif

      printf("nstart %d \n",nStart);
      p[pi].iOrgIdx = nStart++;
   
#ifdef sm2d

      if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	fp = fopen(COLL_LOG_PBHYB_TXT,"a");
	assert(fp != NULL);
	fprintf(fp,"new id 2:p=%i,o=%i,oi=%i,oiop = %i \n",
		pkd->idSelf,p[pi].iOrder,p[pi].iOrgIdx,iorgi);
	fclose(fp);
      }
      if((pkd->param.iCollLogOption & COLL_LOG_TERSE) && (iorgi < pkd->param.N0*10000)){
	// no writing for new supplied pebbles (excluding fragments)
	    fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
	    assert(fp2 != NULL);
	    xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
			  
	    (void) xdr_int(&xdrs,&(p[pi].iOrgIdx));
	    (void) xdr_int(&xdrs,&iorgi);
	 	  
	    xdr_destroy(&xdrs);
	    (void) fclose(fp2);	  
       }


      /*to be deleted */

      printf("new id 2:p=%i,o=%i,oi=%i,oiop = %i \n",
	      pkd->idSelf,p[pi].iOrder,p[pi].iOrgIdx,iorgi);
    	  

#endif	  
    }
  }


}

void pkdGetnMaxOrgIdx(PKD pkd, int *nMaxOrgIdx){
  int i;
  PARTICLE *p; 
  p = pkd->pStore;
  
  int maxi = 0;

  for(i=0;i<pkdLocal(pkd);++i) {  
    if(p[i].iOrgIdx > maxi){
      maxi = p[i].iOrgIdx;
    }  
  }
  *nMaxOrgIdx = maxi;
}

#endif

void
pkdSetNParts(PKD pkd,int nGas,int nDark,int nStar,int nMaxOrderGas,
	     int nMaxOrderDark) {
    pkd->nGas = nGas;
    pkd->nDark = nDark;
    pkd->nStar = nStar;
    pkd->nMaxOrderGas = nMaxOrderGas;
    pkd->nMaxOrderDark = nMaxOrderDark;
    /* add nMaxOrgIdx ?*/
    }


void
pkdSetRungVeryActive(PKD pkd, int iRung)
    {
    /* Remember, the first very active particle is at iRungVeryActive + 1 */
    pkd->uRungVeryActive = iRung;
    }

void pkdSetParticleTypes(PKD pkd)
    {
    PARTICLE *p;
    int i, iSetMask;
    
    for(i=0;i<pkdLocal(pkd);++i) {
	p = &pkd->pStore[i];
	iSetMask = 0;
	if (pkdIsGas (pkd,p)) iSetMask |= TYPE_GAS;
	if (pkdIsDark(pkd,p)) iSetMask |= TYPE_DARK;
	if (pkdIsStar(pkd,p)) iSetMask |= TYPE_STAR;

	TYPESet(p,iSetMask);
	}
    }

int pkdIsGas(PKD pkd,PARTICLE *p) {
    if (p->iOrder <= pkd->nMaxOrderGas) return 1;
    else return 0;
    }

int pkdIsDark(PKD pkd,PARTICLE *p) {
  if (p->iOrder > pkd->nMaxOrderGas && p->iOrder <= pkd->nMaxOrderDark){
    return 1;
  }else{ 
    /*printf("pkdisdark iorder %d  nMaxOrderGas %d nMaxOrderDark %d \n",p->iOrder,pkd->nMaxOrderGas,pkd->nMaxOrderDark);*/
    return 0;
  }
    }

int pkdIsStar(PKD pkd,PARTICLE *p) {
    if (p->iOrder > pkd->nMaxOrderDark) return 1;
    else return 0;
    }

#ifdef RELAXATION
void pkdInitRelaxation(PKD pkd)
    {
    int i,j;
    
    for(i=0;i<pkdLocal(pkd);++i) {
	pkd->pStore[i].fRelax = 0.0;
	}
    }

#endif /* RELAXATION */

#ifdef PLANETS
void
pkdReadSS(PKD pkd,char *pszFileName,int nStart,int nLocal)
{
	SSIO ssio;
	SSDATA data;
	PARTICLE *p;
	int i,j, iSetMask;

	pkd->nLocal = nLocal;
	pkd->nActive = nLocal;
	/*
	 ** General initialization (modeled after pkdReadTipsy()).
	 */
	for (i=0;i<nLocal;++i) {
		p = &pkd->pStore[i];
		TYPEClear(p);
		p->iRung = 0;
		p->fWeight = 1.0;
		p->fDensity = 0.0;		
		}
	/*
	 ** Seek past the header and up to nStart.
	 */
	if (ssioOpen(pszFileName,&ssio,SSIO_READ))
		mdlassert(pkd->mdl,0); /* unable to open ss file */
	if (ssioSetPos(&ssio,SSHEAD_SIZE + nStart*SSDATA_SIZE))
		mdlassert(pkd->mdl,0); /* unable to seek in ss file */
	/*
	 ** Read Stuff!
	 */
	for (i=0;i<nLocal;++i) {
		p = &pkd->pStore[i];
		p->iOrder = nStart + i;
		iSetMask = TYPE_DARK;
		if (ssioData(&ssio,&data))
			mdlassert(pkd->mdl,0); /* error during read in ss file */
		p->iOrgIdx = data.org_idx;
		p->fMass = data.mass;
		p->fSoft = data.radius;
		p->nump = data.nump;
		for (j=0;j<3;++j) p->r[j] = data.pos[j];
		for (j=0;j<3;++j) p->v[j] = data.vel[j];
		for (j=0;j<3;++j) p->w[j] = data.spin[j];
		p->iColor = data.color;
		p->dls = data.dls; /* added 012314 */
		p->fGasMass = data.gasmass; /* added 021417 */
		p->tcheck = data.tcheck; /* added 021417 */	
#ifdef NEED_VPRED
		for (j=0;j<3;++j) p->vPred[j] = p->v[j];
#endif
		TYPESet(p,iSetMask);
		}
	if (ssioClose(&ssio))
		mdlassert(pkd->mdl,0); /* unable to close ss file */
	}

void
pkdWriteSS(PKD pkd,char *pszFileName,int nStart)
{
	SSIO ssio;
	SSDATA data;
	PARTICLE *p;
	int i,j;

	/*
	 ** Seek past the header and up to nStart.
	 */
	if (ssioOpen(pszFileName,&ssio,SSIO_UPDATE))
		mdlassert(pkd->mdl,0); /* unable to open ss file */
	if (ssioSetPos(&ssio,SSHEAD_SIZE + nStart*SSDATA_SIZE))
		mdlassert(pkd->mdl,0); /* unable to seek in ss file */
	/* 
	 ** Write Stuff!
	 */
	for (i=0;i<pkdLocal(pkd);++i) {
		p = &pkd->pStore[i];
		if (!pkdIsDark(pkd,p))
			mdlassert(pkd->mdl,0); /* only dark particles allowed in ss file */
		data.org_idx = p->iOrgIdx;
		data.mass = p->fMass;
		data.radius = p->fSoft;
		data.nump = p->nump;
		for (j=0;j<3;++j) data.pos[j]  = p->r[j];
		for (j=0;j<3;++j) data.vel[j]  = p->v[j];
		for (j=0;j<3;++j) data.spin[j] = p->w[j];
		data.color = p->iColor;
		data.dls = p->dls;
		data.gasmass = p->fGasMass; /* added 021417 */
		data.tcheck = p->tcheck; /* added 021417 */
	
		if (ssioData(&ssio,&data))
			mdlassert(pkd->mdl,0); /* unable to write in ss file */
		}
	if (ssioClose(&ssio))
		mdlassert(pkd->mdl,0); /* unable to close ss file */
	}

 void pkdSunIndirect(PKD pkd,double aSun[],double adSun[],int iFlag)
 {
     PARTICLE *p;
     FLOAT r2,r1i,r3i,r5i,rv;
     int i,j,n;
   
     for (j=0;j<3;++j)
	       	{                 
                 aSun[j] = 0;
		 adSun[j] = 0;
	       	}
     p = pkd->pStore;
     n = pkdLocal(pkd); 
     for (i=0;i<n;++i) {
       
        if (iFlag == 2){ 
	    if (pkdIsActive(pkd,&p[i])) continue;  /* inactive */
       }else if(iFlag == 1){
	    if (!pkdIsActive(pkd,&p[i])) continue; /* active */
       }

	 r2 = 0;
	 rv = 0;
	 for (j=0;j<3;++j)
	       	{ 
                 r2 += p[i].r[j]*p[i].r[j];
                 rv += p[i].v[j]*p[i].r[j];
	       	}
	 r1i = (r2 == 0 ? 0 : 1/sqrt(r2));
	 r3i = p[i].fMass*r1i*r1i*r1i;
         r5i = 3.0*rv*r3i*r1i*r1i; 
	 for (j=0;j<3;++j)
	       	{ 
                 aSun[j] += p[i].r[j]*r3i;
                 adSun[j] += p[i].v[j]*r3i-p[i].r[j]*r5i;
	       	}	
 }
 } 

void pkdGravSun(PKD pkd,double aSun[],double adSun[],double dSunMass)
{
	PARTICLE *p;
	double r2,v2,r1i,r3i;
        double aai,aa3i,idt2;
        double rv, r5i; 
	int i,j,n;
	double hx,hy,hz,h2,E,e,sum;

	p = pkd->pStore;
	n = pkdLocal(pkd);
	for (i=0;i<n;++i) {
	    if (pkdIsActive(pkd,&(p[i]))) {
			r2 = 0;
			v2 = 0;
                        rv = 0;
			for (j=0;j<3;++j)
			{ 
                        r2 += p[i].r[j]*p[i].r[j];
                        v2 += p[i].v[j]*p[i].v[j];
                        rv += p[i].v[j]*p[i].r[j];
			}
		
			r1i = (r2 == 0 ? 0 : 1/sqrt(r2)); /*gravity at origin = zero */
			p[i].fPot -= dSunMass*r1i;
			r3i = dSunMass*r1i*r1i*r1i;
                        r5i = 3.0*rv*r3i*r1i*r1i;
			/* time step is determined by semimajor axis, not the heliocentric distance*/ 
			if(pkd->param.bGravStep && p[i].fMass > 0){
			  /* E and h are normalized by the reduced mass */
			  sum = dSunMass + p[i].fMass;
			  hx =  p[i].r[1]*p[i].v[2] - p[i].r[2]*p[i].v[1];  
			  hy =  p[i].r[2]*p[i].v[0] - p[i].r[0]*p[i].v[2];  
			  hz =  p[i].r[0]*p[i].v[1] - p[i].r[1]*p[i].v[0];  
			  h2 = hx*hx + hy*hy + hz*hz;
			  E = 0.5*v2 - sum*r1i;			  
			  e = sqrt(1.0+2.0*E*h2/sum/sum);
			  aai = -2.0*E/sum/(1.0-e); 
			  aai = aai*aai*aai;
			  idt2 = sum*aai;
			  /*if (p[i].dtSun > p[i].dtGrav) p[i].dtGrav = p[i].dtSun;*/
			  if (idt2 > p[i].dtGrav) p[i].dtGrav = idt2;
			}		   
			for (j=0;j<3;++j) {	
#ifdef HERMITE
				  if(pkd->param.bHermite){
				    p[i].app[j] = p[i].a[j] - aSun[j]; /* perturbation force*/
				    p[i].adpp[j] = p[i].ad[j] - adSun[j];					
				    p[i].ad[j] -= (adSun[j] + p[i].v[j]*r3i-p[i].r[j]*r5i);
				  }
#endif
					p[i].a[j] -= (aSun[j] + p[i].r[j]*r3i);
					}				
			}
		}
	}

void pkdHandSunMass(PKD pkd, double dSunMass)
{
  pkd->dSunMass = dSunMass; 
}


//void pkdGetJupiter(PKD pkd, double *paj, double *pmj){
void  pkdGetJupiter(PKD pkd, GASDISK_PARAMS * GP, int  *pnpgap,double *apgap, double *k1, double *k2){
  
  int i;
  PARTICLE *p;
  p = pkd->pStore;
  double dSunMass = pkd->dSunMass;
  int npgap = 0;
  double alpha = GP->dalpha;
  STEPINSKI * ST;
  double Sigma,Sigma0,Gasp,Temp,Gasq,h,Kappa;
  double ap,mp,omega;

  if (pkd->param.HY.iGasAcc2Planet ==2)alpha = 2.e-2; //test

  // search for planets more massive than Earth
  for(i=0;i<pkdLocal(pkd);++i) {
    if(p[i].iColor > SUBEMBRYO)continue;
    if(p[i].fMass > M_EARTH/M_SUN){
      ap = p[i].ele[0];
      mp = p[i].fMass;   
      omega = sqrt((dSunMass+ mp)/ap)/ap;
      // get only h
      pkdGetGasDisk(pkd,GP,0.0/(2.0*M_PI),ap,omega,1.0,0.1,1000.0,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);

      apgap[npgap] = ap;  
      k2[npgap] = mp*mp*pow((ap/h),3.0)/alpha; // parameter K' kanagawa et al.(2016)
      k1[npgap] = k2[npgap]*(ap/h)*(ap/h); // parameter K kanagawa et al.(2016)
      //k2[npgap] = sqrt(sqrt(k2[npgap])); // K'^(1/4)
      k2[npgap] = sqrt(1.89+0.53/mp*(h/ap)*(h/ap)*(h/ap)); // sqrt(tau_sh) Duffell (2015) 
      // printf("get jupiter ap %g,mp %g,k1 %g,k2 %g \n",ap,mp,k1[npgap],k2[npgap]);
      npgap++;
    }  
  }

  *pnpgap = npgap;
}

void pkdGasAcc2Planet(PKD pkd,GASDISK_PARAMS * GP, double dTime, int iGasAcc2Planet, double dDPBHYB){
  assert(GP->iGasModel == 1); // gas model = 1 only for now
  PARTICLE *p;
  double m_e = M_EARTH/M_SUN;
  double kappa = pkd->param.GP.dkappa;
  double dSunMass = pkd->dSunMass;
  double alpha = GP->dalpha;
  double rin, rout,depfac,mass,dmdt,r1,omega;
  double tau_kh,mdot_kh,nu,mdot_gl,mdot_lc,mdot,mcrit,mb;

  int    i, j, n;
  STEPINSKI * ST;
  double Sigma,Sigma0,Gasp,Temp,Gasq,h,Kappa;
  int ng,ig[20];
  double ag[20],mdot_up;

  
  if (iGasAcc2Planet ==2)alpha = 2.e-2; //test
			
  p = pkd->pStore;
  n = pkdLocal(pkd);

  rin = 0.1; 
  rout = 100.0;
  
  if(GP->dTau_diss < 1.e8 && (GP->iGasModel == 1 || GP->iGasModel == 4)){
    depfac = exp(-dTime/(2.0*M_PI*GP->dTau_diss));
  }else{
    depfac = 1.0;
  }

  ng = 0;
  for(i=0;i<n;++i) {
    mass = p[i].fMass;
    dmdt = p[i].dmdt;
    if(dmdt > 0){
      if(dmdt < 0.1*mass/dTime){
	printf("id %d mass %g dmdt %g dTime %g tgrow (yr) %g, m/t %g \n",p[i].iOrgIdx,mass,dmdt,dTime,mass/dmdt/(2.0*M_PI),mass/dTime);
	//	assert(0); not appropriate if a planet is introduced at t = 0
      }
    }
 
     
    // promote a planetesimal to giant if m > mcrit 
    if(p[i].iColor == PLANETESIMAL && dmdt > 0){      
      mcrit = 7.0*pow((dmdt/(1.e-7*(m_e/(2.0*M_PI)))),0.25)*pow(kappa,0.25)*m_e; // Ikoma et al. Eq. (A2)
      // printf("id %d dmdt (m_e/yr) %g mcrit (m_e) %g \n",p[i].iOrgIdx,dmdt/((m_e/(2.0*M_PI))),mcrit/m_e);
      if(mass > mcrit){
	p[i].iColor = GIANT;
	p[i].tcheck = dTime;
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");	
	printf("Particle %d is promoted to GIANT at time %g yr, mass %g, dmdt (m_e/yr) %g \n",
	       p[i].iOrgIdx,dTime/(2.0*M_PI),mass,dmdt/((m_e/(2.0*M_PI))));
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
      }   
    }

    //list of giant planets
    if(p[i].iColor == GIANT){
      ig[ng] = i;
      ag[ng] = p[i].ele[0];
      ng ++;    
    }   
  }
  
  //sort in ascending order of semimajor axis
  if(ng >= 2){
    qasort(ag,ig,0,ng-1);
  }

  mdot_up = 0.0; // total accretion rate of other exterior giant planets
  for(j=ng-1;j>=0;--j){
    i = ig[j];
    assert(p[i].iColor == GIANT);
   
    mass = p[i].fMass;
    r1 = p[i].ele[5];
    omega = sqrt((dSunMass+ mass)/r1)/r1;    
    pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),r1,omega,depfac,rin,rout,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);
    
    tau_kh = 1.e8*2.0*M_PI*pow((mass/m_e),-2.5)*kappa; // Ikoma et al. Eq. (19)
    mdot_kh = mass/tau_kh;
    
    nu = alpha*h*h*omega;
    mdot_gl = 3.0*M_PI*Sigma0*nu - mdot_up;

    // printf("j %d i %d ag %g, mass %g, mdot_gl %g mdot_gl0 %g \n", j,i,ag[j],mass,mdot_gl,3.0*M_PI*Sigma0*nu);
    // assert(mdot_gl >= 0.0);
    if(mdot_gl < 0)mdot_gl = 0.0;
    
    //   assert(dTime > p[i].tcheck); failed for introduced embryos need to specify in add_planets.c
    
    mdot = 0.9*mdot_gl;

    if(mdot > mdot_kh) mdot = mdot_kh;
  
    mdot_up += mdot;
    //  printf("mdot_gl %g mdot_kh %g mdot_up %g \n", 0.9*mdot_gl,mdot_kh,mdot_up);

    
    mb = p[i].fMass;
    p[i].fMass += mdot*dDPBHYB;
    p[i].fGasMass += mdot*dDPBHYB;
    p[i].fSoft *= cbrt(p[i].fMass/mb);
  } 
 
  
}

void qasort(double *ag, int *ig,int left,int right){
  int i,j,pivot;
  i = left;
  j = right;
  pivot = ag[(left+right)/2];
  while(1){
    while (ag[i] < pivot)i++;
    while (pivot < ag[j])j--;
    if(i>=j)break;
    swap(ag,ig,i,j); 
    if(left < i-1)qasort(ag,ig,left,i-1);
    if(j+1 < right)qasort(ag,ig,j+1,right);
  }  
}

void swap(double *ag,int *ig,int i,int j){
  double temp;
  int itemp;
  temp = ag[i];
  ag[i] = ag[j];
  ag[j] = temp;
  itemp = ig[i];
  ig[i] = ig[j];
  ig[j] = itemp;
  
}




void pkdPebble2Planetesimal(PKD pkd,GASDISK_PARAMS * GP, double dTime, int iPlForm, double dDPBHYB){
  assert(GP->iGasModel == 1); // gas model = 1 only for now
 
  double dapin = pkd->param.HY.dapin;
  double dSt_min = pkd->param.HY.dSt_min;
  double alpha = GP->dalpha;
  double mpl = pkd->param.HY.dmpl;
  double cpl = pkd->param.HY.dcpl;
  double tau_em = pkd->param.HY.dtau_em*2.0*M_PI;
  double rhop = 2.0*ffrho;
  STEPINSKI * ST;
  double Gasp, Gasq, Sigma,Sigma0,omega,Temp,f1,p1,vr,tau_pl,rr,mpl_new,rin,rout,depfac,h,Kappa;
  double dapout0,dapout,r1;
  double dSunMass = pkd->dSunMass;
  int i,j,n,iStart;
  PARTICLE *p; 
  struct helio hel;
  struct delaunay del;
  double dSunMass1,a1,e1,i1,e_new,i_new,pp,mpl0,mpl1,rpl1;
  double mplm,deno,pm,pp2,facp2;
  double a0 = pkd->param.daout;
  double rsunc = pkd->param.dRSunc; /* solar radius for circularly orbiting bodies */
  int iPbGrow = pkd->param.HY.iPbGrow;
  int iGap;

  rin = 0.1; 
  rout = 100.0;
  
  if(GP->dTau_diss < 1.e8 && (GP->iGasModel == 1 || GP->iGasModel == 4)){
    depfac = exp(-dTime/(2.0*M_PI*GP->dTau_diss));
  }else{
    depfac = 1.0;
  }

  mpl1 = mpl;
  //if(iPlForm ==100)mpl1 *= depfac*sqrt(depfac);
  rpl1 = cbrt(3.0*mpl1/(4.0*M_PI*rhop));
  omega = sqrt(dSunMass);

   if(iPlForm >= 1 && iPlForm < 100){
    // The following four lines can be moved to initial set up
    pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),1.0,omega,depfac,rin,rout,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa); 
    f1 = 0.087*pow((alpha*h*GP->dSigma10*fsig),1.5)*pow(rhop/(dSunMass*dSunMass*dSunMass),0.25);
    p1 = (1.5-0.5*GP->dGasq)*1.5 -1.5*GP->dGasp + 9.0/4.0; // mpl = f1*r^p1
    dapout0 = pow(mpl/f1,1.0/p1); // p1 = 21.0/8.0 for Gasp = 1 and Gasq = 1/2  
    dapout = dapout0*pow(depfac,-1.5/p1); // -1.5/p1 = -4/7  dapout/dapout0 = 1.77079, 3.13572, 5.55271, 9.83271, 17.4117 for  t/tau = 1,2,3,4,5
      }
   if(iPlForm >= 100){
      dapout = a0; // test!!
   }
  
   //printf("dapout0 %g f1 %g \\",dapout0,f1);
   //if((iPbGrow == 1 || iPbGrow == 2) && dapout < dapin) return; // no planetesimal formation //mod1
   //if((iPbGrow == 3 || iPbGrow == 4) && dapout < rsunc) return; // no planetesimal formation

   if(dapout < rsunc) return; // no planetesimal formation

   p = pkd->pStore;
   n = pkdLocal(pkd);
   for(i=0;i<n;++i) {
     if(p[i].iColor <= SUBEMBRYO) continue;
     if(p[i].St > 2.0) continue;
     if(p[i].iOrder < 0) continue;
     if(p[i].iRung > 0) continue;
     assert(pkdIsActive(pkd,&p[i]));
     
     r1 = p[i].ele[5];
       
     tau_pl = cpl*(1.0+p[i].St*p[i].St)/(2.0*p[i].St)*2.0*M_PI;
     if(iPlForm >= 100)tau_pl = cpl*(1.0+p[i].St*p[i].St)/(2.0*p[i].St)*2.0*M_PI*r1*sqrt(r1);

     
     rr = (double)drand48();

     iGap = 0;
     if(tau_em > 0){
       pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),r1,omega/(r1*sqrt(r1)),depfac,rin,rout,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);
       if(Gasp < -1.5-0.5*Gasq && rr < dDPBHYB/tau_em)iGap = 1; //  gap edge
     }
    //printf("rr %g dDPBHYB/tau_pl %g tau_pl %e st %e,\n",rr,dDPBHYB/tau_pl,tau_pl,p[i].St);
    
     if((iGap ==0 && rr < dDPBHYB/tau_pl && r1 > dapin && r1 < dapout) ||  // planetesimal formation
	(iGap ==1)){ // embryo formation at gap edge
       
       
       if(iGap == 0){
	 rr = (double)drand48();
	 rr = (double)drand48(); // just in case
	 
	//  mpl_new = mpl*pow(1.e3,rr-1.0);
	 
	// p = -1.6 between m0 and m1 and p = -3.5 between m1 and mm 030117
	 mpl0 = mpl1*1.e-3; // minimum planetesimal mass (max mass is mpl)
	 pp = 2.0-1.6; // 1.6 is power low index (johansen 2015, simon 2016)
	 pp2 = 2.0-3.0;
	 //mpl_new = pow(rr*(pow(mpl1,pp)-pow(mpl0,pp)) + pow(mpl0,pp),1.0/pp);

	 mplm = mpl1;
	 if(iPlForm == 2){
	   mplm = mpl1*100.0; // max;
	 }
	 
	 facp2 = pow(mpl1,pp-pp2);
	 deno = (pow(mpl1,pp)-pow(mpl0,pp))/pp + facp2*(pow(mplm,pp2)-pow(mpl1,pp2))/pp2;
	 pm = (pow(mpl1,pp)-pow(mpl0,pp))/(pp*deno);
	 if(rr < pm){
	   mpl_new = pow((rr*deno*pp + pow(mpl0,pp)),1.0/pp);
	 }else{
	   mpl_new = pow(((rr-pm)*deno*pp2/facp2 + pow(mpl1,pp2)),1.0/pp2);
	 }
	 
	 p[i].nump = p[i].fMass/mpl_new;
	 if(p[i].nump < INT_MAX*1.0) p[i].nump = ((int)p[i].nump)*1.0;
	 assert(p[i].nump >= 1.0);
	 p[i].ele[8] = p[i].fSoft/cbrt(p[i].nump); /*physical radius*/
	 
	 if(iPlForm >= 1 && iPlForm < 100){
	   e_new = cbrt(1.84*rhop*p[i].ele[8]*Sigma*r1*r1*r1*h*alpha);
	 }
	 
	 if(iPlForm >= 100){
	   e_new = sqrt(2.0*mpl1*r1/(dSunMass*rpl1))*0.1; //test!
	 }
       }
       if(iGap == 1){
	 p[i].nump = 1.0;
	 p[i].ele[8] = p[i].fSoft;
	 p[i].iColor = SUBEMBRYO;
	 e_new = 1.e-3;
       }

       //printf("e_new %e mpl1 %e,r1 %e ,dSunMass %e,rpl1 %e\n",e_new,mpl1,r1,dSunMass,rpl1);
       
       dSunMass1 = dSunMass - p[i].a_pr;
       hel.x = p[i].r[0]; 
       hel.y = p[i].r[1];
       hel.z = p[i].r[2];
       hel.vx = p[i].v[0];
       hel.vy = p[i].v[1];
       hel.vz = p[i].v[2];
       
       // del.mea in heltodel is ecc anomaly while it is mean anomaly, but it does not matter for this case.
       
       heltodel(dSunMass1,&hel,&del);
       a1 = del.sma;
       e1 = del.ecc;
       i1 = del.inc;
       
       
       //Rayleigh distribution 022717
       do
	 rr = (double)drand48();
       while (rr == 0);
       rr =  sqrt(-log(rr));
       
       //e_new = sqrt(3.0)*rr*cbrt(e_new);
       i_new = 0.5*rr*e_new;
       
       do
	 rr = (double)drand48();
       while (rr == 0);
       rr =  sqrt(-log(rr));
       
       e_new = rr*e_new;
       
       // z component of angular momentum conservation
       del.sma = (a1*(1.0-e1*e1)*cos(i1)*cos(i1))/((1.0-e_new*e_new)*cos(i_new)*cos(i_new));
       del.ecc = e_new;
       del.inc = i_new;

       // printf("a %e e %e i %e a1 %e e1 %e i1 %e rr %e \n",del.sma,del.ecc,del.inc,a1,e1,i1,rr);
       
       deltohel(dSunMass1,&del,&hel);
       p[i].r[0] = hel.x; 
       p[i].r[1] = hel.y;
       p[i].r[2] = hel.z;
       p[i].v[0] = hel.vx;
       p[i].v[1] = hel.vy;
       p[i].v[2] = hel.vz;    
       
       p[i].tcheck = dTime;
       
     }
     
   }
   
}


//void pkdGasAccel(PKD pkd, double dTime, double dDelta, GASDISK_PARAMS * GP, double aj, STEPINSKI * ST, double *dT, int iRung){  
void pkdGasAccel(PKD pkd, double dTime, double dDelta, GASDISK_PARAMS * GP, double *dT, int iRung){  
  /* acceralation due to gas 
     iGasModel 
     1 -> single power-law disk, uniform dissipation
     2 -> single power-law disk, inside-out dissipation
     3 -> Stepinski 1998
     4 -> User designed

     Gas-drag and tidal damping are calculated. Type I migration and global disk potential are optional.    
  */
  STEPINSKI * ST;
  int i,j,n,iStart;
  PARTICLE *p; 
  p = pkd->pStore;
  double x,y,z,v_x,v_y,v_z,r,r2,v2,rv,omega;
  double a_r,a_th,a_z,a_x,a_y;
  double Sigma, Sigma0, Gasp, Temp, Gasq, h, Kappa;
  double zh, Mass, Soft, pid;
  double erfc, v_kep, eta, v_gas, rho;
  double v_rel_x,v_rel_y,v_rel_z,v_rel_r, v_rel_th, v_rel; 
  double rh2, aeh, aeh3, tau_mig_in, tau_wave_in;
  double dv_x, dv_y, dv_z, depfac;
  int iGasModel = GP->iGasModel;
  double fiso, fadi, Gasen, taur, ftor;
  double Gamma = 1.4;
  double dSunMass = pkd->dSunMass;
  double rin, rout;
  double v_the,lamg,re,cd,mach,smin,rhop,rr,d_tur;
    
  /* parameters for table*/ 
#ifdef gastable
  GASDISK_TABLE GD0, GD1;
  int iGasTable = GP->iGasTable;
  int ip, jp0, jp1;
  double Sigma_t0, Sigma_t1, dt1, dt0, dt10, rr0, rr1;
  double zz00, zz01, zz10, zz11, dr00, dr01, dr10, dr11, drtotal;
  double a_r_t0,a_r_t1,a_z_t0,a_z_t1;
  double big = 1.0e7;
#endif 

  double St_min = pkd->param.HY.dSt_min;
  int iPbGrow = pkd->param.HY.iPbGrow;
  int iPlForm = pkd->param.HY.iPlForm;
  double dapin = pkd->param.HY.dapin;
  double aout = pkd->param.daout;
  double alpha = pkd->param.GP.dalpha;
  double sal = sqrt(alpha/3.0); // factor 3 added 022217
  double vtur, ctur1, ctur2;
     
  rin = 0.1; 
  rout = 100.0;
  
  if(pkd->param.GP.dTau_diss < 1.e8 && (iGasModel == 1 || iGasModel == 4)){
    depfac = exp(-dTime/(2.0*M_PI*pkd->param.GP.dTau_diss));
  }else{
    depfac = 1.0;
  }

  if(iGasModel == 2) rin = 0.1 + dTime/(2.0*M_PI*pkd->param.GP.dTau_diss);
  if(iGasModel == 3) rout = ST->rout;

#ifdef gastable
  if(iGasTable) GD0 = pkd->GD0;

  if(iGasTable == 2){   
    GD1 = pkd->GD1;
    dt1 = GD1.dTime - dTime;
    dt0 = dTime - GD0.dTime;
    dt10 = GD1.dTime- GD0.dTime;
  }
#endif
  
  *dT = 0.0;
  n = pkdLocal(pkd);
  if(iRung == 0){
    iStart = 0;
  }else{
    iStart = n-pkd->nVeryActive;
  }
 

  
  for(i=iStart;i<pkdLocal(pkd);++i) {    
    //  assert(pkdIsActive(pkd,&p[i]));
    // printf("i %d, rung %d \n",i,p[i].iRung);
     
    if(p[i].iOrder < 0) continue;
    if(p[i].iRung != iRung) continue; // added110516
    assert(pkdIsActive(pkd,&p[i]));

       if(fabs(p[i].a[0]) < 100.0 && fabs(p[i].a[1]) < 100.0 && fabs(p[i].a[2]) < 100.0){
      }else{
	printf("in gasaccel 0 oid=%d, col = %d, rung = %d (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), (ax,ay,az) = (%e,%e,%e), m = %e cd = %e v_gas = %e vtur = (%e %e %e)\n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],a_x,a_y,a_z,p[i].fMass,cd,v_gas,p[i].vtur[0],p[i].vtur[1],p[i].vtur[2]);	
	assert(0);
      }


    
    x = p[i].r[0];
    y = p[i].r[1];
    z = p[i].r[2];
    v_x = p[i].v[0]*(1.0 + p[i].fMass/dSunMass);
    v_y = p[i].v[1]*(1.0 + p[i].fMass/dSunMass);
    v_z = p[i].v[2]*(1.0 + p[i].fMass/dSunMass);
    
    r = x*x+y*y;
    r2 = r + z*z;
    v2 = v_x*v_x+v_y*v_y+v_z*v_z;
    rv = (x*v_x+y*v_y+z*v_z)/r2;
    r = sqrt(r);
    omega = 1.0/r*sqrt((dSunMass+ p[i].fMass)/r);
    pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),r,omega,depfac,rin,rout,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);

    /*Gasp = GP->dGasp;
    Gasq = GP->dGasq;
    Sigma = GP->dSigma10*depfac*pow(r,-Gasp);
    Temp = GP->dTemp1*pow(r,-Gasq);*/

    zh = z/h;

    a_r = 0.0;
    a_th = 0.0;
    a_z = 0.0;
    a_x = 0.0;
    a_y = 0.0;
      
    /* (1) Global disk potential */
#ifdef gastable
      if(iGasTable){
	ip = floor(10*r); 
	rr0 = GD0.rr[ip-1];
	rr1 = GD0.rr[ip];
    
	/* inverse distance weighted interpolation for *a_r and a_z */
	jp0 = floor(fabs(z)/(rr0*0.03));
	jp1 = floor(fabs(z)/(rr1*0.03));
	zz00 = GD0.zz[ip-1][jp0];
	zz01 = GD0.zz[ip-1][jp0+1];
	zz10 = GD0.zz[ip][jp1];	
	zz11 = GD0.zz[ip][jp1+1];
	
	dr00 = (z-zz00)*(z-zz00) + (r-rr0)*(r-rr0);
	dr01 = (z-zz01)*(z-zz01) + (r-rr0)*(r-rr0);
	dr10 = (z-zz10)*(z-zz10) + (r-rr1)*(r-rr1);
	dr11 = (z-zz11)*(z-zz11) + (r-rr1)*(r-rr1);
	
	dr00 = MIN(1.0/sqrt(dr00),big);
	dr01 = MIN(1.0/sqrt(dr01),big);
	dr10 = MIN(1.0/sqrt(dr10),big);
	dr11 = MIN(1.0/sqrt(dr11),big);
	drtotal = dr00 + dr01 + dr10 + dr11;
	
	a_r_t0 = GD0.ar[ip-1][jp0]*dr00 + GD0.ar[ip-1][jp0+1]*dr01 + GD0.ar[ip][jp1]*dr10 + GD0.ar[ip][jp1+1]*dr11;
	a_z_t0 = GD0.az[ip-1][jp0]*dr00 + GD0.az[ip-1][jp0+1]*dr01 + GD0.az[ip][jp1]*dr10 + GD0.az[ip][jp1+1]*dr11;
	a_r_t0 /=  drtotal;
	a_z_t0 /=  drtotal;
	
	if(iGasTable == 1){ /* uniform */
	  a_r += a_r_t0*depfac;
	  if(z >= 0.0){
	    a_z += a_z_t0*depfac;
	  }else{
	    a_z -= a_z_t0*depfac;
	  }
	}else{ /* non-uniform */
	  a_r_t1 = GD1.ar[ip-1][jp0]*dr00 + GD1.ar[ip-1][jp0+1]*dr01 + GD1.ar[ip][jp1]*dr10 + GD1.ar[ip][jp1+1]*dr11;
	  a_z_t1 = GD1.az[ip-1][jp0]*dr00 + GD1.az[ip-1][jp0+1]*dr01 + GD1.az[ip][jp1]*dr10 + GD1.az[ip][jp1+1]*dr11;
	  a_r_t1 /=  drtotal;
	  a_z_t1 /=  drtotal;
	  a_r += (a_r_t0*dt1 + a_r_t1*dt0)/dt10;
	  if(z >= 0.0){
	    a_z += (a_z_t0*dt1 + a_z_t1*dt0)/dt10;
	  }else{
	    a_z -= (a_z_t0*dt1 + a_z_t1*dt0)/dt10;
	  } 
	}
      } /* iGasTable*/
# endif          
      if(Sigma <= 0.0 || fabs(z/r) >= 1.5) continue; /* no gas */ //sigma condition mod on 031517
      
	/* (2) aerodynamic gas drag */
	/* Adachi et al. (1976) */
	/* v_kep takes into account nebular potential */
	
      Mass = p[i].fMass;
      Soft = p[i].fSoft;

#ifdef sm2d	
	if(pkd->param.iGravDirect >= 4 && p[i].iColor >= TRACER){
	  Mass /= (p[i].nump*1.0);
	  Soft = p[i].ele[8];
	}
#endif	

	  
      /*v_kep = sqrt((dSunMass+ Mass)*(r*r)/r2/sqrt(r2) - a_r*r);*/

      v_kep = r*omega;
      eta = 0.5*((Gasp+0.5*Gasq+1.5)*h*h + (0.5*Gasq-1.5)*z*z)/(r*r); 
      v_gas = v_kep*(1.0-eta);	
      rho = facrho*Sigma/h*exp(-0.5*zh*zh); /* vertically isothermal disk. facrho is defined in pkd.h */    

      /* (2a) 
	 turblent randam walk 011217	
	 gravitational drag (Okuzumi and Ormel, 2013)
	 kick is uniform, not gaussian after Ciesla (2010b)
       */

       
      vtur = sal*h*omega; // gas turblent velocity
      if(p[i].vtur[0] == 0.0 && p[i].vtur[1] == 0.0 && p[i].vtur[2] == 0.0){
	// we give about 0.1 vtur for the initial state
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[0] = 0.2*rr*vtur;
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[1] = 0.2*rr*vtur;
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[2] = 0.2*rr*vtur; 
      }else{
	ctur1 = 1.0-omega*dDelta;
	assert(ctur1 > 0.0);
	ctur2 = sqrt(3.0*(1.0-ctur1*ctur1));
	ctur1 = ctur1-1.0;
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[0] += ctur1*p[i].vtur[0]+ctur2*rr*vtur;
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[1] += ctur1*p[i].vtur[1]+ctur2*rr*vtur;
	rr = 1.0-2.0*((double)drand48());
	p[i].vtur[2] += ctur1*p[i].vtur[2]+ctur2*rr*vtur;
      }

      
      if(iPlForm >=1 && iPlForm <= 100){ // gravity torque due to density fluctuation 
	// d_tur = alpha*h*h*omega/(1.0+p[i].St*p[i].St) + 0.55*alpha*(Sigma*Sigma*r*r*r*r)*r*r*omega;
	d_tur = 0.55*alpha*(Sigma*Sigma*r*r*r*r)*r*r*omega;
	if(d_tur > alpha*h*h*omega)d_tur = alpha*h*h*omega;
	d_tur = 0.5*omega*sqrt(6.0*d_tur/dDelta); // del v/del t


	rr = 1.0-2.0*((double)drand48());
	a_x += rr*d_tur;
	rr = 1.0-2.0*((double)drand48());
	a_y += rr*d_tur;
	rr = 1.0-2.0*((double)drand48());
	a_z += rr*d_tur;
      }
      
      if(fabs(a_x) < 100.0 && fabs(a_y) < 100.0 && fabs(a_z) < 100.0){
      }else{
	printf("in gasaccel oid=%d, col = %d, rung = %d (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), (ax,ay,az) = (%e,%e,%e), m = %e \n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],a_x,a_y,a_z,p[i].fMass);	
	assert(0);
      }
         
      
      if(GP->bDragEnhance == 2){ // save nebula density for atmospheres
	p[i].rho_neb = rho;
	p[i].temp_neb = Temp;
	p[i].r_Bond = Mass/(1.4*h*omega*h*omega); //factor 1.4 added 022817
      }
      
      v_rel_x =  v_x + v_gas*y/r - p[i].vtur[0];
      v_rel_y =  v_y - v_gas*x/r - p[i].vtur[1];
      v_rel_z =  v_z - p[i].vtur[2];
      
      v_rel_r = (x*v_rel_x + y*v_rel_y)/r;
      v_rel_th = (x*v_rel_y - y*v_rel_x)/r;
      
      v_rel = v_rel_x*v_rel_x + v_rel_y*v_rel_y + v_rel_z*v_rel_z;
      v_rel = sqrt(v_rel);

      v_the = 1.59577*h*omega; // thermal velocity;  factor corrected on 022117 (0.626657 --> 1.59577)     
      lamg = 2.19396e-16/rho; //mean free path,  factor =3.94e-24 g/2.e-15 cm^2 normalized by msun/au^2  
      assert(lamg > 0.0);
      re = (6.0*Soft*v_rel)/(v_the*lamg); // Reynolds number;  old one is (4.0*Soft*v_rel)/(v_the*lamg)
      mach = v_rel/(1.18322*h*omega); // Mach number; factor added 022117
     
      // cd = cd*v_rel
      if(mach > 1.0){
	cd = 2.0*v_rel;
      }else{
	//weidenschilling 1977
	if(re >= 800.0){
	  cd = 0.44*v_rel;
	}else if(re < 800.0 && re > 1.0){
	  cd = 24.0/pow(re,0.6)*v_rel;
	}else{
	  cd = 24.0*(v_the*lamg)/(4.0*Soft);	  
	}

	// Epstein's Law
	// If the criterion Soft = 9.0*lamg/4.0 is used, the jump in cd occurs for re > 1
	// We thus adopt the following form 	
	if(cd > 8.0/3.0*v_the)  cd = 8.0/3.0*v_the; 
	
	cd = 2.0*mach*mach*v_rel + (1.0-mach*mach)*cd;
      }
	
      cd = 0.5*cd*M_PI/Mass*Soft*Soft*rho; // St = omega/cd        
      p[i].St = omega/cd;
      p[i].hp = h*sqrt(alpha/(alpha+p[i].St)*0.5); // fac 0.5 added 042817     
      rhop = 3.0*Mass/(4.0*M_PI*Soft*Soft*Soft); //physical density

      // smin and mmin are not used at all..121117
      if(iPbGrow ==1 || iPbGrow ==3){ 
	smin = facrho*Sigma0*St_min/rhop*sqrt(8.0/M_PI); // particle size at St = St_min in Epstein's Law; sqrt factor added 121117
      }
      if(iPbGrow ==2 || iPbGrow ==4){ 
	smin = facrho*Sigma0*St_min*(r/aout)/rhop*sqrt(8.0/M_PI); // particle size constant; sqrt factor added 121117
      }
      
      /*double sfac = 3.0; 
      if((iPbGrow ==3 || iPbGrow ==4) && (r > dapin+1.0 && r > dapin+0.5)){
        smin = smin/sfac;
	}*/

      
      p[i].mmin = 4.0*M_PI*smin*smin*smin*rhop/3.0; // and mass

      
      if((iPbGrow ==1 || iPbGrow ==3) && p[i].iColor >= TRACER && p[i].St < St_min && p[i].iRung == 0 && mach < 1.0) { // mach < 1.0 is necessary to avoid growth of planetesimals with very large v_rel
	p[i].nump *= 0.5;	// We force the small particle to grow to keep their St larger than St_min. 111416

	
	if(p[i].nump < INT_MAX*1.0) p[i].nump = ((int)p[i].nump)*1.0;
	assert(p[i].nump >= 1.0);
	
	// if(p[i].iColor > TRACER)printf("ss St %e < St_min %e pid %i v_rel %g,v_the %g ,mach %g,re %g m %g r %g \n",p[i].St,St_min,p[i].iOrgIdx,v_rel,v_the,mach,re,Mass,Soft);    
	// if(2.0*Mass > mpebble && p[i].iColor == PEBBLE) p[i].iColor  = TRACER;
      }

      /*if(iPbGrow ==3 && p[i].St < 2.0 && p[i].iColor >= TRACER && p[i].iRung == 0 && mach < 1.0) { 
	if(r > dapin+1.0){ //outside the sinterin 
	  if(p[i].St < St_min) p[i].nump *= 0.5;
	}else{// in the sintering zone
	   if(p[i].St < St_min/sfac) p[i].nump *= 0.5; 	  // factor 3 after Okuzumi et al. (2015)
	   // if(p[i].St > St_min) p[i].nump *= 64.0; // = 4^3 this is supposed to occur when entering the sintering zone for the first time
	   if(p[i].St > 1.26*St_min/sfac) p[i].nump *= 1.01; // 2^(1/3)	  
	}
	if(p[i].nump < INT_MAX*1.0) p[i].nump = ((int)p[i].nump)*1.0;
	assert(p[i].nump >= 1.0);
	}*/

      /* if(iPbGrow ==4 && p[i].St < 2.0 && p[i].iColor >= TRACER && p[i].iRung == 0 && mach < 1.0) {	
	 if(r < dapin+1.0 && r > dapin+0.5){ //size change in a limited zone	
	  if(p[i].St > St_min*(r/30.0)/sfac) p[i].nump *= 1.01; // 2^(1/3)
	  if(p[i].nump < INT_MAX*1.0) p[i].nump = ((int)p[i].nump)*1.0;
	  assert(p[i].nump >= 1.0);
	}	
	}*/

      if(fabs(cd*v_rel_x) > 1.0/r || fabs(cd*v_rel_y) > 1.0/r || fabs(cd*v_rel_z) > 1.0/r){

	printf("in pkdGasAccel time %e yr, oid=%d, col = %d, rung = %d,r = %e, (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), m = %g, rad %g, cd %g, rho %g, v_rel (%g %g %g) \n",dTime/(2.0*M_PI),p[i].iOrgIdx,p[i].iColor,p[i].iRung,r,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],Mass,Soft,cd,rho,v_rel_x,v_rel_y,v_rel_z);
	printf("Most likely, the time step is too large or Stokes number (or particle size) is too low \n");
	
	//assert(0);
	// test:  absolute accelearation does not exceed solar gravity ...
	re = fabs(cd*v_rel_x);
	if(fabs(cd*v_rel_y) > re) re = fabs(cd*v_rel_y);
	if(fabs(cd*v_rel_z) > re) re = fabs(cd*v_rel_z);
	cd = cd/(re*r);
	}
    
      a_x += - cd*v_rel_x;
      a_y += - cd*v_rel_y;
      a_z += - cd*v_rel_z;

      if(fabs(a_x) < 100.0 && fabs(a_y) < 100.0 && fabs(a_z) < 100.0){
      }else{
	printf("in gasaccel b oid=%d, col = %d, rung = %d (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), (ax,ay,az) = (%e,%e,%e), m = %e cd = %e v_gas = %e vtur = (%e %e %e)\n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],a_x,a_y,a_z,p[i].fMass,cd,v_gas,p[i].vtur[0],p[i].vtur[1],p[i].vtur[2]);	
	assert(0);
      }
      
      if(p[i].iColor != TEST && Mass > 1.e-15){
      /* (3) tidal damping */
      /* Type I migration 
	 GP->iTypeI 
	 1: Isothermal, Tanaka et al. 2002
	 2: Adiabatic, Paardekooper et al. 2010 
	 3: Optical depth dependent model (1 and 2), Lyra et al. 2010
       */

      /* Damping is from Tanaka and Ward (2004) */
      /* correction factors due to finite e and i are from Larwood and 
	 Papaloizou (2000): see also Creswill et al. (2007) */ 
   
      /*v_rel_x =  v_x + v_kep*y/r;
	v_rel_y =  v_y - v_kep*x/r;
	v_rel_z =  v_z;
	
	v_rel_r = (x*v_rel_x + y*v_rel_y)/r;
	v_rel_th = (x*v_rel_y - y*v_rel_x)/r;*/
		
	rh2 = r*r/(h*h);
	aeh = 0.5*p[i].ele[0]*sqrt(p[i].ele[1]+p[i].ele[2])/h; 
	
	/* factor 0.5 is necessary to avoid outward migration,
	   which is not observed in Creswell et al 2007*/
	
	aeh3 = aeh*aeh*aeh;
	tau_mig_in = Mass*(Sigma*r*r*M_PI)*rh2*omega; /* Changed to ta of Papaloizou and Larwood (2000)*/ // 
	tau_wave_in = tau_mig_in*rh2/(1.0+0.25*aeh3);
	if(tau_wave_in > 1./(2.e3*M_PI))tau_wave_in = 1./(2.e3*M_PI); 

	if(GP->iTypeI && (Mass < Mgiant)){
	  //if(GP->bDragEnhance == 0 || (GP->bDragEnhance = 1 && (Mass > Mp1))){
	    fiso = 1.364+0.541*Gasp; /* Tanaka et al. 2002*/
	    Gasen = Gasq-(Gamma-1.0)*Gasp;
	    fadi = ((0.85 + Gasp + 1.7*Gasq) -7.9*Gasen/Gamma)/Gamma; /*Paardekooper et al. 2010a (no saturation of corotation)*/
	    
	    switch (GP->iTypeI){
	    case 1: ftor = fiso;
	      break;
	    case 2: ftor = fadi; 
	      break;
	    case 3: taur = 4.677E3/fsig*Sigma*Sigma*Kappa*omega/(Temp*Temp*Temp); 
	      /*fac = 3*cv/64/pi/sigma_SB = 4.677E3/fsig, cv = 2.5R/mu mu = 2.33gmol^-1 */
	      ftor = (fadi*taur*taur+fiso)/(taur+1.0)/(taur+1.0);
	      break;
	    case 5:
	      ftor = fiso*tanh(p[i].ele[0]-GP->rcon);	   
	      break;
	    }
	    /*tau_mig_in *= 2.0*GP->fTI*ftor*(1.0-0.683*aeh3*aeh)/(1.0+0.269329*aeh3*aeh*aeh);	
	      a_th += -0.5*tau_mig_in*v_kep;*/
	    /* changed to Papaloizou and Larwood*/

	      tau_mig_in *= GP->fTI*ftor*(1.0-0.683*aeh3*aeh)/(1.0+0.269329*aeh3*aeh*aeh);
	
	      a_x += -tau_mig_in*v_x;
	      a_y += -tau_mig_in*v_y;
	      a_z += -tau_mig_in*v_z;
	      //}
	}

	/*a_r  += (0.104*v_rel_th + 0.176*v_rel_r)*tau_wave_in;
	a_th += (-1.736*v_rel_th + 0.325*v_rel_r)*tau_wave_in;
	a_z  += (-1.088*v_rel_z -0.871*v_kep*z/r)*tau_wave_in;*/
	
	a_x  += -2.0*rv*x*tau_wave_in;
	a_y  += -2.0*rv*y*tau_wave_in;
	a_z  += -2.0*(rv*z + v_z)*tau_wave_in;

   if(fabs(a_x) < 100.0 && fabs(a_y) < 100.0 && fabs(a_z) < 100.0){
      }else{
	printf("in gasaccel c oid=%d, col = %d, rung = %d (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), (ax,ay,az) = (%e,%e,%e), m = %e cd = %e v_gas = %e vtur = (%e %e %e)\n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],a_x,a_y,a_z,p[i].fMass,cd,v_gas,p[i].vtur[0],p[i].vtur[1],p[i].vtur[2]);	
	assert(0);
      }

	
      }
      
      
      /* convert r, th --> x, y */
      a_x +=  (x*a_r - y*a_th)/r; 
      a_y +=  (y*a_r + x*a_th)/r; 
      if(iRung ==0){
	p[i].a[0] += a_x;
	p[i].a[1] += a_y;
	p[i].a[2] += a_z;
      }else{
	p[i].a_VA[0] += a_x;
	p[i].a_VA[1] += a_y;
	p[i].a_VA[2] += a_z;
      }
      /* energy change due to gas*/ 
      
      dv_x = a_x*dDelta;
      dv_y = a_y*dDelta;
      dv_z = a_z*dDelta;
      
      dv_x *= v_x+0.5*dv_x;
      dv_y *= v_y+0.5*dv_y;
      dv_z *= v_z+0.5*dv_z;
      
      *dT += (p[i].fMass*(dv_x+dv_y+dv_z))*2.0; /* 2.0 for another half step*/
      

      
  }
  /*printf("dEgas %e \n", *dT);*/
  
}

#ifdef gastable
void pkdGasTable(PKD pkd, GASDISK_TABLE GD){
  if(pkd->param.GP.iGasTable == 1){ /* Uniform */ 
    pkd->GD0 = GD;
  }else{
    if(&pkd->GD1)pkd->GD0 = pkd->GD1;
    if(&GD) pkd->GD1 = GD;  
  }
  
  /* printf("time0 %e, ar15 %e az15 %e \n",pkd->GD0.dTime,pkd->GD0.ar[15][15],pkd->GD0.az[15][15]);
     printf("time1 %e, ar15 %e az15 %e \n",pkd->GD1.dTime,pkd->GD1.ar[15][15],pkd->GD1.az[15][15]);*/
  
}
#endif

#ifdef gaptable
void pkdGapTable(PKD pkd, GAP_TABLE GT){
  pkd->GT = GT;  
}
#endif

void pkdGetGasDisk(PKD pkd, GASDISK_PARAMS * GP, double t, double r, double omega, double depfac, double rin, double rout, double *rij, double *fSigma, double *fTemp, double * pSigma, double * pSigma0, double * pGasp, double * pTemp, double * pGasq, double * ph, double * pKappa){
  
  double Sigma, Sigma0, Temp, Gasp, Gasq, h, Kappa;
  double r0, r1, rm, r2;
  /* Sigma and Kappa are first given in units of gcm^-2 and g^-1cm2 then convert to non-dimensional values */
#ifdef gaptable
  GAP_TABLE GT = pkd->GT;
#endif
  int k;

  int iGasModel = GP->iGasModel;
  switch (iGasModel){
  case 1: /* Single power-law model, uniform dissipation */
    Gasp = GP->dGasp;
    Gasq = GP->dGasq;
    Sigma = GP->dSigma10*depfac*pow(r,-Gasp);
    Temp = GP->dTemp1*pow(r,-Gasq);
    Kappa = 0.0; /* optically thin disk */
    break;
  case 2: /* Single power-law model, inside-out dissipation */ 
    Gasp = GP->dGasp;
    Gasq = GP->dGasq;
    Sigma = GP->dSigma10*pow(r,-Gasp); 
    Temp = GP->dTemp1*pow(r,-Gasq); 
    Kappa = 0.0; /* optically thin disk */
    break;
  case 3: /* Stepinski's disk model */
    if(r > rij[0]){/* MOTOR */
      Gasp = 6.0/5.0;
      Gasq = 3.0/10.0;
      Sigma = fSigma[0]*pow(r,-Gasp);
      Temp = fTemp[0]*pow(r,-Gasq);
      Kappa = 2.E-4*Temp*Temp;
    }else if (r <= rij[0] && r > rij[1]){/* IGOR */
      Gasp = 0.0;
      Gasq = 3.0/2.0;
      Sigma = fSigma[1];
      Temp = fTemp[1]*pow(r,-Gasq);
      Kappa = 2.E-4*Temp*Temp;
    }else if (r <= rij[1] && r > rij[2]){/* IGSOR */
      Gasp = 15.0/13.0;
      Gasq = 9.0/26.0;
      Sigma = fSigma[2]*pow(r,-Gasp);
      Temp = fTemp[2]*pow(r,-Gasq);
      Kappa = 1.15E18*pow(Temp, -8.0);
    }else if (r <= rij[2] && r > rij[3]){/* SIGOR */
      Gasp = 15.0/34.0;
      Gasq = 18.0/17.0;
      Sigma = fSigma[3]*pow(r,-Gasp);
      Temp = fTemp[3]*pow(r,-Gasq);
      Kappa = 2.13E-2*pow(Temp, 3.0/4.0);
    }else if (r <= rij[3]){/* SIGSOR */
      Gasp = 24.0/19.0;
      Gasq = 9.0/38.0;
      Sigma = fSigma[4]*pow(r,-Gasp);
      Temp = fTemp[4]*pow(r,-Gasq);
      Kappa = 4.38E44*pow(Temp, -14.0);
    }
    break;
  case 4: /* User desined disk model*/
    /*printf("Make your own disk model here \n");
      assert(0);*/
   
    r0 = pkd->param.dain;
    r1 = pkd->param.daout;
    rm = 0.5*(r0+r1);
    Gasq = 0.5;
    Temp = GP->dTemp1*pow(r,-Gasq); 

    Sigma = GP->dSigma10*depfac/(rm*sqrt(rm)); 
    Gasp = -1.75; /* power for r0 < r < r1 */

    if(r < r0){
      Sigma *= pow((r0/rm),-Gasp);
      Gasp = -3.5;
      Sigma *= pow((r/r0),-Gasp);
    }else if (r >= r0 && r < r1){
      Sigma *= pow((r/rm),-Gasp);
    }else {
      Sigma *= pow((r1/rm),-Gasp);
      Gasp = 0.0;
      /* Sigma *= pow((r/r1),-Gasp);*/
    }
    break;
#ifdef gaptable
  case 5: /* use a gap table*/
    Gasp = GP->dGasp;
    assert(Gasp == 1.0);
    Gasq = GP->dGasq;
    Sigma = GP->dSigma10*depfac*pow(r,-Gasp);
    Temp = GP->dTemp1*pow(r,-Gasq);  
    r2 = r/aj*5.0;
    /* printf("aj %f \n",aj);*/
     k = (int)((r2-0.1)*50.0);
     if (k >= 0 && k <= 1744){     
      Gasp = ((GT.r[k+1]-r2)*GT.p[k] + (r2 - GT.r[k])*GT.p[k+1])*50.0;
      Sigma = Sigma*((GT.r[k+1]-r2)*GT.rsig[k] + (r2 - GT.r[k])*GT.rsig[k+1])*50.0;

      if(GT.r[k] < rin || GT.r[k] > rout){
	printf("r %f, r2, %f, Gasp %f, Sigma %f, k %d, GT.r[k] %f, GT.r[k+1] %f \n",r, r2,Gasp,Sigma,k,GT.r[k],GT.r[k+1]);

	for(k=0;k<1746;++k){
	  printf("k %d, r %f, rsig %f, p %f \n",k,GT.r[k],GT.rsig[k],GT.p[k]);
	}
      }


      }

    break;
#endif 
  }
 
  if(r < rin || r > rout){
    Sigma = 0.0;
  }else{
    Sigma *= fsig; /* convert units here*/ 
    Kappa /= fsig;
  }

  h = 0.0020056075*sqrt(Temp)/omega; /* mean molecular weight = 2.33 */

  Sigma0 = Sigma; // surface density without planetary gaps
  
  // surface density reduction due to gaps opened by planets Duffell (2015)
  // accurate for shallow gaps 
  
  int np,i;
  //double fgap,pgap,ap,kn1,kn2,dr2,dr,fmin,dr1,fgapi,pgapi;
  double fgap,pgap,ap,kn1,kn2,fmin,fgapi,pgapi,sqtau,sqsh,sqar;
  np = GP->npgap;
 
  // printf("np %d \n",np);

 if(np){
    fgap = 1.0;
    pgap = 0.0; // power law exponent of sigma (positive means sigma increases with decreasing r)
     for(i=0;i<np;++i){
       ap = GP->apgap[i];
       kn1 = GP->k1[i]; // k
       kn2 = GP->k2[i]; // sqrt(tau_sh)
       sqtau = 0.962754*pow(ap/h*fabs(r/ap-1.0),1.25); // sqrt(tau_r)
			   
       //  printf("get gas disk dr2 %g, kn1 %g, kn2 %g, ap %g \n",dr2,kn1,kn2,ap);
    
       fmin = 0.048*kn1/(1.0+0.048*kn1); // 1- sigmin/sig0
       sqar = sqrt(ap/r); 
       
       if(sqtau < kn2){ // in the gap bottom
	 fgapi = 1.0-fmin*sqar;
	 pgapi = -0.5*fmin*sqar/fgapi;
       }else{
	 fgapi = 1.0-fmin*sqar*kn2/sqtau;
	 pgapi = -0.5*fmin*sqar/fgapi*kn2/sqtau*(2.5/(r/ap-1.0)*r/ap+1.0);		   
       }	 
	 
       if(fgapi < fgap){
	 fgap = fgapi;
	 pgap = pgapi;	   
       }
	 
     }	 
      
     Sigma = fgap*Sigma0;
     Gasp = Gasp + pgap;
     
     //   if(fgap < 1.0){
     //      printf("get gas disk r = %g, Sigma = %g, Sigma0 = %g,Gasp = %g, Temp = %g, Gasq = %g, h = %g, Kappa = %g \n",r, Sigma, Sigma0, Gasp, Temp, Gasq, h, Kappa);
     // }
  }
 
   // surface density reduction due to gaps opened by planets Kanagawa et al. (2016)
 /*if(np){
    fgap = 1.0;
    pgap = 0.0; // power law exponent of sigma (positive means sigma increases with decreasing r)
     for(i=0;i<np;++i){
       ap = GP->apgap[i];
       kn1 = GP->k1[i]; // k
       kn2 = GP->k2[i]; // k'^(1/4)
       dr2 = 0.33*kn2*ap; // half width of gas reduced zone
       //  printf("get gas disk dr2 %g, kn1 %g, kn2 %g, ap %g \n",dr2,kn1,kn2,ap);
       dr = fabs(r-ap);
       fmin = 1.0/(1.0+0.04*kn1);
       if(fmin > 0.5)continue; // added 030117 as Kanagawa's formulation is not valid for low planets cases        
       if(dr < dr2){// in the gap	
	 dr1 = (0.25*fmin+0.08)*kn2*ap; // half width of the bottom
	 if(dr < dr1){
	   fgapi = fmin;
	   pgapi = 0.0;
	 }else{
	   fgapi = 4.0/kn2*dr/ap-0.32;
	   pgapi = 4.0/kn2*r/ap/fgapi;
	   if(r > ap)pgapi *= -1.0;
	 }
	 if(fgapi < fgap){
	   fgap = fgapi;
	   pgap = pgapi;	   
	 }
       }	 
     }     
     Sigma = fgap*Sigma0;
     Gasp = Gasp + pgap;
     
     //   if(fgap < 1.0){
     //      printf("get gas disk r = %g, Sigma = %g, Sigma0 = %g,Gasp = %g, Temp = %g, Gasq = %g, h = %g, Kappa = %g \n",r, Sigma, Sigma0, Gasp, Temp, Gasq, h, Kappa);
     // }
     }*/


  
  //
  
  *pSigma0 = Sigma0;
  *pSigma = Sigma;
  *pGasp = Gasp;
  *pTemp = Temp;
  *pGasq = Gasq;
  *ph = h;
  *pKappa = Kappa;
  /* printf("r = %g, Sigma = %g, Gasp = %g, Temp = %g, Gasq = %g, h = %g, Kappa = %g \n",r, Sigma, Gasp, Temp, Gasq, h, Kappa);*/
}

void pkdGravDirect(PKD pkd, int n){
  int i,j;
  PARTICLE *p; 
  double x,y,z,d2;
  double fourh2, dir, dir2;
  
#ifdef HERMITE	
  double vx,vy,vz,rv,dir5;
#endif
#ifdef SYMBA
  double a1,a2, a3, hill, rcrit;
  double vx,vy,vz,v2,costh,sincrit2;
#endif
  
  p = pkd->pStore;

  /* reset */
  for(i=0;i<n;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
#ifdef SYMBA
    p[i].drmin = 10000.0;
    p[i].drmin2 = 1000.0; /* we reset this here (used in smoothfcn.c)*/
    p[i].n_VA = 0; /* number of particles within 3 hill radius*/
#endif  
    p[i].fPot = 0;
    for(j=0;j<3;++j){ 
	p[i].a[j] = 0.0;
	}
  }

  for(i=0;i<n-1;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
   
    for(j=i+1;j<n;++j) {
      
      x = p[i].r[0] - p[j].r[0];
      y = p[i].r[1] - p[j].r[1];
      z = p[i].r[2] - p[j].r[2];
      d2 = x*x + y*y + z*z;
      	    
#ifdef HERMITE	   
      vx = p[i].v[0] - p[j].v[0];
      vy = p[i].v[1] - p[j].v[1];
      vz = p[i].v[2] - p[j].v[2];
      rv = x*vx + y*vy + z*vz;
#endif	
      
#ifdef SYMBA	  
      hill = p[i].hill + p[j].hill;	    	
      rcrit =  p[i].rcrit + p[j].rcrit;
   
      a3 = d2/(rcrit*rcrit);
      a1 = 1.0;

      if(p[i].iColor == TEST && p[j].iColor == TEST){
	/* mutual gravity is ignored if a2 < 10RSCALE hill*/
	if(a3 < RHSCALE2*10000.0){
	  a2 = sqrt(a3);
	  if(a2 > 100.0*RHSCALE*RSHELL){
	    a1 = symfac*(1.0-a2/(100.0*RHSCALE)); /*symfac is defined in pkd.h */ 
	    a1 *= a1*(2.0*a1 -3.0);
	    a1 += 1.0;
	  }else{ 
	    a1 = 0.0;		  
	  }
	}
	goto noencounter;
      }


      if(a3 < RHSCALE2){
	/*sincrit2 = FCRIT*hill*hill*RHSCALE2/d2; 
	  if(sincrit2 < 1.0){
	    vx = p[i].v[0] - p[j].v[0];
	    vy = p[i].v[1] - p[j].v[1];
	    vz = p[i].v[2] - p[j].v[2];
	    v2 = vx*vx + vy*vy + vz*vz;
	    costh = -(x*vx + y*vy + z*vz)/sqrt(v2*d2);  cos theta
	    if (costh < sqrt(1.0-sincrit2)){
	      a1 = 1.0;
	      goto noencounter;
	    }
	  }*/

	a2 = sqrt(a3);
	p[i].drmin = (a2 < p[i].drmin)?a2:p[i].drmin; 
	p[j].drmin = (a2 < p[j].drmin)?a2:p[j].drmin; 	    

	/* mod 042913 */
	if((p[i].fMass < p[j].fMass) || (p[i].fMass == p[j].fMass && p[i].iOrgIdx > p[j].iOrgIdx)){
	  p[i].iOrder_VA[p[i].n_VA] = p[j].iOrder;
	  p[i].n_VA++;
	}else{
	  p[j].iOrder_VA[p[j].n_VA] = p[i].iOrder;
	  p[j].n_VA++;
	}

	
	if(a2 > RHSCALE*RSHELL){
	  a1 = symfac*(1.0-a2/RHSCALE);
	  a1 *= a1*(2.0*a1 -3.0);
	  a1 += 1.0;		
	}else{ 
	  a1 = 0.0;		 
	}
      }	
      noencounter:
#endif 
      
#ifdef SOFTLINEAR
      fourh2 = p[i].fSoft + p[j].fSoft;
      if (p[i].iColor == TEST && p[j].iColor != TEST) fourh2 = p[j].fSoft;
      if (p[i].iColor != TEST && p[j].iColor == TEST) fourh2 = p[i].fSoft;
      fourh2*= fourh2;
#endif		    
        
      if(d2 < fourh2){
	if(pkd->param.bCollision){	
	  pkd->iCollisionflag = 1; /*this is for veryactivehermite */
	  p[i].iColflag = 1;
	  p[i].iOrderCol = p[j].iOrder;	    
	  p[i].dtCol = 1.0*p[i].iOrgIdx;
	  if (pkd->param.bVDetails) {
	    printf("dr = %e, r1+r2 = %e, pi = %i, pj = %i active-active \n",
		   sqrt(d2),sqrt(fourh2),p[i].iOrgIdx,p[j].iOrgIdx);  
	  }
	}
      }

      if (d2 < fourh2) {			 
	/*
	** This uses the Dehnen K1 kernel function now, it's fast!
	** (no more lookup tables)
	*/
	dir = 1/sqrt(d2);
	dir2 = dir*dir;
	d2 *= dir2;
	dir2 *= dir;
	d2 = 1 - d2;
	dir *= 1.0 + d2*(0.5 + d2*(3.0/8.0 + d2*(45.0/32.0)));
	dir2 *= 1.0 + d2*(1.5 + d2*(135.0/16.0));	 	
      }else {
	dir = 1/sqrt(d2); 
	dir2 = dir*dir*dir;
      }
      	
#ifdef SYMBA	  
      /*if(a3 < RHSCALE2) dir2 *= a1;*/
      if(a1 < 1.0) dir2 *= a1;
#endif
      p[i].fPot -= dir*p[j].fMass;
      p[i].a[0] -= x*dir2*p[j].fMass;
      p[i].a[1] -= y*dir2*p[j].fMass;
      p[i].a[2] -= z*dir2*p[j].fMass;
      p[j].fPot -= dir*p[i].fMass;
      p[j].a[0] += x*dir2*p[i].fMass;
      p[j].a[1] += y*dir2*p[i].fMass;
      p[j].a[2] += z*dir2*p[i].fMass;
      
#ifdef HERMITE	    
      dir5 = 3.0*rv*dir2*dir*dir;
      p[i].ad[0] -= (vx*dir2-x*dir5)*p[j].fMass;
      p[i].ad[1] -= (vy*dir2-y*dir5)*p[j].fMass;
      p[i].ad[2] -= (vz*dir2-z*dir5)*p[j].fMass;
      p[j].ad[0] += (vx*dir2-x*dir5)*p[i].fMass;
      p[j].ad[1] += (vy*dir2-y*dir5)*p[i].fMass;
      p[j].ad[2] += (vz*dir2-z*dir5)*p[i].fMass;
#endif
      
    }
  }
}

void pkdCorrectHelioDist(PKD pkd, int tag, double rd[3], double vd[3], double dSM, double *dT){
    /* tag == 1: corerction of heliocentric distances (and velocities for not SYMBA) 
       after a collision with the Sun
       tag == 2(SYMBA): corerction of baricentric velocities after an escape
  */

    PARTICLE *p;
    int i,j,n, r2;
 
    p = pkd->pStore;
    n = pkdLocal(pkd);
 
    *dT = 0.0;
    
    if(tag == 1){/* Collision with Sun */ 
      for (i=0;i<n;++i) {
	if(p[i].iOrder < 0) continue; 
	r2 = 0.0;
	for (j=0;j<3;++j){		
	  p[i].r[j] -= rd[j];
#ifndef SYMBA
	  p[i].v[j] -= vd[j];
#endif
	  r2 += p[i].r[j]*p[i].r[j];
	}
	*dT -= dSM*p[i].fMass/sqrt(r2); 
      }     
    }else if(tag == 2){ /* Escape: the follwoing routine is called only for SYMBA */
      for (i=0;i<n;++i) {
	for (j=0;j<3;++j){		
	  p[i].v[j] += vd[j];
	}
      } 	
    }else {
      assert(0);
    }    
}

#ifdef SYMBA
void
pkdStepVeryActiveSymba(PKD pkd, double dStep, double dTime, double dDelta,
		       int iRung, int iKickRung, int iRungVeryActive,
		       int iAdjust, double diCrit2,
		       int *pnMaxRung, double dSunMass, GASDISK_PARAMS * GP, int multiflag)
{
  int nRungCount[256];
  double dDriftFac;
  double ddDelta, ddStep;
  double dT; // return by gasaccel, not used
  /*double *rc = pkd->rc;*/

  if(iRung ==0) {
    /* get pointa of an interacting opponent from its iOrder
       multiflag > 0 if close encounters with more than 2 particles exist*/
      
      pkd->nVeryActive = pkdSortVA(pkd, iRung);   
      multiflag = pkdGetPointa(pkd);
    
      if(pkd->param.GP.bDragEnhance == 2){
	pkd->mf = multiflag;
	if (pkd->mf == 0) pkd->mf = 1;
	pkd->mf = pkd->mf+2; // we make two more spaces for add particle after collision 030117
	pkd->rc = malloc(sizeof(double *)*pkd->nVeryActive*pkd->mf);/* list for radius enhancement */
	pkdCalcrc(pkd,dTime,pkd->param.GP.bDragEnhance);
      }

      /* printf("Time %e, nVA %d,  multiflag %d \n",dTime, pkd->nVeryActive, multiflag);*/
  }
  if(iRung > 0){
    /* at iRung = 0 we just call pkdStepVeryActiveSymba three times*/  
    
    pkdActiveRung(pkd,iRung,1);
    if(iAdjust && (iRung < pkd->param.iMaxRung-1)) {       
      /* determine KickRung from current position */
	*pnMaxRung = pkdDrminToRungVA(pkd,iRung,pkd->param.iMaxRung,multiflag);	    
	if (pkd->param.bVDetails) {
	    printf("%*cAdjust, iRung: %d\n",2*iRung+2,' ',iRung);
	}
    }
    /*if(iAdjust == 0){*/
      /*if(iRung >= 2) pkdSortVA(pkd, iRung); maybe added later */
      pkdGravVA(pkd,iRung,0,iAdjust); /* 0 for no-collision check */	
      
      if (pkd->param.bVDetails) {
	    printf("%*cpkdGravVA, iRung: %d\n",2*iRung+2,' ',iRung);
	}
      
      
    /* following kick is for particles at p[i].iRung > iRung */     
    pkdKickVA(pkd,0.5*dDelta);  
    
    if (pkd->param.bVDetails) {
      printf("%*cVeryActive pkdKickOpen  at iRung: %d, 0.5*dDelta: %g\n",
	     2*iRung+2,' ',iRung,0.5*dDelta);
    } 
    
    /* if particles exist at the current iRung */
    pkdActiveRung(pkd,iRung,0); 
    pkdKeplerDrift(pkd,dDelta,dSunMass,1); /* 1 means VA */
     if (pkd->param.bVDetails) {
      printf("%*cVeryActive pkdKeplerDrift  at iRung: %d, 0.5*dDelta: %g\n",
	     2*iRung+2,' ',iRung,0.5*dDelta);
    }  
    /* if drmin druing drift is less than R_(iRung+1), 
       this interacting pair is sent to iRung + 1*/
     if(iRung < pkd->param.iMaxRung-1){
       if (pkd->param.bVDetails) printf("%*cVeryActive pkdcheckDrminVA starts  at iRung: %d, 0.5*dDelta: %g\n",
					2*iRung+2,' ',iRung,0.5*dDelta);
	 *pnMaxRung = pkdCheckDrminVA(pkd,iRung,multiflag,*pnMaxRung);
     }
       if (pkd->param.bVDetails)  printf("%*cVeryActive pkdcheckDrminVA  at iRung: %d, 0.5*dDelta: %g\n",
					   2*iRung+2,' ',iRung,0.5*dDelta);
  }	
  
  if (*pnMaxRung > iRung) {
	/*
	** Recurse.
	*/
    ddDelta = dDelta/3.0;
    /* ddStep = 1.0/pow(3.0, iRung); this is currently unnecessary */
    ddStep = 0;
    pkdStepVeryActiveSymba(pkd,dStep,dTime,ddDelta,iRung+1,iRung+1,iRungVeryActive,0,
			   diCrit2,pnMaxRung,dSunMass,GP,multiflag);
    dStep += ddStep;
    dTime += ddDelta;
    pkdActiveRung(pkd,iRung,0);
    pkdStepVeryActiveSymba(pkd,dStep,dTime,ddDelta,iRung+1,iRung+1,iRungVeryActive,1,
			   diCrit2,pnMaxRung,dSunMass,GP,multiflag);
    dStep += ddStep;
    dTime += ddDelta;
    pkdActiveRung(pkd,iRung,0);
    pkdStepVeryActiveSymba(pkd,dStep,dTime,ddDelta,iRung+1,iKickRung,iRungVeryActive,1,
			   diCrit2,pnMaxRung,dSunMass,GP,multiflag);
    
    /* move one time step back */
    dTime -= dDelta;			     	
  }
  if(iRung > 0){ 
    dTime += 0.5*dDelta;		
    
    if (pkd->param.bVDetails) {
      printf("%*cVeryActive pkdKickClose at iRung: %d, 0.5*dDelta: %g\n",
	     2*iRung+2,' ',iRung,0.5*dDelta);
    }
    
    /* Kick due to F_iRung for particles at the current or higher iRungs */		
    pkdActiveRung(pkd,iRung,1); 
    pkdGravVA(pkd,iRung,1,iAdjust); /* 1 for collision check */

    if(pkd->param.bCollision && pkd->iCollisionflag){
      pkdDoCollisionVeryActive(pkd,dTime);  
      pkdCalcHill(pkd, pkd->param.dDelta, 1); /* Hill radii need to be updated for bodies with many close encounters*/
      pkdGravVA(pkd,iRung,0,iAdjust);
    }

    if(pkd->param.GP.iGasModel && dTime < 15.0*(2.0*M_PI)*pkd->param.GP.dTau_diss){  	
      pkdGasAccel(pkd, dTime, dDelta, GP, &dT, iRung);
    }
    
    pkdKickVA(pkd,0.5*dDelta);
  }

  if(iRung ==0 && (pkd->param.GP.bDragEnhance == 2)){
    free(pkd->rc);
  }

 
}

int pkdSortVA(PKD pkd, int iRung){
  /* sort very active particles in order of pointer */
    int i,j,n;
    PARTICLE *p = pkd->pStore;
    PARTICLE t;
    n = pkd->nLocal;
    int nSort = 0;
   
    if(iRung == 0){
	i = 0;
    }else{
	i = n-(pkd->nVeryActive);
    }
    j = n - 1;

    while (i <= j) {
	if ( p[i].iRung <= iRung ) ++i;
	else break;
    }
    while (i <= j) {
	if ( p[j].iRung > iRung ) --j;
	else break;
    }

    if (i < j) {
	t = p[i];
	p[i] = p[j];
	p[j] = t;
	while (1) {
	    while ((p[++i].iRung <= iRung));
		   while (p[--j].iRung > iRung);
		   if (i < j) {
		       t = p[i];
		       p[i] = p[j];
		       p[j] = t;
		   }
		   else break;
		   }
	}
    nSort = n - i;
    return(nSort);     
}

void pkdCalcrc(PKD pkd, double dTime, int bDE){
  int i, j, k, n, iStart;
  double h, fen, m1, r1, m2, r2;
  PARTICLE *p;
  double *rc = pkd->rc;
  double rho2,a1,hill1,rho_neb,temp_neb,r_Bond,vr2,d;
  double w_neb,sig_t,sig_c,dmdt;
  double kappa = pkd->param.GP.dkappa;
  
  p = pkd->pStore;
  n = pkdLocal(pkd);
  iStart = n -  pkd->nVeryActive;
  int mf = pkd->mf;

  /* reset 
   */
  for(i=iStart;i<n;++i) {
    for(k=0;k<p[i].n_VA+2;k++){ // reset two more spaces for add particle after collision
      rc[(i-iStart)*mf+k] =  1.0;
    }    
  }

  for(i=iStart;i<n;++i) {
    if(pkdIsActive(pkd,&p[i]) == 0)continue;
  
    m2 = p[i].fMass/p[i].nump; 
    r2 = p[i].ele[8];
    rho2 = (3.0*m2)/(4.0*M_PI*r2*r2*r2);
    
    for(k=0;k<p[i].n_VA;k++){
      j = p[i].i_VA[k];
      assert(p[j].iColor <= SUBEMBRYO);
      if(pkd->param.iGravDirect != 7 && p[j].iColor > PLANETESIMAL)continue; //full embryos only, but direct collision with subembryos is allowed if iGravDirect == 7
      
      m1 = p[j].fMass;
      if(m1 < m2)continue;
      // if(m1 > Mgiant)continue;  

      h = p[j].ele[7];
      if(h <= 0.0) h = cbrt(m1/3.0);
      a1 = p[j].ele[5]; //120116
      hill1 = a1*h;
      r1 = p[j].fSoft;
      // rho1 = (3.0*m1)/(4.0*M_PI*r1*r1*r1);
      
      rho_neb = p[j].rho_neb;
      temp_neb = p[j].temp_neb;
      r_Bond = p[j].r_Bond;

      vr2 = (p[i].v[0]-p[j].v[0])*(p[i].v[0]-p[j].v[0])+(p[i].v[1]-p[j].v[1])*(p[i].v[1]-p[j].v[1])+(p[i].v[2]-p[j].v[2])*(p[i].v[2]-p[j].v[2]);
      d = (p[i].r[0]-p[j].r[0])*(p[i].r[0]-p[j].r[0])+(p[i].r[1]-p[j].r[1])*(p[i].r[1]-p[j].r[1])+(p[i].r[2]-p[j].r[2])*(p[i].r[2]-p[j].r[2]);
      d = sqrt(d);
      vr2 = vr2 - 2.0*m1/d; // relative velocity at infinity
      if(vr2 < 0.0) vr2 = 0.0;
      
      // Eq. 42 of Chambers 2006
      //fen = 24.0/(5.0*(p[i].ele[1] + p[j].ele[1]+p[i].ele[2] + p[j].ele[2])/h + 24.0); // 1/h is missing? 111516
      // fen = fatm*cbrt(fen*p[i].ele[0]*h*r1/r2*m1*dTime); /* we use dM/dt = M/t */

      // Ormel and Kobayashi (2012)
      
      dmdt = p[j].dmdt;
      if(p[j].dmdt < 0.0)dmdt = m1/dTime;
      // if(p[j].dmdt > 0.0) {
      // 	printf("particle %d colorj %d idx %d fen %g w_neb %g sig_t %g sig_c %g rho_neb %g temp_neb %g dmdt %g %g \n",j, p[j].iColor,p[j].iOrgIdx,fen,w_neb,sig_t,sig_c,p[j].rho_neb,temp_neb,p[j].dmdt,m1/dTime);
      // }
	
      w_neb = wfac*kappa*rho_neb*dmdt/(r1*temp_neb*temp_neb*temp_neb); // thier Eq.(22) and (23) 
      sig_t = 0.2/w_neb; // atmosphere density at transition from isothermal to pressure dominant regimes 
      sig_c = (2.0/3.0)*r2/hill1*(1.0+vr2/(2.0*m1/hill1))*rho2/rho_neb; // critical gas density necessary for capture

      if(sig_c < sig_t){
	fen = 1.0 + (2.0*w_neb*(sig_c - 1.0) +log(sig_c))/1.4;
      }else{
	fen = 1.0 + (2.0*w_neb*(sig_t - 1.0) +log(sig_t))/1.4 + 4.0/1.4*cbrt(4.0*w_neb)*(cbrt(sig_c)-cbrt(sig_t)); // sig_c and sig_t were in incorrect order and replaced 120816
      }

      if(fen < 1.0) fen = 1.0; // collsional radius does not exceed Bondi radius
      
      fen = r_Bond/r1/fen;
         
      if(r1*fen > 0.25*hill1)fen = 0.25*hill1/r1; // atmosphere radius does not exceed 0.25 of Hill radius
      
      if(fen < 1.0) fen = 1.0; // collsional radius is not smaller than the geometric radius
      
      rc[(i - iStart)*mf+k] =  fen; 
  
     
      
    }
  }
}

void pkdGravVA(PKD pkd, int iRung, int iColCheck, int iAdjust){
  int i, j, k, n, iStart;
    double x, y, z;
    double x0, y0, z0;
    double fac, d2, d1,d1n;
    PARTICLE *p;
    double r_k = RHSCALE*pow(RSHELL,iRung-1);
    double r_kk = r_k*RSHELL;
    double r_kkk = r_kk*RSHELL;
    double fourh2, dir2, dir, drmin, rcrit, Radj;
    double a, b, c, t, mr, mr0, hij;
    int mf = pkd->mf;
    double mi,ni,mj,nj;
    

    assert(iRung >= 1);
	
    p = pkd->pStore;
    n = pkdLocal(pkd);
    iStart = n - pkd->nVeryActive;
    
   
    /* reset */
    for(i=iStart;i<n;++i) {	
	if(pkdIsActive(pkd,&p[i])){
	    p[i].drmin = 1000.0;
	    for(k=0;k<3;k++){
		p[i].a_VA[k] = 0.0;
		p[i].a_VAs[k] = 0.0;
	    }
	}
    }
    
    for(i=iStart;i<n;++i) {	
	
      if(pkdIsActive(pkd,&p[i])){
	/* if(pkd->param.bVDetails) {
	   printf("particle %d rung %d n_VA %d\n",i, p[i].iRung,p[i].n_VA);
	   }*/
	
	for(k=0;k<p[i].n_VA;k++){
	  j = p[i].i_VA[k]; 
	  assert(pkdIsActive(pkd,&p[j])); // added 051214
	  /* assert(p[i].fMass < p[j].fMass || (p[i].fMass == p[j].fMass && p[i].iOrgIdx<p[j].iOrgIdx));
	     this condition is violated after a collision !!!
	   */

	  if (p[i].iColor == TRACER) assert(p[j].iColor != TRACER);
	  
	  if (p[i].iColor != TEST && p[j].iColor == TEST) {
	    printf("Test particle heavier than the planet? \n");
	    assert(0); 
	  }

	  /* after three body encounter and a collision 
	     we sometimes obtain i<j, p[i].iOrder = p[j].iOrder*/		  
	  x = p[i].r[0] - p[j].r[0];
	  y = p[i].r[1] - p[j].r[1];
	  z = p[i].r[2] - p[j].r[2];
	  d2 = x*x + y*y +z*z;
	  d1 = sqrt(d2);
	  rcrit = p[i].rcrit+p[j].rcrit;
	  if(d1 > r_k*rcrit) continue;
	 	 	 	 
	  // sum of radii are necessary to be used when the tracer's orbit is inside the subembryo
	  fourh2 = p[i].fSoft + p[j].fSoft;
	  if(p[i].iColor > SUBEMBRYO) fourh2 = p[i].ele[8] + p[j].fSoft;
	  	  		 
	  if (d1 > fourh2) {	     
	    dir2 = 1.0/(d1*d1*d1);
	    dir = 1.0/d1;
	  }else {		
	    
	    //** This uses the Dehnen K1 kernel function now, it's fast!	     	
	    dir = 1.0/fourh2; 
	    dir2 = dir*dir;
	    d2 *= dir2;
	    dir2 *= dir;	     
	    d2 = 1.0 - d2;
	    dir *= 1.0 + d2*(0.5 + d2*(3.0/8.0 + d2*(45.0/32.0)));
	    dir2 *= 1.0 + d2*(1.5 + d2*(135.0/16.0));	    	    
	  }
	    		  
	    // dir2 = 1.0/(d1*d2);
	    d1n = d1/rcrit; /* distance normalized by rcrit */ 		
	    
	    if (d1n < r_kk && d1n >=r_kkk){
	      fac = symfac*(1.0-d1n/r_kk);
	      fac *= fac*(2.0*fac -3.0);
	      fac += 1.0;
	    }else if (d1n < r_k && d1n >=r_kk){
	      fac = symfac*(1.0-d1n/r_k);
	      fac *= -fac*(2.0*fac -3.0);
	    } else {
	      fac= 0.0;		  
	    }
	    
	    // avoid too low drmin for subembryo-tracer encounters
	    if(d1n > 0.5*fourh2/rcrit){
	      p[i].drmin = (d1 < p[i].drmin)?d1n:p[i].drmin; 
	      p[j].drmin = (d1 < p[j].drmin)?d1n:p[j].drmin; 
	    }else{
	      p[i].drmin = 0.5*fourh2/rcrit;
	      p[j].drmin = 0.5*fourh2/rcrit;		
	    }
	    	    
	    dir2 *= fac;
	 
	    /*printf("iOrder %d %d, d2 %e iRung %d\n",
	      p[i].iOrder,p[j].iOrder,d2,iRung);*/

	    if(p[i].iColor < SUBEMBRYO){
	      nj = 1.0;
	    }else{
	      nj = p[j].nump;	   
	    }	  
	    //  nj = 1.0;//test

	    mj = dir2*p[j].fMass/nj;

	    // if(d1*rcrit <  3.0*p[i].hill){
	      p[i].a_VAs[0] -= x*mj*(nj-1.0);
	      p[i].a_VAs[1] -= y*mj*(nj-1.0);
	      p[i].a_VAs[2] -= z*mj*(nj-1.0);
	      // }

	    p[i].a_VA[0] -= x*mj;
	    p[i].a_VA[1] -= y*mj;
	    p[i].a_VA[2] -= z*mj;

	    if(p[j].iColor < SUBEMBRYO){
	      ni = 1.0;
	    }else{
	      ni = p[i].nump;
	    }
	    // ni = 1.0;//test

	    mi = dir2*p[i].fMass/ni;

	    // if(d1*rcrit <  3.0*p[j].hill){
	      p[j].a_VAs[0] += x*mi*(ni-1.0);
	      p[j].a_VAs[1] += y*mi*(ni-1.0);
	      p[j].a_VAs[2] += z*mi*(ni-1.0);	
	      // }

	    p[j].a_VA[0] += x*mi;
	    p[j].a_VA[1] += y*mi;
	    p[j].a_VA[2] += z*mi;

	    fac = 1.0;
	  if(pkd->param.bCollision && iColCheck && (iRung >= 1)){

	    // now we check binaries in all the substeps 112816
	    if((p[i].iColor <= SUBEMBRYO || p[j].iColor <= SUBEMBRYO)){
	      a = 0.5*(p[i].ele[5]+p[j].ele[5]); // use r (2d) instead of a 120116
	      	  
	      // For sub-embryo tracer interactions, tracer behaves as a constituent planetesimal
	      // For interaction with full-embryo, tracer behaves as a single partile with the tracer mass
	      mr = p[i].fMass/p[j].fMass;
	    
	      if(p[i].iColor >= TRACER && p[j].iColor == SUBEMBRYO) mr = (p[i].fMass/p[i].nump)/p[j].fMass;
	      
	      hij = p[j].hill/p[j].ele[0];
	      
	      mr0 = mr; /* mass ratio <= 1.0 */
	      if(mr0 > 0.333) mr = 0.5*(mr-1.0);
	      mr = 1.0 + 1.0/3.0*mr*(1.0 - 1.0/3.0*mr*(1.0-5.0/9.0*mr*(1.0-2.0/3.0*mr*(1.0-11.0/15.0*mr*(1.0-7.0/9.0*mr*(1.0-17.0/21.0*mr*(1.0-5.0/6.0*mr)))))));
	      if(mr0 > 0.333) mr *= cbr2;
	      hij *= mr;
	      
	      b = a*hij;
	      	      
	      if(d1 < 0.1*b){ // 0.1 test 110516
		x0 = p[i].v[0] - p[j].v[0];
		y0 = p[i].v[1] - p[j].v[1];
		z0 = p[i].v[2] - p[j].v[2];
		x0 = x0*x0 + y0*y0 +z0*z0;		       
		c = 0.5*(x0*(a*a*a)-3.0*x*x+z*z)/(b*b) -3.0*b*dir + 9.0/2.0;	/* Hill energy; dir = 1.0/d1 if d1 > fourh2 */
	
		if(c < -3.0){ /* just to avoid temporary capture, changed to -0.1 to -1.0 110516*/
		  printf("binary detected; i %d j %d inVA %d, jnVA %d icolor %d jcolor %d\n",i, j, p[i].n_VA, p[j].n_VA,p[i].iColor,p[j].iColor);
		  printf("E %e  K %e U %e d/rhill %g \n", c, 0.5*x0*(a*a*a)/(b*b), c-0.5*x0*(a*a*a)/(b*b),d1/b);
		  goto collision;
		}
			
		
	      }
	    }

	    if(pkd->param.iGravDirect != 7){  // no statistical treat ment subembryo-tracer collision if iGravDirect != 7 112816
	      if((p[j].iColor == SUBEMBRYO && p[i].iColor > SUBEMBRYO)||(p[i].iColor == SUBEMBRYO && p[j].iColor > SUBEMBRYO)){
		goto enStep; // collisions are handled in statistical routine in smoothfnc.c
	      }
	    }
	    
	    fac = 1.0;
	  if((pkd->param.GP.bDragEnhance == 2) && p[j].iColor <= SUBEMBRYO){ // radius enhancement due to atmosphere for full embryo
	    fac = pkd->rc[(i-iStart)*mf+k];
	    if(fac < 1.0 || fac > 1.e4){
	      // this seems to be related to three body encounters --> problem fixed on 030117
	      printf("fac < 1.0 or > 1.e4 !!!!!!!!!; fac %g i %d j %d inVA %d, jnVA %d icolor %d jcolor %d iid %d jid %d \n",fac,i, j, p[i].n_VA, p[j].n_VA,p[i].iColor,p[j].iColor,p[i].iOrgIdx,p[j].iOrgIdx);
	      //assert(fac >= 1.0);
	      fac = 1.0;
	    }	  
	  }	  
	  Radj = fac*p[j].fSoft;

	  fourh2 = p[i].fSoft + Radj;
	  //	  if((p[j].iColor == SUBEMBRYO && p[i].iColor > SUBEMBRYO)){
	  if(p[i].iColor > SUBEMBRYO) fourh2 = p[i].ele[8] + Radj;	    
	  
	  
	  if (p[i].iColor == TEST && p[j].iColor != TEST) fourh2 = Radj;
	  
	  //fourh2 *= fourh2;
	  
	  if (d1 < fourh2) {
	    drmin = d1;
	    goto collision;
	  }
	  /* linear interpolation */
	  x0 = p[i].rb[0] - p[j].rb[0];
	  y0 = p[i].rb[1] - p[j].rb[1];
	  z0 = p[i].rb[2] - p[j].rb[2];	      
	  a = x - x0;
	  b = y - y0;
	  c = z - z0;
	  t = -(a*x0+b*y0+c*z0)/(a*a+b*b+c*c);
	  if(t < 0 || t > 1) goto enStep; 
	  
	  /* calculate min. distance during drift */
	  a = a*t + x0; 
	  b = b*t + y0;
	  c = c*t + z0;
	  
	  drmin = a*a + b*b +c*c; 
	  // drmin = sqrt(drmin);
	  
	  if(drmin < fourh2*fourh2){
	    drmin = sqrt(drmin);
	    goto collision;
	  }else{
	    goto enStep; 
	  }
	  
	  collision:
	  pkd->iCollisionflag = 1;	 
	  p[i].iColflag = 2; // we use 2 instead of 1 072215
	  p[i].iOrderCol = p[j].iOrder;
	  p[i].dtCol = 1.0*p[i].iOrgIdx;

	   /* mod 071213 */
	  if((pkd->param.GP.bDragEnhance == 2) && p[j].iColor <= SUBEMBRYO){
	    p[i].ele[3] = fac;     
	    printf("at fac %e color_j %d color_i %d dmdt %g %g\n",fac,p[j].iColor,p[i].iColor,p[j].dmdt,p[j].fMass/p[j].dmdt/(2.0*M_PI));	
	    assert(fac >= 1.0);	
	  }	      
	  
	  if (pkd->param.bVDetails) {
	    printf("dr = %e, drmin = %e, r1+r2 = %e, pi = %i, pj = %i piRung %d iRung %d\n",
		   d1, drmin,fourh2,p[i].iOrgIdx,p[j].iOrgIdx, p[i].iRung, iRung);
	    printf("i %d j %d inVA %d, jnVA %d \n",i, j, p[i].n_VA, p[j].n_VA);
	  }
	  
	  } /* end collision */
	  
	enStep:
	  fac = 1.0; //dummy
	}
      }	         
    }
}

int pkdCheckDrminVA(PKD pkd, int iRung, int multiflag, int nMaxRung){
  int i, j, k, n, iStart, nloop;
  double x, y, z;
  double dr1;
  double x0, y0, z0, a, b, c, t;
  int iTempRung;
  PARTICLE *p;
  double r_k = RHSCALE*pow(RSHELL,iRung);
  int iupdate = 0;

  assert(iRung >= 1);
  p = pkd->pStore;
  n = pkdLocal(pkd);
  iStart = n - pkd->nVeryActive;
  
  for(i=iStart;i<n;++i) {	
    if(pkdIsActive(pkd,&p[i])){
  
      for(k=0;k<p[i].n_VA;k++){
	j = p[i].i_VA[k]; 
	/*assert(pkdIsActive(pkd,&p[j]));*/
	
	if(pkdIsActive(pkd,&p[j]) == 0){
	    printf("aaaa n %d nv %d piorder %d pj order %d pirung = %d, pjrung = %d, pinva = %d, pjnva = %d  icolor %i jcolor %i\n",
		   n, pkd->nVeryActive, p[i].iOrder, p[j].iOrder, p[i].iRung, p[j].iRung, p[i].n_VA, p[j].n_VA,p[i].iColor,p[j].iColor);

	    for(i=0;i<n;++i) {
	      if(p[i].iColor ==2){
		printf("aaaa i %d, iorder %d mass %e nva %d \n", i, p[i].iOrder, p[i].fMass,p[i].n_VA);
	      }
	    }
	  
	    assert(0);	    
	}

	
	  x = p[i].r[0] - p[j].r[0];
	  y = p[i].r[1] - p[j].r[1];
	  z = p[i].r[2] - p[j].r[2];
	  dr1 = x*x + y*y +z*z; 
	  dr1 = sqrt(dr1);
	  dr1/=  (p[i].rcrit+p[j].rcrit); /* distance normalized by rcrit */ 
	  
	  if(dr1 < r_k) goto iRungup;

	  /* linear interpolation between r and rb */
   	  x0 = p[i].rb[0] - p[j].rb[0];
	  y0 = p[i].rb[1] - p[j].rb[1];
	  z0 = p[i].rb[2] - p[j].rb[2];
	  
	  a = x - x0;
	  b = y - y0;
	  c = z - z0;
	  t = -(a*x0+b*y0+c*z0)/(a*a+b*b+c*c);
	  if(t < 0 || t > 1) goto enStep; 
	  
	  /* calculate min. distance during drift */
	  x = a*t + x0; 
	  y = b*t + y0;
	  z = c*t + z0;

	  dr1 = x*x + y*y +z*z; 
	  dr1 = sqrt(dr1);
	  dr1/= (p[i].rcrit+p[j].rcrit);  

	  if(dr1 < r_k){ 
	    goto iRungup;
	  }else{
	    goto enStep;
	  }
         
      iRungup:
	iupdate = 1;  

	p[i].iRungflag = 1;
	p[j].iRungflag = 1;
	
      enStep:
	continue;
	
      }
    } 
  }
 
  if(iupdate){
    nMaxRung = ((iRung+1) >= nMaxRung)?(iRung+1):nMaxRung;
    
    /* If a close encounter with more than 2 particles exists, we synchronize
       iRungs of interacting particles to the highest iRung in them */
    
    do{       
      nloop = 0;
      for(i=iStart;i<n;++i) {
	if(pkdIsActive(pkd,&p[i])){	  
	  for(k=0;k<p[i].n_VA;k++){	
	    j = p[i].i_VA[k];
	    if(p[i].iRungflag !=p[j].iRungflag){
	      nloop = 1;
	      if(p[i].iRungflag == 1)	p[j].iRungflag = 1;
	      if(p[j].iRungflag == 1)	p[i].iRungflag = 1;
	    }
	  }	  
	}
      }
    }while(nloop > 0);
    
    for(i=iStart;i<n;++i) {	
      if(pkdIsActive(pkd,&p[i]) && (p[i].iRungflag == 1)){
	p[i].iRung = iRung +1;
	p[i].iRungflag = 0;
	/* retrive */
	for(k=0;k<3;k++){
	  p[i].r[k] = p[i].rb[k];
	  p[i].v[k] = p[i].vb[k];
	} 
      }
    }
  }
  
  return(nMaxRung);
}

void pkdKickVA(PKD pkd, double dt){  
  int i, k, iStart;
  PARTICLE *p;
  double tx,ty,tz,lx,ly,lz;

  iStart = pkd->nLocal - pkd->nVeryActive;

  p = pkd->pStore;
  for(i=iStart;i<pkdLocal(pkd);++i) {	
    if(pkdIsActive(pkd,&p[i])){
      for(k=0;k<3;k++){
	p[i].v[k] += p[i].a_VA[k]*dt;	
      }

      /*if(p[i].iColor == SUBEMBRYO){
	p[i].dls +=   (p[i].r[0]*p[i].a_VAs[1] - p[i].r[1]*p[i].a_VAs[0])*dt;
	}*/

      // p[i].ae was incorrectly used instead of p[i].a_VA; corrected 072315 
      if(p[i].iColor == SUBEMBRYO && p[i].ae[2] != 0.0){
	tx =  (p[i].r[1]*p[i].a_VAs[2] - p[i].r[2]*p[i].a_VAs[1]);
	ty =  (p[i].r[2]*p[i].a_VAs[0] - p[i].r[0]*p[i].a_VAs[2]);
	tz =  (p[i].r[0]*p[i].a_VAs[1] - p[i].r[1]*p[i].a_VAs[0]);
	lx =  (p[i].r[1]*p[i].v[2] - p[i].r[2]*p[i].v[1]);
	ly =  (p[i].r[2]*p[i].v[0] - p[i].r[0]*p[i].v[2]);
	lz =  (p[i].r[0]*p[i].v[1] - p[i].r[1]*p[i].v[0]);	 
	tx = (tx*lx+ty*ly+tz*lz)/sqrt(lx*lx+ly*ly+lz*lz);

	p[i].dls +=  tx*dt;
      }


    }
  }
}


void pkdCalcHill(PKD pkd, double dDelta, int bIflag){  
  /* hill radius is the physical radius for a test particle */
  /* if the particle in a close enconter, we do not update hill radius,
   except the initial step */
 /* For Symba, below are orbital elements for democratic coordinate. 
    e2 happens to take a negative value (very rare)  */

  int i,j,n;
  PARTICLE *p; 
  p = pkd->pStore;
  double dSunMass = pkd->dSunMass;
  double r,r2,v2,summ,Etot,Lx,Ly,Lz,L2,hill,vrdt,a,e2,i2 ;
  n = pkdLocal(pkd); 

  for(i=0;i<n;++i) {
    /*assert(pkdIsActive(pkd,&p[i]));*/
    /*if(p[i].iColor == TEST)continue;*/ /*p[i].hill =p[i].crit = p[i].fSoft in pkdsymbainitit*/
    if(pkdIsActive(pkd,&p[i]) && (bIflag || p[i].iRung == 0)){

      r2 = 0.0;
      v2 = 0.0;
      for(j=0;j<3;j++){
	r2 += p[i].r[j]*p[i].r[j];
	v2 += p[i].v[j]*p[i].v[j];
      }
      r = sqrt(r2);
      summ = dSunMass+p[i].fMass;
      Etot = 0.5*v2 - summ/r;

      Lx = p[i].r[1]*p[i].v[2] - p[i].r[2]*p[i].v[1];
      Ly = p[i].r[2]*p[i].v[0] - p[i].r[0]*p[i].v[2];
      Lz = p[i].r[0]*p[i].v[1] - p[i].r[1]*p[i].v[0];

      L2 = Lx*Lx + Ly*Ly + Lz*Lz;
      
      a = -0.5*summ/Etot; 
      if(a < 0.0) a = r;
      p[i].ele[0] = a;	
     
      e2 =  1.0 - L2/(summ*a); /*e^2*/
      if(e2 < 0.0) e2 = 0.0;
      p[i].ele[1] = e2;
         
      i2 = 1.0 - Lz*Lz/L2; /*sin(I)^2*/
      if(i2 < 0.0) i2 = 0.0;
      p[i].ele[2] = i2;


      if(p[i].iColor == TEST){
	hill = p[i].fSoft;
      }else{	
	hill = r*cbrt(p[i].fMass/(3.0*dSunMass)); // a is replaced by r 120116
      } 

      //     if(p[i].fMass > Mgiant) hill /= RHSCALE; 110716
      p[i].hill = hill;

      //test 020217
      //if(p[i].St < 2.0) p[i].hill *= 10.0;
      
      vrdt = p[i].ele[1] + p[i].ele[2];
      if(vrdt > 1.0)vrdt = 1.0;
      /* multiply a factor to vrdt if necessary */
      vrdt = dDelta*sqrt(vrdt/r);
      
      vrdt /= RHSCALE;
      
      p[i].rcrit = (vrdt > hill)?vrdt:hill; 

      /* printf("iorder %d, a %e, r %e, ec2 %e, si2 %e, p[i].fMass %e r (%g %g %g) v (%g %g %g)\n",p[i].iOrder, a, r, p[i].ele[1], p[i].ele[2], p[i].fMass,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2]);*/


      /* temporarily remove
	 if(p[i].rcrit > 1.1){
	printf("rcrit %e, iorder %d, a %e, r %e, ec2 %e, si2 %e, p[i].fMass %e, dsunmass %e, v2 %e, dDelta %e, hill %e, hill2 %e \n",p[i].rcrit,p[i].iOrder, a, r, p[i].ele[1], p[i].ele[2], p[i].fMass,dSunMass,v2,dDelta,hill,vrdt);
	assert(0);
	}*/
    }  
  }
}

int pkdDrminToRung(PKD pkd, int iRung, int iMaxRung, int *nRungCount) {
    int i, j, iTempRung;;
    PARTICLE *p ;
    
    /* R_k = RHSCALE*(RSHELL)^(k-1) with (k= 1,2, ...)*/ 
    /* note iMaxRung = pkd.param->iMaxRung */
    for (i=0;i<iMaxRung;++i) nRungCount[i] = 0; 
    p = pkd->pStore;
    for(i=0;i<pkdLocal(pkd);++i) {
	if(pkdIsActive(pkd,&p[i])){
	    
	    iTempRung = iRung;
	    
	    if(p[i].drmin >  RHSCALE){
		if(p[i].drmin2 > RHSCALE){
		    iTempRung = 0;
		}else{
		    /* if min. dist. during drift is less than RHSCALE*rcrit, 
		       set iRung = 1 */ 
		    iTempRung = 1;
		}
	    }else{

	      iTempRung = floor(log(RHSCALE/p[i].drmin)/log(1.0/RSHELL)) + 1;
	      /* iTempRung =  (p[i].iRung + 1 <= iTempRung)?(p[i].iRung + 1):iTempRung;*/	    
	      if(iTempRung >= iMaxRung) iTempRung = iMaxRung-1; 
	      /* iTempRung = 1; This is simple but causes secular energy drift!!*/
		
	    }
	    
	    /* retrive positions and velocities of active particles to 
	       those before drift*/
	    if(iTempRung > 0){
		for(j=0;j<3;j++){
		    p[i].r[j] = p[i].rb[j];
		    p[i].v[j] = p[i].vb[j];
		}
	    }	

	    /*
	    ** Now produce a count of particles in rungs.
	    */
	    nRungCount[iTempRung] += 1;
	    p[i].iRung = iTempRung;
	    	 
	}
	
	/* printf("pkdDrmintoRung  p %i color %i rung %i nVA %i iorderva0 %i \n",p[i].iOrder,p[i].iColor,p[i].iRung,p[i].n_VA,p[i].iOrder_VA[0]);*/
    }
    iTempRung = iMaxRung-1;
    while (nRungCount[iTempRung] == 0 && iTempRung > 0) --iTempRung;
    return iTempRung;
}

int pkdGetPointa(PKD pkd){
    int i, j, k, n, iStart, iOrderTemp, n_VA;
    int multiflag = 0;
    int deleteflag = 0;
    int iTempRung, nloop;
    /* int bRung = 0;*/
    PARTICLE *p;
    char c;
    int iMaxRung = pkd->param.iMaxRung; 
    int nRungCount[iMaxRung-1];/* 1 to iMaxRung-1 */
    int find;

    p = pkd->pStore;
    n = pkdLocal(pkd);
    iStart = n - pkd->nVeryActive;
    
    /*if(bRung){
	for (i=1;i<iMaxRung;++i) nRungCount[i] = 0; 
	}*/
    
    if (pkd->param.bVDetails) printf("get pointa n = %d nv = %d \n",n,pkd->nVeryActive);

    for(i=iStart;i<n;++i) {
	getagain:
	if(!pkdIsActive(pkd,&p[i]))continue;
	/*if(bRung) nRungCount[p[i].iRung] += 1;*/
	n_VA = p[i].n_VA;      
	/*assert(n_VA >= 1); mod 042913 */
	assert(n_VA <= MAXn_VA);
	
	if(n_VA >= 2) multiflag = (multiflag < n_VA)?n_VA:multiflag; /* multiflag = largest n_VA */

	if (pkd->param.bVDetails) printf("%d  order %d  color %d \n",i,p[i].iOrder,p[i].iColor);
	for(k=0;k<n_VA;k++){
	    iOrderTemp = p[i].iOrder_VA[k];
	    find = 0;
	    for(j=iStart;j<n;++j) {
		if(i==j)continue;
		assert(p[j].iOrder != p[i].iOrder);
		if(p[j].iOrder == iOrderTemp){
		    p[i].i_VA[k] = j;
		    assert(j<n);
		    find = 1;
		    break;
		}
	    }
	    if(find ==0){
	      deleteflag = 1;
	     /* j is not active, we will delete pj from the list of pi.
		This seems to happen for large theta or small nSmooth.
		Is there a good way to activate non-active particles instead of deleting them?
		This is not easy in parallel runs.
	     */
		printf("delete pj, pi= %d, pj =%d, piorder =%d, pjorder =%d pihill =%e,pjhill =%e \n", i,j,p[i].iOrder,p[j].iOrder,p[i].hill,p[j].hill);
		
		p[i].n_VA --;
		/* if(p[i].n_VA == 0) p[i].iRung =0; mod 042913 */
	      
		while(k < p[i].n_VA){
		    p[i].i_VA[k] = p[i].i_VA[k+1];
		    p[i].iOrder_VA[k] = p[i].iOrder_VA[k+1];
		    k++;
		}
		goto getagain;
	    }
	    
	}    	
    }
    
    /*

    int k1, k2;
    for(i=0;i<n;++i) {
      //check if close encounters are not double counted
      if(p[i].n_VA > 1){
	for(k1=0;k1<p[i].n_VA-1;++k1){
	  for(k2=k1+1;k2<p[i].n_VA;++k2){
	    assert(p[i].iOrder_VA[k1] != p[i].iOrder_VA[k2]);
	  } 
	}
      }
      
      // check if interacting pair are not mutually included in the list
      if(p[i].n_VA > 0){
	for(k1=0;k1<p[i].n_VA;++k1){
	  j = p[i].i_VA[k1];
	  assert(p[i].n_VA+p[j].n_VA > 0);
	  for(k2=0;k2<p[j].n_VA;++k2){
	    assert(p[j].iOrder_VA[k2] != p[i].iOrder);
	    assert(p[i].iColor!=TRACER || p[j].iColor!=TRACER);	      	    
	  }
	}
      }
    } //iloop

    */
    



     /* check whether interacting particles are mutually included 
	in both the neighboring lists if using tree.  Missing happens for large theta    

	mod 042913 
	This procedure was omitted. Particles with Rung = 0 but in close encounters 
	are activated below.
     */
    

    /* If a close encounter with more than 2 particles exists, we synchronize
       iRungs of interacting particles to the highest iRung in them */
    
    do{  
      nloop = 0;
      for(i=iStart;i<n;++i) {
	assert(pkdIsActive(pkd,&p[i]));// brackets are replaced to assert 050114
	for(k=0;k<p[i].n_VA;k++){	  
	  j = p[i].i_VA[k];
	  assert(pkdIsActive(pkd,&p[j])); // brackets are replaced to assert 050114
	  if(p[j].iRung != p[i].iRung){
	    nloop = 1;
	    iTempRung = p[j].iRung;
	    p[i].iRung = (iTempRung >= p[i].iRung)?iTempRung:p[i].iRung;
	    p[j].iRung = p[i].iRung;
	  }	   
	}		  	
      }
    }while(nloop > 0);
    
    return(multiflag);
}

int pkdDrminToRungVA(PKD pkd, int iRung, int iMaxRung, int multiflag) {
    int i, j, k, n, iTempRung, iStart;
    int nMaxRung = 0; 
    PARTICLE *p;
    int nloop;
    /* note iMaxRung = pkd.param->iMaxRung -1 */
    
    int bRung = 0;
    char c;
    int nRungCount[iMaxRung-1];/* 1 to iMaxRung-1*/
    if(bRung){
	for (i=1;i<iMaxRung;++i) nRungCount[i] = 0; 
    }
    
    n = pkd->nLocal;
    iStart = n - pkd->nVeryActive;  
    p = pkd->pStore;
    
    for(i=iStart;i<n;++i) {      
      if(pkdIsActive(pkd,&p[i])){
	  	       	    	   	     
	iTempRung = floor(log(RHSCALE/p[i].drmin)/log(1.0/RSHELL)) + 1;     	  
	
	if(iTempRung >= iMaxRung) iTempRung = iMaxRung-1;
	if(iRung > iTempRung)iTempRung =iRung;
	
	/* iTempRung = (iTempRung >= 0)?iTempRung:0; 
	   p[i].iKickRung = iTempRung; */	    
	
	p[i].iRung = iTempRung;
	nMaxRung = (iTempRung >= nMaxRung)?iTempRung:nMaxRung; 
      }
      if(bRung) nRungCount[p[i].iRung] += 1;
    }
    
    if(bRung){
	printf("nVA %d iRung %d\n",pkd->nVeryActive, iRung);
	for (i=1;i<iMaxRung;++i){
	    if (nRungCount[i] == 0) continue;
	    else c = ' ';
	    printf(" %c rung:%d %d\n",c,i,nRungCount[i]);
	}
	printf("\n");
    }
    /* If a close encounter with more than 2 particles exists, we synchronize
       iRungs of interacting particles to the highest iRung in them */
 	
    do{     
      nloop = 0;
      for(i=iStart;i<n;++i) {
	if(pkdIsActive(pkd,&p[i])){		  	    
	  for(k=0;k<p[i].n_VA;k++){	
	    j = p[i].i_VA[k];
	    if(p[j].iRung != p[i].iRung){
	      nloop = 1;
	      iTempRung = p[j].iRung;
	      p[i].iRung = (iTempRung >= p[i].iRung)?iTempRung:p[i].iRung;
	      p[j].iRung = p[i].iRung;
	    }
	  }		    
	}
      }
    }while(nloop > 0);
    
    return(nMaxRung);
}


void pkdMomCent(PKD pkd,double momCent[],double *mCent){
    PARTICLE *p;
    int i,j,n;
    
    for (j=0;j<3;++j){                 
	momCent[j] = 0.0;
    }
    *mCent = 0.0;

    p = pkd->pStore;
    n = pkdLocal(pkd); 
    for (i=0;i<n;++i) {
      
	for (j=0;j<3;++j){ 
	    momCent[j] += p[i].fMass*p[i].v[j];     
	}   
	*mCent += p[i].fMass; 
    }   
} 

void pkdDriftSun(PKD pkd,double vSun[],double dt){
    PARTICLE *p;
    int i,j,n;
    
    p = pkd->pStore;
    n = pkdLocal(pkd); 
    for (i=0;i<n;++i) {
	for (j=0;j<3;++j){ 
	    p[i].r[j] -= vSun[j]*dt;     
	} 
    }
} 

void pkdHeltoDemo(PKD pkd,double vCent[]){
    PARTICLE *p;
    int i,j,n;
    
    p = pkd->pStore;
    n = pkdLocal(pkd); 
    for (i=0;i<n;++i) {
	for (j=0;j<3;++j){ 
	    p[i].v[j] -= vCent[j];     
	} 
    }
} 

void pkdDemotoHel(PKD pkd,double vSun[]){
    PARTICLE *p;
    int i,j,n;
    
    p = pkd->pStore;
    n = pkdLocal(pkd); 
    for (i=0;i<n;++i) {
	for (j=0;j<3;++j){ 
	    p[i].v[j] -= vSun[j];     
	} 
    }
} 


void pkdKeplerDrift(PKD pkd,double dt,double mu, int tag_VA) {
    /* 
     * Use the f and g functions to advance an unperturbed orbit.
     */
    PARTICLE *p;	
    int  i,j,n, iStart;
    int iflg = 0;
    double dttmp;
    mdlDiag(pkd->mdl, "Into pkdKeplerDrift \n");
    p = pkd->pStore;
    n = pkdLocal(pkd);
    
    if(tag_VA){
	iStart = pkd->nLocal - pkd->nVeryActive;
    }else{
	iStart = 0; 
    }
    
    for (i=iStart;i<n;++i) {	
	if (pkdIsActive(pkd,&p[i])&&(p[i].iOrder>=0)) {
	    
	    /* copy r and v before drift 
	       this is necessary as we determine the time step implicitly
	       this may be removed in future if we use an implicit time step size (Pelupessy et al. 2012)	       
	     */ 
	    for (j=0;j<3;++j) {	
		p[i].rb[j] = p[i].r[j];
		p[i].vb[j] = p[i].v[j];
	    }
            	    		    
	    iflg = drift_dan0(mu,p[i].r,p[i].v,dt);  /*see kepler.c */	 

	    if(iflg != 0){
	      printf("exit drift_dan, iflg = %d, oid=%d, col = %d, rung = %d, (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e),(ax,ay,az)= (%e,%e,%e), m = %e, mp = %e, ms =%e \n", iflg, p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].rb[0],p[i].rb[1],p[i].rb[2],p[i].vb[0],p[i].vb[1],p[i].vb[2],p[i].a[0],p[i].a[1],p[i].a[2],p[i].fMass,p[i].fMass/p[i].nump,mu);

	      printf("-1 oid=%d, col = %d, rung = %d, (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e),(ax,ay,az)= (%e,%e,%e), m = %e, mp = %e, ms =%e \n", p[i+1].iOrgIdx,p[i+1].iColor,p[i+1].iRung,p[i+1].rb[0],p[i+1].rb[1],p[i+1].rb[2],p[i+1].vb[0],p[i+1].vb[1],p[i+1].vb[2],p[i+1].a[0],p[i+1].a[1],p[i+1].a[2],p[i+1].fMass,p[i+1].fMass/p[i+1].nump,mu);	
	    }
	    assert(iflg == 0);	  
	    
	}
    }
}	

void pkdSymbaInitial(PKD pkd){
    PARTICLE *p;	
    int  i,n;
    p = pkd->pStore;
    n = pkdLocal(pkd);
    
    for (i=0;i<n;++i) {   
	p[i].iColflag = 0;
	p[i].iRungflag = 0;
	p[i].drmin = 10000.;
	p[i].drmin2 = 10000.;
	if(p[i].iColor == TEST){
	  p[i].hill = p[i].fSoft;
	  p[i].rcrit = p[i].fSoft;
	}
	/* used to check nSmooth for sm2d */
	p[i].vb[0] = 0.0;
	p[i].vb[1] = 0.0;

	// gas turblent velocity added 011417
	p[i].vtur[0] = 0.0;
	p[i].vtur[1] = 0.0;
	p[i].vtur[2] = 0.0;
    }    
}

void pkdSearchDirect(PKD pkd, int n){
  int i,j,k;
  PARTICLE *p; 
  p = pkd->pStore;
  double dDelta = pkd->param.dDelta;
  double dSunMass = pkd->dSunMass;
  
  double x0,y0,z0,x1,y1,z1,vx0,vy0,vz0,vx1,vy1,vz1;
  double dx0,dy0,dz0,dx1,dy1,dz1,dvx0,dvy0,dvz0,dvx1,dvy1,dvz1;
  double dr0,dr1,dv0,dv1;
  double a,b,c,d;
  double tmin,drmin,hill,rcrit;
  double v2,costh,sincrit2;
  
  for(i=0;i<n-1;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
    if(p[i].iColor == TEST)continue;
    x0 = p[i].rb[0];
    y0 = p[i].rb[1];
    z0 = p[i].rb[2];
    vx0 = p[i].vb[0];
    vy0 = p[i].vb[1];
    vz0 = p[i].vb[2];
    
    vx1 = p[i].v[0];
    vy1 = p[i].v[1];
    vz1 = p[i].v[2];
    
    for(j=i+1;j<n;++j) {
      
      /* check if particle pj is already in the list*/     
      if(p[i].n_VA > 0){
	for(k=0;k<p[i].n_VA;k++){
	  if(p[i].iOrder_VA[k] == p[j].iOrder){
	    goto enstep; 	      
	  }
	}
      }
      /* check if particle pi is already in the list*/     
      if(p[j].n_VA > 0){
	for(k=0;k<p[j].n_VA;k++){
	  if(p[j].iOrder_VA[k] == p[i].iOrder){
	    goto enstep; 	      
	  }
	}
      }

      rcrit = p[i].rcrit + p[j].rcrit;  
      dx1 = p[i].r[0] - p[j].r[0];
      dy1 = p[i].r[1] - p[j].r[1];
      dz1 = p[i].r[2] - p[j].r[2];
      dr1 = dx1*dx1 + dy1*dy1 + dz1*dz1;
      
      if(dr1 > 9.0*RHSCALE2*rcrit*rcrit) continue;

      hill = p[i].hill + p[j].hill;    
      dr1 = sqrt(dr1);
      dx0 = x0 - p[j].rb[0];
      dy0 = y0 - p[j].rb[1];
      dz0 = z0 - p[j].rb[2];
      dr0 = sqrt(dx0*dx0 + dy0*dy0 + dz0*dz0);
      
      dvx0 = vx0 - p[j].vb[0];
      dvy0 = vy0 - p[j].vb[1];
      dvz0 = vz0 - p[j].vb[2];
      dvx1 = vx1 - p[j].v[0];
      dvy1 = vy1 - p[j].v[1];
      dvz1 = vz1 - p[j].v[2];
      dv0 = (dvx0*dx0 + dvy0*dy0 + dvz0*dz0)/dr0; 
      dv1 = (dvx1*dx1 + dvy1*dy1 + dvz1*dz1)/dr1; 


      if(dr0 < RHSCALE*rcrit){ /* before encounter */
	sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr0*dr0); 
	  if(sincrit2 < 1.0){
	    v2 = dvx0*dvx0 + dvy0*dvy0 + dvz0*dvz0;
	    costh = -dv0/sqrt(v2); /* cos theta*/
	    if (costh < sqrt(1.0-sincrit2)){	   
	      goto enstep;
	    }
	  }
	drmin =  dr0;
	goto encounter;	
      }
      
       if(dr1 < RHSCALE*rcrit){/* after encounter */
	 sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr1*dr1); 
	  if(sincrit2 < 1.0){	   
	    v2 = dvx1*dvx1 + dvy1*dvy1 + dvz1*dvz1;
	    costh = dv1/sqrt(v2); /* cos theta*/
	    if (costh < sqrt(1.0-sincrit2)){	   
	      goto enstep;
	    }
	  }
	drmin =  dr1;
	goto encounter;	
      }
      
      a = 2.0*(dr0-dr1) + (dv0 + dv1)*dDelta;
      b = 3.0*(dr1-dr0) - (2.0*dv0 + dv1)*dDelta; 
      c = dv0*dDelta;
      d = 4.0*b*b -12.0*a*c; /* d =BB-4AC: A=3a, B=2b C=c */
      
      if(d < 0.0){      
	goto enstep; /* no encounter */
      }else{
	drmin = 100.0;
	tmin = (-4.0*b+sqrt(d))/(6.0*a);
	if((tmin > 0.0) && (tmin < 1.0)) drmin = ((a*tmin + b)*tmin + c)*tmin + dr0;
	
	if(drmin < RHSCALE*hill){ 	  
	  goto encounter;
	}else{	
	  goto enstep;
	}
      }      
    encounter:
      p[i].drmin2 = drmin/rcrit;
      p[j].drmin2 = drmin/rcrit;
      
      /* mod 042913 */
      if((p[i].fMass < p[j].fMass) || (p[i].fMass == p[j].fMass && p[i].iOrgIdx > p[j].iOrgIdx)){
	p[i].iOrder_VA[p[i].n_VA] = p[j].iOrder;
	p[i].n_VA++;
      }else{
	p[j].iOrder_VA[p[j].n_VA] = p[i].iOrder;
	p[j].n_VA++;
      }
      /*
      p[i].iOrder_VA[p[i].n_VA] = p[j].iOrder;
      p[i].n_VA++;
      p[j].iOrder_VA[p[j].n_VA] = p[i].iOrder;
      p[j].n_VA++;*/

      assert(p[i].iOrder != p[j].iOrder);

    enstep:
      continue;
    }   
  }
}

void pkdGetPlanets(PKD pkd,int *nPL,PARTICLE *pp){
  int i,n;
  PARTICLE *p; 
  p = pkd->pStore;
  n = pkdLocal(pkd);

  int nP = 0;
  /* pp = (PARTICLE *) malloc(MAX_nPL*sizeof(PARTICLE));*/

  for(i=0;i<n;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
    if(p[i].iColor <= SUBEMBRYO){/* planets are bodies with colors <= 5 */
   
      pp[nP] =  p[i];
      nP ++;   
      assert(nP <= MAX_nPL);
      /* printf("%i, n_VA %i \n",p[i].iOrder, p[i].n_VA);*/
    }
  }
  *nPL = nP;
 
}

void pkdHandPlanets(PKD pkd,int nPL,PARTICLE *pp){
  int i,n,j;
  PARTICLE *p; 

  p = pkd->pStore;
  n = pkdLocal(pkd);
  
  for(i=0;i<n;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
    if(p[i].iColor <= SUBEMBRYO){
      for(j=0; j<nPL; ++j){	
	if(pp[j].iOrder ==  p[i].iOrder){
	  p[i] = pp[j];
	}
      }
    }
  }

}


void pkdGravPlanets(PKD pkd,int nPL,PARTICLE *pp){
  int i,j,n;
  PARTICLE *p;
  double ax,ay,az,dx,dy,dz,dr,fPot;
  double a1,a2,a3,hill,rcrit;
  double vx,vy,vz,v2,costh,sincrit2;
  double mi,ni;

  p = pkd->pStore;
  n = pkdLocal(pkd);

  /* printf("GravPlanets the num of planets %i \n",nPL);*/


  /* reset gravity on planets*/
 for(j=0;j<nPL;++j){ 
   pp[j].a[0] = 0.0;
   pp[j].a[1] = 0.0;
   pp[j].a[2] = 0.0;
   pp[j].ae[0] = 0.0;
   pp[j].ae[1] = 0.0;
   pp[j].ae[2] = 0.0;
   pp[j].fPot = 0.0;
   pp[j].n_VA = 0;
   pp[j].drmin = 10000.0;
   pp[j].drmin2 = 10000.0;
   pp[j].a_pr = 0.0;
   /* printf("GravPlanets %i, r0 %e \n",pp[j].iOrder, pp[j].r[0]);*/
 }

 for(i=0;i<n;++i) {
   assert(pkdIsActive(pkd,&p[i]));
   if(p[i].nump < 1.0){
    printf("GravPlanets nump %g id %d io %d icol %d irung %d mi %g xyz %e %e %e \n",
	   p[i].nump,p[i].iOrder,p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].fMass,p[i].r[0],p[i].r[1],p[i].r[2]);
    assert(0);
   }
   /* test particles are reset here */
   ax = 0.0;
   ay = 0.0;
   az = 0.0;
   fPot = 0.0;
   p[i].n_VA = 0;
   p[i].drmin = 10000.0;
   p[i].drmin2 = 10000.0;
   p[i].a_pr = 0.0;
      
   for(j=0;j<nPL;++j){
     //test   if(pp[j].iColor == SUBEMBRYO && p[i].iColor > SUBEMBRYO)continue;
 
     if(pp[j].iOrder != p[i].iOrder){ 
       dx = p[i].r[0] - pp[j].r[0];
       dy = p[i].r[1] - pp[j].r[1];
       dz = p[i].r[2] - pp[j].r[2];
       dr = dx*dx + dy*dy + dz*dz;
       
       hill = p[i].hill + pp[j].hill;
       rcrit = p[i].rcrit + pp[j].rcrit;
       a3 = dr/(rcrit*rcrit);
       
       if(a3 < RHSCALE2){
	 /* sincrit2 = FCRIT*hill*hill*RHSCALE2/dr;
	 if(sincrit2 < 1.0){
	   vx = p[i].v[0] - pp[j].v[0];
 	   vy = p[i].v[1] - pp[j].v[1];
	   vz = p[i].v[2] - pp[j].v[2];
	   v2 = vx*vx + vy*vy + vz*vz;
	   costh = -(dx*vx + dy*vy + dz*vz)/sqrt(v2*dr);  cos theta
	   if (costh < sqrt(1.0-sincrit2)){
	     a1 = 1.0;
	     goto noencounter;
	   }
	 }*/
	 
	 a2 = sqrt(a3);

	 // avoid too low drmin for subembryo-tracer encounters
	 if(a2 > 0.5*pp[j].fSoft/rcrit){
	   p[i].drmin = (a2 < p[i].drmin)?a2:p[i].drmin; 
	   pp[j].drmin = (a2 < pp[j].drmin)?a2:pp[j].drmin; 
	 }else{
	   p[i].drmin = 0.5*pp[j].fSoft/rcrit; 
	   pp[j].drmin = 0.5*pp[j].fSoft/rcrit;
	 }
	 
	 
	 
	 /*mod 042913 additional mod 121116*/
	 if((p[i].iColor > pp[j].iColor) || (p[i].fMass < pp[j].fMass) || (p[i].fMass == pp[j].fMass && p[i].iOrgIdx > pp[j].iOrgIdx)){
	   p[i].iOrder_VA[p[i].n_VA] = pp[j].iOrder;
	   p[i].n_VA++;	  
	 }else{
	   pp[j].iOrder_VA[pp[j].n_VA] = p[i].iOrder;
	   pp[j].n_VA++;
	 }	    	      
	 
	 if(a2 > RHSCALE*RSHELL){
	   a1 = symfac*(1.0-a2/RHSCALE);
	   a1 *= a1*(2.0*a1 -3.0);
	   a1 += 1.0;		
	 }else{ 
	   a1 = 0.0;		 
	 }
       }
       
     noencounter:
       dr = 1.0/sqrt(dr);      
       fPot -= dr*pp[j].fMass;     
       dr = dr*dr*dr;
       if(a3 < RHSCALE2) dr *= a1;

       ax -= dx*dr*pp[j].fMass;
       ay -= dy*dr*pp[j].fMass;
       az -= dz*dr*pp[j].fMass; 

       /*       if(pp[j].iColor < SUBEMBRYO || (pp[j].iColor == SUBEMBRYO && p[i].iColor <= SUBEMBRYO)){
	 pp[j].a[0] += dx*dr*p[i].fMass;
	 pp[j].a[1] += dy*dr*p[i].fMass;
	 pp[j].a[2] += dz*dr*p[i].fMass;
	 pp[j].fPot -= dr*p[i].fMass;
       }
       if(pp[j].iColor == SUBEMBRYO && p[i].iColor > SUBEMBRYO){
	 pp[j].ae[0] += dx*dr*p[i].fMass;
	 pp[j].ae[1] += dy*dr*p[i].fMass;
	 pp[j].ae[2] += dz*dr*p[i].fMass;
	 } */

       if(pp[j].iColor < SUBEMBRYO){
	 ni = 1.0;
       }else{
	 ni =  p[i].nump;
       }
	 // ni = 1.0; //test

       mi = dr*p[i].fMass/ni;
   
       pp[j].a[0] += dx*mi;
       pp[j].a[1] += dy*mi;
       pp[j].a[2] += dz*mi;
       pp[j].fPot -= mi;

       // if(a2*rcrit<3.0*pp[j].hill){
	 pp[j].ae[0] += dx*mi*(ni-1.0);
	 pp[j].ae[1] += dy*mi*(ni-1.0);
	 pp[j].ae[2] += dz*mi*(ni-1.0);
	 //  }
	 
	 // assert(fabs(pp[j].ae[0]) < 100.0 && fabs(pp[j].ae[1]) < 100.0  && fabs(pp[j].ae[2]) < 100.0);
	 if(fabs(pp[j].ae[0]) < 100.0 && fabs(pp[j].ae[1]) < 100.0  && fabs(pp[j].ae[2]) < 100.0){
	 }else{
	   printf("GravPlanets id %d io %d icol %d irung %d mi %g xyz %e %e %e jd %d jo %d jcol %d jrung %d mj %g xyz %e %e %e \n",
		  p[i].iOrder,p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].fMass,p[i].r[0],p[i].r[1],p[i].r[2],pp[j].iOrder,pp[j].iOrgIdx,pp[j].iColor,pp[j].iRung,pp[j].fMass,pp[j].r[0],pp[j].r[1],pp[j].r[2]);
	   printf("mi %g ,ni %g \n",mi,ni);

	   
	   assert(0);
	 }
	 
     }

     
   } /* j loop */

   /* Following operations were placed wrongly inside the above bracket. Corrected on 10/17/13 */
   p[i].fPot = fPot;
   p[i].a[0] = ax;
   p[i].a[1] = ay;
   p[i].a[2] = az;
   assert(fabs(p[i].a[0]) < 100.0 && fabs(p[i].a[1]) < 100.0  && fabs(p[i].a[2]) < 100.0);
   
   if(ax != 0.0)p[i].a_pr = (p[i].a[0]*p[i].r[0] + p[i].a[1]*p[i].r[1]+p[i].a[2]*p[i].r[2])*sqrt(p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1]+ p[i].r[2]*p[i].r[2]);
   
     /* printf("GravPlanets %i, n_VA %i drmin %e drmin2 %e fPot %e \n",p[i].iOrder, p[i].n_VA,p[i].drmin,p[i].drmin2,p[i].fPot);*/

 }/* i loop */

 for(j=0;j<nPL;++j){
   if(pp[j].a[0] != 0){
     pp[j].a_pr = (pp[j].a[0]*pp[j].r[0] + pp[j].a[1]*pp[j].r[1]+pp[j].a[2]*pp[j].r[2])*sqrt(pp[j].r[0]*pp[j].r[0] + pp[j].r[1]*pp[j].r[1]+ pp[j].r[2]*pp[j].r[2]);
   }
 }
 
}

void pkdSearchPlanets(PKD pkd,int nPL,PARTICLE *pp){
  int i,j,k,n;
  PARTICLE *p; 
  p = pkd->pStore;
  n = pkdLocal(pkd);

  double dDelta = pkd->param.dDelta;
  double dSunMass = pkd->dSunMass;
  
  double x0,y0,z0,x1,y1,z1,vx0,vy0,vz0,vx1,vy1,vz1;
  double dx0,dy0,dz0,dx1,dy1,dz1,dvx0,dvy0,dvz0,dvx1,dvy1,dvz1;
  double dr0,dr1,dv0,dv1;
  double a,b,c,d;
  double tmin,drmin,hill,rcrit;
  double v2,costh,sincrit2;

  for(i=0;i<n;++i) {	
    x0 = p[i].rb[0];
    y0 = p[i].rb[1];
    z0 = p[i].rb[2];
    vx0 = p[i].vb[0];
    vy0 = p[i].vb[1];
    vz0 = p[i].vb[2];  
    vx1 = p[i].v[0];
    vy1 = p[i].v[1];
    vz1 = p[i].v[2];
    
    for(j=0;j<nPL;++j) {
      if(p[i].iOrder == pp[j].iOrder)continue;
      //test    if(pp[j].iColor == SUBEMBRYO && p[i].iColor > SUBEMBRYO)continue;

      /* check if particle pj is already in the list*/     
      if(p[i].n_VA > 0){
	for(k=0;k<p[i].n_VA;k++){
	  if(p[i].iOrder_VA[k] == pp[j].iOrder){
	    goto enstep; 	      
	  }
	}
      }
      /* check if particle pi is already in the list*/     
      if(pp[j].n_VA > 0){
	for(k=0;k<pp[j].n_VA;k++){ // p[j].n_VA --> pp[j].n_VA 050814 !
	  if(pp[j].iOrder_VA[k] == p[i].iOrder){
	    goto enstep; 	      
	  }
	}
      }

      rcrit = p[i].rcrit + pp[j].rcrit;  
      dx1 = p[i].r[0] - pp[j].r[0];
      dy1 = p[i].r[1] - pp[j].r[1];
      dz1 = p[i].r[2] - pp[j].r[2];
      dr1 = dx1*dx1 + dy1*dy1 + dz1*dz1;
      
      if(dr1 > 9.0*RHSCALE2*rcrit*rcrit) continue;

      hill = p[i].hill + pp[j].hill;    
      dr1 = sqrt(dr1);
      dx0 = x0 - pp[j].rb[0];
      dy0 = y0 - pp[j].rb[1];
      dz0 = z0 - pp[j].rb[2];
      dr0 = sqrt(dx0*dx0 + dy0*dy0 + dz0*dz0);
      if(dr0 > 9.0*RHSCALE2*rcrit*rcrit) continue; // 012915
     
      dvx0 = vx0 - pp[j].vb[0];
      dvy0 = vy0 - pp[j].vb[1];
      dvz0 = vz0 - pp[j].vb[2];
      dvx1 = vx1 - pp[j].v[0];
      dvy1 = vy1 - pp[j].v[1];
      dvz1 = vz1 - pp[j].v[2];
      dv0 = (dvx0*dx0 + dvy0*dy0 + dvz0*dz0)/dr0; 
      dv1 = (dvx1*dx1 + dvy1*dy1 + dvz1*dz1)/dr1; 

      if(dr0 < RHSCALE*rcrit){ /* before encounter */
	/*	sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr0*dr0); 
	  if(sincrit2 < 1.0){
	    v2 = dvx0*dvx0 + dvy0*dvy0 + dvz0*dvz0;
	    costh = -dv0/sqrt(v2); // cos theta
	    if (costh < sqrt(1.0-sincrit2)){	   
	      goto enstep;
	    }
	  }*/
	drmin =  dr0;
	goto encounter;	
      }
      
       if(dr1 < RHSCALE*rcrit){/* after encounter */
	 /*	 sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr1*dr1); 
	  if(sincrit2 < 1.0){	   
	    v2 = dvx1*dvx1 + dvy1*dvy1 + dvz1*dvz1;
	    costh = dv1/sqrt(v2); // cos theta
	    if (costh < sqrt(1.0-sincrit2)){	   
	      goto enstep;
	    }
	    }*/
	drmin =  dr1;
	goto encounter;	
      }
      
      a = 2.0*(dr0-dr1) + (dv0 + dv1)*dDelta;
      b = 3.0*(dr1-dr0) - (2.0*dv0 + dv1)*dDelta; 
      c = dv0*dDelta;
      d = 4.0*b*b -12.0*a*c; /* d =BB-4AC: A=3a, B=2b C=c */
      
      if(d < 0.0){      
	goto enstep; /* no encounter */
      }else{
	drmin = 100.0;
	tmin = (-4.0*b+sqrt(d))/(6.0*a);
	if((tmin > 0.0) && (tmin < 1.0)) drmin = ((a*tmin + b)*tmin + c)*tmin + dr0;
	
	//	if(drmin < RHSCALE*hill){ 
	if(drmin < RHSCALE*rcrit){ 	  
	  goto encounter;
	}else{	
	  goto enstep;
	}
      }      
    encounter:
      p[i].drmin2 = drmin/rcrit;
      pp[j].drmin2 = drmin/rcrit;
      
      /*mod 042913 additional mod 121116 */
      if((p[i].iColor > pp[j].iColor)||(p[i].fMass < pp[j].fMass) || (p[i].fMass == pp[j].fMass && p[i].iOrgIdx > pp[j].iOrgIdx)){
	p[i].iOrder_VA[p[i].n_VA] = pp[j].iOrder;
	p[i].n_VA++;
      }else{
	pp[j].iOrder_VA[pp[j].n_VA] = p[i].iOrder;
	pp[j].n_VA++;
      }	   

    enstep:
      /* printf("SearchPlanets %i, n_VA %i drmin %e drmin2 %e n_VA %i iorderva0 %i \n",p[i].iOrder, p[i].n_VA,p[i].drmin,p[i].drmin2,p[i].n_VA,p[i].iOrder_VA[0]);*/
      continue;
    }   
  }
}

#ifdef sm2d

void pkdCalcElem(PKD pkd){
    PARTICLE *p;
    int i,n;
    double dSunMass = pkd->dSunMass;
    double r2;
    
    struct helio hel;
    struct delaunay del;

    p = pkd->pStore;
    n = pkdLocal(pkd); 
    for (i=0;i<n;++i) {
      hel.x = p[i].r[0]; 
      hel.y = p[i].r[1];
      hel.z = p[i].r[2];
      hel.vx = p[i].v[0];
      hel.vy = p[i].v[1];
      hel.vz = p[i].v[2];
      /*printf("i %d, id %d, (x,y,z) =(%g,%g,%g), r %g, (vx,vy,vz) =(%g,%g,%g) \n",i,p[i].iOrgIdx,hel.x,hel.y,hel.z,sqrt(hel.x*hel.x+hel.y*hel.y+hel.z*hel.z),hel.vx,hel.vy,hel.vz);*/
      r2 = p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1];
      
      heltodel(dSunMass + p[i].fMass- p[i].a_pr,&hel,&del);
      p[i].ele[0] = del.sma;
      p[i].ele[1] = del.ecc*sin(del.lop);
      p[i].ele[2] = del.ecc*cos(del.lop);
      p[i].ele[3] = del.inc*sin(del.lan);
      p[i].ele[4] = del.inc*cos(del.lan);
      p[i].ele[9] = del.mea; /* !!!! this is the eccentric anomaly !!! */
      /*if(p[i].ele[9] < 0) {
	p[i].ele[9] += 2.0*M_PI; 
	}*/
      p[i].ele[10] = del.lop-del.lan;
      if(p[i].ele[10] < 0) {
	p[i].ele[10] += 2.0*M_PI; 
      }

      /*2d heliocentric distance and azimuthal angle used in tree search for PBHYB*/
      p[i].ele[5] = sqrt(p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1]);
      p[i].ele[6] = acos(p[i].r[0]/p[i].ele[5]);
      if(p[i].r[1] < 0) p[i].ele[6] = 2.0*M_PI - p[i].ele[6];

      p[i].ele[7] = p[i].nump*1.0;
      p[i].ele[8] = p[i].fSoft/cbrt(p[i].ele[7]); /*physical radius*/
      p[i].ele[7] = cbrt(p[i].fMass/(3.0*dSunMass*p[i].ele[7])); /* reduced hill */

      int fff = 0;
      if(fff)printf("id %d m %7e a %7e e %7e i %7e \n",p[i].iOrgIdx,p[i].fMass,p[i].ele[0],del.ecc,del.inc);

 
      if(fabs(p[i].ele[0]) >= 0.0 && fabs(p[i].ele[1]) >= 0.0 && fabs(p[i].ele[2]) >= 0.0 && fabs(p[i].ele[3]) >= 0 &&
	 fabs(p[i].ele[4]) >= 0.0 && fabs(p[i].ele[5]) >= 0.0 && fabs(p[i].ele[6]) >= 0.0 && fabs(p[i].ele[7]) >= 0 &&
	 fabs(p[i].ele[8]) >= 0.0 && fabs(p[i].ele[9]) >= 0.0 && fabs(p[i].ele[10]) >= 0.0){
      }else{
	printf("id %d col %d m %7e a %7e e %7e i %7e lop %e lan %e mea %e\n",p[i].iOrgIdx,p[i].iColor,p[i].fMass,p[i].ele[0],del.ecc,del.inc,del.lop,del.lan,del.mea);
	
      };

      assert(fabs(p[i].ele[0]) >= 0);
      assert(fabs(p[i].ele[1]) >= 0);
      assert(fabs(p[i].ele[2]) >= 0);
      assert(fabs(p[i].ele[3]) >= 0);
      assert(fabs(p[i].ele[4]) >= 0);
      assert(fabs(p[i].ele[5]) >= 0);
      assert(fabs(p[i].ele[6]) >= 0);
      assert(fabs(p[i].ele[7]) >= 0);
      assert(fabs(p[i].ele[8]) >= 0);	
      assert(fabs(p[i].ele[9]) >= 0);
      assert(fabs(p[i].ele[10]) >= 0);

      
      
      /*     if(p[i].iOrgIdx ==573){ 
	printf("i %d, a %g, es %g, ec %g, is %g, ic %g, r %g, theta %g, h %g, rad %g, f %g num %f \n",
	       i, p[i].ele[0],p[i].ele[1],p[i].ele[2],p[i].ele[3],p[i].ele[4],p[i].ele[5],p[i].ele[6],p[i].ele[7],p[i].ele[8],p[i].ele[9],p[i].nump);
       }*/

    }
} 

void pkdResetKick(PKD pkd){
  /* This is for PBHYB 
     We use 
     rb[0]  d(e^2) 
     rb[1]  d(i^2)
     rb[2]  D (diffusion coefficient)
     vb[0]  d(e^2)_VS.
     vb[1]  d(i^2)_VS.
     There is no violation to the original use of them for Kepler drift.
   */
  
  PARTICLE *p;
  int i,n,k;
  p = pkd->pStore;
  n = pkdLocal(pkd); 
  for (i=0;i<n;++i) {
    for(k=0;k<3;++k){
      p[i].rb[k] = 0.0;
      p[i].vb[k] = 0.0;
    }
    p[i].fSigf[0] = 0.0;
    p[i].fSigf[1] = 0.0;
  }
 
}


void pkdDeletoKick(PKD pkd, double dTime,double dDPBHYB,double *ptsmin){

  PARTICLE *p;
  int i,n,k,ikick,akick,retry;
  double e2, i2, e2u, i2u, RN;
  double de,di,da,e1,e1u,i1,i1u,e1b,i1b;
  double msun = pkd->dSunMass;
  double sqmsun = sqrt(msun);
  double tsmin = 1.e30; /* minimum stirring time */
  double div,dev;
  double mfast,as, das0, das,r2;

  struct helio hel;
  struct delaunay del;

  p = pkd->pStore;
  n = pkdLocal(pkd); 

  //  srand((unsigned int)(time(NULL)*dTime*100.));  comment out 072914

  /*printf("dDPBHYB %g \n",dDPBHYB);*/

  // pvb0 +=  qes*pvs*2.0/2.0*aij*aij; /* D for p (random kick in tangential direction) *
  // prb1 +=  qes*(-pe2*pmass/qmass)*pdf; /* DF for e */
  // pvb1 +=  qes*qe2*pdf-qes*pvs; /* used for random kick in radial direction */
  // prb2 +=  qes*(-pi2*pmass/qmass)*pdf; /* DF for i */		
  // pvb2 +=  qes*qvs + qes*(qi2)*pdf; /* used for random kick in vertical direction */


  for (i=0;i<n;++i) {
    as = p[i].ele[0];
    if(p[i].iColor < SUBEMBRYO)continue; /* dls of full embryo is ignored when it is promoted */
    //  if(p[i].iColor == SUBEMBRYO)p[i].dls *= 0.999;
    if(p[i].vb[0] ==0){
      // if(p[i].iColor == SUBEMBRYO)p[i].dls *= (1.0-dDPBHYB/(1.e2*2.0*M_PI*as*sqrt(as))); 
      continue;
    }
    // if(p[i].n_VA > 0 && p[i].iColor == TRACER)continue; //test 050914
    r2 =  p[i].r[1]*p[i].r[1] + p[i].r[0]*p[i].r[0];
    
    e2 = p[i].ele[1]*p[i].ele[1] + p[i].ele[2]*p[i].ele[2];
    i2 = p[i].ele[3]*p[i].ele[3] + p[i].ele[4]*p[i].ele[4];

    /* dynamical friction only */
    e2u = e2 + p[i].rb[1]*dDPBHYB;
    i2u = i2 + p[i].rb[2]*dDPBHYB;
   
    if(p[i].vb[0] < 0){
      p[i].vb[1] += 1.0*p[i].vb[0]/(as*as); // factor corrected
      p[i].vb[0] = 0.0;
    }
 
    if(p[i].vb[1] < 0){
      e2u += p[i].vb[1]*dDPBHYB;
      if(e2u < 0) e2u = e2; 
    }

    // printf("ok13 i e2 %g %g, i2 %g %g \n",i,e2,e2u,i2,i2u);

    if(e2u < 0.0) {
      if(pkd->param.iCollLogOption & COLL_LOG_STAND)printf("nege e2 %g e2u %g i2 %g i2u %g \n",e2,e2u,i2,i2u);
      e2u = e2 - p[i].rb[1]*dDPBHYB;  
    }
    if(i2u < 0.0){  
      if(pkd->param.iCollLogOption & COLL_LOG_STAND)printf("negi e2 %g e2u %g i2 %g i2u %g \n",e2,e2u,i2,i2u);
      i2u = i2 - p[i].rb[2]*dDPBHYB;   
    }

    e1 = sqrt(e2);
    e1u = sqrt(e2u);
    de = (e1u-e1);
    //de = 0.0; //test
    
    i1 = sqrt(i2);
    i1u = sqrt(i2u);
    di = (i1u-i1);


    da = p[i].vb[0];
    if(da > 0){
    /* for a Marsaglia polar method to obtain gaussian */
      do{
	e2u  =  ((double)drand48())*2.0-1.0; 
	i2u  =  ((double)drand48())*2.0-1.0; 
	e2u = i2u*i2u + e2u*e2u; 
      }while(e2u >= 1.0 || e2u < 0.01);
      
      da = i2u*sqrt((-2.0*log(e2u)/e2u)*(2.0*fabs(da)*dDPBHYB));
    }else{
      da = 0.0; 
    }

    /* add planetesimal driven migration*/

    if(p[i].iColor == SUBEMBRYO){    
    
      /*   mfast = 2.0*M_PI*as*as*p[i].rb[0]/(3.0*msun);
      mfast = 4.0*mfast*sqrt(mfast)*msun/p[i].fMass; // m_fast/m_embryo 
      //if(mfast > 1.0)mfast = 1.0; */

      if(p[i].dls*p[i].fSigf[0] < 0){
	printf("dls %g fsigf0 %g   \n",p[i].dls,p[i].fSigf[0]);
	// assert(0);
	// this occurs very very rarely. probably ejected subembryos?
	// No miration in this case by resetting torque 121916
	p[i].fSigf[0] = 0.0;
	p[i].dls = 0.0;
      }
      //   assert(p[i].dls*p[i].fSigf[0] >= 0);

      das0 = p[i].dls*2.0*as/(sqrt(as*(1.0-e2))*(msun - p[i].a_pr)); /* da from the n-body routine  */
      das = (p[i].fSigf[0]+p[i].fSigf[1])*dDPBHYB; // expected da from the statistical routine 

      if(das*das0 < 0){
	das = 0.0;
      }else{	
	if(fabs(das0) <= fabs(das)){
	  das = das0;
	}
      }

      /* if (fabs(das0) > fabs(das)){
	das = p[i].fSigf[0]*dDPBHYB;	
      }else{
	das = das0;
	}*/
       
      // printf("das_n %g das_est %g, das_dis %g  \n",das0,p[i].fSigf[0]*dDPBHYB,p[i].fSigf[1]*dDPBHYB);

      da += (das + p[i].fSigf[1]*dDPBHYB);    
      if(fabs(das0)>0){
	das0 = fabs(das/das0);
	assert(das0 <= 1.0);
	p[i].dls *= (1.0-das0);
      }

      //printf("as %g mfast %g fsig0 %g fsig1 %g dls%g  rb0 %g  \n",as,mfast,p[i].fSigf[0],p[i].fSigf[1],p[i].dls,p[i].rb[0]);
    }


    /* for a Marsaglia polar method to obtain gaussian */
    do{
      e2u  =  ((double)drand48())*2.0-1.0; 
      i2u  =  ((double)drand48())*2.0-1.0; 
      e2u = i2u*i2u + e2u*e2u; 
    }while(e2u >= 1.0 || e2u < 0.01);

    div = p[i].vb[2];
    div = i2u*sqrt((-2.0*log(e2u)/e2u)*(1.0*fabs(div)*dDPBHYB)); 
 
    /* for a Marsaglia polar method to obtain gaussian */
    dev = p[i].vb[1];
    if(dev > 0){
      do{
	e2u  =  ((double)drand48())*2.0-1.0; 
	i2u  =  ((double)drand48())*2.0-1.0; 
	e2u = i2u*i2u + e2u*e2u; 
      }while(e2u >= 1.0 || e2u < 0.01);     
      dev = i2u*sqrt((-2.0*log(e2u)/e2u)*(1.0*fabs(dev)*dDPBHYB)); 
    }else{
      dev = 0.0;
    }
  
    //OneDeletoKick(&(p[i]),sqmsun*(1.0+0.5*p[i].fMass-0.5*p[i].a_pr),e1,i1,da,de,dev,di,div,das);
    OneDeletoKick(&(p[i]),sqrt(msun+p[i].fMass-p[i].a_pr),e1,i1,da,de,dev,di,div,das);

    
    // p[i].dls = 0.0; /* angular monetume change of a subembryo resets here */
    // hel.x = p[i].r[0]; 
    // hel.y = p[i].r[1];
    // hel.z = p[i].r[2];
    // hel.vx = p[i].v[0];
    // hel.vy = p[i].v[1];
    // hel.vz = p[i].v[2];
    // heltodel(pkd->dSunMass + p[i].fMass,&hel,&del);
    //  printf("i1 %d aa %g  e %g  i %g \n",i, del.sma,del.ecc,del.inc);

  }

  *ptsmin = tsmin;
}

void OneDeletoKick(PARTICLE *p,double sqmsun,double e1, double i1, double da,double de,double dev,double di,double div,double das){
  int k,ia;
  double e2u, i2u;
  double E, cE, cf,sf,cwf,swf,r3;
  double r[3],t[3],z[3];
  double e2 = e1*e1;
  double fac, temp, da0;
  
  E = p->ele[9];
  cE = cos(E);

  cf = (1.0-e1)*(1.0+cE)/(1.0-e1*cE)-1.0;
  sf = sqrt(1.0-cf*cf);
  if(E > M_PI)sf = -sf; 
  cwf = cos(p->ele[10])*cf - sin(p->ele[10])*sf;
  swf = sin(p->ele[10])*cf + cos(p->ele[10])*sf;

  i2u = p->ele[0]; /* a */
  e2u = sqrt((1.0-e2)*i2u); /* sqrt((1-e^2)a)*/
  
  da *= (sqmsun*e2u/(2.0*i2u*i2u));   
  de *= (sqmsun/e2u);
  dev *= (sqmsun/e2u);

  temp = (sqmsun/e2u);

  r3 = sqrt(p->r[0]*p->r[0]+p->r[1]*p->r[1]+p->r[2]*p->r[2]); /* 3d r */

  di *= sqmsun*e2u/(r3); // use a instead of r?
  div *= sqmsun*e2u/(r3);

  da0 = da;

  da = da + 0.5*cf*de; /* F_T*dt */
  de = dev + sf*de; /* F_R*dt */

  // da = da ; /* F_T*dt */
  // de = dev + 2.0*sf*de; /* F_R*dt */
  
  di = div + 2.0*cwf*di;  /* F_N*dt */

  //das = 0.0; //test
  // if(p->iColor == SUBEMBRYO){
  // da += das/(r3);
  // }

  /* unit vectors */
  
  r[0] = p->r[0]/r3;
  r[1] = p->r[1]/r3;
  r[2] = p->r[2]/r3;
  
  z[0] = p->r[1]*p->v[2] - p->r[2]*p->v[1];
  z[1] = p->r[2]*p->v[0] - p->r[0]*p->v[2];
  z[2] = p->r[0]*p->v[1] - p->r[1]*p->v[0];
  
  i2u = sqrt(z[0]*z[0]+z[1]*z[1]+z[2]*z[2]);
  z[0] /= i2u;
  z[1] /= i2u;
  z[2] /= i2u;
  
  t[0] = z[1]*r[2] - z[2]*r[1];
  t[1] = z[2]*r[0] - z[0]*r[2];
  t[2] = z[0]*r[1] - z[1]*r[0];
  i2u = sqrt(t[0]*t[0]+t[1]*t[1]+t[2]*t[2]);
  t[0] /= i2u;
  t[1] /= i2u;
  t[2] /= i2u;
  
  assert(fabs(p->v[0]) < 100.0 && fabs(p->v[1]) < 100.0  && fabs(p->v[2]) < 100.0);
  assert(fabs(r[0]) < 100.0 && fabs(r[1]) < 100.0  && fabs(r[2]) < 100.0);
  assert(fabs(t[0]) < 100.0 && fabs(t[1]) < 100.0  && fabs(t[2]) < 100.0);
  assert(fabs(z[0]) < 100.0 && fabs(z[1]) < 100.0  && fabs(z[2]) < 100.0);
  
  /* Kick !! */
  for(k=0;k<3;++k){   
    p->v[k] += de*r[k] + da*t[k] + di*z[k];
  }

}



void pkdChecknSmooth(PKD pkd, int *piFlag){
 PARTICLE *p;
 int i,n;

 p = pkd->pStore;
 n = pkdLocal(pkd); 
 for (i=0;i<n;++i) {
   if(p[i].vb[1] != p[i].vb[0]){
     *piFlag = 0;
     return;
   }
 }
 *piFlag = 1; /* Number of neighboring particles matches with the previous result for all particles */

}

//void CalcPcollPebble(double st,double sti,double eij,double iij,double qr,double pr,double *rj,double *ri,double *vj,double *vi,double msun,double hp,double rp,double *ppcol){
void CalcPcollPebble(PARTICLE *pj,PARTICLE *pi,double eij,double iij,double hij,double msun,double rp,double *ppcol){
  // pebble accretion rate; setteling regime of Ormel and Klahr (2010)
  // see also Ormel and Kobayashi (2012)
  
  double st,sti,vr,b3b,pcol_peb;
  double pr,qr,rj[3],vj[3],ri[3],vi[3],hp,v_kep,fr,fv,vj_r,vj_th,vi_r,vi_th;  
  double st_cr, bset, bset_max, bhyp;

  st = pj->St;
  sti = pi->St;
  
  if(st > 2.0 && sti > 2.0){ // b_3b added 010217
    vr = sqrt(eij*eij + iij*iij);    
    b3b = 1.0/st*exp(-pow(0.7*vr/st,5.0));
    pcol_peb = M_PI*b3b*b3b*vr/(2.0*iij);
  if(pcol_peb > 2.0*b3b*vr) pcol_peb = 2.0*b3b*vr;
  if(pcol_peb > *ppcol) *ppcol = pcol_peb;
  
  }else{ // b_set
       
    pr = pi->ele[5];
    qr = pj->ele[5];
    rj[0] = pj->r[0];
    rj[1] = pj->r[1];
    rj[2] = pj->r[2];
    vj[0] = pj->v[0];
    vj[1] = pj->v[1];
    vj[2] = pj->v[2];
    ri[0] = pi->r[0];
    ri[1] = pi->r[1];
    ri[2] = pi->r[2];
    vi[0] = pi->v[0];
    vi[1] = pi->v[1];
    vi[2] = pi->v[2];
    hp = pj->hp;
    //    vbj = pj->vb; // used for velocity relative to local keplerian after semi-major axis correction 
    //    vbi = pi->vb;
    
    v_kep = sqrt(msun/pr); 
    // scaling factor
    fr = pr/qr;
    fv = 1.0/sqrt(fr);
    // r and v for j
    rj[0] *= fr;
    rj[1] *= fr;
    rj[2] *= fr;
    vj[0] *= fv;
    vj[1] *= fv;
    vj[2] *= fv;

    // velocities relative to local Keplerian
    // vj[0] += v_kep*rj[1]/pr;
    // vj[1] -=  v_kep*rj[0]/pr;
     
    vj_r = (rj[0]*vj[0] + rj[1]*vj[1])/pr;
    vj_th = (rj[0]*vj[1] - rj[1]*vj[0])/pr -v_kep;
    
    //save
    pj->vb[0] = vj_r;
    pj->vb[1] = vj_th;
    pj->vb[2] = vj[2];
    
    // r and v for i
    // velocities relative to local Keplerian
    //vi[0] += v_kep*ri[1]/pr;
    //vi[1] -= v_kep*ri[0]/pr;
    
    vi_r = (ri[0]*vi[0] + ri[1]*vi[1])/pr;
    vi_th = (ri[0]*vi[1] - ri[1]*vi[0])/pr - v_kep;
    
    //save
    pi->vb[0] = vi_r;
    pi->vb[1] = vi_th;
    pi->vb[2] = vi[2];
    
    // relative velocity between j and i normalized by Hill
    vr = sqrt((vi_r-vj_r)*(vi_r-vj_r)+(vi_th-vj_th)*(vi_th-vj_th)+(vi[2]-vj[2])*(vi[2]-vj[2]))/(hij*v_kep);
	
    bset = sqrt(12.0*st/vr);
    bset_max = 2.0*cbrt(st);
    if(bset > bset_max)bset = bset_max; // hill accretion
    
    st_cr = 12.0/(vr*vr*vr);
    if(st_cr > 2.0)st_cr = 2.0; // changed from 1 to 2 010217
    bset *= exp(-pow(st/st_cr,0.65));

    // printf("vr %g ,bset %g, bhyp %g, rp %g, hij %g, vr/vesc %g, mi %g \n",vr,bset,rp*sqrt(1.0+6.0/(rp*vr*vr)),rp,hij,vr/sqrt(6.0/rp),pi->fMass/pi->nump);
    if(st > st_cr){
      bhyp = rp*sqrt(1.0+6.0/(rp*vr*vr));
      if(bhyp > bset) bset = bhyp;
    }
    
    pcol_peb = M_PI*bset*bset*vr*facrho*exp(-ri[2]*ri[2]/(2.0*hp*hp))/(hp/(pr*hij)); // hp/(pr*hij) = pebble scale height normalized by hill
    if(pcol_peb > 2.0*bset*vr) pcol_peb = 2.0*bset*vr;
   
    *ppcol = pcol_peb;
  }


} 

void pkdPBHYBCollStirDirect(PKD pkd, double dTime, int TYPE_PBHYB, double dDPBHYB){
  PARTICLE *p;
  int i,j,n,nt,nr,np,nrmax,ntmax,npmax,nn,nr0,nt0,ntin;

  double rmin, rmax, lrfac;
  double pa,pes,pec,pis,pic,pr,pth,ph,prad,ptmass,pnum,pmass;
  int pid,qid,idel; 
  double dr,area,pe2,pi2,drf,drm; 
  double qtmass,qnum,qmass,qrad;
  double qes,qec,qr,qa,qe2,qi2;
  double eij,iij,aij,saij,hij,x,x0,dmdt,RN,dDmi;
  //int iself = 0;
  double pvs,qvs,pdf,pb;
  double prb0,prb1,prb2,pvb0,pvb1,pvb2,vr2,dth,dy,pcol,pcol_peb,nttmax,pdfe;
  double dSunMass = pkd->dSunMass;
  double h1 = pkd->param.HY.fh1; /* the reduced hill radius for a minimum full embryo */
  double h0 = pkd->param.HY.fh0;
  double fff = pkd->param.HY.fff; /* factor for full embryo*/
  double mt0 = pkd->param.HY.fMt0;
  double dtheta = pkd->param.HY.fdtheta;
  double fdr = pkd->param.HY.ffdr;
  double aa,lmr,qcor,pcor,fen;
  //  double mmin;
  int nm,nmmax,ngr0;
  double ej,ij,rj1,rj0,mgr0;
  // moved to pkd.h  double ftmin = 0.1; // minimum mass of a tracer is ftmin*mt0 except for those with nump = 1 
  // double p04,p09,p04b,p09b,p04c,p09c;
  double rho2,rho_neb,temp_neb,r_Bond,w_neb,sig_t,sig_c; //111616
  double kappa = pkd->param.GP.dkappa;
  double alpha = pkd->param.GP.dalpha;
  p = pkd->pStore;
  n = pkdLocal(pkd); 

  int nta,ntb,nra,nrb;
  int ig[nrlim][ntlim][nlim], ng[nrlim][ntlim];
  // int igr[nrlim][ntlim][nlim],ngr[nrlim][ntlim];
  // double mgr[nrlim][ntlim];
  int TRGRAV = pkd->param.HY.iTRGRAV;

  /* first calculate rmin rmax (2d r  ele[5]) */
  rmin = 1000.0;
  rmax = 0.0;

  //  mmin = mt0; 
  for (i=0;i<n;++i) {
    if(p[i].ele[5] < rmin) rmin = p[i].ele[5];
    if(p[i].ele[5] > rmax) rmax = p[i].ele[5];
    // pmass = p[i].fMass/(p[i].nump*1.0);
    // if(pmass < mmin) mmin = pmass;
  }
 
  lrfac = 1.0+11.0*h1*fdr; /* ratio of radii of the neighboring radial grid points */
  lrfac = log(lrfac);

  ///////// this mass grid is no longer used
  // lmr = 1.2; // favored mass ratio changed from 1.3 to 1.2 072114
  //nmmax = (int)(ceil(log(mt0*1.02/mmin)/log(lmr))) + 1; // 1.02 just for safety ; +1 for embryos
  //if(nmmax > 20){ //maximum mass bin number is 20 
  //  lmr = pow(mt0*1.02/mmin,1.0/19.0);
  //  nmmax = 20;
  //}
  //lmr = log(lmr);
  /////////

  
  /* Numbers of grid in radial and azimuthal directions */
  nrmax = (int)(log(rmax/rmin)/lrfac) + 1;
  ntmax = (int)(2.0*M_PI/(dtheta*1.01));
  nttmax =ntmax;
  assert(nrmax < nrlim);
  // assert(ntmax < ntlim); //mod on 090417
  if(ntmax > ntlim-1) ntmax = ntlim-1;
  
  nttmax =ntmax;
  dth = 2.0*M_PI/nttmax; /* grid size (>= 2*dtheta)*/
  // printf("dth %e, ntmax %d \n",dth,ntmax);
  /* distribute to grids */
  /* first reset*/
  for(nr = 0;nr<nrmax;++nr){
    for(nt = 0;nt<ntmax;++nt){
      ng[nr][nt] = 0;
    }
    //    for(nm = 0;nm<nmmax;++nm){
    //      ngr[nr][nm] = 0;  //not used
    //     mgr[nr][nm] = 0.0; //not used
    //    }
  }

  for (i=0;i<n;++i) {
    /* we may be able to aviod fullembryos in the list but we have them just in case */

    nr = (int)(log(p[i].ele[5]/rmin)/lrfac);
    nt = (int)(p[i].ele[6]/dth);
    assert(nr < nrmax && nr >= 0);
    if(nt == ntmax){
      printf("nt %d ntmax %d the %f \n",nt,ntmax,p[i].ele[6]);
      nt = 0;
    }
    assert(nt < ntmax);

    ig[nr][nt][ng[nr][nt]] = i;
    ng[nr][nt] ++;
    p[i].nrt[0] = nr;
    p[i].nrt[1] = nt;

    if(ng[nr][nt] > nlim){
      printf("ng %d nr %d nt %d \n",ng[nr][nt],nr,nt);  
    }
    assert(ng[nr][nt] <= nlim);

    // mass bins skip 062415
    /*
    if(p[i].iColor >= TRACER){ // TRACERS 
      pmass = p[i].fMass/(p[i].nump*1.0);
      nm = (int)(log(pmass/mmin)/lmr);
      assert(nm < nmmax-1 && nm >= 0);
    }else{
      nm = nmmax -1; //embryos are put in a single bin for here
    }
 
    igr[nr][nm][ngr[nr][nm]] = i;
    ngr[nr][nm] ++;
    mgr[nr][nm] += p[i].fMass; 
    p[i].nrt[2] = nm;
    p[i].nrt[3] = 0; // reset isolation flag for tracer
    */
  }

  /* check isolation 
     isolation removed 062415
  lrfac = 1.0+11.0*h1*fdr;
  for(nr=0;nr<nrmax;nr++){
    pa = rmin*pow(lrfac,nr);
    dr = pa*(lrfac-1.0);
    qa = 0.0;
    
    for(nm = nmmax-1;nm>0;nm--){ //mass in the smallest bin (nm =0) is not isolated
      //      printf("nr %d nm %d ngr %d  \n",nr,nm,ngr[nr][nm]);  
      for(j=0;j<ngr[nr][nm];j++){	
	i = igr[nr][nm][j];
	//	printf("j %d i %d num %i a %g h %g  \n",j,i,p[i].nump,p[i].ele[0],p[i].ele[7]);  
	qa += p[i].nump*p[i].ele[0]*(4.3645*p[i].ele[7]+2.0*sqrt(p[i].ele[1]*p[i].ele[1]+p[i].ele[2]*p[i].ele[2]));
	if(qa < dr){
	  p[i].nrt[3] = 1;
	}else{
	  goto nextr;
	}
      }     
    } 
  nextr: continue;
  }*/

  /*  for(nr=0;nr<nrmax;nr++){    
   for(nt=0;nt<ntmax;nt++){
     printf("nr %d, nt %d, np %d \n",nr,nt,ng[nr][nt]);
    }
    }*/

  /* list done */
  double tsig, ttsig[2],nnsig[2],nbsig[2];
  ttsig[0] = ttsig[1] = nnsig[0] = nnsig[1] = nbsig[0] = nbsig[1] = 0.0;

  /* */
  for (i=0;i<n;++i) {
    if(p[i].iColor < SUBEMBRYO) continue; /* no statistical treatments for fullembryos */
    if(TYPE_PBHYB ==1 && pkd->param.iGravDirect==7 && p[i].iColor==SUBEMBRYO)continue;  /* no statistical treatments for subembryo-tracer collisions if iGravDirect==7 */
    
    /* tracer i has already collided with another particle; multiple impacts onto subembryos are allowed now 072215*/
    /* futher update on 082615 multiple impacts onto a target are allowed 
       impacts of an impactor on multiple targets are not allowed
     */
    // if(TYPE_PBHYB ==1 && p[i].iColflag && p[i].iColor > SUBEMBRYO)continue; 

    if(TYPE_PBHYB ==2 && p[i].iColor == SUBEMBRYO){
       ttsig[0] = ttsig[1] = nnsig[0] = nnsig[1] = nbsig[0] = nbsig[1] = 0.0; 
    }
    // if(p[i].iColor == TRACER) continue;//test
    // pa = p[i].ele[0];
    pa = p[i].ele[5]; // 120116; r is now used since a can be negative
    pes = p[i].ele[1];
    pec = p[i].ele[2];
    pis = p[i].ele[3];
    pic = p[i].ele[4];
    pr = p[i].ele[5];
    pth = p[i].ele[6];
    ph = p[i].ele[7];
    prad = p[i].ele[8];
    ptmass = p[i].fMass;
    pnum = p[i].nump*1.0;
    pmass = p[i].fMass/pnum;
    pid = p[i].iOrgIdx;
 
    if(ptmass < 0.5*ftmin*mt0){
      printf("ptmass %g 0.5*ftmin*mt0 %g pnum %g pid %d \n",ptmass,0.5*ftmin*mt0,pnum,pid);
    }
    assert(ptmass >= 0.5*ftmin*mt0);

    dr = 10.0*pr*h1;
    if(p[i].iColor > SUBEMBRYO)dr = 10.0*pr*h0;

    area = 4.0*dtheta*pr*dr; 
    pe2 = pes*pes + pec*pec;
    if(p[i].ele[0] < 0 || pe2 > 1.0) continue; //120116
    pi2 = pis*pis + pic*pic;
    prb0 = prb1 = prb2 = pvb0 = pvb1 = pvb2 = 0.0;

    nr0 = p[i].nrt[0];
    nt0 = p[i].nrt[1];
    nn = 0;

    tsig = 0;

    nta = nt0-1;
    ntb = nt0+2;
    if(ntmax <=2)ntb = nt0+1;
    if(ntmax ==1)nta = nt0;

    // printf("ok3 i %d r %g \n",i,pr);

    nra = nr0-1;
    nrb = nr0+1;
    if(p[i].iColor == SUBEMBRYO){
      nra -= (int)(10.999/(11.0*fdr));
      nrb += (int)(10.999/(11.0*fdr));     
    }


    /* check neighbors in the present and neighboring cells (total 9 cells)*/
    for(nr=nra;nr<nrb+1;nr++){ 
      if(nr < 0 || nr >= nrmax)continue;
      // for(nt=nt0-1;nt<nt0+2;nt++){ 
      for(nt=nta;nt<ntb;nt++){ 
	ntin = nt;
	if(ntin < 0) ntin += ntmax;/* nt = ntmax-1*/
	if(ntin >= ntmax) ntin -= ntmax; /* nt = 0 */
	assert(ntin >= 0 && ntin < ntmax);

	npmax = ng[nr][ntin]; /* num of particles in the cell */
	//printf("ok6 nr %d, nt %d, ntin %d npmax %d\n",nr,nt,ntin,npmax);
	for(np=0;np<npmax;np++){
	  j = ig[nr][ntin][np];
	  if(i==j) continue;
	  //printf("ok7 np %d j %d \n",np,j);
	  qid = p[j].iOrgIdx;
	  if(p[j].iColflag) continue;
	  if(p[j].iColor <= SUBEMBRYO) continue;  /* particle j must be a tracer */
	 
	  // no interaction between isolated tracers
	  //  if(p[i].iColor==TRACER && p[i].nrt[3] ==1 && p[j].nrt[3] ==1)continue; 

	  // interaction of a subembryo with a planetesimal in a tracer is handled in N-body routine
	  if(TYPE_PBHYB ==2 && p[i].iColor==SUBEMBRYO && p[j].nump <= 1.0)continue; // pi corrected 121314
	  if(TYPE_PBHYB ==2 && (p[i].St < 2.0 || p[j].St < 2.0))continue; // no gravitational interaction with pebbles
	  
	  // interaction between pebble tracers are ignored for now 111316
	  if(p[i].iColor==PEBBLE && p[j].iColor == PEBBLE)continue;
	  if(p[i].St < 2.0 && p[j].St < 2.0)continue;
	  
	  /* check q is in the area */
	  qr = p[j].ele[5];
	  
	  if(fabs(qr-pr) > dr)continue; /* radial */
	  
	  dy = fabs(pth-p[j].ele[6]);
	  if(dy > 2.0*M_PI) dy -=2.0*M_PI;
	  if(dy > dtheta)continue;  /* azimuthal */	  
	
	  nn++;

	  //	  if(TYPE_PBHYB ==0)continue; /* simply count neighboring particles */

	  qtmass = p[j].fMass;
	  qnum = p[j].nump*1.0;
	  qmass = p[j].fMass/qnum;
	  qrad = p[j].ele[8];
	  
	  tsig += qtmass/area;
	  if(TYPE_PBHYB ==0)continue; /* simply count neighboring particles */

	  if((pnum < qnum) || (qnum == pnum && qmass < pmass) || (qmass == pmass && (qnum == pnum) && qid > pid)){
	   	  
	    qes = p[j].ele[1];
	    qec = p[j].ele[2];
	    eij = sqrt((pes-qes)*(pes-qes) + (pec-qec)*(pec-qec));
	 
	    qe2 = qes*qes + qec*qec; /* qe2 */
	    if(p[j].ele[0] < 0 || qe2 > 1.0) continue; //120116
	     
	    qes = p[j].ele[3];
	    qec = p[j].ele[4];
	    iij = sqrt((pis-qes)*(pis-qes) + (pic-qec)*(pic-qec));    
	    qi2 = qes*qes + qec*qec; /* qi2 */

	    /* mean semimajor axis */
	    // qa = p[j].ele[0]; 
	    qa = p[j].ele[5]; // 120116
	    aij = 0.5*(pa + qa); 
	    if(p[i].iColor == SUBEMBRYO) aij = pa;// 101514
	    saij = sqrt(aij*dSunMass); // aij*aij*omega ; assume central star's gravity is dominant
	    /*calculate hij using taylor expansion*/
	    x = qmass/pmass;
	    hij = ph;
	    if(x > 1.0){/* qmass > pmass */
	      x = 1.0/x;
	      hij = p[j].ele[7];
	    }
	    x0 = x; /* mass ratio <= 1.0 */
	    if(x0 > 0.333) x = 0.5*(x-1.0);
	    x = 1.0 + 1.0/3.0*x*(1.0 - 1.0/3.0*x*(1.0-5.0/9.0*x*(1.0-2.0/3.0*x*(1.0-11.0/15.0*x*(1.0-7.0/9.0*x*(1.0-17.0/21.0*x*(1.0-5.0/6.0*x)))))));
	    if(x0 > 0.333) x *= cbr2;
	    hij *= x; 
 
	    // if(iself == 0 && x0 > 1.0/1.3)iself = 1;

	    if(p[i].iColor == SUBEMBRYO){/* only tracers in the feeding zone are taken into account */
	    
	      /* correction for aij due to gravity of the subembryo ?*/

	      // jacob = 1.0/2.0*(eij*eij+iij*iij)*aij*aij - 3.0/8.0*(qa-pa)*(qa-pa) + 9.0/2.0*aij*aij*hij*hij;
	      //jacob /= (aij*aij*hij*hij);
	      drf = sqrt(4.0/3.0*(eij*eij+iij*iij) + 12.0*hij*hij)*aij; 
	      drm = sqrt(8.0/(2.5+2.0*eij/hij))*hij*aij; //Ida et al 1989 Eq. 18	      

	      // calculate probability that a particle is in the area
	      ej = sqrt(qe2);
	      ij = cos(sqrt(qi2));
	      rj1 = qa*(1.0+ej)*ij;
	      rj0 = qa*(1.0-ej)*ij;
	    
	      if(rj1 > (pr + dr)){ //apocenter is outside of the area 
		//		printf("pr %g, pr+dr %g, pr-dr %g, qa %g, qr%, rj0 %g, rj1 %g, ej %g, cij %g \n",pr, pr+dr, pr-dr, qa, qr, rj0, rj1, ej, ij);
		rj1 = (1.0-(pr + dr)/(ij*qa))/ej; // cosE1
		//		printf("cosE1 %g \n", rj1);
		assert(rj1 >=-1.0);
		if(rj1 >= 1.0) rj1 = 0.99; // this may happens probably because we calculate elements using democratic coordinates
		rj1 = acos(rj1)-ej*sqrt(1.0-rj1*rj1); //M1
	      }else{
		rj1 = M_PI;
	      }

	      if(rj0 < (pr - dr)){ //pericenter is outside of the area 
		//		printf("pr %g, pr+dr %g, pr-dr %g, qa %g, qr %g, rj0 %g, rj1 %g, ej %g, cij %g \n",pr, pr+dr, pr-dr, qa, qr,rj0, rj1, ej, ij);
		rj0 = (1.0-(pr - dr)/(ij*qa))/ej; // cosE0
		//		printf("cosE0 %g \n", rj0);
		assert(rj0 <= 1.0);
		if(rj0 <= -1.0) rj0 = -0.99; // this happens probably because we calculate elements using democratic coordinates
		rj0 = acos(rj0)-ej*sqrt(1.0-rj0*rj0); //M0
	      }else{
		rj0 = 0.0;
	      }
	      assert(rj1 > rj0);

	      rj0 = (rj1-rj0)/M_PI; // correction factor 070914
	      if(rj0 < 0.01) rj0 = 0.01; //072114 added but necessary ?
	    	      
	      area = 4.0*dtheta*pr*(drf-drm)*rj0;

	      // vr2 = (eij*eij+iij*iij)/(hij*hij);
	      // vr2 *= sqrt(vr2);
	      //test
	       ej = 1.0;
	      ij = 1.0;
	      //p04c = 1.0;

	      /*if(vr2 > 8.0 && fabs(qa-pa) < drf && fabs(qa-pa) > drm){
		p04 = 1.0/sqrt((1.0-0.16)*(1.0+iij*iij/(eij*eij)-0.75*0.16)); 
		p09 = 1.0/sqrt((1.0-0.81)*(1.0+iij*iij/(eij*eij)-0.75*0.81)); 
		
		p04b = p04/(1.0+iij*iij/(eij*eij)-0.75*0.16); 
		p09b = p09/(1.0+iij*iij/(eij*eij)-0.75*0.81); 

		p04c = p04b*0.4; 
		p09c = p09b*0.9;
	
		if(fabs(qa-pa) > 0.8*drf+0.2*drm){
		  p09 /= (0.2*p09 + 0.8*p04);
		  p09b /= (0.2*p09b + 0.8*p04b);
		  p09c /= (0.2*p09c + 0.8*p04c);

		  if(TYPE_PBHYB == 1) area /= p09;
		  if(TYPE_PBHYB == 2) {
		    area /= p09b;
		    ej = p09/p09b;	
		    p04c = p09c/p09b;
		  }
		}else{
		  p04 /= (0.2*p09 + 0.8*p04);
		  p04b /= (0.2*p09b + 0.8*p04b);
		  p04c /= (0.2*p09c + 0.8*p04c);

		  if(TYPE_PBHYB == 1) area /= p04;
		  if(TYPE_PBHYB == 2) {		    
		    area /= p04b;
		    ej = p04/p04b;	
		    p04c = p04c/p04b;
		  }
		}	
		}*/
	    
	      //vr2 *= sqrt(vr2); 
	      // vr2 = 2.0/(1.0+2.0*vr2/(27.0)); // reduction factor for planetesimal driven migration
	      /*printf("drf %g \n",drf);*/

	    } // end subembryo

	    /*reduced e and i */
	    eij /= hij; 
	    iij /= hij;

	    /* correction due to a self-encounter */
	    qcor = 1.0;
	    pcor = 1.0;	  
	    /*  This correction causes some issues when the size distribution is very broad 
		we skip this as we know this correction has only negligible effects

		if(p[i].iColor >= TRACER){	      
	      nm = p[i].nrt[2];
	      ngr0 = ngr[nr0][nm];
	      mgr0 = mgr[nr0][nm];
	      if(nr0 == p[j].nrt[0] && nm == p[j].nrt[2]){ 
		// A similar mass tracer pair detected and calculate mass correction factors
		assert(ngr0 > 1);	
		qcor = (mgr0-pmass)/(mgr0-ptmass); 
		pcor = (mgr0-qmass)/(mgr0-qtmass); 	
	      }	      	      
	      }*/
	    
	    if(TYPE_PBHYB == 1){ /* collision start */
	      if(p[i].iColor == SUBEMBRYO && (fabs(qa-pa) > drf || fabs(qa-pa) < drm))goto endcollision;  
	      /* collisions occur only with tracers in the feeding zone */

	      // radius enhancement due to atmosphere 110716
	      fen = 1.0;
	   
	      if((pkd->param.GP.bDragEnhance == 2) && pmass > 1.e-9){	
		
		//fen = 24.0/(5.0*(eij*eij +iij*iij) + 24.0);
		//	fen = fatm*cbrt(fen*p[i].hill*prad/p[j].ele[8]*pmass*dTime); /* we use dM/dt = M/t */
		
		rho2 = (3.0*qmass)/(4.0*M_PI*qrad*qrad*qrad);
		rho_neb = p[i].rho_neb;
		temp_neb = p[i].temp_neb;
		r_Bond = p[i].r_Bond;

		// Ormel and Kobayashi (2012)
		w_neb = wfac*kappa*pmass*rho_neb/(prad*temp_neb*temp_neb*temp_neb*dTime); // thier Eq.(22) and (23) 
		sig_t = 0.2/w_neb; // atmosphere density at transition from isothermal to pressure dominant regimes 
		sig_c = (2.0/3.0)*qrad/(pa*ph)*(1.0+(eij*eij +iij*iij)/6.0)*rho2/rho_neb; // critical gas density necessary for capture
		
		if(sig_c < sig_t){
		  fen = 1.0 + (2.0*w_neb*(sig_c - 1.0) +log(sig_c))/1.4;
		}else{
		  fen = 1.0 + (2.0*w_neb*(sig_t - 1.0) +log(sig_t))/1.4 + 4.0/1.4*cbrt(4.0*w_neb)*(cbrt(sig_c)-cbrt(sig_t));
		}

		if(fen < 1.0) fen = 1.0; // collsional radius does not exceed Bondi radius
		
		fen = r_Bond/prad/fen;
		
		if(prad*fen > 0.25*(pa*ph))fen = 0.25*(pa*ph)/prad; // atmosphere radius does not exceed 0.25 of Hill radius		
		if(fen < 1.0) fen = 1.0;
		
	      }
	      
	      dmdt = (qrad+prad*fen)/(aij*hij); /* rp parameter */
	      
	      CalcPcoll(eij,iij,dmdt,&pcol,TRGRAV); /* calculate pcoll */
	  
	      // if St < 100, calculate pebble probability */
	      // only if the targe is a tracer.
	      // pebble accretion is directly solved in N-body routine for sub and full embryos
	      // double pcol0;
	      // pcol0 = pcol;
	      if(p[j].St < 1000.0 && p[i].iColor ==TRACER && TRGRAV ==2){

		CalcPcollPebble(&(p[j]),&(p[i]),eij,iij,hij,(dSunMass-p[i].a_pr),dmdt,&pcol) ;
		//if(pmass > 1.e-10 && pcol > pcol0){
		//  printf("pid %d, pmass %e, pst %e, qid %d, qmass %e, qst %e, pcol %e pcol0 %e fen %e \n",pid,pmass,p[i].St,qid,qmass,p[j].St,pcol,pcol0,fen);
		//}
		
	      }
	      
	      dmdt = pcol*qtmass*qcor/area*saij*hij*hij;	/* (dm/dt)j */
	
	      /* correction due to self-encounter removed 021214
	       the correction factor qcor added again 070314 */

	      assert(pnum <= qnum);
		 /* dDmi */
	      idel = 0; /* the interloper is deleted if idel = 1 */
	      if(qtmass > 0.1*mt0){
		dDmi = qmass;
		if(pnum == qnum){
		  idel = 1;	    
		}
		
		/*	if(qmass < pmass*0.01){
		  dDmi = floor((pmass*0.01)/qmass)*qmass;
		  }*/
		if(qmass < pmass*0.01){
		  dDmi = floor((pmass*0.01)/qmass)*qmass;
		}
		
		if(qtmass-dDmi*pnum < ftmin*mt0){
		  dDmi = qtmass/pnum;
		  idel = 1;	    
		}	
	      }else{
		dDmi = qtmass/pnum;
		idel = 1;
	      }
	      
	      /*   prb0 += eij*hij; 
	      prb1 += iij*hij;
	      prb2 += 1.0;*/

	      /* Judge collision */
	      RN = (double)drand48(); 
	      //  printf("RN %e eij %e, iij %e \n", RN,eij,iij);
	      if(RN < dmdt*dDPBHYB/dDmi){/* collision */
		
		p[i].iColflag = 1; // now unecessary 072215
		//	printf("\n");
		//	printf("!! Collision ST !! time %g yr, pid %d qid %d \n",dTime/(2.0*M_PI),pid,qid);
		if(idel){
		  p[j].iColflag = 3;
		}else{
		  p[j].iColflag = 2;
		}
	  
		//	p[i].iOrderCol = p[j].iOrder;	    
		//	p[i].dtCol = dDmi;

		// now impactor has these information 072215
		p[j].iOrderCol = p[i].iOrder;	    
		p[j].dtCol = dDmi;

		// Do not call collision and stirring routine simultaneously as rb[0] and rb[1] are used for different purposes
	
		goto enloop;

		//break; /* only one collision for one planetesimal in a tracer during dDPBHYB */
	      }
	    } //end type1 
	  endcollision:

	    if(TYPE_PBHYB ==2){ /* stirring start */
	      qes = qmass/(qmass+pmass);
	      qec = pmass/(qmass+pmass);
	      
	      if(p[i].iColor == SUBEMBRYO) qnum -= 1.0; 
	 
	      if(p[i].iColor > SUBEMBRYO ||  (p[i].iColor == SUBEMBRYO && fabs(qa-pa) < drf && fabs(qa-pa) > drm)){
		
		/* calculate PVS QVS, and PDF (PDF = QDF) */
		CalcPstir(eij,iij,&pvs,&qvs,&pdf,&pb);
		//	if(p[i].iColor == SUBEMBRYO){
		//  printf("eij %g, iij %g, b %g, qa %g, pa %g, pvs %g, qvs %g, pdf %g, pd %g \n",eij, iij, (qa-pa)/(ph*pa), qa,pa,pvs,qvs,pdf,pb);
		//	}

		/* printf("pvs %g, qvs %g, pdf %g \n",pvs,qvs,pdf);*/
		
		// corrections due to b-dependence
		/*	if(p[i].iColor == SUBEMBRYO){
		  pvs *= ej;
		  qvs *= ej;	
		  }*/
		
		qes *= qes;
		qec *= qec;
		x = 1.0/area*hij*hij*hij*hij*saij;
	  
		qes *= x*qnum*qcor;
		qec *= x*pnum*pcor; 
		
		pdf /= (hij*hij);

		/* viscous stirring */	
		aa = 2.0*(pvs+qvs);

		pvb0 +=  qes*(aa)*1.0/2.0*aij*aij; /* D for p (random kick in tangential direction) */		
	   
		ej = (p[i].ele[1]*p[j].ele[1] + p[i].ele[2]*p[j].ele[2]);
		ij = (p[i].ele[3]*p[j].ele[3] + p[i].ele[4]*p[j].ele[4]);
	
		        prb1 +=  -qes*(pmass/qmass+1.0)*(pe2-ej)*pdf; /* df for e*/
			prb2 +=  -qes*(pmass/qmass+1.0)*(pi2-ij)*pdf; /* df for i*/ 
			pvb1 +=  qes*(eij*eij*hij*hij)*pdf-qes*(aa-pvs); /* used for random kick in radial direction */		  
			pvb2 +=  qes*qvs + qes*(iij*iij*hij*hij)*pdf; /* used for random kick in vertical direction */
	       	  
		//	prb1 +=  -qes*(pmass/qmass+1.0)*(pe2)*pdf; /* df for e*/
		//		prb2 +=  -qes*(pmass/qmass+1.0)*(pi2)*pdf; /* df for i*/ 
		//		pvb1 +=  qes*(pe2+qe2)*pdf-qes*(aa-pvs); /* used for random kick in radial direction */		  
		//		pvb2 +=  qes*qvs + qes*(pi2+qi2)*pdf; /* used for random kick in vertical direction */


		if(p[i].iColor > SUBEMBRYO){ /* force from subembryo is directly calculated in grav */	       
		  p[j].vb[0] +=  qec*(aa)*1.0/2.0*aij*aij;       
			
		  p[j].rb[1] +=  -qec*(qmass/pmass+1.0)*(qe2-ej)*pdf; /* q e */
		  p[j].rb[2] +=  -qec*(qmass/pmass+1.0)*(qi2-ij)*pdf; /* q i */
		  p[j].vb[1] +=  qec*(eij*eij*hij*hij)*pdf-qec*(aa-pvs); 		
		  p[j].vb[2] +=  qec*qvs + qec*(iij*iij*hij*hij)*pdf;   
	   	 
		  //p[j].rb[1] +=  -qec*(qmass/pmass+1.0)*(qe2)*pdf; /* q e */
		  //p[j].rb[2] +=  -qec*(qmass/pmass+1.0)*(qi2)*pdf; /* q i */
		  //p[j].vb[1] +=  qec*(eij*eij*hij*hij)*pdf-qec*(aa-pvs); 		
		  //p[j].vb[2] +=  qec*qvs + qec*(iij*iij*hij*hij)*pdf;   

		}
		if(p[i].iColor == SUBEMBRYO){      		 	
		  vr2 = 2.0*qnum*qmass/(pmass+qmass)/area*aij*saij*hij*hij*hij*pb;

		  if(p[i].dls <= 0.0 && qa <= pa){ // inner 
		    p[i].fSigf[0] += vr2/(1.0-0.5*drf/pa);
		  }else if (p[i].dls > 0.0 && qa > pa){ //outer
		    p[i].fSigf[0] -= vr2/(1.0+0.5*drf/pa);
		  }

		  /* if(qa <= pa){ // inner 
		    ttsig[0] += vr2/(1.0-0.5*drf/pa);
		  }else{        //dls
		    ttsig[1] -= vr2/(1.0+0.5*drf/pa);
		    }*/		 

		  // p[i].rb[0] += qtmass/area; 
		  //	  p[i].fSigf[0] += 2.0*(pa-qa)/fabs(pa-qa)*qnum*qmass/(pmass+qmass)/area*aij*saij*hij*hij*hij*pb*(1.0-2.0*ph*x);				    
		}
	      }// end close encounter 

	      x = 10.0*h0*pr;
	      if(p[i].iColor == SUBEMBRYO && (fabs(qa-pa) < x || fabs(qa-pa) < drf) && fabs(qa-pa) > drm){// neighbor count for choise of a torque
		if(fabs(qa-pa) > drf) CalcPstir(eij,iij,&pvs,&qvs,&pdf,&pb); //need pb
		//vr2 = (eij*eij+iij*iij);
		//vr2 *= sqrt(vr2);
		//vr2 = 1.0/(1.0+vr2/8.0);	
		if(drf > x) x = drf;
		 if(qa <= pa){ // inner 
		   // nnsig[0] += pb*qtmass/(1.0-0.5*x/pa)/rj0;
		   nnsig[0] += qtmass;
		 }else{        //outer
		   // nnsig[1] += pb*qtmass/(1.0+0.5*x/pa)/rj0;
		   nnsig[1] += qtmass;	   
		 }
	      }
	   
	      if(p[i].iColor == SUBEMBRYO && fabs(qa-pa) > drf){/* distant encounter */
		x = aij/fabs(qa-pa);
	      	hij *= hij;
	      	qes *= qes*qnum/rj0; // rj0 correction added 071514
	      	qec *= qec; // not used
	      	pvs = cd1*hij*hij*hij*x*x*x/dtheta*(saij/(aij*aij)); /* note qes and pvs have diffent dimensions than those above */
	      	qvs = cd2*hij*hij*hij*hij*iij*iij*x*x*x*x*x/dtheta*(saij/(aij*aij)); /* Note iij is redueced one */
	    
	        aa = 2.0*(pvs+qvs);
		//aa = pvs;
	      	pvb0 +=  0.5*qes*(aa)*aij*aij;	
		pvb1 += -qes*(aa-pvs);
		pvb2 += qes*qvs;
		
	      	x = (qa-pa)/(ph*pa);
		p[i].fSigf[1] += -32.0/(x*x*x*x*x)*(1.0+ph*x)*ph*ph*sqrt(pa)*fabs(x)*3.0/8.0*qes*qnum/(qa*dtheta)/rj0; // rj0 correction added 071514
	
	      }//end distant encounter 	  

	    }/* end TYPE_PBHYB ==2 */

	  } /* endif for avioding double count */
	}// nploop 	
      }// ntloop
    }// nrloop
    
  enloop:
    //printf("ok4 i %d r %g \n",i,pr);

    /* if(TYPE_PBHYB ==0){
      p[i].vb[1] = p[i].vb[0]; // copy previous nn (not necessary for here)
      p[i].vb[0] = nn;
      
      // printf("pid %d,r %g, nn %d tsig %g \n",pid,p[i].ele[5],nn,tsig);
      if(p[i].ele[5] < 1.0){
	ttsig[0] += tsig;
	nnsig[0] += nn;
	nbsig[0] ++;
      }else{
	ttsig[1] += tsig;
	nnsig[1] += nn;
	nbsig[1] ++;
      } 
    }*/
    
    if(TYPE_PBHYB ==2){ 
      p[i].rb[0] += prb0;
      p[i].rb[1] += prb1;
      p[i].rb[2] += prb2;
      p[i].vb[0] += pvb0;
      p[i].vb[1] += pvb1;
      p[i].vb[2] += pvb2;

      if(p[i].iColor == SUBEMBRYO){//reset torque at the disk edge

	x = 1.8;
	x = (4.0*M_PI/(3.0*x*x))*pa/(saij*ph*ph)*p[i].fSigf[0];
	if(fabs(x) < 1.0)p[i].fSigf[0] *= fabs(x);

	if((p[i].dls > 0 && nnsig[1]*M_PI/dtheta < ptmass) || (p[i].dls < 0 && nnsig[0]*M_PI/dtheta < ptmass)){
	  // printf("a %g, dls %g nnsig[0]/ptmass %g nnsig[1]/ptmass %g \n",pa, p[i].dls,nnsig[0]/ptmass,nnsig[1]/ptmass);
	  p[i].dls *= 0.999;
	}
      }

    }
    // printf("ok45 i %d  \n",i);

  }//iloop

  /* if(TYPE_PBHYB ==0){
    printf("r < 1 sig %g nn %g n %g \n",ttsig[0]/nbsig[0],nnsig[0]/nbsig[0],nbsig[0]);
    printf("r > 1 sig %g nn %g n %g \n",ttsig[1]/nbsig[1],nnsig[1]/nbsig[1],nbsig[1]);
  }*/


}

void pkdDmdt(PKD pkd,double dTime_now){
  PARTICLE *p;
  MVST *d;
  int i,n,np,ip,nc,iOutcome;
  double mt0 = pkd->param.HY.fMt0;
  double fm,mj,m_now,dTime;
  FILE *fp;
  XDR xdrs;
  COLLIDER c1,c2;

  // printf("pkdDmdt start \n");
  
  p = pkd->pStore;
  n = pkdLocal(pkd);

  np = 0;
  // reset dmdt 
  // first count embryos with >= 10 mt0 
  for (i=0;i<n;++i) {
    p[i].dmdt = -1.0;
    if(p[i].iColor <= SUBEMBRYO && p[i].fMass >= 10.0*mt0) np++;
  }

  if(np == 0) return;
  
  // memory allocation for MVST
  d = calloc(np, sizeof(MVST));

  ip = 0;
  // assign id's for embryos
  for (i=0;i<n;++i) {
    if(p[i].iColor <= SUBEMBRYO && p[i].fMass >= 10.0*mt0){
       d[ip].iOrgIdx = p[i].iOrgIdx;
       d[ip].i = i;
       d[ip].ncoll = 0;
       d[ip].m09 = 0.0;
       d[ip].t09 = 0.0;
       d[ip].fmmin = 100.0;
       ip ++;
    }
  }

  //printf("ok1 \n");
  
  // read ss.coll.bin and give m vs t for embryos
  fp = fopen(pkd->param.achCollLog2,"r");
  if(fp == NULL) {
    //    free(d);
    printf("!!!!! no ss.coll.bin !!!! \n");
    return; /* no coll file; this should not occur unless the file is accidentaly lost */
  }
  xdrstdio_create(&xdrs,fp,XDR_DECODE);

 do{
      if (!xdr_double(&xdrs,&dTime)) {
	  xdr_destroy(&xdrs);
	  (void) fclose(fp);
	  break;
      }
      //assert(dTime <= dTime_now);
      if(dTime > dTime_now){
	printf("dTime %.10e, dTime_now %.10e",dTime,dTime_now);
	assert(0);
      }
      (void) xdr_int(&xdrs,&iOutcome); 
      CollisionData(&xdrs, &c1, &c2);

      // we keep information only after the first hit as ss.coll.bon does not contain times at which
      // embryos are promoted to subembryos from tracers
       //serach for mass which is closest to 0.9 m_now and t at that time
      // if(dTime_now - dTime < 1.e5*2.0*M_PI){
	for (ip=0;ip<np;++ip) {
	  if(c1.id.iOrgIdx == d[ip].iOrgIdx || c2.id.iOrgIdx == d[ip].iOrgIdx){
	    if(c1.fMass > c2.fMass){
	      mj = c1.fMass + 0.5*c2.fMass;
	    }else{
	      mj = 0.5*c1.fMass + c2.fMass;
	    }
	    m_now = p[d[ip].i].fMass;
	    fm = fabs((m_now-mj)/m_now-0.1); // corrected from 0.9 to 0.1
	    if(fm < d[ip].fmmin){
	      d[ip].fmmin = fm;
	      d[ip].m09 = mj;
	      d[ip].t09 = dTime;
	    }
	    d[ip].ncoll ++;
	  }
	}	
	
	//  }
  }while(1);   

 //printf("ok2 \n");

 for (ip=0;ip<np;++ip) {
   nc = d[ip].ncoll; 
   // assert(nc > 0);    // this makes an error if any embryos are placed in the initial condition
   if(nc > 0){ // if nc = 0, dmdt = m/t in pkd_calcrc
     m_now = p[d[ip].i].fMass;
     p[d[ip].i].dmdt = (m_now-d[ip].m09)/(dTime_now - d[ip].t09);
     if(p[d[ip].i].dmdt < 0.1*m_now/dTime_now)p[d[ip].i].dmdt = 0.1*m_now/dTime_now; //added a lower limit on 030317

     printf("ip %d id %d dmdt %g m/t %g m_now %g m09 %g tnow %g t09 %g \n",ip,d[ip].iOrgIdx,p[d[ip].i].dmdt,m_now/dTime_now,m_now,d[ip].m09,dTime_now,d[ip].t09);
   }
 }

 free(d);
 printf("pkdDmdt done \n");
}


void pkdTrPotTable(PKD pkd, double dTime){
  /* Calculate radial and vertical force due to potential of tracers 
     The routine is for serial.
  */
  PARTICLE *p;
  TRACERPOT *PD;
  int i,n,nr,nz,nrmax,nt,nrb,nzb,aga;
  double nzz,ar,az,dz,rpzm,rmzm,temp;
  double rmin,rmax,rfac,lrfac;
  double rp0,h,z,k2,ek,kk,rp,zp,r,dr;
  double r0,ee,r00;								
  double temp2,ar2,az2;

  double h1 = pkd->param.HY.fh1; /* the reduced hill radius a minimum full embryo) */
  double fdr = pkd->param.HY.ffdr;
  double stp = sqrt(2.0*M_PI);
  double fz = 0.2;
  double rsun = pkd->param.dRSunc*0.5; /* solar radius*/

  p = pkd->pStore;
  n = pkdLocal(pkd); 

  PD = pkd->PD;
  PD->dTime = dTime;

  double fSig[nrlim], fh[nrlim], rr[nrlim], fhp[nrlim],zmax[nrlim];
  double zz[nrlim][nzlim],frho[nrlim][nzlim];
  double fSig2[nrlim],frho2[nrlim][nzlim],c2; // for subembryo

  //temporarily use fdr = 1.0 to reduce computatinal cost
  fdr = 1.0;
  //if(n < 1000)fdr = 1.0;
 
  nt = 0;
  /* first calculate rmin and rmax (2d r  ele[5]) */
  rmin = 100.0;
  rmax = 0.0;
  for (i=0;i<n;++i) {
    /*if(p[i].iColor < TRACER) continue;   Tracers Only */
    // if(p[i].iColor < TRACER)nt ++; //THIS LINE LOOKS STRANGE!!!!!! 112016
    // following two lines look correct 
    if(p[i].iColor < TRACER) continue;   /*Tracers Only */
    nt ++;
    
    p[i].ele[5] = sqrt(p[i].r[0]*p[i].r[0]+p[i].r[1]*p[i].r[1]);
    
    ee = sqrt(p[i].ele[1]);
    r00 = p[i].ele[5];
    if(pkd->param.iGravDirect <= 3)r00 = p[i].ele[0];
    r0 = r00*(1.0-ee);    
    if(r0 < rmin) rmin = r0;
    r0 = r00*(1.0+ee);
    if(r0 > rmax) rmax = r0;
  }
  
  if(pkd->param.dRSunc < rmin) rmin = pkd->param.dRSunc;
  
  if(pkd->param.HY.iPebbleSupply){
    if(pkd->param.daout > rmax) rmax = pkd->param.daout;
  }
  
  rmax = rmax*1.5; //test 120815 
  if(rmax > 50.0) rmax = 100.0;
  if(rmin < rsun)rmin = rsun;

  PD->nt = nt;
  if(nt == 0) return;
  
  rfac = 11.0*h1*fdr; /* 1.0+rfac = ratio of radii of the neighboring radial grid points */

  PD->rfac = rfac;
  lrfac = log(1.0+rfac);

  /* add additional meshes at both sides */
  //  rmin = rmin/(1.0+rfac); /* initial grid point for sigma; no particle in this mesh */
  rmin = rmin/((1.0+rfac)*(1.0+rfac)*(1.0+rfac)*(1.0+rfac)); /* one more mesh in each side 042214 now three more 062514*/
  rmax = rmax*(1.0+rfac)*(1.0+rfac)*(1.0+rfac)*(1.0+rfac);

  rp0 = rmin/(1.0+rfac)*(1.0+0.5*rfac); /* initial grid point for pot */
  
  /* Numbers of radial grid points for potential*/
  /* Grid number for sigma is nrmax -1 */
  nrmax = (int)(log(rmax/rmin)/lrfac) + 5;
  assert(nrmax < nrlim);

  PD->nrmax = nrmax;
  
  //printf("rmin  %g rmax %g nrmax %d \n",rmin,rmax,nrmax);


  // reset
  for(nr = 0;nr<nrmax;++nr){ 
      fSig[nr] = 0;
      fSig2[nr] = 0;
      fh[nr] = 0;
      fhp[nr] = 0;
      zmax[nr] = 0;
      if(nr ==0){
	rr[0] = rmin; /* grid point for sigma */
	PD->rp[0] = rp0; /* grid point for potential */
      }else{
	rr[nr] = rr[nr-1]*(1.0+rfac);
	PD->rp[nr] = PD->rp[nr-1]*(1.0+rfac);
      }
      for(nz = 0;nz<nzlim;++nz){
	PD->ar[nr][nz] = 0.0;
	PD->az[nr][nz] = 0.0;
	PD->ar2[nr][nz] = 0.0;
	PD->az2[nr][nz] = 0.0;
      }
  }


  // calculate surface density and scale height
  for (i=0;i<n;++i) {
    if(p[i].iColor < TRACER) continue;   /* Tracers Only */
    
    nr = (int)(log(p[i].ele[5]/rp0)/lrfac);
    assert(nr < nrmax && nr >=0);

    r0 = p[i].ele[0]*sqrt(p[i].ele[2]);
    if(r0 > zmax[nr]) zmax[nr] = r0;

    fSig[nr] += p[i].fMass;
    fh[nr] += p[i].fMass*p[i].r[2]*p[i].r[2];
    fSig2[nr] += p[i].fMass*(p[i].nump-1.0)/p[i].nump;
  }

  /* smoothing (042114 added for test)
  for (nr=0;nr<nrmax;++nr) {
    if(nr == 0){
      fSig[nr] =  (2.0*fSig[nr]+fSig[nr+1])/3.0;  
      fh[nr] =  (2.0*fh[nr]+fh[nr+1])/3.0;  
    }else if(nr == nrmax-1){
      fSig[nr] =  (2.0*fSig[nr]+fSig[nr-1])/3.0;  
      fh[nr] =  (2.0*fh[nr]+fh[nr-1])/3.0;  
    }else{
      fSig[nr] =  0.25*(fSig[nr-1]+2.0*fSig[nr]+fSig[nr+1]);  
      fh[nr] =  0.25*(fh[nr-1]+2.0*fh[nr]+fh[nr+1]);  
    }
    }*/


  // calculate density distribution assuming Gaussian vertical distribution
  for (nr=0;nr<nrmax;++nr) {
    if(fSig[nr] > 0){
      fh[nr] /= fSig[nr];
      fh[nr] = sqrt(fh[nr]);
      if(fh[nr] < 1.e-4)fh[nr] = 1.e-4; // added 122316
      h = fh[nr]; //scale height
      c2 = (1.0+0.5*rfac)*(1.0+0.5*rfac)/(M_PI*rr[nr]*rr[nr]*rfac*(1.0+2.0*rfac)); 
      fSig[nr] *= c2; 
      fSig2[nr] *= c2; 
	  
      // loop for zz
      if(zmax[nr] > 0 && 2.0*zmax[nr] > 6.0*fh[nr]) fh[nr] = zmax[nr]/3.0;   
      dz = fz*fh[nr];   

      for(nz = 0;nz<nzlim;++nz){
	nzz = nz;
	z = (nzz+0.5)*dz;
	zz[nr][nz] = z;
       	PD->zp[nr][nz] = nzz*dz;
	c2 = exp(-(z*z)/(2.0*h*h))/(stp*h);
	frho[nr][nz] = fSig[nr]*c2;
	frho2[nr][nz] = fSig2[nr]*c2;
      }
    }
  }
  
  // so far fh = 0 if fSig = 0 we use fh of neighboring grids. 
  // make fh > 0 for all grids
  do{
    aga = 0;
    for (nr=0;nr<nrmax;++nr) {
      //  printf("aa nr %d  fh %g fhp %g zmax %g fsig %g\n", nr,fh[nr],fhp[nr],zmax[nr],fSig[nr]);
      if(fh[nr] <= 0){     
	aga = 1;
	if(nr ==0 && fh[1] > 0)fh[0] = fh[1];
	if(nr ==nrmax-1 && fh[nrmax-2] > 0)fh[nrmax-1] = fh[nrmax-2];
	if(nr >0 && nr<nrmax-1){
	  fh[nr] = fh[nr+1];
	  if(fh[nr-1] > fh[nr])fh[nr] = fh[nr-1];
	}
	
	if(zmax[nr] > 0 && 2.0*zmax[nr] > 6.0*fh[nr]) fh[nr] = zmax[nr]/3.0;   
	
	if(fh[nr] > 0){ // make zz grid
	  dz = fz*fh[nr];   
	  for(nz = 0;nz<nzlim;++nz){
	    nzz = nz;
	    zz[nr][nz]  = (nzz+0.5)*dz;	 
	    PD->zp[nr][nz] = nzz*dz;
	    frho[nr][nz] = 0.0; // just in case
	    frho2[nr][nz] = 0.0; // just in case

	  }
	}
      }
    }
  }while(aga == 1);
  
  // correct zp grid by taking neighboring zz grid with larger h  
  
    for (nr=0;nr<nrmax;++nr) {
    fhp[nr] = fh[nr];
    if(nr > 0  && fh[nr-1] > fhp[nr]){
      assert(fh[nr] > 0);
      fhp[nr] = fh[nr-1];  
      dz = fz*fh[nr];   
      for(nz = 0;nz<nzlim;++nz){
	nzz = nz;
	PD->zp[nr][nz] = nzz*dz;
      }
    }
    //   printf("nr %d rr %g fh %g fhp %g zmax %g \n", nr,rr[nr],fh[nr],fhp[nr],zmax[nr]);
    }


  //quartic loop for potential calculation
  for(nr = 0;nr<nrmax;++nr){
     assert(fhp[nr] > 0);  // corrected 051414
    rp = PD->rp[nr];    
    for(nz = 0;nz<nzlim;++nz){
      zp = PD->zp[nr][nz];
      ar = 0.0;
      az = 0.0;   
      ar2 = 0.0;
      az2 = 0.0;  
   
      for(nrb = 0;nrb<nrmax-1;++nrb){
	if(fSig[nrb]<=0)continue;
	r = rr[nrb];
	dr = r*rfac/(1.0+0.5*rfac);
	for(nzb = 0;nzb<nzlim;++nzb){
	  z = zz[nrb][nzb];
	  dz = zz[nrb][1]-zz[nrb][0];
	  rpzm = (zp-z)*(zp-z);
	  rmzm = rpzm + (rp-r)*(rp-r);
	  rpzm += (rp+r)*(rp+r);
	  k2 = (4.0*rp*r)/rpzm;	  
	  calc_ellip(k2,&kk,&ek);
	  
	  c2 = -2.0/sqrt(rpzm)*r*dr*dz;
	  temp = frho[nrb][nzb]*c2;
	  temp2 = frho2[nrb][nzb]*c2;
	  //	  temp = -2.0*(frho[nrb][nzb]/sqrt(rpzm))*r*dr*dz;
	  ek /= rmzm;

	  ar += (temp/rp)*(ek*(rp*rp-r*r - (zp-z)*(zp-z)) + kk);
	  az += 2.0*temp*(zp-z)*ek;
	  ar2 += (temp2/rp)*(ek*(rp*rp-r*r - (zp-z)*(zp-z)) + kk);
	  az2 += 2.0*temp2*(zp-z)*ek;

	  z = -z;

	  rpzm = (zp-z)*(zp-z);
	  rmzm = rpzm + (rp-r)*(rp-r);
	  rpzm += (rp+r)*(rp+r);
	  k2 = (4.0*rp*r)/rpzm;	  
	  calc_ellip(k2,&kk,&ek);

	  c2 = -2.0/sqrt(rpzm)*r*dr*dz;

	  temp = frho[nrb][nzb]*c2;
	  temp2 = frho2[nrb][nzb]*c2;

	  ek /= rmzm;

	  ar += (temp/rp)*(ek*(rp*rp-r*r - (zp-z)*(zp-z)) + kk);
	  az += 2.0*temp*(zp-z)*ek;

	  ar2 += (temp2/rp)*(ek*(rp*rp-r*r - (zp-z)*(zp-z)) + kk);
	  az2 += 2.0*temp2*(zp-z)*ek;
	}
      }    
      PD->ar[nr][nz] = ar;
      PD->az[nr][nz] = az;
      PD->ar2[nr][nz] = ar2;
      PD->az2[nr][nz] = az2;
      //printf("nr %d nz %d rp %g zp %g ar %g az %g \n",nr,nz,rp,zp,ar,az);
    }
  }

 

  
}
  

void pkdTrPotAcc(PKD pkd, double dTime){  
  
  int i,j,n;
  PARTICLE *p; 
  TRACERPOT *PD;
  double big = 1.0e8;
  double rp0,x,y,z,r,rr0,rr1,dz0,dz1,zz00,zz01,zz10,zz11;
  double dr00, dr01,dr10,dr11,drtotal,a_r,a_z,lrfac,fz;
  int nr,nz0,nz1,nrmax;

  PD = pkd->PD;
  p = pkd->pStore;
  n = pkdLocal(pkd);
  lrfac = log(1.0+PD->rfac);
  nrmax = PD->nrmax;

  rp0 = PD->rp[0];
  if(rp0 == 0) return; // no tracer

  if (pkd->param.bVDetails) printf("pkdTrPotAcc dTime %g \n",dTime);
  for(i=0;i<n;++i) {	
    assert(pkdIsActive(pkd,&p[i]));
    if(p[i].iOrder < 0) continue;

    if(p[i].iColor >= SUBEMBRYO){ 
    // if(p[i].iColor == SUBEMBRYO){ //test
      x = p[i].r[0];
      y = p[i].r[1];
      z = p[i].r[2];
      fz = fabs(z);
      r = sqrt(x*x+y*y);
      nr = (int)(log(r/rp0)/lrfac);
    
      if(nr<0 || nr >= nrmax){
	printf("i %d, r %g, x,y,z %g %g %g a %g, e %g i %g rp0 %g, nr %d log %g, lrfac %g, rfac %g col %d masst %g mass %g \n",
	       i,r,x,y,z,p[i].ele[0],sqrt(p[i].ele[1]),sqrt(p[i].ele[2]),rp0,nr,log(r/rp0),lrfac,PD->rfac,p[i].iColor,p[i].fMass,p[i].fMass/p[i].nump);
      }

      // assert(nr>=0 && nr < nrlim);
      if(nr < 0)nr = 0; //extrapolate potential if nr < 0 072314 
      if(nr >= nrmax)nr = nrmax-1; // 072814

      rr0 = PD->rp[nr];
      rr1 = PD->rp[nr+1];
      
      dz0 = PD->zp[nr][1]-PD->zp[nr][0];
      nz0 = (int)(fabs(z/dz0));
      if(nz0 >= nzlim)nz0 = nzlim-1; 
      dz1 = PD->zp[nr+1][1]-PD->zp[nr+1][0];
      nz1 = (int)(fabs(z/dz1));
      if(nz1 >= nzlim)nz1 = nzlim-1; 

      zz00 = PD->zp[nr][nz0];
      zz01 = PD->zp[nr][nz0+1];
      zz10 = PD->zp[nr+1][nz1];	
      zz11 = PD->zp[nr+1][nz1+1];
      
      dr00 = (fz-zz00)*(fz-zz00) + (r-rr0)*(r-rr0);
      dr01 = (fz-zz01)*(fz-zz01) + (r-rr0)*(r-rr0);
      dr10 = (fz-zz10)*(fz-zz10) + (r-rr1)*(r-rr1);
      dr11 = (fz-zz11)*(fz-zz11) + (r-rr1)*(r-rr1);
      
      dr00 = MIN(1.0/dr00,big);
      dr01 = MIN(1.0/dr01,big);
      dr10 = MIN(1.0/dr10,big);
      dr11 = MIN(1.0/dr11,big);
      drtotal = dr00 + dr01 + dr10 + dr11;
      
      if(p[i].iColor == SUBEMBRYO){
      	a_r = PD->ar2[nr][nz0]*dr00 + PD->ar2[nr][nz0+1]*dr01 + PD->ar2[nr+1][nz1]*dr10 + PD->ar2[nr+1][nz1+1]*dr11;
      	a_z = PD->az2[nr][nz0]*dr00 + PD->az2[nr][nz0+1]*dr01 + PD->az2[nr+1][nz1]*dr10 + PD->az2[nr+1][nz1+1]*dr11;
      }else{
	a_r = PD->ar[nr][nz0]*dr00 + PD->ar[nr][nz0+1]*dr01 + PD->ar[nr+1][nz1]*dr10 + PD->ar[nr+1][nz1+1]*dr11;
	a_z = PD->az[nr][nz0]*dr00 + PD->az[nr][nz0+1]*dr01 + PD->az[nr+1][nz1]*dr10 + PD->az[nr+1][nz1+1]*dr11;
      }

      a_r /=  drtotal;
      a_z /=  drtotal;


      if(z<0)a_z *= -1.0;
      
      p[i].a[0] += a_r*x/r;
      p[i].a[1] += a_r*y/r;
      p[i].a[2] += a_z;


      p[i].a_pr += (a_r*r + a_z*z)*sqrt(x*x+y*y+z*z);
       
      //printf("dTime %g, r %g, z %g a_r %g, a_z %g, a_pr %g nr %d nz0 %d nz1 %d a %g e %g i %g \n",dTime,r,z,a_r,a_z,p[i].a_pr,nr,nz0,nz1,p[i].ele[0],sqrt(p[i].ele[1]),sqrt(p[i].ele[2]));
           
      
      /*if(i == 0){
	int nz;
	for (nr=0;nr<nrlim;++nr){
	  for(nz=0;nz<nzlim;++nz){
	    printf("nr %d, nz %d, r %g, z %g, ar %g, az %g \n",nr,nz,PD->rp[nr],PD->zp[nr][nz],PD->ar[nr][nz],PD->az[nr][nz]);
	  }
	}
	}*/
      
      if(fabs(p[i].a[0]) < 100.0){
      }else{
	printf("r %g drtotal %g a_r %g a_z %g \n",r,drtotal,a_r,a_z);
	printf("aaaa oid=%d, col = %d, rung = %d (x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), m = %e \n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],p[i].fMass);
	for (i=0;i<n;++i){
	  printf("oid=%d, col = %d, rung = %d,(x,y,z)= (%e,%e,%e),(vx,vy,vz)= (%e,%e,%e), m = %e \n",p[i].iOrgIdx,p[i].iColor,p[i].iRung,p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2],p[i].fMass);
	}

	/*	int nz;
	for (nr=0;nr<nrlim;++nr){
	  for(nz=0;nz<nzlim;++nz){
	    printf("r %g, z %g, ar %g, az %g \n",PD->rp[nr],PD->zp[nr][nz],PD->ar[nr][nz],PD->az[nr][nz]);
	  }
	  }*/


	//	assert(0);
      }
      
    }
  }

}




#endif /* sm2d */

#endif /* SYMBA */
#endif /* PLANETS */


