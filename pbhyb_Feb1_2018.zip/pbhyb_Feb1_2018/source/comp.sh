#!/bin/sh
# make mvapich2
###################################################
#
# script to install mvapich2 to Schroedinger
# chribo, 2009-09-24
#
#
#
####################################################

#$ -S /bin/sh
#$ -N make.pkd
#$ -cwd
#$ -j y
#$ -o $JOB_NAME-$JOB_ID.out

# initial settings
execdir=`pwd`

# clean up first
make distclean
make clean

# set environment for make
export ARCH="_X86_64_"
export COMPAT="AUTO_DETECT"
export IBHOME="/usr"
export IBHOME_LIB="/usr/lib64"
export RSHCOMMAND="rsh"
export OPT_FLAG="-march=core2 -mtune=native -O3"

#configure with options
./configure --prefix=/panfs/panfs0.ften.es.hpcn.uzh.ch/mpi-libs/gcc/mvapich2-1.4rc2 \
    --enable-f77 --enable-f90 --enable-cxx --enable-romio --enable-soft-linear \
    --enable-planets --enable-symba

echo "=====config-end======"

# make if a make file has been created
if [ -f Makefile ]
    then
    echo "+++++ compilation +++++"
    make
else
    echo "no makefile"
fi
