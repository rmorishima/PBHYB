#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef PLANETS

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>

#include "collision.h"
#include "../analysis/delaunay.h"
#include "../analysis/helio.h"
#include "../analysis/ss.h"

#define BOUNCE_OK 0
#define NEAR_MISS 1


void
pkdNextCollision(PKD pkd,double *dt,int *iOrder1,int *iOrder2)
{
	/*
	 ** Returns time and iOrder of particles for earliest predicted
	 ** collision on this processor. Argument initialization must
	 ** occur in calling routine.
         ** (!!Note temporary we are using iOrgIdx in stead of dtCol)
	 */

	PARTICLE *p;
	int i;

	for (i=0;i<pkdLocal(pkd);i++) {
		p = &pkd->pStore[i];

		//check only impactor with icolflag >=2 
		if (p->iColflag < 2) continue; /* skip particles without collision flag; colflag = 1 is the target, we skip them*/
       
		if (!pkdIsActive(pkd,p)) continue; /* skip over inactive particles */
		if (p->iOrder < 0) continue; /* skip over deleted particles */				
		if (p->dtCol < *dt) {
			*dt = p->dtCol;
			*iOrder2 = p->iOrder; // iorder2 for impactor
			*iOrder1 = p->iOrderCol; //target		
			}
		}
	}

void
pkdGetColliderInfo(PKD pkd,int iOrder,COLLIDER *c)
{
	/*
	 ** Returns collider info for particle with matching iOrder.
	 */

	PARTICLE *p;
	int i,j,k;

	for (i=0;i<pkdLocal(pkd);i++) {
		p = &pkd->pStore[i];
		if (p->iOrder == iOrder) {		 
			c->id.iPid = pkd->idSelf;		
			c->id.iOrder = iOrder;
			c->id.iIndex = i;
			c->id.iOrgIdx = p->iOrgIdx;			
			c->fMass = p->fMass;
			c->fRadius = p->fSoft;
			c->fGasMass = p->fGasMass;
			for (j=0;j<3;j++) {
				c->r[j] = p->r[j];
				c->v[j] = p->v[j];
				c->w[j] = p->w[j];
				c->rb[j] = p->rb[j]; // relative e and i 031214, not used now
				c->vb[j] = p->vb[j]; // velocity relative to local keplerian
#ifdef HERMITE
				c->a[j] = p->a[j];
				c->ad[j] = p->ad[j];
#endif
				}
#ifdef SYMBA		
			c->drmin = p->drmin;
			c->n_VA = p->n_VA;
			c->hill=p->hill;
			c->rcrit=p->rcrit;
			for(k=0;k<p->n_VA;k++){
			    c->iOrder_VA[k]=p->iOrder_VA[k];
			    c->i_VA[k]=p->i_VA[k];			
			    }
			c->nump = p->nump;
			c->dls = p->dls; /* added 012314 */
			c->a_pr = p->a_pr;
			c->mmin = p->mmin;
			c->St = p->St;
#endif
#ifdef sm2d
			for (j=0;j<11;j++) {
			  c->ele[j] = p->ele[j];
			}		
			c->iColflag = p->iColflag;
			c->dDmi = p->dtCol; 
#endif
			c->iColor = p->iColor;
			c->dt = p->dt;
			c->iRung = p->iRung;		
			//	if((pkd->param.GP.bDragEnhance & 2) && p->iColor <= PLANETESIMAL){
			c->fac = 1.0;
			if(pkd->param.GP.bDragEnhance == 2){
			  c->fac = p->ele[3];     /* mod 071213;  atmospheres of full embryos for PBHYB */	      
			}	      
			
			return;
			}
		}
	}

void PutColliderInfo(const COLLIDER *c,int iOrder2,PARTICLE *p,double dt)
{
	/*
	 ** Stores collider info in particle structure (except id & color).
	 ** Also, dt is stored in dtPrevCol for inelastic collapse checks.
	 **
	 ** NOTE: Because colliding particles have their positions traced back to
	 ** the start of the step using their NEW velocities, it is possible for
	 ** a neighbour to no longer lie inside a previous collider's search ball.
	 ** To fix this, the ball radius is expanded by a conservative estimate of
	 ** the displacement amount (using the "Manhattan metric").
	 */

	int i,k;
	double r;

	p->fMass = c->fMass;
	p->fSoft = c->fRadius;
	p->fGasMass = c->fGasMass;
	r = fabs(c->r[0] - p->r[0]) +
		fabs(c->r[1] - p->r[1]) +
		fabs(c->r[2] - p->r[2]);
	for (i=0;i<3;i++) {
	  p->r[i] = c->r[i];
	  p->v[i] = c->v[i];
	  p->w[i] = c->w[i];
#ifdef HERMITE
	  p->a[i] = c->a[i];
	  p->ad[i] = c->ad[i];
#endif
	}
		
#ifdef SYMBA

	p->drmin = c->drmin;
	p->n_VA = c->n_VA;
	p->hill=c->hill;
	p->rcrit=c->rcrit;
	for(k=0;k<c->n_VA;k++){
	    p->iOrder_VA[k]=c->iOrder_VA[k];
	    p->i_VA[k]=c->i_VA[k];
	}
	p->a_pr = 0.0; // c->a_pr not explicity defined
	p->mmin = 0.0;  // not defined
	p->St = c->St;
#ifdef sm2d
	p->nump = c->nump;
	p->dls = c->dls;
	p->ele[8] = c->fRadius/cbrt(c->nump*1.0); /* physical radius of a planetesimal in a tracer */
#endif

#endif
	p->iRung = c->iRung;
	p->iColor = c->iColor; /* this is added for sm2d */
	/*p->fBall2 += 2*sqrt(p->fBall2)*r + r*r;
	p->dtPrevCol = dt;
	p->iPrevCol = iOrder2;  stored to avoid false collisions */
	p->dtCol = DBL_MAX; /* nessesary in pkdNextcollision */  
	p->iColflag = 0;  /* here we reset collision flag */
	}

void
pkdMerge(PKD pkd,const COLLIDER *c1,const COLLIDER *c2,double dDensity,
		 COLLIDER **cOut,int *pnOut)
{
	/*
	 ** Merges colliders into new centre-of-mass particle (cOut[0])
	 ** with radius determined by the supplied fixed bulk density.
	 ** If dDensity is zero, the radius of the merged particle is
	 ** instead set by the bulk density of the largest collider.
	 */

	const double dDenFac = 4.0/3*M_PI;
	int iOrderTemp;
	
	COLLIDER *c;
	double com_pos[3],com_vel[3],rc1[3],rc2[3],vc1[3],vc2[3],ang_mom[3];
	double m1,m2,m,r1,r2,r,i1,i2,i;
	int k,j;
	double com_a[3],com_ad[3];
	double lz1,lz2,fsub; //120216
	m1 = c1->fMass;
	m2 = c2->fMass;
	m = m1 + m2;
	r1 = c1->fRadius;
	r2 = c2->fRadius;
	if (c1->iColor == TEST && c2->iColor != TEST) r1 = 0.0;
	if (c1->iColor != TEST && c2->iColor == TEST) r2 = 0.0;

	if (dDensity)
	  r = (m2 > m1 ? r2*pow(m/m2,1.0/3) : r1*pow(m/m1,1.0/3));
	/*r = pow(m/(dDenFac*dDensity),1.0/3);*/
	else
	  r = pow(r1*r1*r1 + r2*r2*r2,1.0/3); /*conserves volume */
	i1 = 0.4*m1*r1*r1;
	i2 = 0.4*m2*r2*r2;
	i = 0.4*m*r*r;

	// 120216
	lz1 = (rc1[0]*vc1[1] - rc1[1]*vc1[0]);
	lz2 = (rc2[0]*vc2[1] - rc2[1]*vc2[0]);
	/*if(c1->iColor == SUBEMBRYO && c2->iColor > SUBEMBRYO){
	  fsub 	=  sqrt(((m1*lz1 + m2*lz2)/m)/((m1*lz1+m2*lz2/c2->nump)/(m1+m2/c2->nump)));
	}
	if(c2->iColor == SUBEMBRYO && c1->iColor > SUBEMBRYO){
	  fsub 	=  sqrt(((m1*lz1 + m2*lz2)/m)/((m1*lz1/c1->nump+m2*lz2)/(m1/c1->nump+m2)));
	  }*/
	fsub = 1.0;
	
	for (k=0;k<3;k++) {
		com_pos[k] = (m1*c1->r[k] + m2*c2->r[k])/m;		
		rc1[k] = c1->r[k] - com_pos[k];
		rc2[k] = c2->r[k] - com_pos[k];
		com_vel[k] = (m1*c1->v[k] + m2*c2->v[k])/m;
		vc1[k] = c1->v[k] - com_vel[k];
		vc2[k] = c2->v[k] - com_vel[k];
#ifdef HERMITE
		com_a[k] = (m1*c1->a[k] + m2*c2->a[k])/m;
		com_ad[k] = (m1*c1->ad[k] + m2*c2->ad[k])/m;
#endif
		//120216 added
		if(c1->iColor == SUBEMBRYO && c2->iColor > SUBEMBRYO){
		  com_pos[k] = fsub*(m1*c1->r[k] + m2*c2->r[k]/c2->nump)/(m1+m2/c2->nump);
		  com_vel[k] = 1.0/sqrt(fsub)*(m1*c1->v[k] + m2*c2->v[k]/c2->nump)/(m1+m2/c2->nump);			  
		}
		if(c2->iColor == SUBEMBRYO && c1->iColor > SUBEMBRYO){
		  assert(0);
		  com_pos[k] = fsub*(m1*c1->r[k]/c1->nump + m2*c2->r[k])/(m1/c1->nump+m2);
		  com_vel[k] = 1.0/sqrt(fsub)*(m1*c1->v[k]/c1->nump + m2*c2->v[k])/(m1/c1->nump+m2);		  
		}
		
	}



	
	ang_mom[0] = m1*(rc1[1]*vc1[2] - rc1[2]*vc1[1]) + i1*c1->w[0] +
		         m2*(rc2[1]*vc2[2] - rc2[2]*vc2[1]) + i2*c2->w[0];
	ang_mom[1] = m1*(rc1[2]*vc1[0] - rc1[0]*vc1[2]) + i1*c1->w[1] +
				 m2*(rc2[2]*vc2[0] - rc2[0]*vc2[2]) + i2*c2->w[1];
	ang_mom[2] = m1*(rc1[0]*vc1[1] - rc1[1]*vc1[0]) + i1*c1->w[2] +
				 m2*(rc2[0]*vc2[1] - rc2[1]*vc2[0]) + i2*c2->w[2];

	*pnOut = 1;
	*cOut = (COLLIDER *) malloc(*pnOut*sizeof(COLLIDER));
	assert(*cOut != NULL);

	c = &(*cOut)[0];

	/* Note: id info set in pkdDoCollision(), used only for log */

	c->fMass = m;
	c->fRadius = r;
	c->fGasMass = c1->fGasMass + c2->fGasMass;
	
	/* added as color and nump are handed at putcolliderinfo: this is the most safe way to define c->iColor */
	c->iColor = (c1->iColor<c2->iColor ? c1->iColor : c2->iColor);	
	c->nump = 1.0;

	// added 052914
	if(c->iColor == SUBEMBRYO && c->fMass >=  pkd->param.HY.fMt0*pkd->param.HY.fff)c->iColor = PLANETESIMAL;

	for (k=0;k<3;k++) {
		c->r[k] = com_pos[k];
		c->v[k] = com_vel[k];
		c->w[k] = ang_mom[k]/i;
#ifdef HERMITE
		c->a[k] = com_a[k];
		c->ad[k] = com_ad[k];
#endif
		}
#ifdef SYMBA
	c->drmin = c1->drmin;
	c->n_VA = 0;
	c->dls = (c1->dls*m1 + c2->dls*m2)/m; /* added 012314  mass weight corrected 072314 */

	if(c1->n_VA > 1){
	    /* copy neiboring list of c1 to that of c excluding particle c2*/
	    for(k=0;k<c1->n_VA;k++){
		if(c1->iOrder_VA[k] != c2->id.iOrder){
		    c->iOrder_VA[c->n_VA] = c1->iOrder_VA[k];
		    c->i_VA[c->n_VA] = c1->i_VA[k];		   
		    /* Since mass has changed, this is not exactly correct!
		       But probably does not cause any problem */ 	 
		    c->n_VA++;
		}
	    }
	}
	
	if(c2->n_VA > 0){
	    for(k=0;k<c2->n_VA;k++){
		iOrderTemp = c2->iOrder_VA[k];
		/* check if neigboring particles for c2 are already included 
		   in the list for c */ 
		if(iOrderTemp == c1->id.iOrder)goto skip_VA;
		for(j=0;j<c->n_VA;j++){
		    if(iOrderTemp == c->iOrder_VA[j])goto skip_VA;
		}			
		c->iOrder_VA[c->n_VA] = iOrderTemp;
		c->i_VA[c->n_VA] = c2->i_VA[k];	
		c->n_VA++;
	    skip_VA: 
		continue;
	    }
	}

	printf("pkdmerge id1 %d col1 %d mass1 %e nva1 %d id2 %d col2 %d masst2 %e mass2 %e nva2 %d \n",c1->id.iOrgIdx,c1->iColor,c1->fMass,c1->n_VA,c2->id.iOrgIdx,c2->iColor,c2->fMass,c2->fMass/c2->nump,c2->n_VA);

#endif
	
	/* Set merger's timestep to iRung of largest mass. */
	/* XXX there is a bug in changing timesteps during a collision 
	   but this makes it less bothersome. */
	/*c->iRung = (c2->fMass > c1->fMass ? c2->iRung : c1->iRung);*/
	c->iRung = (c2->iRung > c1->iRung ? c2->iRung : c1->iRung);

	/* for quick care -- should be modified? */
	c->hill =  (c2->hill > c1->hill ? c2->hill : c1->hill); 
	c->rcrit =  (c2->rcrit > c1->rcrit ? c2->rcrit : c1->rcrit); 
}

int
pkdBounce(PKD pkd,const COLLIDER c1,const COLLIDER c2,
		  double dEpsN,double dEpsT,int bFixCollapse,
		  COLLIDER **cOut,int *pnOut)
{
	/* Bounces colliders, preserving particle order */

	COLLIDER *co1,*co2;
	double n[3],s1[3],s2[3],v[3],s[3],u[3],un[3],ut[3],p[3],q[3];
	double m1,m2,m,r1,r2,i1,i2,mu,alpha,beta;
	double a,b,c,d;
	int i;
	double ve2,ut2,un2;
/*DEBUG verbose EpsN, EpsT output
	(void) printf("e_n = %g e_t = %g\n",dEpsN,dEpsT);
*/

	*pnOut = 2;
	*cOut = (COLLIDER *) malloc(*pnOut*sizeof(COLLIDER));
	assert(*cOut != NULL);
	
	(*cOut)[0] = c1; 
	(*cOut)[1] = c2;

	co1 = &(*cOut)[0];
	co2 = &(*cOut)[1];
	
	/*m1 = c1->fMass;
	m2 = c2->fMass;
	m = m1 + m2;
	r1 = c1->fRadius;
	r2 = c2->fRadius;*/
	
	m1 = c1.fMass;
	m2 = c2.fMass;
	r1 = c1.fRadius;
	r2 = c2.fRadius;
	if(c1.iColor == SUBEMBRYO && c2.iColor > SUBEMBRYO){
	  m2 /= c2.nump;
	  r2 /= cbrt(c2.nump);
	}
	m = m1 + m2;
	ve2 = 2.0*(m1 + m2)/(r1 + r2);
	i1 = 0.4*m1*r1*r1;
	i2 = 0.4*m2*r2*r2;
	mu = m1*m2/m;
	//	alpha = 2.5*(1/m1 + 1/m2);
	//beta = 1/(1 + alpha*mu);
	alpha = 2.5/mu;
	beta = 2.0/7.0;

	a = 0;
	for (i=0;i<3;i++) {
	  /*n[i] = (c2->r[i] - c1->r[i]);*/
	  n[i] = (c2.r[i] - c1.r[i]);
	  
		a += n[i]*n[i];
		}
	a = 1/sqrt(a);
	for (i=0;i<3;i++)
		n[i] *= a;

	/* s1[0] = r1*(c1->w[1]*n[2] - c1->w[2]*n[1]);
	s1[1] = r1*(c1->w[2]*n[0] - c1->w[0]*n[2]);
	s1[2] = r1*(c1->w[0]*n[1] - c1->w[1]*n[0]);

	s2[0] = r2*(c2->w[2]*n[1] - c2->w[1]*n[2]);
	s2[1] = r2*(c2->w[0]*n[2] - c2->w[2]*n[0]);
	s2[2] = r2*(c2->w[1]*n[0] - c2->w[0]*n[1]);*/

	/*	s1[0] = r1*(c1.w[1]*n[2] - c1.w[2]*n[1]);
	s1[1] = r1*(c1.w[2]*n[0] - c1.w[0]*n[2]);
	s1[2] = r1*(c1.w[0]*n[1] - c1.w[1]*n[0]);

	s2[0] = r2*(c2.w[2]*n[1] - c2.w[1]*n[2]);
	s2[1] = r2*(c2.w[0]*n[2] - c2.w[2]*n[0]);
	s2[2] = r2*(c2.w[1]*n[0] - c2.w[0]*n[1]);*/
	

	for (i=0;i<3;i++) {
	  /*v[i] = c2->v[i] - c1->v[i];*/
	  v[i] = c2.v[i] - c1.v[i];
	  //		s[i] = s2[i] - s1[i];
	}
	
	for (i=0;i<3;i++){
	  //		u[i] = v[i] + s[i];
	  u[i] = v[i];
	}
	
	a = u[0]*n[0] + u[1]*n[1] + u[2]*n[2]; /* relative vel in normal direction */
	if (a >= 0) {
#if (INTERNAL_WARNINGS)
		static int bGiveWarning = 1;
		if (bGiveWarning) {
			(void) fprintf(stderr,"WARNING: %i & %i -- near miss? (a = %g)\n",
						   c1->id.iOrder,c2->id.iOrder,a);
#if (INTERNAL_WARNINGS_ONCE)
			bGiveWarning = 0;
#endif
			}
#endif /* INTERNAL WARNINGS */

		if (bFixCollapse)
			return NEAR_MISS; /* particles remain unchanged */
		else
			assert(0); /* near miss not allowed */
		}
	ut2 = 0.0;
	un2 = 0.0;
	for (i=0;i<3;i++) {
		un[i] = a*n[i];
		ut[i] = u[i] - un[i];

		ut2 += ut[i]*ut[i]; 
		un2 += un[i]*un[i]; 
		}

	if(dEpsN*dEpsN*un2 + ut2 < ve2){/* post-impact relative velocity is lower than the escape velocity; 
					   here we set new dEpsN so that relative velocity is ve */
	  
	  dEpsN = sqrt((ve2-ut2)/un2)+1.e-5;
	  if(dEpsN > 1.0)dEpsN = 1.0;
	  //assert(dEpsN < 1.0);
	}


	a = (1 + dEpsN);
	b = beta*(1 - dEpsT);
	for (i=0;i<3;i++)
		p[i] = a*un[i] + b*ut[i];

	a = mu*b;
	q[0] = a*(n[1]*u[2] - n[2]*u[1]);
	q[1] = a*(n[2]*u[0] - n[0]*u[2]);
	q[2] = a*(n[0]*u[1] - n[1]*u[0]);

	a =   m2/m;
	b = - m1/m;

	// no spin change due to bouncing
	//	c = r1/i1;
	//	d = r2/i2;

	/*co1 = &(*cOut)[0];
	  co2 = &(*cOut)[1];*/

	for (i=0;i<3;i++) {
		co1->v[i] += a*p[i];
		co2->v[i] += b*p[i];
		//	co1->w[i] += c*q[i];
		//	co2->w[i] += d*q[i];
		}

/*DEBUG -- dT check
	{
	double dT;
	dT =
		- mu*(v[0]*p[0] + v[1]*p[1] + v[2]*p[2]) +
			0.5*mu*(p[0]*p[0] + p[1]*p[1] + p[2]*p[2]) +
				(r1*c1->w[0] + r2*c2->w[0])*q[0] +
					(r1*c1->w[1] + r2*c2->w[1])*q[1] +
						(r1*c1->w[2] + r2*c2->w[2])*q[2] +
							0.5*alpha*(q[0]*q[0] + q[1]*q[1] + q[2]*q[2]);
	(void) printf("COLLISION %i & %i e_n=%f e_t=%f dT %e\n",
				  c1->id.iOrder,c2->id.iOrder,dEpsN,dEpsT,dT);
	}
*/

	return BOUNCE_OK;
	}

void
pkdFrag(PKD pkd,const COLLIDER *c1,const COLLIDER *c2,
		COLLIDER **cOut,int *pnOut)
{
	/*
	 ** Fragments colliders into at most MAX_NUM_FRAG pieces.
	 ** Not implemented yet. Development notes:
	 ** - be sure new particles are ACTIVE
	 ** - may need to assert(*pnOut <= MAX_NUM_FRAG)
	 ** - remember to set id info for logging purposes
	 ** - and decide on starting iRung values
	 ** - and assign colors
	 */
	}



void
pkdDoCollision(PKD pkd,double dt, const COLLIDER *pc1, const COLLIDER *pc2,
	       int bPeriodic,const COLLISION_PARAMS *CP,int *piOutcome, 
	       double *dT, COLLIDER *cOut, int *pnOut)
{

  /* this is called by pkdDoCollisionVeryactive */

	/*
	 ** Processes collision by advancing particle coordinates to impact
	 ** time, determining the collision outcome, and moving the resulting
	 ** particles back to their (new) start-of-step positions. Diagnostic
	 ** info is returned if the first collider resides on the processor
	 ** (the second collider may not be local, in which case this routine
	 ** is called twice in parallel, once for each particle). Local copies
	 ** of the collider info are used because the particle coordinates need
	 ** to be advanced to the moment of collision. With periodic boundary
	 ** conditions, the second collider may be offset by one period as well.
	 ** The offset is removed before calling PutColliderInfo().
	 */

	COLLIDER c1,c2,*c;
	double v2,ve2,r2,rv,vcri2,rv0;
	int bDiagInfo,iOutcome,i,j,n,iflag; /*DEBUG would bReportInfo be better?*/
	double r, v, Radii,fac, a1,a2,ac,gam,c2Mass;
	double dSunMass = pkd->dSunMass;
	int CPiOut = CP->iOutcomes;
	
	if(CPiOut > 3) CPiOut=3; // no fragmentation for embryos

/*DEBUG verbose collision output
	(void) printf("COLLISION %i & %i (dt = %.16e)\n",
				  pc1->id.iOrder,pc2->id.iOrder,dt);
*/

	/* Get local copies of collider info */

	c1 = *pc1; /* struct copy  */
	c2 = *pc2;

	bDiagInfo = (c1.id.iPid == pkd->idSelf);

	if (bDiagInfo && dT) *dT = 0;

	/* Trace particles back to impact time*/ 
	r2 = 0.0;
	rv = 0.0;
	v2 = 0.0;
	for (i=0;i<3;i++) {
	  r = c2.r[i] - c1.r[i];
	  v = c2.v[i] - c1.v[i];
	  r2 += r*r;
	  rv += r*v;
	  v2 += v*v;
	}
	
	fac = 1.0;
	
	//c1 c2 replaced 072215, atmosphere not used so far 
	//	if((pkd->param.GP.bDragEnhance & 2) && c2.iColor <= PLANETESIMAL){
	if(pkd->param.GP.bDragEnhance == 2){
	  fac = c2.fac;
	  assert(fac >= 1.0);
	  assert(c1.iColor <= SUBEMBRYO);
	  if(fac > 1.0)CPiOut=MERGE; // merging forced for a collision with the capturing atmosphere
	}
	Radii = fac*c1.fRadius + c2.fRadius/cbrt(c2.nump);

	//	if(c1.iColor == SUBEMBRYO && c2.iColor >= TRACER) Radii = fac*c1.fRadius + c2.fRadius/cbrt(c2.nump); 
	if(c1.iColor == TEST && c2.iColor != TEST) assert(0); 
	if(c1.iColor != TEST && c2.iColor == TEST) Radii = fac*c1.fRadius; 

	//r2 -= Radii*Radii;
	//	r2 = sqrt(r2);
	//dt = (Radii-r2)/(rv/r2);	

	if(rv*rv < v2*(r2-Radii*Radii)){
	    dt = -pkd->param.dDelta/pow(3.0,pkd->pStore[c1.id.iIndex].iRung);
	    printf("rv*rv-v2*r2 = %e \n",rv*rv-v2*(r2-Radii*Radii));
	}else{
	    dt = -(rv+sqrt(rv*rv-v2*(r2-Radii*Radii)))/v2;	
	}
	  printf(" dr %10e Radii %10e Radii-dr %e dt %g \n",sqrt(r2),Radii,Radii-sqrt(r2),dt);

	if(dt > 0.0){
	  /* this may occur for binary collisions */
	  printf("dt = %e, c1color = %d, c2color = %d, c1order = %d, c2order = %d, rv*rv-v2*r2 = %e \n",dt,c1.iColor,c2.iColor,c1.id.iOrder,c2.id.iOrder,rv*rv-v2*r2);
	  dt = -pkd->param.dDelta/pow(3.0,pkd->pStore[c1.id.iIndex].iRung);;
	}
#ifdef SYMBA
	iflag = drift_dan0(dSunMass,c1.r,c1.v,dt);
	assert(iflag ==0);

	iflag = drift_dan0(dSunMass,c2.r,c2.v,dt);
	assert(iflag ==0);

#endif
	/* sometimes |sqrt(r2)-Radii|/Radii becomes as large as 0.01 while it is usuall nearly 0  
           dt is not correct or kepler drift does not work correctly? 122115 */

#ifndef SYMBA	
	  for (i=0;i<3;i++) {
		c1.r[i] += c1.v[i]*dt;
		c2.r[i] += c2.v[i]*dt;
	}
#endif
 
	/* Determine collision outcome */
	  if (CPiOut != MERGE){
	    r2 = 0.0;
	    rv = 0.0;
	    v2 = 0.0;
	    for (i=0;i<3;i++) {
	      r = c2.r[i] - c1.r[i];
	      v = c2.v[i] - c1.v[i];
	      r2 += r*r;
	      rv += r*v;
	      v2 += v*v;
	    }
	    
	    rv /= -sqrt(v2*r2); /* cos theta ; minus sign added 063015*/
	    rv0 = rv;
	    if(rv < 0){
	      printf("negative rv %e \n", rv);
	      rv = 0; /*should be assert? */
   	    }
	    
	    rv = 1.0 - sqrt(1.0 -rv*rv); /* 1 - sin theta */
	    rv = rv*rv*sqrt(rv);

	    c2Mass = c2.fMass;
	    if(c1.iColor == SUBEMBRYO && c2.iColor >= TRACER)c2Mass /= c2.nump;
	    
	    gam = fabs(c1.fMass-c2Mass)/(c1.fMass+c2Mass);
	    gam *= gam; // corrcted 110316, see kokubo and Genda Eq.(3)
	    // if(gam < 0) gam *= -1.0;
	    
	    ve2 = 2.0*(c1.fMass + c2Mass)/Radii;
	    
	    vcri2 = 2.43*gam*rv -0.0408*gam + 1.86*rv + 1.08; /* Genda et al. 2012 Eq.(16)*/  
	    vcri2 *= vcri2*ve2;
	    
	    printf("ve %g vcri %g vimp %g cos the %e dr %10e Radii %10e \n",sqrt(ve2),sqrt(vcri2),sqrt(v2),rv0,sqrt(r2),Radii);
	  
	  }
	//	dImpactEnergy = 0.5*c1.fMass*c2.fMass/(c1.fMass + c2.fMass)*v2;

	iOutcome = MISS;

	if (CPiOut == MERGE ||((CPiOut & MERGE) && (v2 < vcri2 || v2 < ve2))) {
		iOutcome = MERGE;	
		pkdMerge(pkd,&c1,&c2,CP->dDensity,&c,&n);
		
		assert(n == 1);

		/* if (CP->iOutcomes & (BOUNCE | FRAG))*/
		if(0){ /* check if spinning too fast */
		  /* this causes grazing particles remain contact forever!! */
			double w2max,w2=0;
			w2max = c->fMass/(c->fRadius*c->fRadius*c->fRadius);
			for (i=0;i<3;i++)
				w2 += c->w[i]*c->w[i];
			if (w2 > w2max) {
				int tag;
				free((void *) c);
				iOutcome = BOUNCE;
							
			        tag = pkdBounce(pkd,c1,c2,CP->dEpsN,CP->dEpsT,CP->bFixCollapse,&c,&n); 
				assert(tag == BOUNCE_OK);
				assert(n == 2);
			}
		}

	}
	else if (CPiOut & BOUNCE) {	   
		iOutcome = BOUNCE;
		
	
		if (pkdBounce(pkd,c1,c2, CP->dEpsN, CP->dEpsT,CP->bFixCollapse,&c,&n) == NEAR_MISS)
			iOutcome = MISS;
		assert(n == 2);
		
		
		}
	else if (CPiOut & FRAG) {
	  assert(0);
		iOutcome = FRAG;
		pkdFrag(pkd,&c1,&c2,&c,&n);
		assert(n <= MAX_NUM_FRAG);
		}

  
	
	if (!CP->bFixCollapse)
		assert(iOutcome != MISS); /* SOMETHING has to happen... */

	if (bDiagInfo) *piOutcome = iOutcome;

	assert(n > 0);

	if (bDiagInfo) {
		if (dT) {
			double moi;
			*dT = 0; /* redundant */
			for (j=0;j<n;j++) {
				moi = 0.4*c[j].fMass*c[j].fRadius*c[j].fRadius;
				for (i=0;i<3;i++)
					*dT += c[j].fMass*(c[j].v[i]*c[j].v[i]) +
						moi*(c[j].w[i]*c[j].w[i]);
				}
			moi = 0.4*c1.fMass*c1.fRadius*c1.fRadius;
			for (i=0;i<3;i++)
				*dT -= c1.fMass*(c1.v[i]*c1.v[i]) + moi*(c1.w[i]*c1.w[i]);
			moi = 0.4*c2.fMass*c2.fRadius*c2.fRadius;
			for (i=0;i<3;i++)
				*dT -= c2.fMass*(c2.v[i]*c2.v[i]) + moi*(c2.w[i]*c2.w[i]);
			*dT *= 0.5;

			if(iOutcome == MERGE) /* add potential change*/
                        {
			  *dT += c1.fMass*c2.fMass/sqrt(r2);
#ifdef PLANETS
			  /*correction for solar potential*/
			  a1 = sqrt(c1.r[0]*c1.r[0] + c1.r[1]*c1.r[1] + c1.r[2]*c1.r[2]);
			  a2 = sqrt(c1.r[0]*c1.r[0] + c1.r[1]*c1.r[1] + c1.r[2]*c1.r[2]);
			  ac = (a1*c1.fMass + a2*c2.fMass)/(c1.fMass + c2.fMass);
			  *dT += (-(c1.fMass + c2.fMass)/ac + c1.fMass/a1 + c2.fMass/a2)*pkd->dSunMass;

			  /* correction due to mass change in a collision between a test particle and a non-testparticle 
			   should be taken into account somewhere else*/



#endif
                        }
			}
		/*DEBUG (void) printf("Compare: dT = %e\n",*dT); */

		for (i=0;i<n;i++)
			cOut[i] = c[i];
		*pnOut = n;
		}
      
	/* Trace particles back to start of step */
	
	for (i=0;i<n;i++){
#ifndef SYMBA	
	  for (j=0;j<3;j++)
		  c[i].r[j] -= c[i].v[j]*dt; 
#endif
#ifdef SYMBA
		iflag = drift_dan0(pkd->dSunMass,c[i].r,c[i].v,-dt);
		assert(iflag ==0);	
#endif
	
	}
	/* Handle output cases */

	if (n == 1) { /* merge */
		PARTICLE_ID *pMrg=NULL,*pDel=NULL,*pOth=NULL;
		if (c1.id.iPid == pkd->idSelf) { /* local particle */
			/*
			 ** Keep this particle if it has larger mass, or, if both
			 ** particles are the same mass, keep this particle if it
			 ** has a lower original index, or, if both particles have
			 ** same original index, keep this particle if it has a
			 ** lower processor number, or, if both particles are on
			 ** same processor, keep particle with lower iOrder.
			 */
			if (c1.fMass/c1.nump > c2.fMass/c2.nump ||
				(c1.fMass/c1.nump == c2.fMass/c2.nump &&
				 (c1.id.iOrgIdx < c2.id.iOrgIdx ||
				  (c1.id.iOrgIdx == c2.id.iOrgIdx &&
				   (c1.id.iPid < c2.id.iPid ||
					(c1.id.iPid == c2.id.iPid &&
					 c1.id.iOrder < c2.id.iOrder))))))
				pMrg = &c1.id; /* new centre-of-mass particle */
			else
				pDel = &c1.id; /* this particle is removed */
			pOth = &c2.id;
			}
		if (c2.id.iPid == pkd->idSelf) { /* same thing for other particle */
			if (c2.fMass/c2.nump > c1.fMass/c1.nump ||
				(c2.fMass/c2.nump == c1.fMass/c1.nump &&
				 (c2.id.iOrgIdx < c1.id.iOrgIdx ||
				  (c2.id.iOrgIdx == c1.id.iOrgIdx &&
				   (c2.id.iPid < c1.id.iPid ||
					(c2.id.iPid == c1.id.iPid &&
					 c2.id.iOrder < c1.id.iOrder))))))
				pMrg = &c2.id;
			else
				pDel = &c2.id;
			pOth = &c1.id;
			}
	
		/* 
		 ** Store or delete particle as appropriate, and make
		 ** sure master knows ID of surviving particle for
		 ** tracking purposes.
		 */
		if (pMrg) {		  
			PutColliderInfo(&c[0],INT_MAX,&pkd->pStore[pMrg->iIndex],dt);
			if (bDiagInfo) cOut[0].id = *pMrg; /* struct copy */
			}
	
		if (pDel) {		 
	
    		        pkdDeleteParticle(pkd,&pkd->pStore[pDel->iIndex]);		 
			if (bDiagInfo && !pMrg) cOut[0].id = *pOth; /* may need merger info */
			}

#ifdef SYMBA
		/* Check whether particles in the list of pMrg include pMrg in their lists */
		/* This is necessary:  consider pa<->pb<->pc and a collision between pb and pc
		   produces a new pc. Note all actives are in the same cpu for SYMBA */
		PARTICLE *p; 
		int k ,kk, ii, jj;
		p = pkd->pStore;	       
		i = pMrg->iIndex;
		
		for(k=0;k<p[i].n_VA;k++){	
		  j = p[i].i_VA[k];		 
		  for(kk=0;kk<p[j].n_VA;kk++){		   
		    ii = p[j].i_VA[kk];		
		    if(ii==i)goto inlist;
		  }	  
		  
		  /* add pi to the list of pj */
	 	  
		  printf("add after collision pi, pi= %d, pj =%d, piorder =%d, pjorder =%d pihill =%e,pjhill =%e \n",i,j,p[i].iOrder,p[j].iOrder,p[i].hill,p[j].hill);	      
		  p[j].i_VA[p[j].n_VA] = i;
		  p[j].iOrder_VA[p[j].n_VA] = p[i].iOrder;
		  p[j].n_VA ++;
		  
		  /* if(p[j].n_VA > 1 || p[i].n_VA > 1) multiflag = 2; 
		     multiflag should be already larger than unity */
		  
		  if(p[i].iRung > p[j].iRung){
		    p[j].iRung = p[i].iRung;
		    for(kk=0;kk<p[j].n_VA;kk++){
		      ii = p[j].i_VA[kk];
		      p[ii].iRung = p[j].iRung;
		    }
		  } else if(p[j].iRung > p[i].iRung){
		    p[i].iRung = p[j].iRung;
		    for(kk=0;kk<p[i].n_VA;kk++){
		      jj = p[i].i_VA[kk];
		      p[jj].iRung = p[i].iRung;
		    }
		  }
		  
		inlist:	      
		  continue;
		}				
#endif 

		}
	else if (n == 2) { /* bounce or mass transfer */	 
		if (c1.id.iPid == pkd->idSelf)
			PutColliderInfo(&c[0],c2.id.iOrder,&pkd->pStore[c1.id.iIndex],dt);
		if (c2.id.iPid == pkd->idSelf) {			
			PutColliderInfo(&c[1],c1.id.iOrder,&pkd->pStore[c2.id.iIndex],dt);
			}	
		}
	else { /* fragmentation */
		assert(0); /* not implemented yet */
		/* note in this case new iOrders start at pkd->nMaxOrderDark */
		}

	/* Free resources */

	free((void *) c);
	}


void
pkdDoCollisionVeryActive(PKD pkd,double dTime)
{
	COLLIDER c1out,c2out,cOut;
	COLLIDER *c1,*c2,*c;
	COLLIDER c1temp,c2temp;
	double sec;
	unsigned int nCol=0,nMis=0,nMrg=0,nBnc=0,nFrg=0;		 
        int bPeriodic = pkd->param.bPeriodic;
	int iOrder1, iOrder2, piOutcome, pnOut, nowrite;
	double dt, dT;
	
	c1 = &c1out;
	c2 = &c2out; 
	
	do{	
		  dt = DBL_MAX;
		  pkdNextCollision(pkd, &dt, &iOrder1, &iOrder2);
		  	
		  /* process the collision */
		  if (COLLISION(dt)) {
		    /*printf("%i,%i\n",iOrder1,iOrder2);*/
		        assert(iOrder1 >= 0);
		        assert(iOrder2 >= 0);		
		        assert(iOrder1 != iOrder2);
		        pkdGetColliderInfo(pkd,iOrder1,&c1out);	
			
			//	c1 = &c1out;  /* pointa definition (correct?) */			
				
			c1temp = c1out;
			
			assert(c1->id.iOrder == iOrder1);
		
			pkdGetColliderInfo(pkd,iOrder2,&c2out);
			
			//c2 = &c2out; 
		
			c2temp = c2out;

			assert(c2->id.iOrder == iOrder2);
			

		  	pkdDoCollision(pkd, dt, c1, c2, bPeriodic,
				       &pkd->param.CP, &piOutcome, &dT, &cOut, &pnOut);
	
					
			pkd->dDeltaEcoll += dT; /*account for kinetic energy loss + (potential)*/
			++nCol;
			switch (piOutcome) {
			case MISS:
				++nMis;
				--nCol;
				break;
			case MERGE:
				++nMrg;
				break;
			case BOUNCE:
				++nBnc;
				break;
			case FRAG:
				++nFrg;
				break;
			default:
				assert(0); /* unknown outcome */
				}

			/* log collision if requested */
			nowrite = 0;
			//	if((pkd->param.iCollLogOption & COLL_LOG_TXT) && (c1->iColor == TEST) && (c2->iColor == TEST)){
			// /* collisions between test particles are excluded */ 
			  // nowrite = 1;
			//	}
			/*printf("nowrite = %d \n",nowrite);*/
			printf("%s-%s COLLISION:T=%e years, ",
			       _pkdParticleLabel(pkd,c1temp.iColor),
			       _pkdParticleLabel(pkd,c2temp.iColor),dTime/(2.0*M_PI));
			printf("***OUTCOME=%s \n",
			       piOutcome == MISS ? "MISS" :
			       piOutcome == MERGE ? "MERGE" :
			       piOutcome == BOUNCE ? "BOUNCE" :
			       piOutcome == FRAG ? "FRAG" : "UNKNOWN");

			if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE && nowrite == 0){
			  FILE *fp;
			  int i;

			  fp = fopen(pkd->param.achCollLog,"a");
			  assert(fp != NULL);
			  
			  /* for (i=0;i<3;i++) {
			     c1->r[i] += c1->v[i]*dt;
			     c2->r[i] += c2->v[i]*dt;
			     } */

			  /* The reason is unclear but *c1 and *c2 are sometimes overwritten. 
			     We temproraly use c1temp and c2temp */

			  /* 
			  fprintf(fp,"%s-%s COLLISION:T=%e years \n",
				  _pkdParticleLabel(pkd,c1->iColor),
					_pkdParticleLabel(pkd,c2->iColor),dTime/(2.0*M_PI));
			  
			  fprintf(fp,"***1:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
				  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
				  c1->id.iPid,c1->id.iOrder,c1->id.iIndex,c1->id.iOrgIdx,
				  c1->fMass,c1->fRadius,c1->dt,c1->iRung,
				  c1->r[0],c1->r[1],c1->r[2],
				  c1->v[0],c1->v[1],c1->v[2],
				  c1->w[0],c1->w[1],c1->w[2]);
			  
			  fprintf(fp,"***2:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
				  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
				  c2->id.iPid,c2->id.iOrder,c2->id.iIndex,c2->id.iOrgIdx,
				  c2->fMass,c2->fRadius,c2->dt,c2->iRung,
				  c2->r[0],c2->r[1],c2->r[2],
				  c2->v[0],c2->v[1],c2->v[2],
				  c2->w[0],c2->w[1],c2->w[2]);
			  fprintf(fp,"***OUTCOME=%s dT=%e\n",
				  piOutcome == MISS ? "MISS" :
				  piOutcome == MERGE ? "MERGE" :
				  piOutcome == BOUNCE ? "BOUNCE" :
				  piOutcome == FRAG ? "FRAG" : "UNKNOWN",dT);
			  for (i=0;i<(pnOut < MAX_NUM_FRAG ? pnOut : MAX_NUM_FRAG);i++) {
			    c = &((&cOut)[i]);
			    
			    fprintf(fp,"***out%i:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,rung=%i,"
				    "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",i,
				    c->id.iPid,c->id.iOrder,c->id.iIndex,c->id.iOrgIdx,
				    c->fMass,c->fRadius,c->iRung,
				    c->r[0],c->r[1],c->r[2],
				    c->v[0],c->v[1],c->v[2],
				    c->w[0],c->w[1],c->w[2]);
			  }
			  */
			  fprintf(fp,"%s-%s COLLISION:T=%e years \n",
				  _pkdParticleLabel(pkd,c1temp.iColor),
					_pkdParticleLabel(pkd,c2temp.iColor),dTime/(2.0*M_PI));
			  
			  fprintf(fp,"***1:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
				  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
				  c1temp.id.iPid,c1temp.id.iOrder,c1temp.id.iIndex,c1temp.id.iOrgIdx,
				  c1temp.fMass,c1temp.fRadius,c1temp.dt,c1temp.iRung,
				  c1temp.r[0],c1temp.r[1],c1temp.r[2],
				  c1temp.v[0],c1temp.v[1],c1temp.v[2],
				  c1temp.w[0],c1temp.w[1],c1temp.w[2]);
			  
			  fprintf(fp,"***2:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,dt=%e,rung=%i,"
				  "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",
				  c2temp.id.iPid,c2temp.id.iOrder,c2temp.id.iIndex,c2temp.id.iOrgIdx,
				  c2temp.fMass,c2temp.fRadius,c2temp.dt,c2temp.iRung,
				  c2temp.r[0],c2temp.r[1],c2temp.r[2],
				  c2temp.v[0],c2temp.v[1],c2temp.v[2],
				  c2temp.w[0],c2temp.w[1],c2temp.w[2]);
			  fprintf(fp,"***OUTCOME=%s dT=%e\n",
				  piOutcome == MISS ? "MISS" :
				  piOutcome == MERGE ? "MERGE" :
				  piOutcome == BOUNCE ? "BOUNCE" :
				  piOutcome == FRAG ? "FRAG" : "UNKNOWN",dT);
			  for (i=0;i<(pnOut < MAX_NUM_FRAG ? pnOut : MAX_NUM_FRAG);i++) {
			    c = &((&cOut)[i]);
			    
			    fprintf(fp,"***out%i:p=%i,o=%i,i=%i,oi=%i,M=%e,R=%e,rung=%i,"
				    "r=(%e,%e,%e),v=(%e,%e,%e),w=(%e,%e,%e)\n",i,
				    c->id.iPid,c->id.iOrder,c->id.iIndex,c->id.iOrgIdx,
				    c->fMass,c->fRadius,c->iRung,
				    c->r[0],c->r[1],c->r[2],
				    c->v[0],c->v[1],c->v[2],
				    c->w[0],c->w[1],c->w[2]);
			  }
			  fclose(fp);
			}

			if(pkd->param.iCollLogOption & COLL_LOG_TERSE && nowrite == 0){				  
			  /*
			  ** FORMAT: For each event, time (double), collider 1 iOrgIdx
			  ** (int), collider 2 iOrgIdx (int), number of post-collision
			  ** particles (int), iOrgIdx for each of these (n * int).
			  */
			  
			  FILE *fp2;
			  XDR xdrs;		       
			  int i;
			  
			  /*if (piOutcome != MERGE && piOutcome != FRAG)
			    break;  only care when particle indices change */
			  fp2 = fopen(pkd->param.achCollLog2,"a");
			  assert(fp2 != NULL);
			  xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
			  
			  (void) xdr_double(&xdrs,&dTime);
			  /* MERGE =1, BOUNCE =2*/
			  (void) xdr_int(&xdrs,&piOutcome); 
			  
			  CollisionData(&xdrs, &c1temp, &c2temp);

			  xdr_destroy(&xdrs);
			  (void) fclose(fp2);	      
			}			
		  } /* if collision */
		
	} while (COLLISION(dt));
	
	/* Adddelete is taken care of in master level.*/	

	if (pkd->param.bVStep) {
		double dsec = dTime - sec;
		printf("%i collision%s: %i miss%s, %i merger%s, %i bounce%s, %i frag%s\n",
			   nCol,nCol==1?"":"s",nMis,nMis==1?"":"es",nMrg,nMrg==1?"":"s",
			   nBnc,nBnc==1?"":"s",nFrg,nFrg==1?"":"s");
		printf("Collision search completed, time = %g sec\n",dsec);
		}
	pkd->iCollisionflag = 0;
}


static char *
_pkdParticleLabel(PKD pkd,int iColor)
{
	switch (iColor) {
	case SUN:
		return "SUN";
	case GIANT:
		return "GIANT";
	case PLANETESIMAL:
		return "FULLEMBRYO";
	case TEST:
		return "TEST";
	case TRACER:
	        return "TRACER";
	case PEBBLE:
	        return "PEBBLE";
	case SUBEMBRYO:
	        return "SUBEMBRYO";
	default:
		return "UNKNOWN";
		}
	}


void pkdGetVariableVeryActive(PKD pkd, double *dDeltaEcoll)
{
  *dDeltaEcoll = pkd->dDeltaEcoll;
  pkd->dDeltaEcoll = 0.0;
}


void
CollisionData(XDR *xdrs, COLLIDER *c1, COLLIDER *c2){
   int i;

  /* info for c1*/
  (void) xdr_int(xdrs,&c1->iColor);
  (void) xdr_int(xdrs,&c1->id.iOrgIdx);			
  (void) xdr_double(xdrs,&c1->fMass);
  (void) xdr_double(xdrs,&c1->fRadius);
  (void) xdr_double(xdrs,&c1->nump);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c1->r[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c1->v[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c1->w[i]);
  
  /* info for c2*/
  (void) xdr_int(xdrs,&c2->iColor);
  (void) xdr_int(xdrs,&c2->id.iOrgIdx);			
  (void) xdr_double(xdrs,&c2->fMass);
  (void) xdr_double(xdrs,&c2->fRadius);
  (void) xdr_double(xdrs,&c2->nump);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c2->r[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c2->v[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c2->w[i]);
}

#ifdef sm2d
void
pkdDoCollisionPBHYB(PKD pkd,const COLLIDER *pc1, const COLLIDER *pc2,
		    const COLLISION_PARAMS *CP,int iexcess,double dTime,int *piOutcome, double *dT,int *pnOut)
{
	/*
	 ** Processes collision by advancing particle coordinates to impact
	 ** time, determining the collision outcome, and moving the resulting
	 ** particles back to their (new) start-of-step positions. Diagnostic
	 ** info is returned if the first collider resides on the processor
	 ** (the second collider may not be local, in which case this routine
	 ** is called twice in parallel, once for each particle). Local copies
	 ** of the collider info are used because the particle coordinates need
	 ** to be advanced to the moment of collision. 
	  c1 is the target and c2 is the interloper */

	COLLIDER c1,c2;
	int bDiagInfo,i,j,n,j2,iflag;
	double dt; //unused
	double dDmi = pc2->dDmi; // pc1 --> pc2 072215
	double n1 = pc1->nump*1.0;
	double m1 = pc1->fMass/n1;
	double n2 = pc2->nump*1.0;
	double m2 = pc2->fMass/n2;
	double dSunMass = pkd->dSunMass;
	double nd = dDmi/n2;
	
	double dthe,facv2,facr2,vr2,ve2,vcri2,rv,cimp,gam;
	double lz1,lz2;
	double dtheta = pkd->param.HY.fdtheta;
	struct helio hel;
	struct delaunay del;
	double a1,e1,i1,lop1,lan1,ean1,f1,df1,dM1,Omega1,dt1;
	double a2,e2,i2,lop2,lan2,ean2,f2,df2,dM2,Omega2,dt2;
	double sB,cB;
	int CPiOut = CP->iOutcomes;
	int iColor1;
	double dSunMass1, dSunMass2;
	int pflag = 0;
	
	if((pc1->iColor == SUBEMBRYO || pc2->iColor == SUBEMBRYO) && CPiOut >= 4)CPiOut=3; // no fragmentation for subembryos
	// if((pc1->iColor == PEBBLE && pc2->iColor == PEBBLE) && CPiOut >= 4)CPiOut=2; // no fragmentation for pebble
	if(pc1->St < 2.0 || pc2->St < 2.0) pflag = 1;
	   
	/* Get local copies of collider info  (may be unnecessary ?) */

	c1 = *pc1; 
	c2 = *pc2;

	dSunMass1 = dSunMass + c1.fMass-c1.a_pr;
	dSunMass2 = dSunMass + c2.fMass-c2.a_pr;
	
	bDiagInfo = (c1.id.iPid == pkd->idSelf);

	/* total angular momentum in z direction conserved */
	a1 = c1.ele[0];
	a2 = c2.ele[0];
	e1 = c1.ele[1]*c1.ele[1] + c1.ele[2]*c1.ele[2];
	e2 = c2.ele[1]*c2.ele[1] + c2.ele[2]*c2.ele[2];
	i1 = sqrt(c1.ele[3]*c1.ele[3] + c1.ele[4]*c1.ele[4]);
	i2 = sqrt(c2.ele[3]*c2.ele[3] + c2.ele[4]*c2.ele[4]);
	
	lz1 = sqrt(a1*(1.0-e1)*dSunMass1)*cos(i1);
	lz2 = sqrt(a2*(1.0-e2)*dSunMass2)*cos(i2);
	//lz12 = (c1.fMass*lz1 + c2.fMass*lz2)/(c1.fMass+c2.fMass);

	if(pflag) goto skip_move1;
	
	/*first adjust a2 to a1 by without changing other orbital elements */
	/* not necessary here
	facr2 = a1/a2;	
	facv2 = sqrt(1.0/facr2);
	for (i=0;i<3;i++) {	  
	  c2.v[i] *= facv2;
	  c2.r[i] *= facr2;
	  } */
	
	/* we call heltodel */
	/* c1 */
	hel.x = c1.r[0]; 
	hel.y = c1.r[1];
	hel.z = c1.r[2];
	hel.vx = c1.v[0];
	hel.vy = c1.v[1];
	hel.vz = c1.v[2];    
	heltodel(dSunMass1,&hel,&del);
	a1 = del.sma;
	e1 = del.ecc;
	i1 = del.inc;
	lop1 = del.lop;
	lan1 = del.lan;
	ean1 = del.mea; // ecc anomaly
	
	/* true anomaly */
	f1 = cos(ean1);
	f1 = (f1 - e1)/(1.0-e1*f1);
	f1 = acos(f1);
	if(ean1 > M_PI) f1 = 2.0*M_PI - f1;
	
	/* c2 */
	hel.x = c2.r[0]; 
	hel.y = c2.r[1];
	hel.z = c2.r[2];
	hel.vx = c2.v[0];
	hel.vy = c2.v[1];
                   	hel.vz = c2.v[2];    
	heltodel(dSunMass2,&hel,&del);
	a2 = del.sma;
	e2 = del.ecc;
	i2 = del.inc;
	lop2 = del.lop;
	lan2 = del.lan;
	ean2 = del.mea; // ecc anomaly
	
	/* true anomaly */
	f2 = cos(ean2);
	f2 = (f2 - e2)/(1.0-e2*f2);
	f2 = acos(f2);
	if(ean2  > M_PI) f2 = 2.0*M_PI - f2;

	/* align the longitudes and z/r  */
	sB = sin(i1)*sin(lan1)-sin(i2)*sin(lan2); // sin i sin Omega
	cB = sin(i1)*cos(lan1)-sin(i2)*cos(lan2);
	
	cB /= sqrt(sB*sB+cB*cB);
	cB = acos(cB);
	if(sB < 0)cB = 2.0*M_PI-cB;

	df1 = cB-(lop1 + f1)-2.0*M_PI; //df1 < 0 now
	
	while(fabs(df1) > M_PI/2.0){
	  df1 += M_PI;	  
	}
	//printf("df1 %g \n",df1);
	assert(fabs(df1) < M_PI/2.0);
	
	df2 = df1 + lop1 + f1 -(lop2 + f2);
	if(df2 > 2.0*M_PI) df2 -= 2.0*M_PI;
	if(df2 < -2.0*M_PI) df2 += 2.0*M_PI;
	
	/*test 
	double yyy;
	yyy = ((double)drand48());
	if(yyy > 0.5){
	  df2 +=  100.*(c1.ele[8]+c2.ele[8])/a2;
	}else{
	  df2 -=  100.*(c1.ele[8]+c2.ele[8])/a2;
	}

	printf("df2 %g, c1.ele[8]+c2.ele[8] %g, a2 %g\n",df2, c1.ele[8]+c2.ele[8], a2);*/

	/* df -> dM */
	dM1 = cos(f1+df1); // cos f1+df1
	dM1 = (dM1 + e1)/(1.0+e1*dM1); // cos E1 + dE1
	dM1 = acos(dM1);
	if(sin(f1+df1) < 0.0) dM1 = -dM1;
	dM1 = (dM1-e1*sin(dM1))-(ean1-e1*sin(ean1)); //dM1
	if(dM1 > M_PI) dM1 -= 2.0*M_PI;
	if(dM1 < -M_PI) dM1 += 2.0*M_PI;

	dM2 = cos(f2+df2); // cos f2 + df2
	dM2 = (dM2 + e2)/(1.0+e2*dM2); // cos E2 +dE2
	dM2 = acos(dM2);
	if(sin(df2+f2) < 0.0) dM2 = -dM2;
	dM2 = (dM2-e2*sin(dM2))-(ean2-e2*sin(ean2)); //dM2
	if(dM2 > M_PI) dM2 -= 2.0*M_PI;
	if(dM2 < -M_PI) dM2 += 2.0*M_PI;

	if(bDiagInfo && pkd->param.iCollLogOption & COLL_LOG_STAND){
	  printf("00 lop1 %g, lan1 %g, f1 %g df1 %g dM1 %g, lop1+f1+df1 %g lop2 %g, lan2 %g, f2 %g df2 %g dM2 %g, lop2+f2+df2 %g \n",lop1, lan1, f1, df1, dM1, lop1+f1+df1, lop2, lan2, f2, df2, dM2, lop2+f2+df2);
	}
	/* Move particles to impact time*/ 
	Omega1 = 1.0/a1;
	Omega1 *= sqrt(dSunMass1*Omega1);
       	dt1 = dM1/Omega1;

	Omega2 = 1.0/a2;
	Omega2 *= sqrt(dSunMass2*Omega2);
	dt2 = dM2/Omega2;

	if(bDiagInfo && pkd->param.iCollLogOption & COLL_LOG_STAND){
	  calc_dthe(c1,c2,&dthe);

          sB = 0.0;
	  cB = 0.0;
	  for (i=0;i<3;i++) {
	  sB += c1.r[i]*c1.r[i];
	  cB += c2.r[i]*c2.r[i];
	  }
	  sB = sqrt(sB);
	  cB = sqrt(cB);

	  printf("11 x1 %g, y1 %g, z1 %g x1/y1 %g x2 %g, y2 %g z2 %g x2/y2 %g dthe %g e1 %g e2 %g i1 %g i2 %g r1 %g r2 %g \n",c1.r[0],c1.r[1],c1.r[2],c1.r[0]/c1.r[1],c2.r[0],c2.r[1],c2.r[2],c2.r[0]/c2.r[1],dthe,e1,e2,i1,i2,sB,cB);
	}

#ifdef SYMBA
	iflag = drift_dan0(dSunMass1,c1.r,c1.v,dt1); // c1 mass taken into account
	assert(iflag ==0);
	iflag = drift_dan0(dSunMass2,c2.r,c2.v,dt2); // c2 mass taken into account
	assert(iflag ==0);

#endif
#ifndef SYMBA	
	assert(0);
	for (i=0;i<3;i++) {
	  c1.r[i] += c1.v[i]*dt;
	  c2.r[i] += c2.v[i]*dt;
	}
#endif	
	// position and velocity correction for c2
	// !!! handled in subroutines
	a1 = sqrt(c1.r[0]*c1.r[0]+c1.r[1]*c1.r[1]+c1.r[2]*c1.r[2]);
	a2 = sqrt(c2.r[0]*c2.r[0]+c2.r[1]*c2.r[1]+c2.r[2]*c2.r[2]);
	facr2 = a1/a2;
	facv2 = sqrt(1.0/facr2);

	double dx,dy,dz,dr;

	if(bDiagInfo && pkd->param.iCollLogOption & COLL_LOG_STAND){
	  calc_dthe(c1,c2,&dthe);
	  printf("22 x1 %g, y1 %g, z1 %g x1/y1 %g x2 %g, y2 %g z2 %g x2/y2 %g dthe %g e1 %g e2 %g i1 %g i2 %g\n",c1.r[0],c1.r[1],c1.r[2],c1.r[0]/c1.r[1],c2.r[0],c2.r[1],c2.r[2],c2.r[0]/c2.r[1],dthe,e1,e2,i1,i2);

	  dx = c2.r[0]*facr2-c1.r[0];
	  dy = c2.r[1]*facr2-c1.r[1];
	  dz = c2.r[2]*facr2-c1.r[2];
	  dr = sqrt(dx*dx+dy*dy+dz*dz);
	  
	  printf("22v dr/rp %g, dx1 %g, dy1 %g, dz1 %g dvx1 %g, dvy1 %g, dvz1 %g \n",dr/(c1.ele[8]+c2.ele[8]),dx,dy,dz,c2.v[0]*facv2-c1.v[0],c2.v[1]*facv2-c1.v[1],c2.v[2]*facv2-c1.v[2]);
	  
	}

	
 skip_move1:
	  
	*dT = 0.0;	
	// Judge collision outcome
	  if (CPiOut != MERGE){	
		
	    vr2 = 0.0;
	    ve2 = 2.0*(m1+m2)/(c1.ele[8]+c2.ele[8]);

	    for (i=0;i<3;i++) {	  
	      // vr2 += (c2.v[i] - c1.v[i])*(c2.v[i] - c1.v[i]);	
	      vr2 += (facv2*c2.v[i] - c1.v[i])*(facv2*c2.v[i] - c1.v[i]);	// corrected relative velocity   061015
	    }
	    
	    if(pflag){ // saved velocities at CalcPcollPebble in pkd.c
	      vr2 = (c1.vb[0]-c2.vb[0])*(c1.vb[0]-c2.vb[0]) + (c1.vb[1]-c2.vb[1])*(c1.vb[1]-c2.vb[1]) + (c1.vb[2]-c2.vb[2])*(c1.vb[2]-c2.vb[2]);
	    }
	    
	    // cos (impact angle)
	    cimp = sqrt(((double)drand48()));
	    
	    rv = 1.0 - sqrt(1.0-cimp*cimp); /* 1 - sin theta */
	    rv = rv*rv*sqrt(rv);
	    
	    gam = (m1-m2)/(m1+m2);
	    if(gam < 0) gam *= -1.0;
	    gam *= gam; // corrcted 110316, see kokubo and Genda Eq.(3)
	    
	    vcri2 = 2.43*gam*rv -0.0408*gam + 1.86*rv + 1.08; /* Genda et al. 2012 Eq.(16)*/
  
	    //  if(ve2 < AU/(G*M_SUN)){
	    //    vcri2 *= vcri2*AU/(G*M_SUN); // stick if vcri = 1 m/s if > vesc 081115
	    //   }else{
	      vcri2 *= vcri2*ve2;
	      //    }	  
 
	      //  printf("vr/ve %g, vcri/ve %g, (vr2+ve2)/vcri2 %g  cimp %g \n",sqrt(vr2/ve2),sqrt(vcri2/ve2),(vr2+ve2)/vcri2,cimp);
	  }
	  	  
	  
	  if (CPiOut == MERGE ||((CPiOut & MERGE) && (vr2+ve2 < vcri2))) {
	    *piOutcome = MERGE;	 
	    pkdMergePBHYB(pkd,&c1,&c2,CP->dDensity,dDmi,lz1,lz2,facr2,iexcess,bDiagInfo,dTime,&n, dT,*piOutcome,n1,pflag);
	  } else if (CPiOut & BOUNCE) {	   	  	    
	    pkdBouncePBHYB(pkd,&c1,&c2,dDmi,lz1,lz2,facr2,cimp,CP->dEpsN,CP->dEpsT,bDiagInfo,dTime,&n, dT);
	    *piOutcome = BOUNCE;
	    assert(n == 2);
	  }
	  else if (CPiOut & FRAG) {
	    *piOutcome = FRAG;
	    pkdFragmass(pkd,&c1,&c2,dDmi,vr2+ve2,&m1,&n1); 
	    pkdMergePBHYB(pkd,&c1,&c2,CP->dDensity,dDmi,lz1,lz2,facr2,iexcess,bDiagInfo,dTime,&n, dT,*piOutcome,n1,pflag);
	    // c1.nump = n1;
	    // if(iColor1 == PEBBLE)c1.iColor = PEBBLE;
	    	
	  }


	  if(pflag) goto skip_move2;
	  
	  calc_aei(c1,dSunMass1,&a1,&e1,&i1);
	  calc_aei(c2,dSunMass2,&a2,&e2,&i2);


	  if(bDiagInfo && (pkd->param.iCollLogOption & COLL_LOG_STAND)){	   
	    printf("33 x1 %g, y1 %g, z1 %g x1/y1 %g x2 %g, y2 %g z2 %g x2/y2 %g dthe %g e1 %g e2 %g i1 %g i2 %g\n",c1.r[0],c1.r[1],c1.r[2],c1.r[0]/c1.r[1],c2.r[0],c2.r[1],c2.r[2],c2.r[0]/c2.r[1],dthe,e1,e2,i1,i2);
	  }
	  
	  if (bDiagInfo) {
	    //  *piOutcome = MERGE;	  
	    *pnOut = n;
	  }else{					
	    *dT = 0.0;
	  }
	 	  	  
	  /* Trace back the particles */
	  Omega1 = 1.0/a1;
	  Omega1 *= sqrt(dSunMass1*Omega1);
	  dt1 = dM1/Omega1;

	  iflag = drift_dan0(dSunMass1,c1.r,c1.v,-dt1);	  
	  assert(iflag == 0);


	  if(n==2){	  
#ifdef SYMBA
	    Omega2 = 1.0/a2;
	    Omega2 *= sqrt(dSunMass2*Omega2);
	    dt2 = dM2/Omega2;
	    
	    iflag = drift_dan0(dSunMass2,c2.r,c2.v,-dt2);	  
	    assert(iflag == 0);
	    	
#endif
#ifndef SYMBA	
	  for (i=0;i<3;i++) {	  
	    c2.r[i] -= c2.v[i]*dt;
	  }
#endif		
	}

 skip_move2:
	  
	/* Handle output cases */

	if (n == 1) { /* merge */
		PARTICLE_ID *pMrg=NULL,*pDel=NULL,*pOth=NULL;
		/* COLLIDER *cOut;  so far unused This information is not sent to Master */

		if (c1.id.iPid == pkd->idSelf) { /* local particle */
		  /*
		  ** Keep this particle if it has larger mass, or, if both
		  ** particles are the same mass, keep this particle if it
		  ** has a lower original index, or, if both particles have
		  ** same original index, keep this particle if it has a
		  ** lower processor number, or, if both particles are on
		  ** same processor, keep particle with lower iOrder.
		  */		  
		  pMrg = &c1.id; /* new centre-of-mass particle */		  
		  pOth = &c2.id;
		}
		if (c2.id.iPid == pkd->idSelf) { /* same thing for other particle */  
		  pDel = &c2.id;
		  pOth = &c1.id;
		}
	
		/* 
		 ** Store or delete particle as appropriate, and make
		 ** sure master knows ID of surviving particle for
		 ** tracking purposes.
		 */
		if (pMrg) {			
		  PutColliderInfo(&c1,INT_MAX,&pkd->pStore[pMrg->iIndex],dt);
			/*if (bDiagInfo) cOut[0].id = *pMrg;*/ /* struct copy */	
			}
	
		if (pDel) {	
    		        pkdDeleteParticle(pkd,&pkd->pStore[pDel->iIndex]);		 
			/*if (bDiagInfo && !pMrg) cOut[0].id = *pOth;*/ /* may need merger info */	
			}


		}
	else if (n == 2) { /* bounce or mass transfer */	 
		if (c1.id.iPid == pkd->idSelf)
			PutColliderInfo(&c1,c2.id.iOrder,&pkd->pStore[c1.id.iIndex],dt);
		if (c2.id.iPid == pkd->idSelf) {			
			PutColliderInfo(&c2,c1.id.iOrder,&pkd->pStore[c2.id.iIndex],dt);
			}	
		}
	else { /* fragmentation */
		assert(0); /* not implemented yet */	
	}


	// split here?

}

void calc_aei(COLLIDER c1,double dSunMass,double *pa1,double *pe1,double *pi1){
  double r2,v2,r,summ,Etot,Lx,Ly,Lz,L2,a,e2,i2;
  int j;

  /* 2body e i for c1 
     the central mass position is assumed to be the mass center
  */
  r2 = 0.0;
  v2 = 0.0;
  for(j=0;j<3;j++){
    r2 += c1.r[j]*c1.r[j];
    v2 += c1.v[j]*c1.v[j];
  }
  r = sqrt(r2);
  //  summ = dSunMass+c1.fMass;
  summ = dSunMass;
  Etot = 0.5*v2 - summ/r;

      Lx = c1.r[1]*c1.v[2] - c1.r[2]*c1.v[1];
      Ly = c1.r[2]*c1.v[0] - c1.r[0]*c1.v[2];
      Lz = c1.r[0]*c1.v[1] - c1.r[1]*c1.v[0];

      L2 = Lx*Lx + Ly*Ly + Lz*Lz;
      
      a = -0.5*summ/Etot; 
      if(a < 0.0) a = r;
     
      e2 =  1.0 - L2/(summ*a); /*e^2*/
      if(e2 < 0.0) e2 = 0.0;
      
      i2 = 1.0 - Lz*Lz/L2; /*sin(I)^2*/
      if(i2 < 0.0) i2 = 0.0;
        
      *pa1 = a;
      *pe1 = sqrt(e2);
      *pi1 = sqrt(i2);
      
}

void calc_dthe(COLLIDER c1,COLLIDER c2,double *pdthe){
  double dthe,r2d,the2,r1d,the1;
	  
  r2d = sqrt(c2.r[0]*c2.r[0] + c2.r[1]*c2.r[1]);
  the2 = acos(c2.r[0]/r2d);
  if(c2.r[1] < 0) the2 = 2.0*M_PI - the2;

  r1d = sqrt(c1.r[0]*c1.r[0] + c1.r[1]*c1.r[1]);
  the1 = acos(c1.r[0]/r1d);
  if(c1.r[1] < 0) the1 = 2.0*M_PI - the1;

  dthe = the2-the1;
  if(dthe > M_PI)dthe -= 2.0*M_PI;
  if(dthe < -M_PI)dthe += 2.0*M_PI;
  
  *pdthe = dthe;
}


 void pkdBouncePBHYB(PKD pkd,COLLIDER *c1,COLLIDER *c2,double dDmi,double lz1,double lz2, double facr2,double cimp,double dEpsN, double dEpsT,int bDiagInfo,double dTime,int *pnOut, double *dT){
  
  COLLIDER *c2p,cc;
  
  int i,k;
  double n1 = c1->nump*1.0;
  double mt1 = c1->fMass;
  double n2 = c2->nump*1.0;
  double mt2 = c2->fMass;
  double dSunMass = pkd->dSunMass;
  double m1,m2,a1,a2,a1a,a2a,e1,e2,i1,i2,tot_ang;
  double facv2,vr2,ve2,nf[3],vr[3],vr0[3],vrd[3],vr02;
  double cb,sb,cg,sg,a,b,ut2,un2,ut[3],un[3],vrd2;
  double rc[3],nd,simp,fz2,fzb;
  FILE *fp;
  int TRGRAV = pkd->param.HY.iTRGRAV;

  double dSunMass1, dSunMass2;

  
  dSunMass1  = dSunMass + c1->fMass - c1->a_pr;
  dSunMass2  = dSunMass + c2->fMass - c2->a_pr;

    
  *dT = 0.0; // temporary

  m1 = mt1/n1;
  m2 = mt2/n2;

  //copy c2 to c2p 
  c2p = &cc;
  *c2p = *c2; 
  *pnOut = 2;
  nd = dDmi/m2;

  // tot_ang (before a correction)
  tot_ang = mt1*lz1+mt2*lz2;

  if(bDiagInfo){
    

    if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
      fp = fopen(COLL_LOG_PBHYB_TXT,"a");
      assert(fp != NULL);	
      
      fprintf(fp,"time=%e yr,Bounce,Nin=%i,Nout=%i,dDmi=%e,nd=%g)\n",
	      dTime/(2.0*M_PI),2,*pnOut,dDmi,nd);
      fprintf(fp,"in 1:p=%i,o=%i,oi=%i,color=%i,c2id = %i,mt=%e,rt=%e,m=%e,n=%f,"
	      "r=(%e,%e,%e),v=(%e,%e,%e)\n",
	      c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
	      c1->fMass,c1->fRadius,m1,c1->nump,
	      c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);	
      fprintf(fp,"in 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i mt=%e,rt=%e,m=%e,n=%f,"
	      "r=(%e,%e,%e),v=(%e,%e,%e)\n",
	      c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
	      c2->fMass,c2->fRadius,m2,c2->nump,
	      c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);
      fclose(fp);
    }
    
    /* to be deleted */

    /* use pkd->param.iCollLogOption = 1 or 3 to display the following line*/
    
    if(pkd->param.iCollLogOption & COLL_LOG_BOUNCE2){
      printf("Collision ST t %g yr, Bounce, m1 %g, m2 %g, nd %g, n1 %g, n2 %g id1 %d id2 %d col1 %d \n",
	     dTime/(2.0*M_PI),m1,m2,nd,c1->nump,c2->nump,c1->id.iOrgIdx,c2->id.iOrgIdx,c1->iColor);
    }

    if(pkd->param.iCollLogOption & COLL_LOG_STAND){

      a1 = 0.0;
      a2 = 0.0;
      for (k=0;k<3;k++) {
	a1 += c1->r[k]*c1->r[k];
	a2 += c2->r[k]*c2->r[k];
      }
        
      printf("in 1:p=%i,o=%i,oi=%i,color=%i,c2id = %i,mt=%e,rt=%e,m=%e,n=%f,"
	     "r=(%e,%e,%e),v=(%e,%e,%e), r1 %g \n",
	     c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
	     c1->fMass,c1->fRadius,m1,c1->nump,
	     c1->r[0],c1->r[1],c1->r[2],
	     c1->v[0],c1->v[1],c1->v[2],sqrt(a1));	
      printf("in 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i mt=%e,rt=%e,m=%e,n=%f,"
	     "r=(%e,%e,%e),v=(%e,%e,%e), r2 %g \n",
	     c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
	     c2->fMass,c2->fRadius,m2,c2->nump,
	     c2->r[0],c2->r[1],c2->r[2],
	     c2->v[0],c2->v[1],c2->v[2],sqrt(a2));
    }
    
  }
  
 
  // a correction for c2p
  facv2 = sqrt(1.0/facr2);
  for (i=0;i<3;i++) {
    c2p->r[i] *= facr2;
    c2p->v[i] *= facv2;
  }
 
  // facv2 = sqrt(a2/a1);			
  vr02 = 0.0;
  ve2 = 2.0*(m1+m2)/(c1->ele[8]+c2->ele[8]);
  if(TRGRAV==0)ve2 = 0.0; //test
  for (i=0;i<3;i++) {				
    /*    c2p->v[i] = c2->v[i]*facv2;
	  c2p->r[i] = c2->r[i]*(a1/a2);*/
    vr0[i] = (c2p->v[i] - c1->v[i]); 
    vr02 += vr0[i]*vr0[i];
  }
  // printf("vr0 %g ve %g cimp %g\n",sqrt(vr02),sqrt(ve2),cimp);

  /* relative velocity correction due to gravitational accelaration */
  if(TRGRAV){
    facv2 = sqrt(1.0+ve2/vr02);
  }else{
    facv2 = 1.0;
  }
    vr2 = 0;
    for (i=0;i<3;i++) {	  
      vr[i] = facv2*vr0[i]; 
      vr2 += vr[i]*vr[i];
    }
  
  /* making ficticious normal vector contacting centers of particles relative to z axis */
  
  nf[2] = cimp;
  simp = sqrt(1.0-cimp*cimp);
  nf[0] = 2.0*M_PI*((double)drand48());
  nf[1] = simp*sin(nf[0]);
  nf[0] = simp*cos(nf[0]);	 
   
  // printf("nf0 = (%g %g %g) \n",nf[0],nf[1],nf[2]);
  /* calculate vr relative to z axis 
     vr/|vr| is first given as (0,0,1). It is then rotated around y axis by beta 
     and rotated around z axis by gamma. These rotations are applied to nf below.
  */
  cb = vr[2]*vr[2]/vr2;
  sb = sqrt(1.0-cb);
  cb = sqrt(cb);
  if(vr[2] < 0) cb = -cb; 
  cg = sqrt(vr[0]*vr[0] + vr[1]*vr[1]);
  sg = vr[1]/cg;
  cg = vr[0]/cg;
  
  //printf("cb %g sb %g cg %g sg %g \n",cb,sb,cg,sg);

  //rotate nf by beta around y axis (rc tempoerarily use)
  rc[0] = cb*nf[0] + sb*nf[2];
  rc[1] = nf[1];
  rc[2] = -sb*nf[0] + cb*nf[2];
  
  //rotate vr by gamma around z axis
  nf[0] = cg*rc[0] -sg*rc[1];
  nf[1] = sg*rc[0] +cg*rc[1];
  nf[2] = rc[2];
  
  // renormalization just in case
  cg = sqrt(nf[0]*nf[0]+nf[1]*nf[1]+nf[2]*nf[2]);
  nf[0] = nf[0]/cg;  
  nf[1] = nf[1]/cg;
  nf[2] = nf[2]/cg;
  
  // printf("nf = (%g %g %g) \n",nf[0],nf[1],nf[2]);
  // printf("vr = (%g %g %g) \n",vr[0]/sqrt(vr2),vr[1]/sqrt(vr2),vr[2]/sqrt(vr2));
  a = vr[0]*nf[0] + vr[1]*nf[1] + vr[2]*nf[2]; /* relative vel in normal direction */
  
  //printf("relative vr vn = %g %g \n",sqrt(vr2),a);
  assert(a >= 0.0);   

  ut2 = 0.0;
  un2 = 0.0;
  for (i=0;i<3;i++) {
    un[i] = a*nf[i];
    ut[i] = vr[i] - un[i];

    ut2 += ut[i]*ut[i]; 
    un2 += un[i]*un[i]; 
  }
  if(ve2 > 0 && dEpsN*dEpsN*un2 + dEpsT*dEpsT*ut2 < ve2){/* post-impact relative velocity is lower than the escape velocity; 
				     here we set new dEpsN so that relative velocity is ve */
    
    dEpsN = sqrt((ve2-ut2)/un2)+1.e-5; 
    //printf("dEpsN = %g \n",dEpsN);
    assert(dEpsN < 1.01);
  }
  // printf("dEpsN = %g dEpsT = %g \n",dEpsN,dEpsT);

  vrd2 = 0.0;
  for (i=0;i<3;i++){
    vrd[i] = -dEpsN*un[i] + dEpsT*ut[i];
    vrd2 += vrd[i]*vrd[i];
  }
  //printf("vrd a  = %g \n",sqrt(vrd2));
  /* a = (1 + dEpsN);
  b = 2.0/7.0*(1 - dEpsT); // we leave this equation, but dEpsT needs to be 1 as we ignore spins
  vr2d = 0;
  for (i=0;i<3;i++){
    vr[i] = a*un[i] + b*ut[i];
    vr2d = vr[i]*vr[i];
  }*/

  // deceleration due to gravity
  if(TRGRAV==0){
    facv2 = sqrt(1.0-ve2/vrd2);
  }else{
    facv2 = 1.0;
  }
  vrd2 = 0.0;
  for (i=0;i<3;i++){
    vrd[i] *= facv2;
    vrd2 += vrd[i]*vrd[i];
  }
  // printf("vrd = %g \n",sqrt(vrd2));   
  
  a =  dDmi/(m1+dDmi);
  b =  m1/(m1+dDmi);
  // facv2 = sqrt(vrd2/vr02);
  //printf("facv2 = %g \n",facv2);

  for (i=0;i<3;i++) {
    c1->v[i] -= a*(vrd[i]-vr0[i]);
    c2p->v[i] += b*(vrd[i]-vr0[i]);   
  }
        
  /* merge c2p (mt = m1*dDmi) and c2 (mt = mt2 - m1*dDmi) if m1*dDmi < mt2 */
  if(c2->iColflag == 3){ // all planetesimals in c2 are involved in the collision 
    *c2 = *c2p;
  }else{ // partial
    m1 = n1*dDmi;
    m2 = mt2 - m1;
    assert(m2 > 0);
     
    //  printf("m2 %g r2 = (%g %g %g), v2 = (%g %g %g) \n",m2,c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);   
    //  printf("m1 %g r2p = (%g %g %g), v2p = (%g %g %g) \n",m1,c2p->r[0],c2p->r[1],c2p->r[2],c2p->v[0],c2p->v[1],c2p->v[2]);
    
    a = 0.0;
    b = 0.0;
    for (i=0;i<3;i++) {
      a += c2->r[i]*c2->r[i];
      b += c2p->r[i]*c2p->r[i];
    }  
   
    a = sqrt(a/b);

    /* now merge */
    for (i=0;i<3;i++) {
      c2->r[i] = (m1*c2p->r[i]*a + m2*c2->r[i])/mt2; // positions should be the same after a correction, but just in case
      c2->v[i] = (m1*c2p->v[i]/sqrt(a) + m2*c2->v[i])/mt2;      	
    }  
  }

    /* determine new a for c2 based on angular momentum conservation */
    calc_aei(*c1,dSunMass1,&a1,&e1,&i1);
    // tot_ang -= mt1*sqrt(a1*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass+mt1));
    tot_ang -= mt1*sqrt(a1*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass1));
    
    calc_aei(*c2,dSunMass2,&a2,&e2,&i2);
    //  a2a = tot_ang*tot_ang/(mt2*mt2*(1.0-i2*i2)*(1.0-e2*e2)*(dSunMass+mt2));
    a2a = tot_ang*tot_ang/(mt2*mt2*(1.0-i2*i2)*(1.0-e2*e2)*(dSunMass2));
    facr2 = a2a/a2;
    facv2 = sqrt(1.0/facr2);
    
    for (i=0;i<3;i++) {
      c2->v[i] *= facv2; 
      c2->r[i] *= facr2;
    }


    if(bDiagInfo){
      if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	fp = fopen(COLL_LOG_PBHYB_TXT,"a");
	assert(fp != NULL);
	fprintf(fp,"out 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		"r=(%e,%e,%e),v=(%e,%e,%e)\n",
		c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		c1->fMass,c1->fRadius,m1,c1->nump,
		c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);	   
	fprintf(fp,"out 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		"r=(%e,%e,%e),v=(%e,%e,%e)\n",
		c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		c2->fMass,c2->fRadius,m2,c2->nump,
		c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);	    
	fclose(fp);
      }
      
      /* to be deleted */
      if(pkd->param.iCollLogOption & COLL_LOG_STAND){
	a1 = 0.0;
	a2 = 0.0;
	for (k=0;k<3;k++) {
	  a1 += c1->r[k]*c1->r[k];
	  a2 += c2->r[k]*c2->r[k];
	}
	
	printf("out 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
	       "r=(%e,%e,%e),v=(%e,%e,%e),r1 %g\n",
	       c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
	       c1->fMass,c1->fRadius,m1,c1->nump,
	       c1->r[0],c1->r[1],c1->r[2],
	       c1->v[0],c1->v[1],c1->v[2],sqrt(a1));	 
	printf("out 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i,mt=%e,rt=%e,m=%e,n=%f,"
	       "r=(%e,%e,%e),v=(%e,%e,%e), r2 %g\n",
	       c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
	       c2->fMass,c2->fRadius,m2,c2->nump,
	       c2->r[0],c2->r[1],c2->r[2],
	       c2->v[0],c2->v[1],c2->v[2],sqrt(a2));	  
      }

    }
    
      
}

// pkdFragmass(pkd,&c1,&c2,dDmi,vr2+ve2,&m1,&n1,&iColor1); 

void pkdFragmass(PKD pkd,COLLIDER *c1,COLLIDER *c2,double m2,double vimp2,double *pm1,double *pn1){
  double n1 = c1->nump*1.0;
  double mt1 = c1->fMass;
  double m1,m12,m1b,n1b;
  double Qimp,Qds,phi,mfrag,mlr,mlf,n1int,mup,mdown,rr;
  
  double fac1 = 1.e-4/(AU*AU)*(JUL_YR*JUL_YR)/(4.0*PI*PI); // erg/g 
  /*double Q0 = 3.5e7*fac1;
  double B = 0.3*2.95*fac1;
  double aa = -0.38;
  double bb = 1.36;*/
  // ice 3 km/s
  double Q0 = 1.6e7*fac1;
  double B = 1.2*2.95*fac1;
  double aa = -0.39;
  double bb = 1.26;
  double rad = c1->ele[8]/(1.e-2/(AU));

  m1 = mt1/n1;
  m12 = m1+m2;
  Qimp = 0.5*m1*m2*vimp2/(m12*m12);
  Qds =  Q0*pow(rad,aa)+B*pow(rad,bb);
  phi = Qimp/Qds;

  mfrag = m12*phi/(1.0+phi);
  mlr = m12-mfrag;

  rr = ((double)drand48());
  if(rr < mlr/m12){//  tracer 1 is used for the largest remnant
    m1b = mlr;
  }else{//  tracer 1 is used for the fragment
    mlf = 0.2*mfrag/(1.0-phi);
    rr = ((double)drand48());
    m1b = pow(rr,6.0)*mlf;   
  }

  // *piColor = c1->iColor;
  //  if(m1b < mpebble)  m1b = mpebble;
 
  if(m1b < c1->mmin) m1b = c1->mmin; // St = St_min 
  if(m1b < mpe0)  m1b = mpe0; // mass is larger than mpe0 defined in ssio.h

   
  

  // new number of planetesimals 
  n1b = m12*n1/(m1b);
  
  // adjudst n1 to an integer  
  if(n1b < INT_MAX*1.0 - 1.0){
    n1int = ((int)n1b)*1.0;
    mup = m1b*n1b/n1int;
    mdown = m1b*n1b/(n1int+1.0);
    rr = ((double)drand48());
    
    if((m1b-mdown)/(mup-mdown) > rr){
      m1b = mup;
      n1b = n1int;
    }else{
      m1b = mdown;
      n1b = n1int + 1.0;
    }
  }

  //assert(m1b <= m12);
  if(m1b > 1.001*m12){
     printf("WARNING!!!! post collision mass m1b > sum of colliders m12 due to mass discretization; phi %g m1 %g n1 %g m2 %g m12 %g m1b %g n1b %g m1b/m12 %g eff %g\n",
	     phi,m1,n1,m2,m12,m1b,n1b,m1b/m12,(m1b-m1)/m2);
  }
  
  /* if(m1b == m12){
    printf("Merge !! ");
  }else{
     
    if(m1b <= mlf){
      printf("Fragment !!! !! ");
    }else{
      printf("Erosive !! ");
    }
  }
  printf("phi %g m1 %g n1 %g m2 %g m12 %g m1b %g n1b %g m1b/m12 %g eff %g\n",
	 phi,m1,n1,m2,m12,m1b,n1b,m1b/m12,(m1b-m1)/m2);
  */
	    
  
    *pm1 = m1b;
    *pn1 = n1b;
   
}


void pkdMergePBHYB(PKD pkd,COLLIDER *c1,COLLIDER *c2,double dDensity, double dDmi, double lz1, double lz2, double facr2, int iexcess, int bDiagInfo, double dTime, int *pnOut, double *dT, int iOutcome, double n1b, int pflag)
{
     
  COLLIDER *c2p,cc;

        double com_pos[3],com_vel[3];
	double m,a1,a2,e1,i1,i2,e2,tot_ang;
	double facr1,facv1,facv2,a1a,a2a,v1,v2,r1,r2,d;
	int i,k,j;
	
	double dSunMass = pkd->dSunMass;

	double n1 = c1->nump*1.0;
	double mt1 = c1->fMass;
	double n2 = c2->nump*1.0;
	double mt2 = c2->fMass;
	double m1, m2, mt11,mt22;
	double nd,xx,yy,dth,cth,sth,pr,v_r,v_th;
	double mt0 = pkd->param.HY.fMt0;
	double dtheta = pkd->param.HY.fdtheta;
	FILE *fp, *fp2;
	XDR xdrs;	
	int nin = 2;
	int nsp = 1;
	double dSunMass1, dSunMass2;

  
	dSunMass1  = dSunMass + c1->fMass - c1->a_pr;
	dSunMass2  = dSunMass + c2->fMass - c2->a_pr;
	
	//copy c2 to c2p ;;   c2p for r and v of actural colliding planetesimals in the tracer
	c2p = &cc;
	*c2p = *c2; 

	if(c2->iColflag == 3){ // Case (b)
	  /* interloper deleted if iexcess = 1 and m1+m2 >mt0 or c1 is subembryo */
	  if((iexcess && c1->fMass+c2->fMass < 1.999999*mt0) || c1->nump == 1.0){	    
	    *pnOut = 1;
	  }else{
	    *pnOut = 2;
	  }
	}else{ // Case (a) further spliting may be made in pkdsplitPBHYB
	  *pnOut = 2;
	}

	m1 = mt1/n1;
	m2 = mt2/n2;

	nd = dDmi/m2; /* num of planetesimals colliding with a target planetesimal */

	tot_ang = lz1*mt1 + lz2*dDmi*n1; /* ang conservation for planetesimals involved in collisions */
	
	if(bDiagInfo){ // should be recorded before the a2 correction is made ???

	  if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	     fp = fopen(COLL_LOG_PBHYB_TXT,"a");
	     assert(fp != NULL);	
	
	     fprintf(fp,"time=%e yr, Merge, Nin=%i,Nout=%i,dDmi=%e,nd=%g)\n",
		     dTime/(2.0*M_PI),2,*pnOut,dDmi,nd);
	     fprintf(fp,"in 1:p=%i,o=%i,oi=%i,color=%i,c2id = %i,mt=%e,rt=%e,m=%e,n=%f,"
		     "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		     c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		     c1->fMass,c1->fRadius,m1,c1->nump,
		     c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);	
	     fprintf(fp,"in 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i mt=%e,rt=%e,m=%e,n=%f,"
		     "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		     c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		     c2->fMass,c2->fRadius,m2,c2->nump,
		     c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);
	     fclose(fp);
	     }

	  if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
	    fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
	    assert(fp2 != NULL);
	    xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
			  
	    (void) xdr_int(&xdrs,&nsp); /* just for consistency with the log for splitting */	
	    (void) xdr_double(&xdrs,&dTime);	 
	    (void) xdr_int(&xdrs,&nin);
	    (void) xdr_int(&xdrs,pnOut);
	    (void) xdr_double(&xdrs,&nd);

	    //printf("ccccc time=%e yr, Merge, Nin=%i,Nout=%i,dDmi=%e,nd=%g, nsp =%d)\n",
	    //		   dTime/(2.0*M_PI),2,*pnOut,dDmi,nd,nsp);

	    
	    CollisionDataPBHYB(&xdrs,c1);
	    CollisionDataPBHYB(&xdrs,c2);

	    xdr_destroy(&xdrs);
	    (void) fclose(fp2);	  
	  }

	  /* to be deleted */

	  //printf("Collision ST t %g yr, Merge, m1 %g, m2 %g, nd %g, n1 %g, n2 %g col1 %d \n",
	  //		 dTime/(2.0*M_PI),m1,m2,nd,c1->nump,c2->nump,c1->iColor);
	  //if(c1->iColor == PEBBLE || c2->iColor == PEBBLE){
	  if(c1->St < 2.0 || c2->St < 2.0){
	    printf("Collision ST t %g yr, Merge, m1 %g, m2 %g, nd %g, n1 %g, n2 %g id1 %d id2 %d col1 %d col2 %d\n",
		   dTime/(2.0*M_PI),m1,m2,nd,c1->nump,c2->nump,c1->id.iOrgIdx,c2->id.iOrgIdx,c1->iColor,c2->iColor);
	  }
	  
	  if(pkd->param.iCollLogOption & COLL_LOG_STAND){
	    a1 = 0.0;
	    a2 = 0.0;
	    for (k=0;k<3;k++) {
	      a1 += c1->r[k]*c1->r[k];
	      a2 += c2->r[k]*c2->r[k];
	    }
	    
	   
	    printf("in 1:p=%i,o=%i,oi=%i,color=%i,c2id = %i,mt=%e,rt=%e,m=%e,n=%f,"
		   "r=(%e,%e,%e),v=(%e,%e,%e), r1 %g \n",
		   c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		   c1->fMass,c1->fRadius,m1,c1->nump,
		   c1->r[0],c1->r[1],c1->r[2],
		   c1->v[0],c1->v[1],c1->v[2],sqrt(a1));	
	    printf("in 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i mt=%e,rt=%e,m=%e,n=%f,"
		   "r=(%e,%e,%e),v=(%e,%e,%e), r2 %g \n",
		   c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		   c2->fMass,c2->fRadius,m2,c2->nump,
		   c2->r[0],c2->r[1],c2->r[2],
		   c2->v[0],c2->v[1],c2->v[2],sqrt(a2));
	  }
	  
	}

	// a correction for c2p
	facv2 = sqrt(1.0/facr2);
	for (i=0;i<3;i++) {
	  c2p->r[i] *= facr2;
	  c2p->v[i] *= facv2;
	}

	m = m1 + dDmi;
	
	v1 = 0;
	v2 = 0;
	r1 = 0;
	r2 = 0;
	for (k=0;k<3;k++){
	  v1 += (c1->v[k]*c1->v[k]);
	  v2 += (c2p->v[k]*c2p->v[k]);
	  r1 += (c1->r[k]*c1->r[k]);
	  r2 += (c2p->r[k]*c2p->r[k]);	
	}
	r1 = sqrt(r1);
	r2 = sqrt(r2);
	*dT -= 0.5*n1*m1*v1 - pkd->dSunMass*m1*n1/r1;
	*dT -= 0.5*n2*m2*v2 - pkd->dSunMass*m2*n2/r2;

	/* now merge */
	if(pflag == 0){
	  for (k=0;k<3;k++) {
	    c1->r[k] = (m1*c1->r[k] + dDmi*c2p->r[k])/m;
	    c1->v[k] = (m1*c1->v[k] + dDmi*c2p->v[k])/m;
	    c1->w[k] = (pow(m1,5.0/3.0)*c1->w[k] + pow(dDmi,5.0/3.0)*c2p->w[k])/pow(m,5.0/3.0);	
	    /* c2->w is non-zero only if c2 is subembryo (sub-sub collision may be handled here later )*/  
	  }
	}else{
	  pr = sqrt(c1->r[0]*c1->r[0] + c1->r[1]*c1->r[1]);
	  v_r = (c1->r[0]*c1->v[0] + c1->r[1]*c1->v[1])/pr;
	  v_th = (c1->r[0]*c1->v[1] - c1->r[1]*c1->v[0])/pr;
	  //  printf("v_r %g vb[0] %g v_th %g vb[1] %g \n",v_r,c1->vb[0],v_th,c1->vb[1]);
	  
	  v_r =  (m1*c1->vb[0] + dDmi*c2->vb[0])/m;
	  v_th = v_th-c1->vb[1] + (m1*c1->vb[1] + dDmi*c2->vb[1])/m;
	  
	  c1->v[0] = (c1->r[0]*v_r - c1->r[1]*v_th)/pr; 
	  c1->v[1] = (c1->r[1]*v_r + c1->r[0]*v_th)/pr; 
	  c1->v[2] = (m1*c1->vb[2] + dDmi*c2->vb[2])/m;
	}
	
	c1->dls *= m1/m;
	c2->dls = 0.0; // just in case

	/* c1->nump = n1;  unchanged */
	m1 = m;
	c1->fMass = n1*m1; 
	mt11 = c1->fMass; 
	
	//	c2->nump = (int) (n2-nd*n1);
	c2->nump = n2-nd*n1;

	if(c2->nump > 0 && c2->nump*m2 < 0.5*ftmin*mt0){ // correction to remove tracers that have too little masses due to round off error 
	  c2->nump = 0.0;
	  n1 = (mt1+mt2)/m1;
	  printf("n1 corrected id1 = %d, id2 = %d  \n",c1->id.iOrgIdx,c2->id.iOrgIdx);
	}
	if(c2->nump < 1.e-2) c2->nump = 0.0; // correction to remove the round off error no need now? 081115
	nd = c2->nump*1.0;
	c2->fMass = nd*m2;
	mt22 = c2->fMass;

	// add110416 !!!!!  m1, n1, color1
	if(iOutcome == FRAG){
	  // pebble - tracer collision results in tracer if the resulted target (can be pebble) mass is > mmin 
	  if(c1->iColor > c2->iColor)c1->iColor = c2->iColor; 
	  n1 = n1b;
	  c1->nump = n1b;
	  m1 = c1->fMass/n1b;
	  // if(m1 <= mpe0*1.00000001)c1->iColor = PEBBLE;
	  // if(m1 <= c1->mmin*1.00000001)c1->iColor = PEBBLE; // remove this line if we allow sticking bwtween them	 
	}
	// !!!!
	
	/* split the target if the interloper's mass is zero and N < N0 */
 
	if(c2->nump == 0 && *pnOut == 2){
	  assert(c2->fMass == 0.0);	  
	  if(c2->id.iPid == c1->id.iPid && c2->iColflag != 3){
	    printf("%d %d %g \n", c2->iColflag,c1->iColflag,dDmi);
	    assert(0);
	  }

	// adjust n1 to integer if n1 < INT_MAX
	// this adjustment increases the mass of the planetesimal by ~ 1/INT_MAX
	// while the tracer mass is unchanged
	  if(n1 < INT_MAX*1.0){
	    c1->nump = ((int)n1)*1.0;
	    m1 *= n1/c1->nump;
	    c1->fMass *= n1/c1->nump;
	    n1 = c1->nump;

	    c2->nump = ((int)c1->nump)/2;
	    c2->nump *= 1.0;
	    c1->nump -= c2->nump;
	  }else{	   
	    c2->nump = c1->nump/2.0;
	    c1->nump -= c2->nump;
	  }

	  m2 = m1;
	  n1 = c1->nump;
	  n2 = c2->nump;
	  c1->fMass = m1*n1;
	  c2->fMass = m2*n2;	  
	  c2->iColor = c1->iColor;
	    
	  mt11 = c1->fMass; /* tracer mass after split */
	  mt22 = c2->fMass; /* tracer mass after split */
	  
	  r1 = 0;
	  r2 = 0;
	  /*copy c1 r and v to c2p r and v*/
	  for (k=0;k<3;k++) {     
	    c2p->r[k] = c1->r[k];	  
	    c2p->v[k] = c1->v[k];	   	 	  
	    c2p->w[k] = c1->w[k];

	    r1 += c1->r[k]*c1->r[k];
	    r2 += c2p->r[k]*c2p->r[k];
	  }

	  r1 = sqrt(r1);
	  r2 = sqrt(r2);

	  /* give a symmetric kick to make a small relative velocity
	   angular momentum is conserved? */

	  d = 0.1*c1->ele[7];   

	  e1 = d;
	  i1 = 0.5*d;
	    
	  facv1 = c1->v[0]*mt22/(mt11+mt22)*e1;
	  c1->v[0] += facv1;
	  c2p->v[0] -= facv1*r1*mt11/(r2*mt22);
	  facv1 = c1->v[1]*mt22/(mt11+mt22)*e1;
	  c1->v[1] += facv1;
	  c2p->v[1] -= facv1*r1*mt11/(r2*mt22); 
	  facv1 = c1->v[2]*mt22/(mt11+mt22)*i1;
	  c1->v[2] += facv1;
	  c2p->v[2] -= facv1*r1*mt11/(r2*mt22);

	  // change a2 to pre-impact value
	  a2a = c2->ele[0];
	  calc_aei(*c2p,dSunMass2,&a2,&e2,&i2);
	  facr1 = a2a/a2;
	  facv1 = sqrt(1.0/facr1);
	  
	  /* copy v and r of c2p to c2 after fac correction */
	  for (k=0;k<3;k++) {
	    c2->r[k] = facr1*c2p->r[k];
	    c2->v[k] = facv1*c2p->v[k];     
	    c2->w[k] = c2p->w[k];
	  }

	  if(pflag == 1){ // randomly rotates c2 position
	    dth = dtheta*M_PI*(1.0-2.0*(double)drand48());
	    cth = cos(dth);
	    sth = sin(dth);
	    xx = c2->r[0];
	    yy = c2->r[1];
	    c2->r[0] = cth*xx-sth*yy;
	    c2->r[1] = sth*xx+cth*yy; 
	  }
	  
	  //a1 change for ang conservation
	  // tot_ang -= mt22*sqrt(a2a*(1.0-i2*i2)*(1.0-e2*e2)*(dSunMass+mt22));
	  tot_ang -= mt22*sqrt(a2a*(1.0-i2*i2)*(1.0-e2*e2)*(dSunMass2));

	  calc_aei(*c1,dSunMass1,&a1,&e1,&i1); 
	  // a1a = tot_ang*tot_ang/(mt11*mt11*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass+mt11));
	  a1a = tot_ang*tot_ang/(mt11*mt11*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass1));
	  facr1 = a1a/a1;
	  facv1 = sqrt(1.0/facr1);
	  
	  for (k=0;k<3;k++) {
	    c1->r[k] = facr1*c1->r[k];
	    c1->v[k] = facv1*c1->v[k];     
	  }

	  /*
	  // a2 change for ang conservation 
	  calc_aei(*c1,dSunMass,&a1,&e1,&i1); 
	  tot_ang -= mt11*sqrt(a1*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass+mt11));
	  calc_aei(*c2p,dSunMass,&a2,&e2,&i2);
	  a2a = tot_ang*tot_ang/(mt22*mt22*(1.0-i2*i2)*(1.0-e2*e2)*(dSunMass+mt22));
	  facr1 = a2a/a2;
	  facv1 = sqrt(1.0/facr1);
	  
	  // copy v and r of c2p to c2 after fac correction 
	  for (k=0;k<3;k++) {
	    c2->r[k] = facr1*c2p->r[k];
	    c2->v[k] = facv1*c2p->v[k];     
	    c2->w[k] = c2p->w[k];
	  }
	  */

	}else{
	/* a1 change for ang conservation  */
	  calc_aei(*c1,dSunMass1,&a1,&e1,&i1); 
	  //  a1a = tot_ang*tot_ang/(mt11*mt11*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass+mt11));
	  a1a = tot_ang*tot_ang/(mt11*mt11*(1.0-i1*i1)*(1.0-e1*e1)*(dSunMass1));
	  facr1 = a1a/a1;
	  facv1 = sqrt(1.0/facr1);
	  
	  for (k=0;k<3;k++) {
	    c1->r[k] = facr1*c1->r[k];
	    c1->v[k] = facv1*c1->v[k];     
	  }

	  /* position and velocity of c2 unchanged */

	}

	
	/* New Radii for tracers */
	c1->fRadius *= cbrt(mt11/mt1);
	
	if(c2->nump ==0.0){
	  c2->fRadius = 0.0;
	}else{
	  c2->fRadius *= cbrt(mt22/mt2);
	}

	for (k=0;k<3;k++){ // need correction...
	      *dT += 0.5*n1*m1*(c1->v[k]*c1->v[k]) - pkd->dSunMass*m1*n1/r1;
	      if(*pnOut == 2) *dT += 0.5*n2*m2*(c2->v[k]*c2->v[k]) - pkd->dSunMass*m2*n2/r2;
	}
	
	
	/* update to subrmbryo or fullembryo ?  Take log here */
	
	if(c2->nump == 1.0 && c2->fMass >= mt0){
	  c2->iColor = SUBEMBRYO;

	  printf("c2 promoted to Subembryo 1:p=%i,o=%i,oi=%i,color=%i,c1id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		    "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		    c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		    c2->fMass,c2->fRadius,m2,c2->nump,
		    c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);	  
	}
	
	if(c1->nump == 1.0 && c1->fMass >= mt0){
	  c1->iColor = SUBEMBRYO;
	  printf("c1 promoted to subembryo 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		    "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		    c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		    c1->fMass,c1->fRadius,m1,c1->nump,
		    c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);
	}
	if(c1->nump == 1.0 && c1->fMass >=  pkd->param.HY.fff*mt0)c1->iColor = PLANETESIMAL;
	
	if(c1->fMass/c1->nump <= c1->mmin*1.00000001){
	  printf("out 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		    "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		    c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		    c1->fMass,c1->fRadius,m1,c1->nump,
		    c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);
	}
  
	if(bDiagInfo){
	  if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	    fp = fopen(COLL_LOG_PBHYB_TXT,"a");
	    assert(fp != NULL);
	    fprintf(fp,"out 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		    "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		    c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		    c1->fMass,c1->fRadius,m1,c1->nump,
		    c1->r[0],c1->r[1],c1->r[2],c1->v[0],c1->v[1],c1->v[2]);
	    if(*pnOut ==2){
	      fprintf(fp,"out 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		      "r=(%e,%e,%e),v=(%e,%e,%e)\n",
		      c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		      c2->fMass,c2->fRadius,m2,c2->nump,
		      c2->r[0],c2->r[1],c2->r[2],c2->v[0],c2->v[1],c2->v[2]);
	    }
	    fclose(fp);
	  }
	

	  if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
	    fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
	    assert(fp2 != NULL);
	    xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
	    
	    CollisionDataPBHYB(&xdrs,c1);
	    if(*pnOut ==2){
	      CollisionDataPBHYB(&xdrs,c2);
	    }
	    xdr_destroy(&xdrs);
	    (void) fclose(fp2);	  
	  }
	  
	  /* to be deleted */
	  if(pkd->param.iCollLogOption & COLL_LOG_STAND){
	    a1 = 0.0;
	    a2 = 0.0;
	    for (k=0;k<3;k++) {
	      a1 += c1->r[k]*c1->r[k];
	      a2 += c2->r[k]*c2->r[k];
	    }
	    
	    printf("out 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		   "r=(%e,%e,%e),v=(%e,%e,%e),r1 %g\n",
		   c1->id.iPid,c1->id.iOrder,c1->id.iOrgIdx,c1->iColor,c2->id.iOrgIdx,
		   c1->fMass,c1->fRadius,m1,c1->nump,
		   c1->r[0],c1->r[1],c1->r[2],
		   c1->v[0],c1->v[1],c1->v[2],sqrt(a1));
	    if(*pnOut ==2){
	      printf("out 2:p=%i,o=%i,oi=%i,color=%i,c1id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		     "r=(%e,%e,%e),v=(%e,%e,%e), r2 %g\n",
		     c2->id.iPid,c2->id.iOrder,c2->id.iOrgIdx,c2->iColor,c1->id.iOrgIdx,
		     c2->fMass,c2->fRadius,m2,c2->nump,
		     c2->r[0],c2->r[1],c2->r[2],
		     c2->v[0],c2->v[1],c2->v[2],sqrt(a2));
	    }
	  }
	  
	}

}

void
CollisionDataPBHYB(XDR *xdrs, COLLIDER *c1){
   int i;

  (void) xdr_int(xdrs,&c1->iColor);
  (void) xdr_int(xdrs,&c1->id.iOrgIdx);			
  (void) xdr_double(xdrs,&c1->fMass);
  (void) xdr_double(xdrs,&c1->fRadius);
  (void) xdr_double(xdrs,&c1->nump);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c1->r[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&c1->v[i]);
  
}

void
CollisionDataPBHYB2(XDR *xdrs, PARTICLE *p){
  int i;

  (void) xdr_int(xdrs,&p->iColor);
  (void) xdr_int(xdrs,&p->iOrgIdx);			
  (void) xdr_double(xdrs,&p->fMass);
  (void) xdr_double(xdrs,&p->fSoft);
  (void) xdr_double(xdrs,&p->nump);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&p->r[i]);
  for (i=0;i<N_DIM;i++)
    (void)xdr_double(xdrs,&p->v[i]);
  
}

void
pkdSplitTracerPBHYB(PKD pkd,double dTime,double *dT){
  int i,k,n,c2id;
  PARTICLE *p; 
  p = pkd->pStore;
  n = pkdLocal(pkd); 
  double mt0 = pkd->param.HY.fMt0;
  PARTICLE *pn;
  double n1, n2, m1, m2,mt1,mt2,dr,ptmass;  
  double RN,r0,r1,r2,e1,i1,facv1;
  double a,b,c,d;
  double rdr = 10.0*pkd->param.HY.fh0;
  double dtheta = pkd->param.HY.fdtheta;
  double fac1 = 1.999999;
  FILE *fp,*fp2;
  int nsp = 0; // number of splitted particles
  int nin = 1;
  int nout = 2;
  double nd = 0.0; 
  XDR xdrs;	
  double a1,a2,e2,i2,xx,yy,dth,cth,sth;
  double dSunMass = pkd->dSunMass;

  *dT = 0.0;
  
  /* first we conunt how many tracers will split */

  for(i=0;i<n;++i) {	  
    if(p[i].iColor <= SUBEMBRYO)continue;

    ptmass = p[i].fMass;

    p[i].iColflag = 0;

    // if we find a traer with m > mt0 and nump < 2.0, we promote it to a subembryo (this should not happen, but happend once)// 
    if(ptmass >=mt0 && p[i].nump < 2.0 && p[i].iColor > SUBEMBRYO){
      p[i].iColor = SUBEMBRYO;
      p[i].nump = 1.0;      
    }

      // if((ptmass >= fac1*mt0 || p[i].nump==2.0) && p[i].iColor > SUBEMBRYO) 
    // ftmin is defined in pkd.h; default is 0.1   
    if((ptmass >= fac1*mt0 || (p[i].nump==2.0 && ptmass >= ftmin*mt0)) && p[i].iColor > SUBEMBRYO){
      p[i].iColflag = 1;
      nsp ++;
    }
  }

  if(nsp == 0) return;
  
  if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
    fp = fopen(COLL_LOG_PBHYB_TXT,"a");
    assert(fp != NULL);
    fprintf(fp,"num of splitted particles is %i \n", nsp);
    fclose(fp);
  }
  if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
    fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
    assert(fp2 != NULL);
    xdrstdio_create(&xdrs,fp2,XDR_ENCODE);	
    (void) xdr_int(&xdrs,&nsp);	
    xdr_destroy(&xdrs);
    (void) fclose(fp2);	  
  }
  
  printf("num of splitted particles is %i \n", nsp);
  


  for(i=0;i<n;++i) {	
    if(p[i].iColor <= SUBEMBRYO)continue;

    ptmass = p[i].fMass;
    if(ptmass > mt0 && p[i].nump == 1.0 &&  p[i].iColor > SUBEMBRYO){ /*must be subembryo*/
      printf("time %g id %d color %d nump %f, m %g m/mt0 %g \n",dTime/(2.0*M_PI),p[i].iOrgIdx,p[i].iColor,p[i].nump,p[i].fMass,p[i].fMass/mt0);
      assert(0);
    }
    
    
    //if((ptmass >= fac1*mt0 || (p[i].nump==2.0 && ptmass >= ftmin*mt0)) && p[i].iColor > SUBEMBRYO)
    if(p[i].iColflag == 1){ /* Split */
      p[i].iColflag = 0; // just in case
      
      n1 = p[i].nump;
      if(p[i].nump<2.0){
	printf("id %d color %d nump %f, m %g m/mt0 %g \n",p[i].iOrgIdx,p[i].iColor,p[i].nump,p[i].fMass,p[i].fMass/mt0);
	assert(0);
      }
     

      m1 = ptmass/n1;
      r0 = sqrt(p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1]+ p[i].r[2]*p[i].r[2]);
      //r0 = p[i].ele[5];
      dr = rdr*r0; /* radial width */
      do{
	RN = (double)drand48();
      }while(RN < 0.2);
      
      dr *= RN; /* mutual separation */
    
      for (k=0;k<3;k++){
	*dT -= 0.5*n1*m1*(p[i].v[k]*p[i].v[k]) - pkd->dSunMass*m1*n1/r0;	    
      }

      c2id = -1;

      if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	fp = fopen(COLL_LOG_PBHYB_TXT,"a");
	assert(fp != NULL);
	
	fprintf(fp,"tt time=%e yr,Nin=%i,Nout=%i,dDmi=%e,nd=%g)\n",
		dTime/(2.0*M_PI),1,2,0.0,0.0);
	fprintf(fp,"newin 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		"r=(%e,%e,%e),v=(%e,%e,%e)\n",
		pkd->idSelf,p[i].iOrder,p[i].iOrgIdx,p[i].iColor,c2id,
		ptmass,p[i].fSoft,m1,p[i].nump,
		p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2]);

      }


      if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
	fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
	assert(fp2 != NULL);
	xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
	
	(void) xdr_double(&xdrs,&dTime);
	(void) xdr_int(&xdrs,&nin);
	(void) xdr_int(&xdrs,&nout);
	(void) xdr_double(&xdrs,&nd);
	
	CollisionDataPBHYB2(&xdrs,&(p[i]));
	
	xdr_destroy(&xdrs);
	(void) fclose(fp2);	  
      }
          
      /* to be deleted */
      if(pkd->param.iCollLogOption & COLL_LOG_STAND){
	printf("tt time=%e yr,Nin=%i,Nout=%i,dDmi=%e,nd=%g)\n",
	       dTime/(2.0*M_PI),1,2,0.0,0.0);
	printf("newin 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
	       "r=(%e,%e,%e),v=(%e,%e,%e)\n",
	       pkd->idSelf,p[i].iOrder,p[i].iOrgIdx,p[i].iColor,c2id,
	       ptmass,p[i].fSoft,m1,p[i].nump,
	       p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2]);
      }
      
      pn = malloc(sizeof(*pn));
      
      // adjust n1 to integer if n1 < INT_MAX
      // this adjustment increases the mass of the planetesimal by ~ 1/INT_MAX
      // while the tracer mass is unchanged
      if(p[i].nump < INT_MAX*1.0){
	p[i].nump = ((int)n1)*1.0;	 
	m1 *= n1/p[i].nump;
	p[i].fMass *= n1/p[i].nump;
	n1 = p[i].nump;

	pn->nump = ((int)p[i].nump)/2;
	pn->nump *= 1.0;
	p[i].nump -= pn->nump;
      }else{
	pn->nump = p[i].nump/2.0;
	p[i].nump -= pn->nump;
      }

      /*  pn->nump = p[i].nump/2;
	  p[i].nump -= pn->nump;*/

      n1 = p[i].nump;
      n2 = pn->nump;
      p[i].fMass = m1*n1;
      pn->fMass = m1*n2;
      //   pn->iColor = TRACER;
      pn->iColor = p[i].iColor; //110416
      pn->iRung = 0;
      pn->iRungflag = 0;
      pn->iColflag = 0;
      pn->n_VA = 0;
      pn->drmin = 10000.0;
      pn->drmin2 = 100000.0;
      mt1 = p[i].fMass;
      mt2 = pn->fMass;
      pn->iOrder_VA[0] = p[i].iOrgIdx; /* this is used for output at pkdNewOrgIdx; this seems not used at all 111416 */

      /* New Heliocentric distances and tracer radii */
      /* if(pn->nump == p[i].nump){
	r1 = (r0 - 0.25*dr)*(r0 - 0.25*dr)/r0;
	p[i].fSoft /= cbr2; 
	pn->fSoft = p[i].fSoft;
	}else{*/

      if(mt1 == mt2){
       	r1 = (r0 - 0.25*dr)*(r0 - 0.25*dr)/r0;
      }else{
	a = mt1*mt1-mt2*mt2;
	b = (mt1+mt2)*mt1*sqrt(r0);
	c = (mt1+mt2)*(mt1+mt2)*r0 - mt2*mt2*dr;
	r1 = (b-sqrt(b*b-a*c))/a;
	r1 *= r1;
      }
      pn->fSoft  = p[i].fSoft*cbrt(mt2/(mt1+mt2));
      p[i].fSoft *= cbrt(mt1/(mt1+mt2));
      
      //	pn->ele[8] = pn->fSoft/cbrt(pn->nump*1.0);
      //	p[i].ele[8] = p[i].fSoft/cbrt(p[i].nump*1.0);
      pn->ele[8] = p[i].ele[8];
      
      r2 = r1 + dr; 


      /* New positions and velocities */
      a = r1/r0;
      b = r2/r0;
      c = 1.0/sqrt(a);
      d = 1.0/sqrt(b);

      for (k=0;k<3;k++) {
	pn->r[k] =  b*p[i].r[k];
	p[i].r[k] = a*p[i].r[k];
	pn->v[k] =  d*p[i].v[k];
	p[i].v[k] = c*p[i].v[k];
	pn->w[k] =  0.0;
	p[i].w[k] = 0.0;
	p[i].a[k] = 0.0; /* just in case */
	pn->a[k] = 0.0;
      }
      
    
      e1 = sqrt(p[i].ele[1]*p[i].ele[1] + p[i].ele[2]*p[i].ele[2]);
      i1 = sqrt(p[i].ele[3]*p[i].ele[3] + p[i].ele[4]*p[i].ele[4]);

      d = 0.1*p[i].ele[7];   
      /*e1 = 0.5*p[i].rb[0];
      if(d > e1)e1 = d;
      i1 = 0.5*p[i].rb[1];
      if(0.5*d > i1)i1 = 0.5*d;*/
      e1 = d;
      i1 = 0.5*d;
     

      facv1 = p[i].v[0]*mt2/(mt1+mt2)*e1;
      p[i].v[0] += facv1;
      pn->v[0] -= facv1*mt1*r1/(mt2*r2);
      facv1 = p[i].v[1]*mt2/(mt1+mt2)*e1;
      p[i].v[1] += facv1;
      pn->v[1] -= facv1*(mt1*r1)/(mt2*r2);
      facv1 = p[i].v[2]*mt2/(mt1+mt2)*i1;
      p[i].v[2] += facv1;
      pn->v[2] -= facv1*(mt1*r1)/(mt2*r2);
      pn->iOrgIdx = -(p[i].iOrgIdx+1); //021014       
      pn->dls = 0.0;
      pn->fGasMass = 0.0;
      pn->tcheck   = p[i].tcheck;
      pn->dmdt = -1.0;
      /*pn->iOrder_VA[0] = p[i].iOrgIdx; ?? unecessary */

      if(p[i].St < 2.0){ // randomly rotates c2 position
	dth = dtheta*M_PI*(1.0-2.0*(double)drand48());
	cth = cos(dth);
	sth = sin(dth);
	xx = pn->r[0];
	yy = pn->r[1];
	pn->r[0] = cth*xx-sth*yy;
	pn->r[1] = sth*xx+cth*yy; 
      }

      pn->vtur[0] = 0.0;
      pn->vtur[1] = 0.0;
      pn->vtur[2] = 0.0;

      
      /* log here */
      if(pn->nump == 1.0 && pn->fMass >= mt0)pn->iColor = SUBEMBRYO;
      if(p[i].nump == 1.0 && p[i].fMass >= mt0)p[i].iColor = SUBEMBRYO;

      pkdNewParticle(pkd, pn);  /* temporary iOrder = -1 and iOrgIdx are -1 * (iOrgIdx+1) of pi for new particles */

      for (k=0;k<3;k++){
	*dT += 0.5*mt1*(p[i].v[k]*p[i].v[k]) - pkd->dSunMass*mt1/r1;
	*dT += 0.5*mt2*(pn->v[k]*pn->v[k]) - pkd->dSunMass*mt2/r2;
      }
      
      if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE){
	fprintf(fp,"newout 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		"r=(%e,%e,%e),v=(%e,%e,%e)\n",
		pkd->idSelf,p[i].iOrder,p[i].iOrgIdx,p[i].iColor,c2id,
		p[i].fMass,p[i].fSoft,m1,p[i].nump,
		p[i].r[0],p[i].r[1],p[i].r[2],
		p[i].v[0],p[i].v[1],p[i].v[2]);
	fprintf(fp,"newout 2:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
		"r=(%e,%e,%e),v=(%e,%e,%e)\n",
		pkd->idSelf,pn->iOrder,pn->iOrgIdx,pn->iColor,p[i].iOrgIdx,
		pn->fMass,pn->fSoft,m1,pn->nump,
		pn->r[0],pn->r[1],pn->r[2],
		pn->v[0],pn->v[1],pn->v[2]);
      }
  

      if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
        fp2 = fopen(COLL_LOG_PBHYB_BIN,"a");
	assert(fp2 != NULL);
	xdrstdio_create(&xdrs,fp2,XDR_ENCODE);	
	
	CollisionDataPBHYB2(&xdrs,&(p[i]));
	CollisionDataPBHYB2(&xdrs,pn);
	
	xdr_destroy(&xdrs);
	(void) fclose(fp2);	  
      }


      /* pn->iOrgIdx is updated at pkdNewOrgIdx */

      /* to be deleted */
      if(pkd->param.iCollLogOption & COLL_LOG_STAND){
	printf("newout 1:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
	       "r=(%e,%e,%e),v=(%e,%e,%e)\n",
	       pkd->idSelf,p[i].iOrder,p[i].iOrgIdx,p[i].iColor,c2id,
	       p[i].fMass,p[i].fSoft,m1,p[i].nump,
	       p[i].r[0],p[i].r[1],p[i].r[2],
	       p[i].v[0],p[i].v[1],p[i].v[2]);
	printf("newout 2:p=%i,o=%i,oi=%i,color=%i,c2id=%i,mt=%e,rt=%e,m=%e,n=%f,"
	       "r=(%e,%e,%e),v=(%e,%e,%e)\n",
	       pkd->idSelf,pn->iOrder,pn->iOrgIdx,pn->iColor,p[i].iOrgIdx,
	       pn->fMass,pn->fSoft,m1,pn->nump,
	       pn->r[0],pn->r[1],pn->r[2],
	       pn->v[0],pn->v[1],pn->v[2]);
      }
      free(pn);
      if(pkd->param.iCollLogOption & COLL_LOG_VERBOSE) fclose(fp);
      
    }
  }
}


void pkdCheckHelioDist(PKD pkd,double dTime,double *dT,double *dSM, double *md, double rd[3], double vd[3]){
  int i,j,k,n;
  double r2;
  //  double rsun = 0.01; /* solar radius^2 */
  // double rsunc = 0.2; /* solar radius for circularly orbiting bodies */
  double resc = 10000.0; /* escape distance^2 */
  double moi, a, a0;
  double ain = pkd->param.dain; 
  double aout = pkd->param.daout;
  double rsunc = pkd->param.dRSunc; /* solar radius for circularly orbiting bodies */
  double rsun = 0.25*rsunc*rsunc;/* solar radius^2 */
  double apin = pkd->param.HY.dapin; // pebbles are deleted at apin 
  PARTICLE *p;  
  int iOutcome,sbd;
  int iPbGrow = pkd->param.HY.iPbGrow;

  
  n = pkdLocal(pkd); 
  p = pkd->pStore;
  *dT = 0.0;
  *dSM = 0.0;

  // if(iPbGrow ==3 ||iPbGrow ==4)apin -= 1.0; 
  
/* m, r, v for the deleted particle
   We assume not more than one particles are deleted in a single step due to 
   collisions with the central body or escape from the system. 
   If necessary md, rd, vd should be modified to store data for multiple particles 
*/
  *md = 0.0;
  for (k=0;k<3;k++){
      rd[k]= 0.0;
      vd[k]= 0.0;
  }


  for(i=0;i<n;++i) {
    if(p[i].iOrder < 0) continue; 

    //  r2 = (p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1] + p[i].r[2]*p[i].r[2]);
    r2 = (p[i].r[0]*p[i].r[0] + p[i].r[1]*p[i].r[1] ); // mod from 3d r to 2d r on 030717
    a = p[i].ele[0];
    //printf("i %d, St %g \n",i, p[i].St);
    sbd = 0;
    /* small bodies are deleted at snow line (ain) */
    if(pkd->param.bBodySupply == 2 && p[i].iColor > SUBEMBRYO && r2 < ain*ain) sbd = 1; 
    // if((p[i].St < 2.0 && r2 < apin*apin) || (p[i].iColor > SUBEMBRYO && r2 < (apin-1.0)*(apin-1.0)))

    if(iPbGrow ==1 || iPbGrow == 2){
      if(p[i].iColor > SUBEMBRYO && r2 < apin*apin) sbd = 1; 
    }

    // if(iPbGrow ==3 || iPbGrow == 4){
    //   if(p[i].St < 2.0 && r2 < apin*apin && p[i].iOrgIdx%2==0)sbd =1;
    // }
    // mod1
    //  if(p[i].iColor > SUBEMBRYO && p[i].St < 2.0 && r2 < apin*apin)  {
    // sbd = 1; // added 020117
    //}    
    if((r2 < rsun || a < rsunc) || (r2 > resc) || sbd == 1){
      r2 = sqrt(r2);
      printf("particle %d of mass %e is deleted with r = %e a = %e\n",
	     p[i].iOrder,p[i].fMass,r2,a);
      //assert(0);
      *md = p[i].fMass;
      for (k=0;k<3;k++){
	  rd[k]= p[i].r[k];
	  vd[k]= p[i].v[k];
      }

      /* kinetic and rotational energy */
      moi = 0.4*p[i].fMass*p[i].fSoft*p[i].fSoft;
      for (k=0;k<3;k++){
	*dT -=  0.5*(p[i].fMass*(p[i].v[k]*p[i].v[k]) +
		     moi*(p[i].w[k]*p[i].w[k]));
      }		      	   
      printf("kinetic E %e\n",*dT);
      /* potential change due to particle deletion */	    
      *dT += p[i].fMass*(pkd->dSunMass/r2-p[i].fPot);	  
      printf("kinetic E + potential change due to particle deletion %e\n",*dT);
      /*if(r2*r2 < rsun || a < 0.25){*/
      if(r2*r2 < rsun || a < rsunc || sbd == 1){
	*dSM += p[i].fMass;
	iOutcome = SUNCOLLIDE;
      }else if (r2*r2 > resc){
	iOutcome = ESCAPE;
      }else{
	assert(0);
      }


      if(pkd->param.iCollLogOption & COLL_LOG_TERSE){
	COLLIDER cout;
	COLLIDER *c;
	FILE *fp2;
	XDR xdrs;		       
		 
	pkdGetColliderInfo(pkd,p[i].iOrder,&cout);		
	c = &cout;  /* struct copy (define the pointa not copy?)  */
	
	
	fp2 = fopen(pkd->param.achCollLog2,"a");
	assert(fp2 != NULL);
	xdrstdio_create(&xdrs,fp2,XDR_ENCODE);
	
	(void) xdr_double(&xdrs,&dTime);
	/* ESCAPE =8, SUNCOLLIDE =16*/
	(void) xdr_int(&xdrs,&iOutcome); 
	
	CollisionData(&xdrs, c, c); /* we put the same data in c1 c2 */
	
	xdr_destroy(&xdrs);
	(void) fclose(fp2);	
      }
      
      pkdDeleteParticle(pkd,&p[i]);
    }   
    
    if(pkd->param.bBodySupply == 1){
      /* Body supply boundary condition (see Kokubo and Ida 2000)
	 only semimajor axis changes with keeping other Kepler elements*/

      if(a < ain || a > aout){
	/*	printf("particle %d crosses the boundary a = %e \n",p[i].iOrder, a);*/
	a0 = a;
	if(a < ain){
	  a = aout - (ain-a0);
	}else if (a > aout){
	  a = ain + (a0-aout);
	}
	a0 = a/a0;
	for (k=0;k<3;k++){
	  p[i].r[k] *= a0;
	  p[i].v[k] /= sqrt(a0);
	}	
      }      
    }
 
    if(pkd->param.bBodySupply >= 3){ /* recycling at the snow line */
      if(r2 < ain*ain && p[i].iColor > SUBEMBRYO){
	/*printf("p[i].fMass %e, pkd->param.GP.fMp1 %e\n",p[i].fMass, pkd->param.GP.fMp1);*/

	// srand((unsigned int)time(NULL)*p[i].iOrgIdx);
	for (k = 0 ; k < 3 ; k++){
	  moi = (double)drand48();  
	}
	a = ain + (aout - ain)*moi;

	p[i].r[0] = a;
	p[i].r[1] = 1.e-5*moi;
	p[i].r[2] = 1.e-5*moi;
	p[i].v[0] = 1.e-5*moi;
	p[i].v[1] = sqrt(1.0/a);
	p[i].v[2] = 1.e-5*moi;

	printf("id %d, p[i].fMass %e, x %e y %e z %e vx %e vy %e vz %e \n",p[i].iOrgIdx, p[i].fMass, p[i].r[0],p[i].r[1],p[i].r[2],p[i].v[0],p[i].v[1],p[i].v[2]);
      }
    }

    
  }// loop for i

  
}

void pkdPebbleSupply_old(PKD pkd,double dTime,double dDelta,GASDISK_PARAMS *GP,int *pnew_flag, double *pmt0_peb, double *v){
  
  double M_peb = pkd->param.HY.dM_peb;
  double Tau_peb = pkd->param.HY.dTau_peb*(2.0*M_PI);
  double Mr_peb = pkd->param.HY.dMr_peb;
  double mt0 = pkd->param.HY.fMt0;
  double a0 = pkd->param.daout;
  double mt0_peb = mt0*Mr_peb;
  // we now make a pebble with St = St_min;
  //  double m_peb1 = 1.e4/1.98892e33; //each pebble mass is 1.e-4 g --> 10 cm
  PARTICLE *pn,*p;   
  double m_total0, m_total1,the,v0;
  int n_t0,n_t1,k;

  STEPINSKI * ST;
  int iGasModel = GP->iGasModel;
  double depfac,Sigma,Sigma0,Gasp,Temp,Gasq,h,Kappa;
  double St_min = pkd->param.HY.dSt_min;
  double rho,rhop,smin,mmin;
  
  *pnew_flag = 0; 
  *pmt0_peb = mt0_peb;
  v[0]=v[1]=v[2] = 0.0;
  p = pkd->pStore;
  
  // aout is already used if bBodySupply = 1 or 3
  assert(pkd->param.bBodySupply != 3 && pkd->param.bBodySupply != 1);
  
  // total pebble masses produced until dTime and dTime+dDelta;
  m_total0 =  M_peb*(1.0 - exp(-dTime/Tau_peb));
  m_total1 =  M_peb*(1.0 - exp(-(dTime+dDelta)/Tau_peb));
		     
  n_t0 = (int)(m_total0/mt0_peb);  
  n_t1 = (int)(m_total1/mt0_peb);
  
  assert((n_t1 == n_t0) || ((n_t1-n_t0) == 1));

  if((n_t1-n_t0) == 1){
    // make a new pebble tracer
    if(pkd->param.GP.dTau_diss < 1.e8 && (iGasModel == 1 || iGasModel == 4)){
      depfac = exp(-dTime/(2.0*M_PI*pkd->param.GP.dTau_diss));
    }else{
      depfac = 1.0;
    }

    pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),a0,sqrt(1.0/(a0*a0*a0)),depfac,0.1,100.0,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);
    rho = facrho*Sigma0/h; // gas density at r = a0 and z=0
    rhop = 3.0*p->fMass/(4.0*M_PI*p->fSoft*p->fSoft*p->fSoft); //physical density taken from a particle with id = 0
    smin = rho*h*St_min/rhop*sqrt(8.0/M_PI); // particle size at St = St_min in Epstein's Law; factor sqrt(8.0/M_PI) added in 121117
    mmin = 4.0*M_PI*smin*smin*smin*rhop/3.0; // and mass
    if(mmin < mpe0) mmin = mpe0;
    
    //p = pkd->pStore;
    
    pn = malloc(sizeof(*pn));
    
    pn->fMass = mt0_peb;
    // pn->nump = mt0_peb/m_peb1;
    pn->nump = mt0_peb/mmin;
    pn->fSoft  = cbrt(pn->fMass/p->fMass)*p->fSoft; //same density of other particles
    pn->ele[8] = pn->fSoft/cbrt(pn->nump);
    
      
    the = 2.0*M_PI*((double)drand48());
    v0 = sqrt(1.0/a0)*0.99; //let's try this one
    
    pn->r[0] =  cos(the);
    pn->r[1] =  sin(the);
    pn->r[2] =  0.0;
    
    pn->v[0] =  -v0*pn->r[1];
    pn->v[1] =  v0*pn->r[0];
    pn->v[2] =  0.0;
    pn->r[0] *=  a0;
    pn->r[1] *=  a0;

    pn->a[0] =  0.0;
    pn->a[1] =  0.0;
    pn->a[2] =  0.0;

    pn->a_pr = 0.0;
    
    printf("new pebble tracer; time %g yr, mt %g nump %g x,y,vx,vy %g %g %g %g  \n",
	   dTime/(2.0*M_PI),pn->fMass,pn->nump,pn->r[0],pn->r[1],pn->v[0],pn->v[1]);
    
    for (k=0;k<3;k++) {
      pn->w[k] = 0.0;
      pn->a[k] = 0.0;
    }
    
    // pn->iColor = PEBBLE;

    // if(pe_type == 2)
    pn->iColor = TRACER; // Let's allow them to mutually collide 121916  --> mutual velocity is not estimated correctly..
    pn->iRung = 0;
    pn->iRungflag = 0;
    pn->iColflag = 0;
    pn->n_VA = 0;
    pn->drmin = 10000.0;
    pn->drmin2 = 100000.0;
    
    pn->iOrgIdx = -pkd->param.N0*100000-1; // something large negative value   see  pkdNewOrgIdx  
    pn->dls = 0.0;
    pn->fGasMass = 0.0;
    pn->tcheck   = 0.0;
  
    pn->vtur[0] = 0.0;
    pn->vtur[1] = 0.0;
    pn->vtur[2] = 0.0;
    pn->dmdt = -1.0;

    
    pkdNewParticle(pkd, pn); //copy pn to pkd->pStore

    *pnew_flag = 1;
    *pmt0_peb = mt0_peb;
    v[0] = pn->v[0];
    v[1] = pn->v[1];
    v[2] = pn->v[2];  
  
    free(pn);
  }
}





void pkdPebbleSupply(PKD pkd,double dTime,double dDelta,GASDISK_PARAMS *GP,int *pnew_flag, double *pmt0_peb, double *v){
  int    iPS = pkd->param.HY.iPebbleSupply;
  double M_peb = pkd->param.HY.dM_peb;
  double Tau_peb = pkd->param.HY.dTau_peb*(2.0*M_PI);
  double Mr_peb = pkd->param.HY.dMr_peb;
  double mt0 = pkd->param.HY.fMt0;
  double a0 = pkd->param.daout;
  double mt0_peb = mt0*Mr_peb;
  double s0 = GP->dS0; 
  double dapin = pkd->param.HY.dapin;
  double da = 2.0;
  double M_pebr,Tau_pebr,ac,anew,vr,delt,h2,naa;
  int na,namax;
  double dGasp = GP->dGasp;
  double dGasq = GP->dGasq;
  double Temp1 = pkd->param.GP.dTemp1;
  double Tau_gas = pkd->param.GP.dTau_diss*(2.0*M_PI);
  double cpl = pkd->param.HY.dcpl;
  double tau_pl;

  // we now make a pebble with St = St_min;
  //  double m_peb1 = 1.e4/1.98892e33; //each pebble mass is 1.e-4 g --> 10 cm
  PARTICLE *pn,*p;   
  double m_total0, m_total1,the,v0;
  int n_t0,n_t1,k;

  STEPINSKI * ST;
  int iGasModel = GP->iGasModel;
  double depfac,Sigma,Sigma0,Gasp,Temp,Gasq,h,Kappa;
  double St_min = pkd->param.HY.dSt_min;
  int iPbGrow = pkd->param.HY.iPbGrow;
  int iPlForm = pkd->param.HY.iPlForm;
  
  double rho,rhop,smin,mmin;

 // aout is already used if bBodySupply = 1 or 3
  assert(pkd->param.bBodySupply != 3 && pkd->param.bBodySupply != 1);
  assert(GP->dGasp == 1.0); // p = 1.0 only for now
    
  *pnew_flag = 0; 
  *pmt0_peb = mt0_peb;
  v[0]=v[1]=v[2] = 0.0;
  p = pkd->pStore;

  assert(GP->dGasq == 0.5); // q = 0.5 only for now
  h2 = 0.033560233*0.033560233*(Temp1/280.0); // square of scale height at 1 AU
  vr = (0.5*(dGasp+1.5+0.5*dGasq)*h2); // radial velocity of pebble at 1AU for St = 1; it is radially constant if  dGasq = 1/2
  vr *= 2.0*St_min/(1.0 + St_min*St_min);

  tau_pl = cpl*(1.0+St_min*St_min)/(2.0*St_min)*2.0*M_PI; // pl formation time scale outside a0

  namax = (int)((s0-dapin)/da);
  if(iPS == 2)namax = 1;
  
  M_pebr = M_peb*da/(s0-dapin); // mass in each radial bin for p = 1 
  // printf("M_pebr %g s0 %g namax %d Tau_peb %g \n", M_pebr,s0,namax,Tau_peb);
  
  for(na=0;na<namax;++na) {
    naa = na;
    ac = dapin + naa*da + 0.5*da; // center of a radial bin
    Tau_pebr = Tau_peb*ac*sqrt(ac); // pebble formation time scale at ac
    delt = 0.0;
    if(ac > a0){
      delt = (ac-a0)/vr; // drift timescale from ac to a0
      if(dTime < delt) continue; // no pebble formation before dTime = 0
    }
      
    // total pebble masses produced until dTime and dTime+dDelta;
    // m_total0 =  M_pebr*(1.0 - exp(-(dTime-delt)/Tau_pebr));
    // m_total1 =  M_pebr*(1.0 - exp(-(dTime-delt+dDelta)/Tau_pebr));
    // mod 030917

    // total dust mass at  dTime and dTime+dDelta;
    m_total0 = M_pebr/(Tau_gas/Tau_pebr*(exp((dTime-delt)/Tau_gas)-1.0) + 1.0);
    m_total1 = M_pebr/(Tau_gas/Tau_pebr*(exp((dTime-delt+dDelta)/Tau_gas)-1.0) + 1.0);

    if(iPS == 2){// test purpose, pebbles supplied at a fixed radius with a fixed supply rate
      ac = a0;
      m_total0 = M_peb*(1.0-dTime/(2.e6*M_PI));
      m_total1 = M_peb*(1.0-(dTime+dDelta)/(2.e6*M_PI));
    }
    
    n_t0 = (int)(m_total0/mt0_peb);  
    n_t1 = (int)(m_total1/mt0_peb);

    //printf("na %i, ac %g n_t0 %d n_t1 %d \n",na,ac,n_t0,n_t1);
    //assert((n_t1 == n_t0) || ((n_t1-n_t0) == 1));
    assert((n_t1 == n_t0) || ((n_t0-n_t1) == 1));
    
    if((n_t0-n_t1) == 1){ // make a new pebble tracer
      if(ac < a0){
	anew = ac + (((double)drand48()) - 0.5)*da;
      }else{
	if(iPlForm >= 100){
	  // if(delt*0.5*(1.0/sqrt(a0)-1.0/sqrt(ac)) > 2.0*((double)drand48())*tau_pl)continue;
	  if(0.5*(1.0/sqrt(a0)-1.0/sqrt(ac))/vr > 2.0*((double)drand48())*tau_pl)continue;	  
	}else{  
	  if(delt > 2.0*((double)drand48())*tau_pl)continue;
	}
	anew = a0;
      }
     
      if(pkd->param.GP.dTau_diss < 1.e8 && (iGasModel == 1 || iGasModel == 4)){
	depfac = exp(-dTime/(2.0*M_PI*pkd->param.GP.dTau_diss));
      }else{
	depfac = 1.0;
      }
      
      pkdGetGasDisk(pkd,GP,dTime/(2.0*M_PI),anew,sqrt(1.0/(anew*anew*anew)),depfac,0.1,100.0,ST->rij,ST->fSigma,ST->fTemp,&Sigma,&Sigma0,&Gasp,&Temp,&Gasq,&h,&Kappa);
      rho = facrho*Sigma0/h; // gas density at r = a0 and z=0
      //rhop = 3.0*p->fMass/(4.0*M_PI*p->fSoft*p->fSoft*p->fSoft); //physical density taken from a particle with id = 0
      rhop = 2.0*ffrho;
     
      smin = rho*h*St_min/rhop*sqrt(8.0/M_PI); // particle size at St = St_min in Epstein's Law; factor sqrt() added 121117
      if((iPbGrow == 2 || iPbGrow == 4) &&  ac < a0){
	smin = rho*h*St_min*(ac/a0)/rhop*sqrt(8.0/M_PI); //  St = St_min at a0 and partile size does not change for iPbGrow == 2; factor sqrt() added 121117
      }
      mmin = 4.0*M_PI*smin*smin*smin*rhop/3.0; // and mass
      if(mmin < mpe0) mmin = mpe0;
      
      //p = pkd->pStore;
      
      pn = malloc(sizeof(*pn));
      
      pn->fMass = mt0_peb;
      pn->fGasMass = 0.0;

      
      // pn->nump = mt0_peb/m_peb1;
      pn->nump = mt0_peb/mmin;
      if(pn->nump < 1.0){
	printf("ac %e, St_min %e, nump %e, smin %e, mmin %e rhop %e \n",ac,St_min,pn->nump,smin,mmin,rhop);
      }
      assert(pn->nump >= 1.0);
      pn->fSoft  = cbrt(pn->fMass/p->fMass)*p->fSoft; //same density of other particles
      pn->ele[8] = pn->fSoft/cbrt(pn->nump);
            
      the = 2.0*M_PI*((double)drand48());
      v0 = sqrt(1.0/anew)*0.99; //let's try this one
      
      pn->r[0] =  cos(the);
      pn->r[1] =  sin(the);
      pn->r[2] =  0.0;
      
      pn->v[0] =  -v0*pn->r[1];
      pn->v[1] =  v0*pn->r[0];
      pn->v[2] =  0.0;
      pn->r[0] *=  anew;
      pn->r[1] *=  anew;
      
      pn->a[0] =  0.0;
      pn->a[1] =  0.0;
      pn->a[2] =  0.0;
      
      pn->a_pr = 0.0;
      
      printf("new pebble tracer; time %g yr, mt %g nump %g x,y,vx,vy %g %g %g %g  \n",
	     dTime/(2.0*M_PI),pn->fMass,pn->nump,pn->r[0],pn->r[1],pn->v[0],pn->v[1]);
      
      for (k=0;k<3;k++) {
	pn->w[k] = 0.0;
	pn->a[k] = 0.0;
      }
      
      // pn->iColor = PEBBLE;
      
      // if(pe_type == 2)
      pn->iColor = TRACER; // Let's allow them to mutually collide 121916  --> mutual velocity is not estimated correctly..
      pn->iRung = 0;
      pn->iRungflag = 0;
      pn->iColflag = 0;
      pn->n_VA = 0;
      pn->drmin = 10000.0;
      pn->drmin2 = 100000.0;
      
      pn->iOrgIdx = -pkd->param.N0*100000-1; // something large negative value   see  pkdNewOrgIdx  
      pn->dls = 0.0;
      
      pn->vtur[0] = 0.0;
      pn->vtur[1] = 0.0;
      pn->vtur[2] = 0.0;
      pn->tcheck  = 0.0;
      pn->dmdt = -1.0;
      
      pkdNewParticle(pkd, pn); //copy pn to pkd->pStore
      
      *pnew_flag = 1;
      *pmt0_peb = mt0_peb;
      v[0] = pn->v[0];
      v[1] = pn->v[1];
      v[2] = pn->v[2];  
      
      free(pn);
      //return; // only one pebble formation per timestep
    }
  }
}



#endif /* sm2d */

#endif /* PLANETS */
