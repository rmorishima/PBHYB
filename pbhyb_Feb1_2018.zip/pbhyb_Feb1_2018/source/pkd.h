#ifndef PKD_HINCLUDED
#define PKD_HINCLUDED

#include <stdint.h>
#include <sys/resource.h>
#include "mdl.h"
#ifndef HAVE_CONFIG_H
#include "floattype.h"
#endif
#include "parameters.h"

#include "moments.h"
#include "cosmo.h"
#ifdef USE_HDF5
#include "iohdf5.h"
#endif
#ifdef PLANETS
#include "../analysis/ssio.h"
#include "../analysis/heltodel.h"
#endif

/*
** The following sort of definition should really be in a global
** configuration header file -- someday...
*/

#define CID_PARTICLE	0
#define CID_CELL	1
#define CID_GROUP	2
#define CID_RM		3
#define CID_BIN		4
/*
** Here we define some special reserved nodes. Node-0 is a sentinel or null node, node-1
** is here defined as the ROOT of the local tree (or top tree), node-2 is unused and 
** node-3 is the root node for the very active tree.
*/
#define VAROOT          3
#define ROOT		1
#define NRESERVED_NODES 4
/*
** These macros implement the index manipulation tricks we use for moving
** around in the top-tree. Note: these do NOT apply to the local-tree!
*/
#define LOWER(i)	(i<<1)
#define UPPER(i)	((i<<1)+1)
#define PARENT(i)	(i>>1)
#define SIBLING(i) 	(i^1)
#define SETNEXT(i)\
{\
	while (i&1) i=i>>1;\
	++i;\
	}

/*
** This is useful for debugging the very-active force calculation.
*/
#define A_VERY_ACTIVE  1


#define MAX_TIMERS		10


typedef struct pLite {
    FLOAT r[3];
    int i;
    uint8_t uRung;
    } PLITE;

typedef struct pIO {
    int64_t iOrder;
    FLOAT r[3];
    FLOAT v[3];
    FLOAT fMass;
    FLOAT fSoft;
} PIO;

typedef struct particle {
    int iOrder;
    unsigned int iActive;  
    int iRung;
    int iBucket;
    double fMass;
    FLOAT fSoft;
#ifdef CHANGESOFT
    FLOAT fSoft0;
#endif
    FLOAT r[3];
    FLOAT v[3];
    FLOAT a[3];    
    FLOAT ae[3];   /* used for ewald kicking */ /* acceralation of subembryos*/
#ifdef HERMITE
    FLOAT ad[3];
    FLOAT r0[3];
    FLOAT v0[3];
    FLOAT a0[3];
    FLOAT ad0[3];
    FLOAT rp[3];
    FLOAT vp[3];
    FLOAT app[3];
    FLOAT adpp[3];
    FLOAT dTime0; 
#endif  /* Hermite */
    FLOAT fWeight;

    FLOAT fPot;
    FLOAT fBall;
    FLOAT fDensity;

    FLOAT dt;			/* a time step suggestion */
    FLOAT dtGrav;		/* suggested 1/dt^2 from gravity */

    int pGroup;
    int pBin;
    FLOAT fBallv2;
#ifdef RELAXATION
    FLOAT fRelax;
#endif

#ifdef PLANETS 
/* (collision stuff) */
    int iOrgIdx;		/* for tracking of mergers, aggregates etc. */
    FLOAT w[3];			/* spin vector */
    int iColor;			/* handy color tag */
    int iColflag;	        /* handy collision tag 1 for c1, 2 for c2*/
    int iOrderCol;              /* iOrder of colliding oponent.*/
    double dtCol;
  /* end (collision stuff) */
  double ele[11]; /* a,e^2,i^2, fac*/
  /* in PBHYB functions, ele = a,esin(w),ecos(w),isin(W),icos(W),r,theta,h,rad,f(eccentric anomaly), where h = (m/3M_star)^{1/3}*/
  FLOAT dls; /* angular momentum change of subembyros*/
  FLOAT fSigf[2];
  FLOAT rho_neb;
  FLOAT temp_neb;
  FLOAT r_Bond;
  FLOAT St;
  FLOAT hp;
  FLOAT mmin;
  FLOAT a_pr;
  double dmdt;
  double vtur[3];
  double tcheck;
  double fGasMass;
#ifdef SYMBA
    #define MAXn_VA 20
    FLOAT rb[3]; /* position before drift */
    FLOAT vb[3]; /* velocity before drift */
    FLOAT drmin; /* minimum distance from neighbors normalized by crit dist(Hill)*/
    FLOAT drmin2; /* min. dis. during drift */
    int   iOrder_VA[MAXn_VA]; /* iOrder's of particles within crit radius*/
    int   i_VA[MAXn_VA];    /* pointers of particles */
    int   n_VA;       /* number of particles */
    double  hill;       /* hill radius */  
    double  rcrit;       /* larger of epicyclic velocity times dDelta/ RSCALE or hill */ 
    FLOAT a_VA[3];          /* acceralation due to close encounters */
    FLOAT a_VAs[3];          /* acceralation due to close encounters between tracers and subembryos*/
   
    int iRungflag;
    double  nump; /* number of planetesimals in the tracer, nump = 1 otherwise*/
    int nrt[2]; // tag on r theta mass grids
    
  /* int   iKickRung; */
#endif
#endif/* PLANETS */
    } PARTICLE;

#ifdef sm2d
#define nrlim 200
#define nzlim 31
#define ntlim 50
#define nlim 200

typedef struct {
  int nt,nrmax; // total num of TRACERS
  double dTime;
  double rfac;
  double ar[nrlim][nzlim];
  double az[nrlim][nzlim];
  double ar2[nrlim][nzlim];
  double az2[nrlim][nzlim];
  double zp[nrlim][nzlim];
  double rp[nrlim];  
} TRACERPOT;

typedef struct {
  int i;
  int iOrgIdx;
  int ncoll;
  double m09;
  double t09;
  double fmmin;
} MVST;

#endif /* sm2d */


/* Active Type Masks */

/* Active: -- eg. Calculate new acceleration, PdV, etc... for this particle */
#define TYPE_ACTIVE            (1<<0)

/* Types used for Fast Density only (so far) */
/* Sum Fast Density on this particle */
#define TYPE_DensACTIVE        (1<<4)
/* Neighbour of ACTIVE (incl. ACTIVE): */
#define TYPE_NbrOfACTIVE       (1<<5)
/* Density set to zero already */
#define TYPE_DensZeroed        (1<<7)

/* Particle Type Masks */

#define TYPE_GAS               (1<<8)
#define TYPE_DARK              (1<<9)
#define TYPE_STAR              (1<<10)
#define TYPE_BLACKHOLE         (1<<11)

/* Particle marked for deletion.  Will be deleted in next
   msrAddDelParticles(); */
#define TYPE_DELETED           (1<<12)

/* A particle whose coordinates are output very frequently */
#define TYPE_TRACKER		   (1<<14)

/* Combination Masks */
#define TYPE_ALL				(TYPE_GAS|TYPE_DARK|TYPE_STAR|TYPE_BLACKHOLE)

/* Type Macros */
int TYPEQueryACTIVE      ( PARTICLE *a );
int TYPEQueryGAS         ( PARTICLE *a );
int TYPETest  ( PARTICLE *a, unsigned int mask );
int TYPEFilter( PARTICLE *a, unsigned int filter, unsigned int mask );
int TYPESet   ( PARTICLE *a, unsigned int mask );
int TYPEReset ( PARTICLE *a, unsigned int mask );
/* This retains Particle Type and clears all flags: */
int TYPEClearACTIVE( PARTICLE *a ); 

/* Warning: This erases Particle Type */
int TYPEClear( PARTICLE *a ); 

#define TYPEQueryACTIVE(a)       ((a)->iActive & TYPE_ACTIVE)
#define TYPEQueryGAS(a)			 ((a)->iActive & TYPE_GAS)
#define TYPETest(a,b)            ((a)->iActive & (b))
#define TYPEFilter(a,b,c)        (((a)->iActive & (b))==(c))
#define TYPESet(a,b)             ((a)->iActive |= (b))
#define TYPEReset(a,b)           ((a)->iActive &= (~(b)))
#define TYPEClearACTIVE(a)       ((a)->iActive &= TYPE_ALL)
#define TYPEClear(a)             ((a)->iActive = 0)

#define BND_COMBINE(b,b1,b2)\
{\
	int BND_COMBINE_j;\
	for (BND_COMBINE_j=0;BND_COMBINE_j<3;++BND_COMBINE_j) {\
		FLOAT BND_COMBINE_t1,BND_COMBINE_t2,BND_COMBINE_max,BND_COMBINE_min;\
		BND_COMBINE_t1 = (b1).fCenter[BND_COMBINE_j] + (b1).fMax[BND_COMBINE_j];\
		BND_COMBINE_t2 = (b2).fCenter[BND_COMBINE_j] + (b2).fMax[BND_COMBINE_j];\
		BND_COMBINE_max = (BND_COMBINE_t1 > BND_COMBINE_t2)?BND_COMBINE_t1:BND_COMBINE_t2;\
		BND_COMBINE_t1 = (b1).fCenter[BND_COMBINE_j] - (b1).fMax[BND_COMBINE_j];\
		BND_COMBINE_t2 = (b2).fCenter[BND_COMBINE_j] - (b2).fMax[BND_COMBINE_j];\
		BND_COMBINE_min = (BND_COMBINE_t1 < BND_COMBINE_t2)?BND_COMBINE_t1:BND_COMBINE_t2;\
		(b).fCenter[BND_COMBINE_j] = 0.5*(BND_COMBINE_max + BND_COMBINE_min);\
		(b).fMax[BND_COMBINE_j] = 0.5*(BND_COMBINE_max - BND_COMBINE_min);\
		}\
	}

typedef struct bndBound {
    FLOAT fCenter[3];
    FLOAT fMax[3];
    } BND;

#define MINDIST(bnd,pos,min2) {\
    double BND_dMin;\
    int BND_j;\
    (min2) = 0;					\
    for (BND_j=0;BND_j<3;++BND_j) {\
	BND_dMin = fabs((bnd).fCenter[BND_j] - (pos)[BND_j]) - (bnd).fMax[BND_j]; \
	if (BND_dMin > 0) (min2) += BND_dMin*BND_dMin;			\
	}\
    }

#define PARTITION(p,t,i,j,LOWER_CONDITION,UPPER_CONDITION) {\
    while (i <= j) {\
	if (LOWER_CONDITION) ++i;\
	else break;\
	}\
    while (i <= j) {\
	if (UPPER_CONDITION) --j;\
	else break;\
	}\
    if (i < j) {\
	t = p[i];\
	p[i] = p[j];\
	p[j] = t;\
	while (1) {\
	    ++i;\
	    while (LOWER_CONDITION) ++i;\
	    --j;\
	    while (UPPER_CONDITION) --j;\
	    if (i < j) {\
		t = p[i];\
		p[i] = p[j];\
		p[j] = t;\
		}\
	    else break;\
	    }\
	}\
    }

typedef struct kdNode {
    BND bnd;
    int iLower;
    int iParent;
    int pLower;		/* also serves as thread id for the LTT */
    int pUpper;		/* pUpper < 0 indicates no particles in tree! */
    double dTimeStamp;
#ifdef LOCAL_EXPANSION
    FLOAT fOpen;
#else
    FLOAT fOpen2;
#endif
    FLOAT fSoft2;
    FLOAT r[3];
    FLOAT a[3];  /* a_cm is used in determining the timestep in the new grav stepping */
    FLOAT v[3];
    MOMR mom;
    int iActive;
    uint8_t uMinRung;
    uint8_t uMaxRung;
    } KDN;


#ifdef NEW_TREE
#define MAX_NBUCKET 7

typedef struct kdNew {
    double r[3];
    double v[3];
    union celltype {
	struct cell {
	    double dSplit;
	    uint32_t iLower;
	    uint32_t iUpper;
	    uint32_t iParent:
	    uint16_t idLower;
	    uint16_t idUpper;
	    uint16_t idParent;
	    uint16_t uPad16;
	} c;
	struct bucket {
	    uint32_t iPart[MAX_NBUCKET];
	} b;
    };
    uint64_t uCount:48
    MOMR mom;
} KDNEW;
#endif   

#define NMAX_OPENCALC	100

#define FOPEN_FACTOR	4.0/3.0

#ifdef LOCAL_EXPANSION
#define CALCOPEN(pkdn,diCrit2)\
{\
	FLOAT CALCOPEN_d2 = 0;\
	int CALCOPEN_j;\
	for (CALCOPEN_j=0;CALCOPEN_j<3;++CALCOPEN_j) {\
		FLOAT CALCOPEN_d = fabs((pkdn)->bnd.fCenter[CALCOPEN_j] - (pkdn)->r[CALCOPEN_j]) +\
			(pkdn)->bnd.fMax[CALCOPEN_j];\
		CALCOPEN_d2 += CALCOPEN_d*CALCOPEN_d;\
		}\
	(pkdn)->fOpen = sqrt(CALCOPEN_d2*(diCrit2));	\
	}
#else
#define CALCOPEN(pkdn,diCrit2)\
{\
	FLOAT CALCOPEN_d2 = 0;\
	int CALCOPEN_j;\
	for (CALCOPEN_j=0;CALCOPEN_j<3;++CALCOPEN_j) {\
		FLOAT CALCOPEN_d = fabs((pkdn)->bnd.fCenter[CALCOPEN_j] - (pkdn)->r[CALCOPEN_j]) +\
			(pkdn)->bnd.fMax[CALCOPEN_j];\
		CALCOPEN_d2 += CALCOPEN_d*CALCOPEN_d;\
		}\
	(pkdn)->fOpen2 = CALCOPEN_d2*(diCrit2);	\
	}
#endif

#define CALCAXR(fMax,axr)\
{\
	if (fMax[0] < fMax[1]) {\
		if (fMax[1] < fMax[2]) {\
			if (fMax[0] > 0) axr = fMax[2]/fMax[0];\
			else axr = 1e6;\
			}\
		else if (fMax[0] < fMax[2]) {\
			if (fMax[0] > 0) axr = fMax[1]/fMax[0];\
			else axr = 1e6;\
			}\
		else if (fMax[2] > 0) axr = fMax[1]/fMax[2];\
		else axr = 1e6;\
		}\
	else if (fMax[0] < fMax[2]) {\
		if (fMax[1] > 0) axr = fMax[2]/fMax[1];\
		else axr = 1e6;\
		}\
	else if (fMax[1] < fMax[2]) {\
		if (fMax[1] > 0) axr = fMax[0]/fMax[1];\
		else axr = 1e6;\
		}\
	else if (fMax[2] > 0) axr = fMax[0]/fMax[2];\
	else axr = 1e6;\
	}

/*
** components required for evaluating a monopole interaction
** including the softening.
*/

typedef struct ilPart {
#ifndef USE_SIMD
    int iOrder;
#endif
    double m,x,y,z;
#ifndef USE_SIMD
    double vx,vy,vz;
#endif
#ifdef SOFTLINEAR
    double h;
#endif
#ifdef SOFTSQUARE
    double twoh2;
#endif
#if !defined(SOFTLINEAR) && !defined(SOFTSQUARE)
    double fourh2;
#endif  
#ifdef SYMBA
    double hill;
    double rcrit;
    double fMass;
    int iOrgIdx;
#endif
#ifdef PLANETS
    int iColor;
#endif
    } ILP;

/*
** components required for time-step calculation (particle-bucket list)
*/

typedef struct ilPartBucket {
    double m,x,y,z;
#ifdef SOFTLINEAR
    double h;
#endif
#ifdef SOFTSQUARE
    double twoh2;
#endif
#if !defined(SOFTLINEAR) && !defined(SOFTSQUARE)
    double fourh2;
#endif     
    } ILPB;

typedef struct RhoEncArray {
    int index;
    double x;
    double y;
    double z;
    double dir;
    double rhoenc;
    } RHOENC;

typedef struct RhoLocalArray {
    double d2;
    double m;
    } RHOLOCAL;

typedef struct heapStruct {
    int index;
    double rhoenc;
    } HEAPSTRUCT;

typedef struct ewaldTable {
    double hx,hy,hz;
    double hCfac,hSfac;
    } EWT;
/*
** components required for groupfinder:  --J.D.--
*/
typedef struct remoteMember{
    int iPid;
    int iIndex;
    } FOFRM;
typedef struct groupData{
    int iLocalId;
    int iGlobalId;
    FLOAT fAvgDens;
    FLOAT fVelDisp;
    FLOAT fVelSigma2[3];
    FLOAT fMass;
    FLOAT fGasMass;
    FLOAT fStarMass;
    FLOAT fRadius;
    FLOAT fDeltaR2;
    FLOAT r[3];
    FLOAT potmin;
    FLOAT rpotmin[3];
    FLOAT rmax[3];
    FLOAT rmin[3];
    FLOAT v[3];
    FLOAT vcircMax;
    FLOAT rvcircMax;
    FLOAT rvir;
    FLOAT Mvir;
    FLOAT lambda;
    FLOAT rhoBG;
/*    FLOAT rTidal; */
/*    FLOAT mTidal; */
    int nLocal;
    int nTotal;
    int bMyGroup;
    int nLSubGroups;
    void *lSubGroups;
    int nSubGroups;
    void *subGroups;
    int nRemoteMembers;
    int iFirstRm;
    } FOFGD;

typedef struct protoGroup{
    int iId;
    int nMembers;
    int nRemoteMembers;
    int iFirstRm;
    } FOFPG;

typedef struct groupBin{
    int iId;
    int nMembers;
    FLOAT fRadius;
    FLOAT fDensity;
    FLOAT fMassInBin;
    FLOAT fMassEnclosed;
    FLOAT com[3];
    FLOAT v2[3]; 
    FLOAT L[3];
    FLOAT a;
    FLOAT b;
    FLOAT c;
    FLOAT phi;
    FLOAT theta;
    FLOAT psi;
    } FOFBIN;

typedef struct pkdContext {
    MDL mdl;
    int idSelf;
    int nThreads;
    int nStore;
    int nRejects;
    int nLocal;
    int nVeryActive;
    int nActive;
    int nDark;
    int nGas;
    int nStar;
    int nMaxOrderDark;
    int nMaxOrderGas;
    FLOAT fPeriod[3];
    int nMaxNodes;   /* for kdTemp */
    KDN *kdTop;
    int iTopRoot;
    int nNodes;
    int nNodesFull;     /* number of nodes in the full tree (including very active particles) */
    int nMaxDepth;	/* gives the maximum depth of the local tree */
    int nNonVANodes;    /* number of nodes *not* in Very Active Tree, or index to the start of the VA nodes (except VAROOT) */
    KDN *kdNodes;
    PARTICLE *pStore;
    int nMaxBucketActive;
    PARTICLE **piActive;
    PARTICLE **piInactive;
    PLITE *pLite;

    /*
    ** New activation methods
    */
    uint8_t uMinRungActive;
    uint8_t uMaxRungActive;
    uint8_t uRungVeryActive;    /* NOTE: The first very active particle is at iRungVeryActive + 1 */

    /*
    ** Ewald summation setup.
    */
    MOMC momRoot;		/* we hope to get rid of this */
    int nMaxEwhLoop;
    int nEwhLoop;
    EWT *ewt;
    /*
    ** Timers stuff.
    */
    struct timer {
	double sec;
	double stamp;
	double system_sec;
	double system_stamp;
	double wallclock_sec;
	double wallclock_stamp;
	int iActive;
	} ti[MAX_TIMERS];
    int nGroups;
    FOFGD *groupData;
    int nRm;
    int nMaxRm;
    FOFRM *remoteMember;
    int nBins;

    FOFBIN *groupBin;
    /*
    ** Oh heck, just put all the parameters in here!
    ** This is set in pkdInitStep.
    */
    struct parameters param;
#ifdef PLANETS
    double dDeltaEcoll;
    double dSunMass;
    int    iCollisionflag; /*call pkddocollisionveryactive if iCollisionflag=1*/ 
#ifdef gastable
    GASDISK_TABLE GD0, GD1;
#endif
#ifdef gaptable
    GAP_TABLE GT;
#endif
#ifdef sm2d
    TRACERPOT *PD;
#endif
    double *rc;
    int mf;
#endif   
    } * PKD;

/* New, rung based ACTIVE/INACTIVE routines */
static inline int pkdRungVeryActive(PKD pkd) { return pkd->uRungVeryActive; }
static inline int pkdIsVeryActive(PKD pkd, PARTICLE *p) {
    return p->iRung > pkd->uRungVeryActive;
}

static inline int pkdIsRungActive(PKD pkd, uint8_t uRung ) {
    return uRung >= pkd->uMinRungActive && uRung <= pkd->uMaxRungActive;
}

static inline int pkdIsActive(PKD pkd, PARTICLE *p ) {
    return pkdIsRungActive(pkd,p->iRung);
}

static inline int pkdIsCellActive(PKD pkd, KDN *c) {
    return pkd->uMinRungActive <= c->uMaxRung && pkd->uMaxRungActive >= c->uMinRung;
}
#define CELL_ACTIVE(c,a,b) ((a)<=(c)->uMaxRung && (b)>=(c)->uMinRung)



typedef struct CacheStatistics {
    double dpNumAccess;
    double dpMissRatio;
    double dpCollRatio;
    double dpMinRatio;
    double dcNumAccess;
    double dcMissRatio;
    double dcCollRatio;
    double dcMinRatio;
    } CASTAT;


/*
** From tree.c:
*/
void pkdVATreeBuild(PKD pkd,int nBucket,FLOAT diCrit2,int bSqueeze,double dTimeStamp);
void pkdTreeBuild(PKD pkd,int nBucket,FLOAT dCrit,KDN *pkdn,int bSqueeze,int bExcludeVeryActive,double dTimeStamp);
void pkdCombineCells(KDN *pkdn,KDN *p1,KDN *p2,int bCombineBound);
void pkdDistribCells(PKD,int,KDN *);
void pkdCalcRoot(PKD,MOMC *);
void pkdDistribRoot(PKD,MOMC *);

#ifdef GASOLINE
void pkdCalcBoundBall(PKD pkd,double fBallFactor,BND *);
void pkdDistribBoundBall(PKD,int,BND *);
#endif

#include "parameters.h"
/*
** From pkd.c:
*/
double pkdGetTimer(PKD,int);
double pkdGetSystemTimer(PKD,int);
double pkdGetWallClockTimer(PKD,int);
void pkdClearTimer(PKD,int);
void pkdStartTimer(PKD,int);
void pkdStopTimer(PKD,int);
void pkdInitialize(PKD *,MDL,int,int,FLOAT *,int,int,int);
void pkdFinish(PKD);
void pkdReadTipsy(PKD,char *,char *,int,int,int,double,int);
void pkdSetSoft(PKD pkd,double dSoft);
void pkdCalcBound(PKD,BND *);

#ifdef CHANGESOFT
void pkdPhysicalSoft(PKD pkd,double dSoftMax,double dFac,int bSoftMaxMul);
void pkdPreVariableSoft(PKD pkd);
void pkdPostVariableSoft(PKD pkd,double dSoftMax,int bSoftMaxMul);
#endif

void pkdBucketWeight(PKD pkd,int iBucket,FLOAT fWeight);
void pkdGasWeight(PKD);
void pkdRungDDWeight(PKD, int, double);
int pkdWeight(PKD,int,FLOAT,int,int,int,int *,int *,FLOAT *,FLOAT *);
void pkdCountVA(PKD,int,FLOAT,int *,int *);
int pkdLowerPart(PKD,int,FLOAT,int,int);
int pkdUpperPart(PKD,int,FLOAT,int,int);
int pkdWeightWrap(PKD,int,FLOAT,FLOAT,int,int,int,int,int *,int *);
int pkdLowerPartWrap(PKD,int,FLOAT,FLOAT,int,int,int);
int pkdUpperPartWrap(PKD,int,FLOAT,FLOAT,int,int,int);
int pkdLowerOrdPart(PKD,int,int,int);
int pkdUpperOrdPart(PKD,int,int,int);
int pkdActiveOrder(PKD);

int pkdColRejects(PKD,int);
int pkdColRejects_Old(PKD,int,FLOAT,FLOAT,int);

int pkdSwapRejects(PKD,int);
int pkdSwapSpace(PKD);
int pkdFreeStore(PKD);
int pkdLocal(PKD);
int pkdActive(PKD);
int pkdInactive(PKD);
int pkdNodes(PKD);
int pkdColOrdRejects(PKD,int,int);
void pkdLocalOrder(PKD);
void pkdWriteTipsy(PKD,char *,int,int,double,int);
#ifdef USE_HDF5
void pkdWriteHDF5(PKD pkd, IOHDF5 io,double dvFac);
#endif
void pkdGravAll(PKD,double,int,int,int,int,int,double,double,int *,
		double *,double *,CASTAT *,double *);
void pkdCalcE(PKD,double *,double *,double *);
void pkdCalcEandL(PKD,double *,double *,double *,double []);
void pkdDrift(PKD,double,double,FLOAT *,int,int,FLOAT);
void pkdDriftInactive(PKD pkd,double dTime,double dDelta,FLOAT fCenter[3],int bPeriodic,
		      int bFandG, FLOAT fCentMass);
void pkdStepVeryActiveKDK(PKD pkd, double dStep, double dTime, double dDelta,
			  int iRung, int iKickRung, int iRungVeryActive,int iAdjust,
			  double diCrit2,int *pnMaxRung,
			  double aSunInact[3], double adSunInact[3], double dSunMass);
#ifdef HERMITE
void
pkdStepVeryActiveHermite(PKD pkd, double dStep, double dTime, double dDelta,
		     int iRung, int iKickRung, int iRungVeryActive,int iAdjust, double diCrit2,
			 int *pnMaxRung, double aSunInact[], double adSunInact[], double dSunMass);
void pkdCopy0(PKD pkd,double dTime);
void pkdPredictor(PKD pkd,double dTime); 
void pkdCorrector(PKD pkd,double dTime);
void pkdSunCorrector(PKD pkd,double dTime,double dSunMass); 
void pkdPredictorInactive(PKD pkd,double dTime);
void pkdAarsethStep(PKD pkd, double dEta);
void pkdFirstDt(PKD pkd);
#endif /* Hermite */
void pkdKickKDKOpen(PKD pkd,double dTime,double dDelta);
void pkdKickKDKClose(PKD pkd,double dTime,double dDelta);
void pkdKick(PKD pkd,double,double, double, double, double, double, int, double, double);
void pkdEwaldKick(PKD pkd, double dvFacOne, double dvFacTwo);
void pkdSwapAll(PKD pkd, int idSwap);
void pkdInitStep(PKD pkd,struct parameters *p,CSM csm);
void pkdSetRung(PKD pkd, int iRung);
void pkdBallMax(PKD pkd, int iRung, int bGreater, double ddHonHLimit);
void pkdActiveRung(PKD pkd, int iRung, int bGreater);
int pkdCurrRung(PKD pkd, int iRung);
void pkdGravStep(PKD pkd, double dEta, double dRhoFac);
void pkdAccelStep(PKD pkd, double dEta, double dVelFac, double
		  dAccFac, int bDoGravity, int bEpsAcc, int bSqrtPhi, double dhMinOverSoft);
void pkdDensityStep(PKD pkd, double dEta, double dRhoFac);
int pkdDtToRung(PKD pkd,int iRung, double dDelta, int iMaxRung, int bAll, int *nRungCount);
void pkdInitDt(PKD pkd, double dDelta);
int pkdOrdWeight(PKD,int,int,int,int,int *,int *);
void pkdDeleteParticle(PKD pkd, PARTICLE *p);
void pkdNewParticle(PKD pkd, PARTICLE *p);
int pkdResetTouchRung(PKD pkd, unsigned int iTestMask, unsigned int iSetMask);
void pkdSetRungVeryActive(PKD pkd, int iRung );
int pkdIsGas(PKD,PARTICLE *);
int pkdIsDark(PKD,PARTICLE *);
int pkdIsStar(PKD,PARTICLE *);
void pkdSetParticleTypes(PKD pkd);
void pkdColNParts(PKD pkd, int *pnNew, int *nDeltaGas, int *nDeltaDark,
		  int *nDeltaStar);
void pkdNewOrder(PKD pkd, int nStart);
void pkdSetNParts(PKD pkd, int nGas, int nDark, int nStar, int nMaxOrderGas,
		  int nMaxOrderDark);
#ifdef RELAXATION
void pkdInitRelaxation(PKD pkd);
#endif

int pkdPackIO(PKD pkd,
	      PIO *io, int nMax,
	      int *iIndex,
	      int iMinOrder, int iMaxOrder );

#ifdef PLANETS
void pkdNewOrgIdx(PKD pkd, int nStart);
void pkdGetnMaxOrgIdx(PKD pkd, int *nMaxOrgIdx);
void pkdSunIndirect(PKD pkd,double aSun[],double adSun[],int iFlag);
void pkdGravSun(PKD pkd,double aSun[],double adSun[],double dSunMass);
void pkdHandSunMass(PKD pkd,double dSunMass);
void pkdReadSS(PKD pkd,char *pszFileName,int nStart,int nLocal);
void pkdWriteSS(PKD pkd,char *pszFileName,int nStart);
//void pkdGasAccel(PKD pkd, double dTime, double dDelta, GASDISK_PARAMS * GP, double aj, STEPINSKI * ST, double *dT);
void pkdGasAccel(PKD pkd, double dTime, double dDelta, GASDISK_PARAMS * GP, double *dT, int iRung);
//void pkdGetJupiter(PKD pkd, double *paj, double *pmj);
void  pkdGetJupiter(PKD pkd, GASDISK_PARAMS * GP, int  *pnpgap,double *apgap, double *k1, double *k2);
#ifdef gastable
void pkdGasTable(PKD pkd, GASDISK_TABLE GD);
#endif
#ifdef gaptable
void pkdGapTable(PKD pkd, GAP_TABLE GT0);
#endif
void pkdGravDirect(PKD pkd, int n);
void pkdCorrectHelioDist(PKD pkd, int tag, double rd[3], double vd[3], double dSM, double *dT);
void pkdGetStepinski(PKD pkd, GASDISK_PARAMS * GP, double t, double *prout, double rij[4], double fSigma[5], double fTemp[5]);
void pkdGetGasDisk(PKD pkd, GASDISK_PARAMS * GP, double t, double r, double omega, double depfac, double rin, double rout, double *rij, double *fSigma, double *fTemp, double * pSigma, double * pSigma0, double * pGasp, double * pTemp, double * pGasq, double * ph, double * pKappa);
void pkdCalcrc(PKD pkd, double dTime, int bDE);

#define nDirect 200  /* use N*N gravity solver for msr->N < nDirect 
			when iGravDirect = 1 */
#define fsig (1.49598*1.49598/1.98892*1.0E-7) /* convert g/cm^2 to M_sun/AU^2*/
#define ffrho (1.49598*1.49598*1.49598/1.98892*1.0E6) /* convert g/cm^3 to M_sun/AU^3*/
#define facrho 0.39894227
#define tauc 1.78 /* critical optical depth used in Stepinski's gas disk model*/
#define Mgiant 2.E-4
#define fatm 0.810571177122182 /*use calcfatm.f kappa = 0.01 cm2/g*/ 
#define wfac 1.4767173e17 // = 3 kappa kB / 64 pi sigma_SB mu m_u normalized by AU^4 /(Msun^2 Omega(1AU))

#ifdef SYMBA

#define FCRIT 4.0  /* (> 1) used in close encounter judge */
#define RSHELL  0.6  /* r_j+1/r_j  0.48075*/
#define RHSCALE 4.5     /* critical distance for close encounters in units of hill (3 seems too small) */
#define RHSCALE2 (RHSCALE*RHSCALE)
#define symfac  (1.0/(1.0-RSHELL))
#define MAX_nPL 300
#define ftmin 0.1 // minimum mass of a tracer is ftmin*mt0 except for those with nump = 1 

void
pkdStepVeryActiveSymba(PKD pkd, double dStep, double dTime, double dDelta,
		       int iRung, int iKickRung, int iRungVeryActive,
		       int iAdjust, double diCrit2,
		       int *pnMaxRung, double dSunMass, GASDISK_PARAMS * GP, int);
int pkdSortVA(PKD pkd, int iRung);
void pkdGravVA(PKD pkd, int iRung, int iColCheck, int iAdjust);
int pkdCheckDrminVA(PKD pkd, int iRung, int multiflag, int nMaxRung);
void pkdKickVA(PKD pkd, double dt);
int pkdDrminToRung(PKD pkd, int iRung, int iMaxRung, int *nRungCount);
int pkdGetPointa(PKD pkd);
int pkdDrminToRungVA(PKD pkd, int iRung, int iMaxRung, int multiflag);
void pkdMomCent(PKD pkd,double momSun[], double *mCent);
void pkdDriftSun(PKD pkd,double vSun[],double dt);
void pkdHeltoDemo(PKD pkd,double vCent[]);
void pkdDemotoHel(PKD pkd,double vSun[]);
void pkdKeplerDrift(PKD pkd,double dt,double mu,int tag_VA);
void pkdSymbaInitial(PKD pkd);
void pkdCalcHill(PKD pkd, double dDelta, int bIflag);
void pkdSearchDirect(PKD pkd, int n);
void pkdGetPlanets(PKD pkd,int *nPL,PARTICLE *pp);
void pkdGravPlanets(PKD pkd,int nPL,PARTICLE *pp);
void pkdHandPlanets(PKD pkd,int nPL,PARTICLE *pp);
void pkdSearchPlanets(PKD pkd,int nPL,PARTICLE *pp);

#ifdef sm2d
//#define dtheta  (0.499999*M_PI)
#define cbr2    1.2599210498948732
#define COLL_LOG_PBHYB_TXT "ss.coll_PBHYB.txt"
#define COLL_LOG_PBHYB_BIN "ss.coll_PBHYB.bin"
#define cd1 (243.0*0.747*0.747/8.0) 
#define cd2 (243.0/8.0*(4.0/81.0+0.21*0.21/4.0))

//#define TR_GRAV 0

void pkdCalcElem(PKD pkd);
void pkdResetKick(PKD pkd);
void pkdDeletoKick(PKD pkd, double dTime, double dDLIAPD, double *ptsmin);
void OneDeletoKick(PARTICLE *p,double sqmsun,double e1,double i1,double da,double de,double dev, double di,double div,double das);
void pkdChecknSmooth(PKD pkd, int *piFlag);
void CalcPcollPebble(PARTICLE *pj,PARTICLE *pi,double eij,double iij,double hij,double msun,double rp,double *ppcol);
void pkdPBHYBCollStirDirect(PKD pkd, double dTime, int TYPE_PBHYB, double dDPBHYB);
void pkdDmdt(PKD pkd,double dTime_now);
void pkdTrPotTable(PKD pkd, double dTime);
void pkdTrPotAcc(PKD pkd, double dTime);
void OneDeletoKick2(PARTICLE *p,double sqmsun,double e1, double i1, double da,double de,double dev2,double di,double div,double div2,double das, int *pakick, int *pikick);
void pkdPebble2Planetesimal(PKD pkd,GASDISK_PARAMS * GP, double dTime, int iPlForm, double dDPBHYB);
void pkdGasAcc2Planet(PKD pkd,GASDISK_PARAMS * GP, double dTime, int iGasAcc2Planet, double dDPBHYB);
void qasort(double *ag, int *ig,int left,int right);
void swap(double *ag,int *ig,int i,int j);

#endif /* sm2d */
#endif /* SYMBA */
#endif /* PLANETS*/

#endif
