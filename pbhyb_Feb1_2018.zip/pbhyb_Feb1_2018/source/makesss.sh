#!/usr/bin/sh

for i in ss.0*00000
do
/Users/rmorishi/Documents/Planet_formation/pbhyb/analysis/ssa $i
#convert ssa.sss $i.dat
mv  ssa.sss ./anime/$i.dat
echo "i = $i"
#i=`expr $i + 1`
done
