#ifdef PLANETS
#ifndef COLLISION_HINCLUDED
#define COLLISION_HINCLUDED

#include "pkd.h" /*for PARTICLE struct */
#include "kepler.h"
#include "../analysis/ssio.h"  /*for SSDATA struct */
#include "parameters.h" /* for COLLISION_PARAMS struct */

#define NORMAL 0	/* drift types */
#define KEPLER 1

int REJECT(PARTICLE *p);
#define REJECT(p) ((p)->dtCol < 0)

#define DBL_MAX 1.7976931348623157E+308
int COLLISION(double t);
#define COLLISION(t) ((t) < DBL_MAX)

unsigned int BIT(unsigned int n);
#define BIT(n) (1 << (n))

/* Filenames for collision logs */
#define COLL_LOG_TXT "ss.coll.txt"
#define COLL_LOG_BIN "ss.coll.bin"

#define COLL_LOG_NONE		0
#define COLL_LOG_BOUNCE2	BIT(0) /* one line output of bouncing to display */
#define COLL_LOG_TERSE		BIT(1) /* merging infomation to binary file */
#define COLL_LOG_STAND		BIT(2) /* standard output to display */
#define COLL_LOG_VERBOSE	BIT(3) /* standard output to text file  */



#define MISS	0
#define MERGE	BIT(0)
#define BOUNCE	BIT(1)
#define FRAG	BIT(2)
#define ESCAPE	BIT(3)
#define SUNCOLLIDE	BIT(4)

#define MAX_NUM_FRAG 4

enum {ConstEps,Frosty200,Frosty120,Compacted,Glancing}; /* bounce options */

enum {EscVel,MaxTrv}; /* slide options */

typedef struct {
	int iPid;
	int iOrder;
	int iIndex;
	int iOrgIdx;
	} PARTICLE_ID;

typedef struct {
	PARTICLE_ID id;
	double fMass;
        double fRadius;
        double fGasMass;
	double r[3];
	double v[3];
	double w[3];
#ifdef HERMITE
	double a[3];
	double ad[3];
#endif
#ifdef SYMBA
    double drmin;
    int   iOrder_VA[MAXn_VA]; /* iOrder's of particles within 3 hill radius*/
    int   i_VA[MAXn_VA];    /* pointers of particles */
    int   n_VA;       /* number of particles */
  double  hill;       /* hill radius */ 
  double rcrit;
  double nump;
  double rb[3];
  double vb[3];
  double a_pr;
  double mmin;
  double St;
#endif
#ifdef sm2d
  double ele[11];
  int iColflag;
  double dDmi;
  double dls;
#endif
	int iColor;
	double dt;
        int iRung;
        double fac;
	} COLLIDER;

void PutColliderInfo(const COLLIDER *c,int iOrder2,PARTICLE *p,double dt);
void pkdNextCollision(PKD pkd, double *dtCol, int *iOrder1, int *iOrder2);
void pkdGetColliderInfo(PKD pkd, int iOrder, COLLIDER *c);
void pkdDoCollision(PKD pkd, double dt, const COLLIDER *c1, const COLLIDER *c2,
					int bPeriodic, const COLLISION_PARAMS *CP, int *piOutcome,
					double *dT,	COLLIDER *cOut, int *pnOut);
void pkdDoCollisionVeryActive(PKD pkd,double dTime);
static char * _pkdParticleLabel(PKD pkd,int iColor);
void pkdGetVariableVeryActive(PKD pkd, double *dDeltaEcoll);
void pkdCheckHelioDist(PKD pkd, double dTime,double *dT,double *dSM, double *md, double rd[3], double vd[3]);
void CollisionData(XDR *xdrs, COLLIDER *c1, COLLIDER *c2);
#ifdef sm2d
void pkdDoCollisionPBHYB(PKD pkd,const COLLIDER *pc1, const COLLIDER *pc2,
			 const COLLISION_PARAMS *CP,int iexcess,double dTime,int *piOutcome, double *dT,int *pnOut);
void pkdMergePBHYB(PKD pkd,COLLIDER *c1,COLLIDER *c2,double dDensity, double dDmi,double lz1,double lz2, double facr2, int iexcess, int bDiagInfo, double dTime, int *pnOut, double *dT, int iOutcome, double n1b,int pflag);
void pkdBouncePBHYB(PKD pkd,COLLIDER *c1,COLLIDER *c2,double dDmi,double lz1,double lz2, double facr2, double cimp,double dEpsN, double dEpsT,int bDiagInfo,double dTime,int *pnOut, double *dT);
void pkdSplitTracerPBHYB(PKD pkd,double dTime,double *dT);
void calc_dthe(COLLIDER c1,COLLIDER c2,double *pdthe);
void calc_aei(COLLIDER c1,double dSunMass,double *pa1,double *pe1,double *pi1);
void CollisionDataPBHYB(XDR *xdrs, COLLIDER *c1);
void CollisionDataPBHYB2(XDR *xdrs, PARTICLE *p);
void pkdFragmass(PKD pkd,COLLIDER *c1,COLLIDER *c2,double m2,double vimp2,double *pm1,double *pn1);
void pkdPebbleSupply(PKD pkd,double dTime,double dDelta,GASDISK_PARAMS *GP, int *pnew_flag, double *pmt0_peb, double *v);
void pkdPebbleSupply_old(PKD pkd,double dTime,double dDelta,GASDISK_PARAMS *GP, int *pnew_flag, double *pmt0_peb, double *v);
#endif

#endif
#endif /* PLANETS */

