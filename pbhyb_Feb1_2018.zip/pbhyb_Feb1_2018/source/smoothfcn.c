#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <math.h>
#include <assert.h>
#include "smoothfcn.h"
#include "master.h"

#ifdef M43D
/* M43D Creates a 3D kernel by convolution of 3D tophats the way M4(1D) is made in 1D */
#define BALL2(a) ((a)->fBall*(a)->fBall)
#define KERNEL(ak,ar2) { \
		ak = sqrt(ar2); \
		if (ar2 < 1.0) ak = 6.*0.25/350./3. *(1360+ar2*(-2880 \
			 +ar2*(3528+ak*(-1890+ak*(-240+ak*(270-6*ar2)))))); \
		else ak = 6.*0.25/350./3. *(7040-1152/ak+ak*(-10080+ak*(2880+ak*(4200 \
	                 +ak*(-3528+ak*(630+ak*(240+ak*(-90+2*ar2)))))))); \
                }
#define DKERNEL(adk,ar2) { \
		adk = sqrt(ar2); \
		if (ar2 < 1.0) adk = 6.*0.25/350./3. * (-2880*2 \
	                 +ar2*(3528*4+ adk*(-1890*5 + adk*(-240*6+ adk*(270*7-6*9*ar2))))); \
		else adk = 6.*0.25/350./3. *((1152/ar2-10080)/adk+(2880*2+adk*(4200*3 \
	                 +adk*(-3528*4+adk*(630*5+adk*(240*6 +adk*(-90*7+2*9*ar2))))))); \
                }

#else
#ifdef HSHRINK
/* HSHRINK M4 Kernel uses an effective h of (pi/6)^(1/3) times h for nSmooth neighbours */
#define dSHRINKFACTOR        0.805995977
#define BALL2(a) ((a)->fBall*(a)->fBall*(dSHRINKFACTOR*dSHRINKFACTOR))
#define KERNEL(ak,ar2) { \
		ak = 2.0 - sqrt(ar2); \
		if (ar2 < 1.0) ak = (1.0 - 0.75*ak*ar2); \
		else if (ar2 < 4.0) ak = 0.25*ak*ak*ak; \
		else ak = 0.0; \
                }
#define DKERNEL(adk,ar2) { \
		adk = sqrt(ar2); \
		if (ar2 < 1.0) { \
			adk = -3 + 2.25*adk; \
			} \
		else if (ar2 < 4.0) { \
			adk = -0.75*(2.0-adk)*(2.0-adk)/adk; \
			} \
		else adk = 0.0; \
                }

#else
/* Standard M_4 Kernel */
#define BALL2(a) ((a)->fBall*(a)->fBall)
#define KERNEL(ak,ar2) { \
		ak = 2.0 - sqrt(ar2); \
		if (ar2 < 1.0) ak = (1.0 - 0.75*ak*ar2); \
		else ak = 0.25*ak*ak*ak; \
                }
#define DKERNEL(adk,ar2) { \
		adk = sqrt(ar2); \
		if (ar2 < 1.0) { \
			adk = -3 + 2.25*adk; \
			} \
		else { \
			adk = -0.75*(2.0-adk)*(2.0-adk)/adk; \
			} \
                }
#endif
#endif

void NullSmooth(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf) {
    }

void initDensity(void *p)
    {
    ((PARTICLE *)p)->fDensity = 0.0;
    }

void combDensity(void *p1,void *p2)
    {
    ((PARTICLE *)p1)->fDensity += ((PARTICLE *)p2)->fDensity;
    }

void Density(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    FLOAT ih2,r2,rs,fDensity;
    int i;

    ih2 = 4.0/BALL2(p);
    fDensity = 0.0;
    for (i=0;i<nSmooth;++i) {
	r2 = nnList[i].fDist2*ih2;
	KERNEL(rs,r2);
	fDensity += rs*nnList[i].pPart->fMass;
	}
    p->fDensity = M_1_PI*sqrt(ih2)*ih2*fDensity; 
    }

void DensitySym(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    PARTICLE *q;
    FLOAT fNorm,ih2,r2,rs;
    int i;

    ih2 = 4.0/(BALL2(p));
    fNorm = 0.5*M_1_PI*sqrt(ih2)*ih2;
    for (i=0;i<nSmooth;++i) {
	r2 = nnList[i].fDist2*ih2;
	KERNEL(rs,r2);
	rs *= fNorm;
	q = nnList[i].pPart;
	p->fDensity += rs*q->fMass;
	q->fDensity += rs*p->fMass;
	}
    }

void initParticleMarkDensity(void *p)
    {
    ((PARTICLE *)p)->fDensity = 0.0;
    TYPESet((PARTICLE *) p,TYPE_DensZeroed);
    }

void initMarkDensity(void *p)
    {
    ((PARTICLE *)p)->fDensity = 0.0;
    }

void combMarkDensity(void *p1,void *p2)
    {
    if (TYPETest((PARTICLE *) p1,TYPE_DensZeroed)) 
	((PARTICLE *)p1)->fDensity += ((PARTICLE *)p2)->fDensity;
    else if (TYPETest((PARTICLE *) p2,TYPE_DensZeroed)) {
	((PARTICLE *)p1)->fDensity = ((PARTICLE *)p2)->fDensity;
	}
    ((PARTICLE *)p1)->iActive |= ((PARTICLE *)p2)->iActive;
    }

void MarkDensity(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    assert(0);
    }

void MarkDensitySym(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    PARTICLE *q;
    FLOAT fNorm,ih2,r2,rs;
    int i;
    unsigned int qiActive;

    ih2 = 4.0/(BALL2(p));
    fNorm = 0.5*M_1_PI*sqrt(ih2)*ih2;
    if (TYPETest(p,TYPE_ACTIVE)) {
	TYPESet(p,TYPE_NbrOfACTIVE);
	for (i=0;i<nSmooth;++i) {
	    r2 = nnList[i].fDist2*ih2;
	    KERNEL(rs,r2);
	    rs *= fNorm;
	    q = nnList[i].pPart;
	    p->fDensity += rs*q->fMass;
	    if (TYPETest(q,TYPE_DensZeroed)) 
		q->fDensity += rs*p->fMass;
	    else {
		q->fDensity = rs*p->fMass;
		TYPESet(q, TYPE_DensZeroed);
		}
	    TYPESet(q,TYPE_NbrOfACTIVE);
	    }
	} 
    else {
	qiActive = 0;
	for (i=0;i<nSmooth;++i) {
	    r2 = nnList[i].fDist2*ih2;
	    KERNEL(rs,r2);
	    rs *= fNorm;
	    q = nnList[i].pPart;
	    if (TYPETest(p,TYPE_DensZeroed)) 
		p->fDensity += rs*q->fMass;
	    else {
		p->fDensity = rs*q->fMass;
		TYPESet(p,TYPE_DensZeroed);
		}
	    if (TYPETest(q,TYPE_DensZeroed)) 
		q->fDensity += rs*p->fMass;
	    else {
		q->fDensity = rs*p->fMass;
		TYPESet(q, TYPE_DensZeroed);
		}
	    qiActive |= q->iActive;
	    }
	if (qiActive & TYPE_ACTIVE) TYPESet(p,TYPE_NbrOfACTIVE);
	}
    }

void initParticleMarkIIDensity(void *p)
    {
    if (TYPEFilter((PARTICLE *) p,TYPE_DensACTIVE|TYPE_DensZeroed,
		   TYPE_DensACTIVE)) {
	((PARTICLE *)p)->fDensity = 0.0;
	TYPESet((PARTICLE *)p,TYPE_DensZeroed);
	}
    }

void initMarkIIDensity(void *p)
    {
    ((PARTICLE *) p)->fDensity = 0.0;
    }

void combMarkIIDensity(void *p1,void *p2)
    {
    if (TYPETest((PARTICLE *) p1,TYPE_DensACTIVE)) {
	if (TYPETest((PARTICLE *) p1,TYPE_DensZeroed)) 
	    ((PARTICLE *)p1)->fDensity += ((PARTICLE *)p2)->fDensity;
	else if (TYPETest((PARTICLE *) p2,TYPE_DensZeroed)) {
	    ((PARTICLE *)p1)->fDensity = ((PARTICLE *)p2)->fDensity;
	    }
	}
    ((PARTICLE *)p1)->iActive |= ((PARTICLE *)p2)->iActive;
    }

void MarkIIDensity(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    assert(0);
    }

void MarkIIDensitySym(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    PARTICLE *q;
    FLOAT fNorm,ih2,r2,rs;
    int i;
    unsigned int qiActive;

    ih2 = 4.0/(BALL2(p));
    fNorm = 0.5*M_1_PI*sqrt(ih2)*ih2;
    if (TYPETest(p,TYPE_DensACTIVE)) {
	qiActive = 0;
	for (i=0;i<nSmooth;++i) {
	    q = nnList[i].pPart;
	    qiActive |= q->iActive;
	    r2 = nnList[i].fDist2*ih2;
	    KERNEL(rs,r2);
	    rs *= fNorm;
	    p->fDensity += rs*q->fMass;
	    if (TYPETest(q,TYPE_DensACTIVE)) {
		if (TYPETest(q,TYPE_DensZeroed)) 
		    q->fDensity += rs*p->fMass;
		else {
		    q->fDensity = rs*p->fMass;
		    TYPESet(q,TYPE_DensZeroed);
		    }
		}
	    if (TYPETest(p,TYPE_ACTIVE)) TYPESet(q,TYPE_NbrOfACTIVE);
	    }
	if (qiActive & TYPE_ACTIVE) TYPESet(p,TYPE_NbrOfACTIVE);
	}
    else if (TYPETest(p,TYPE_ACTIVE)) {
	TYPESet( p,TYPE_NbrOfACTIVE);
	for (i=0;i<nSmooth;++i) {
	    q = nnList[i].pPart;
	    TYPESet(q,TYPE_NbrOfACTIVE);
	    if (!TYPETest(q,TYPE_DensACTIVE)) continue;
	    r2 = nnList[i].fDist2*ih2;
	    KERNEL(rs,r2);
	    rs *= fNorm;
	    if (TYPETest(q,TYPE_DensZeroed)) 
		q->fDensity += rs*p->fMass;
	    else {
		q->fDensity = rs*p->fMass;
		TYPESet(q,TYPE_DensZeroed);
		}
	    }
	}
    else {
	qiActive = 0;
	for (i=0;i<nSmooth;++i) {
	    q = nnList[i].pPart;
	    qiActive |= q->iActive;
	    if (!TYPETest(q,TYPE_DensACTIVE)) continue;
	    r2 = nnList[i].fDist2*ih2;
	    KERNEL(rs,r2);
	    rs *= fNorm;
	    if (TYPETest(q,TYPE_DensZeroed)) 
		q->fDensity += rs*p->fMass;
	    else {
		q->fDensity = rs*p->fMass;
		TYPESet(q,TYPE_DensZeroed);
		}
	    }
	if (qiActive & TYPE_ACTIVE) TYPESet(p,TYPE_NbrOfACTIVE);
	}
    }

void initMark(void *p)
    {
    }

void combMark(void *p1,void *p2)
    {
    ((PARTICLE *)p1)->iActive |= ((PARTICLE *)p2)->iActive;
    }


void initGroupMerge(void *g)
    {
    /* nothing to do here */
    }
void combGroupMerge(void *g1, void *g2)
    {
    FOFGD * gd1 = (FOFGD *)g1;
    FOFGD * gd2 = (FOFGD *)g2;

    /* accept second (remote) group number, if its smaller */	
    if(gd1->iGlobalId < gd2->iGlobalId)       
	gd2->iGlobalId = gd1->iGlobalId;
    else gd1->iGlobalId = gd2->iGlobalId;
    /* if someone says its not my group, accept it */	
    gd1->bMyGroup *= gd2->bMyGroup;
    gd2->bMyGroup *= gd1->bMyGroup;
    }
void initGroupBins(void *b)
    {
    /* nothing to do here */
    }
void combGroupBins(void *b1, void *b2)
    {
    FOFBIN * gb1 = (FOFBIN *)b1;
    FOFBIN * gb2 = (FOFBIN *)b2;

    /* add entries */	
    gb1->nMembers += gb2->nMembers;
    gb1->fMassInBin += gb2->fMassInBin;	
    gb1->fMassEnclosed += gb2->fMassEnclosed;	
    gb1->v2[0] += gb2->v2[0];
    gb1->v2[1] += gb2->v2[1];
    gb1->v2[2] += gb2->v2[2];
    gb1->L[0]  += gb2->L[0];
    gb1->L[1]  += gb2->L[1];
    gb1->L[2]  += gb2->L[2];
    }

#ifdef RELAXATION 
void AddRelaxation(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf)
    {
    FLOAT  fNorm,ih2,vSigma2,L,fRel,e,pmax,pmin,vMean[3],feps;
    FLOAT beta,gamma,rho;
    int i,j;
    PARTICLE *q;

    beta = 10.0; /* pmax=beta*l, large beta parameter reduces eps dependence  */
    gamma = 0.17; /* gamma scales overall relaxation time */
    feps = 1.0; /* cuttoff for pmin at feps*epsilon or p_90 deg */
	
    for (j=0;j<3;++j) {
	vMean[j] = 0.0;
 	}
    ih2 = 4.0/BALL2(p);
    vSigma2 = 0.0;
    rho = 0.0;
    fNorm = M_1_PI*sqrt(ih2)*ih2;
    for (i=0;i<nSmooth;++i) {
	q = nnList[i].pPart;
	rho += q->fMass;
	for (j=0;j<3;++j) { 
	    vSigma2 += q->v[j]*q->v[j];
	    vMean[j] += q->v[j];
	    } 
	}	
    vSigma2 /= nSmooth;
    rho /= 4.18*pow(p->fBall,3.0);
    for (j=0;j<3;++j) {
	vMean[j] /= nSmooth;
	vSigma2 -= vMean[j]*vMean[j];
   	}
    vSigma2 = 0.33333*vSigma2; /* now its the one dimensional vel.dispersion squared */
    pmin = 2.0*p->fMass/(6.0*vSigma2);  /* pmin in comoving units */
    e = feps*p->fSoft;
    if(pmin < e) pmin = e;  /* pmin is the bigger one of epsilon and p90 */
    pmax = beta*pow(p->fMass/rho, 0.333333); /* pmax=beta*mean interp. separation */
    if(pmax < pmin || vSigma2 < 0) return;   /* no relaxation if pmin > pmax */
    L = pmax/pmin;
    fRel = 0.5*( log(1+L*L) - L*L/(1+L*L) );
    fRel *= p->fMass*rho*pow(vSigma2, -1.5)/gamma;
    p->fRelax += fRel * smf->dDeltaT;	
    }
#endif  /* RELAXATION */

#ifdef SYMBA
  /* mod 062113 */

void initDrmininDrift(void *p)
    {
    }

void combDrmininDrift(void *v1,void *v2) {
 
    PARTICLE *p1 = (PARTICLE *)v1;
    PARTICLE *p2 = (PARTICLE *)v2;
    int k;
    
    if (p2->n_VA > p1->n_VA) {
      p1->drmin2 = p2->drmin2;     
      for(k = p1->n_VA; k < p2->n_VA; k++){
	p1->iOrder_VA[k] = p2->iOrder_VA[k];     
	p1->n_VA++;
      }	
    }
  
    }


void DrmininDrift(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf){
  int i,j,k;
  PARTICLE *q;
  double dDelta = smf->pkd->param.dDelta;
  double fMass1 = p->fMass;
  double piOrder = p->iOrder;
  /*double a1,a2;*/
  double x0,y0,z0,x1,y1,z1,vx0,vy0,vz0,vx1,vy1,vz1;
  double dx0,dy0,dz0,dvx0,dvy0,dvz0,dvx1,dvy1,dvz1;
  double dr0,dr1,dv0,dv1;
  double a,b,c,d;
  double tmin,drmin,hill,rcrit;
  double v2,costh,sincrit2;

  /*double a1b, a2b, hillb;*/
  /*
  **  calculates drmin during drift using third order interpolation      
  ** dr0, dr1: relative distance before and after drift    
  ** dv0, dv1: relative velocity before and after drift 
  */   
  
  if(p->iColor == TEST)return;

  x0 = p->rb[0];
  y0 = p->rb[1];
  z0 = p->rb[2];
  vx0 = p->vb[0];
  vy0 = p->vb[1];
  vz0 = p->vb[2];
  /* x1 = p->r[0];
  y1 = p->r[1];
  z1 = p->r[2];*/
  vx1 = p->v[0];
  vy1 = p->v[1];
  vz1 = p->v[2];

  /*printf("iorder %d, ihill %e\n", p->iOrder, p->hill);*/
  
  for (i=0;i<nSmooth;++i) {
    q = nnList[i].pPart;
    if(piOrder==(q->iOrder)) goto enstep; 		
    
    /* check if particle q is already in the list*/
    if(p->n_VA > 0){
      for(k=0;k<p->n_VA;k++){
	if(p->iOrder_VA[k] == q->iOrder){
	  goto enstep; 	      
	}
      }
    }

    /* check if particle p is already in the list*/
    if(q->n_VA > 0){
      for(k=0;k<q->n_VA;k++){
	if(q->iOrder_VA[k] == p->iOrder){
	  goto enstep; 	      
	}
      }
    }
    
    rcrit = p->rcrit + q->rcrit;  
    dr1 = nnList[i].dx*nnList[i].dx + nnList[i].dy*nnList[i].dy 
      + nnList[i].dz*nnList[i].dz;
   
    if(dr1 > 9.0*RHSCALE2*rcrit*rcrit) continue; 

    hill = p->hill + q->hill; 
    dr1 = sqrt(dr1);

    dx0 = x0 - q->rb[0];
    dy0 = y0 - q->rb[1];
    dz0 = z0 - q->rb[2];
    dr0 = sqrt(dx0*dx0 + dy0*dy0 + dz0*dz0);
  
    dvx0 = vx0 - q->vb[0];
    dvy0 = vy0 - q->vb[1];
    dvz0 = vz0 - q->vb[2];
    dvx1 = vx1 - q->v[0];
    dvy1 = vy1 - q->v[1];
    dvz1 = vz1 - q->v[2];
    
    dv0 = (dvx0*dx0 + dvy0*dy0 + dvz0*dz0)/dr0; 
    dv1 = (dvx1*nnList[i].dx + dvy1*nnList[i].dy + dvz1*nnList[i].dz)/dr1; 


      /* Note if p and q are in different cpus, data for q below 
	 are not stored but abandoned at mdlFinishCache in smooth.c. 
	 This problem is taken cared of in pkdgetPointa. --> (taken care of by comb? not sure)
      */


    if(dr0 < RHSCALE*rcrit){ /* before encounter */
      sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr0*dr0); 
	if(sincrit2 < 1.0){	  
	  v2 = dvx0*dvx0 + dvy0*dvy0 + dvz0*dvz0;
	  costh = -dv0/sqrt(v2); /* cos theta*/
	  if (costh < sqrt(1.0-sincrit2)){	   
	    goto enstep;
	  }
	}
      drmin =  dr0;
      goto encounter;	
    }
    
    if(dr1 < RHSCALE*rcrit){ /* after encounter */
      sincrit2 = FCRIT*hill*hill*RHSCALE2/(dr1*dr1); 
	if(sincrit2 < 1.0){	  
	  v2 = dvx1*dvx1 + dvy1*dvy1 + dvz1*dvz1;
	  costh = dv1/sqrt(v2); /* cos theta*/
	  if (costh < sqrt(1.0-sincrit2)){	   
	    goto enstep;
	  }
	}
      drmin =  dr1;
      goto encounter;	
    }
    
    a = 2.0*(dr0-dr1) + (dv0 + dv1)*dDelta;
    b = 3.0*(dr1-dr0) - (2.0*dv0 + dv1)*dDelta; 
    c = dv0*dDelta;
    d = 4.0*b*b -12.0*a*c; /* d =BB-4AC: A=3a, B=2b C=c */  
    
    if(d < 0.0){ 
      /*printf("iOrder %d, 2, drmin2 %e \n",p->iOrder, p->drmin2);*/
      goto enstep; /* no encounter */
    }else{
      drmin = 100.0;
      tmin = (-4.0*b+sqrt(d))/(6.0*a);
      if((tmin > 0.0) && (tmin < 1.0)) drmin = ((a*tmin + b)*tmin + c)*tmin + dr0;
              
	if(drmin < RHSCALE*hill){
	  goto encounter;
	}else{	
	  goto enstep;
	}
    }      
  encounter:
    p->drmin2 = drmin/rcrit;
    q->drmin2 = drmin/rcrit;
    
    /* mod 042913 */
    if((p->fMass < q->fMass) || (p->fMass == q->fMass && p->iOrgIdx > q->iOrgIdx)){
      p->iOrder_VA[p->n_VA] = q->iOrder;
      p->n_VA++;
    }else{
      q->iOrder_VA[q->n_VA] = p->iOrder;
      q->n_VA++;
    }
    /*
    p->iOrder_VA[p->n_VA] = q->iOrder;
    p->n_VA++;
    q->iOrder_VA[q->n_VA] = p->iOrder;
    q->n_VA++;
    */

    assert(piOrder != q->iOrder);	

  enstep:
    continue;
  }   
}

#ifdef sm2d

void initPBHYBCollStir(void *p){    
}

void combPBHYBCollStir(void *v1,void *v2) {

}

void PBHYBCollStir(PARTICLE *p,int nSmooth,NN *nnList,SMF *smf){
  assert(p->iColor >= SUBEMBRYO);
  int TYPE_PBHYB = smf->TYPE_PBHYB; /* 1 for collision and 2 for stirring 3 for both*/ 
  if(TYPE_PBHYB ==1 && p->iColflag)return; /* particle p has already collided with another particle*/
  int i,j,k;
  PARTICLE *q;
  double dDPBHYB = smf->dDPBHYB; 
  double mt0 = smf->pkd->param.HY.fMt0;
  // double mr = smf->pkd->param.GP.fMp0; /* mass of minimum full embryo divided by m0*/
  double pa = p->ele[0];
  double pes = p->ele[1];
  double pec = p->ele[2];
  double pis = p->ele[3];
  double pic = p->ele[4];
  double pr = p->ele[5];
  double ph = p->ele[7];
  double prad = p->ele[8];
  double ptmass = p->fMass;
  double pnum = p->nump*1.0;
  double pmass = p->fMass/pnum;
  int pid = p->iOrgIdx;
  double dr,area,pe2,pi2,drf,area2; 
  double dSunMass = smf->pkd->dSunMass;
  double dtheta = smf->pkd->param.HY.fdtheta;

  int qid, idel;
  double qtmass,qnum,qmass;
  double qes,qec,qr,qa,qe2,qi2;
  double eij,iij,aij,saij,hij,x,x0,dmdt,RN,dDmi;
  int iself = 0;
  double pvs,qvs,pdf,pb;
  int nn = 0;
  double prb0,prb1,prb2,pvb0,pvb1,pvb2,vr2,pcol;
  prb0 = prb1 = prb2 = pvb0 = pvb1 = pvb2 = 0.0;

  dr = 10.0*pr*smf->pkd->param.HY.fh0; /* the reduced hill radius for m = fMp0*fMp1 (minimum mass of a full embryo) */
  area = 4.0*dtheta*pr*dr; 
  pe2 = pes*pes + pec*pec;
  pi2 = pis*pis + pic*pic;

  /*printf("pid %d, pr %g, pthe %g dr %g, nsmooth %d \n",pid,pr,p->ele[6],dr,nSmooth);*/


  for (i=0;i<nSmooth;++i) {

    q = nnList[i].pPart;
    assert(q != NULL);
    qid = q->iOrgIdx;
   
    if(pid == qid) continue;
    /* particle q has not collided with other bodies */
    if(q->iColflag) continue;

    /* particle q must be a trecer */
    if(q->iColor <= SUBEMBRYO) continue;
    
    /* fist check q is in the area */
    qr = q->ele[5];

    if(nnList[i].dy > dtheta)continue; 

    if(p->iColor == TRACER && fabs(nnList[i].dx) > dr)continue; 
    /* there is no radial limit for neighboring serach of SUBEMBRYO */

    nn ++;

    /* printf("i %d qid %d, qr %g, qthe %g dr %g, dth %g fdist2 %g \n",i, qid,q->ele[5],q->ele[6],nnList[i].dx/dr,nnList[i].dy/dtheta,nnList[i].fDist2);*/
    
    if(TYPE_PBHYB ==0)continue; /* simply count neighboring particles */
  
    /*printf("qid %d, qr %g, qthe %g dr %g, dth %g \n",qid,qr,q->ele[6],nnList[i].dx/dr,nnList[i].dy/dtheta);*/

    qtmass = q->fMass;
    qnum = q->nump*1.0;
    qmass = q->fMass/qnum;
    /* check only less massive bodies */
    /*if(qmass < pmass || (qmass == pmass && qnum < pnum) || (qmass == pmass && (qnum == pnum) && qid > pid)){  */
    if(pnum < qnum || (qnum == pnum && qmass < pmass) || (qmass == pmass && (qnum == pnum) && qid > pid)){

      /*printf("qid %d, qr %g, qthe %g dr %g, dth %g \n",qid,qr,q->ele[6],fabs(pr-qr)/dr,fabs(p->ele[6]-q->ele[6])/(0.1*M_PI));*/
     
      /* relative e and i */
      qes = q->ele[1];
      qec = q->ele[2];
      eij = sqrt((pes-qes)*(pes-qes) + (pec-qec)*(pec-qec));
 
      qe2 = qes*qes + qec*qec; /* qe2 */

      qes = q->ele[3];
      qec = q->ele[4];
      iij = sqrt((pis-qes)*(pis-qes) + (pic-qec)*(pic-qec));    
      qi2 = qes*qes + qec*qec; /* qi2 */
    
      //test
      // eij = sqrt(pe2+qe2);
      // iij = sqrt(pi2+qi2);


      /* mean semimajor axis */
      qa = q->ele[0];
      aij = 0.5*(pa + qa); 
      saij = sqrt(aij*dSunMass); //aij*aij*omega
      /*calculate hij using taylor expansion*/
      x = qmass/pmass;
      hij = ph;
      if(x > 1.0){/* qmass > pmass */
	x = 1.0/x;
	hij = q->ele[7];
      }
      x0 = x; /* mass ratio <= 1.0 */
      if(x0 > 0.333) x = 0.5*(x-1.0);
      x = 1.0 + 1.0/3.0*x*(1.0 - 1.0/3.0*x*(1.0-5.0/9.0*x*(1.0-2.0/3.0*x*(1.0-11.0/15.0*x*(1.0-7.0/9.0*x*(1.0-17.0/21.0*x*(1.0-5.0/6.0*x)))))));
      if(x0 > 0.333) x *= cbr2;
      hij *= x; 
 
      if(iself == 0 && x > 1.0/1.3)iself = 1;

      if(p->iColor == SUBEMBRYO){/* only tracers in the feeding zone are taken into account */
	drf = sqrt(4.0/3.0*(eij*eij+iij*iij) + 12.0*hij*hij)*aij;
	if(drf > dr) drf =dr; // 041414 added
	area = 4.0*dtheta*pr*drf; 
	area2 = 10.0*aij*hij;
	area2 = dtheta*((pa+area2)*(pa+area2)-(pa-area2)*(pa-area2));
	vr2 = ((eij*eij+iij*iij)/(hij*hij)-3.0/4.0*(qa-pa)*(qa-pa)/(aij*aij*hij*hij)+9.0); 
	if (vr2 < 0.0) vr2 = (eij*eij+iij*iij)/(hij*hij);
	vr2 *= sqrt(vr2); 
	/*printf("drf %g \n",drf);*/
      }

      /*reduced e and i */
      eij /= hij; 
      iij /= hij;
     
      /*printf("eij %g iij %g \n",eij,iij);*/
 
      if(TYPE_PBHYB == 1){ /* collision start */
	if(p->iColor == SUBEMBRYO && fabs(qa-pa) > drf)goto endcollision;  /* collisions occur only with tracers in the feeding zone */
	/* rp parameter */
	dmdt = (q->ele[8]+prad)/(aij*hij);

	/* calculate pcoll */
	CalcPcoll(eij,iij,dmdt,&pcol,1);
	//	dmdt = CalcPcoll(eij,iij,dmdt);
	
	/* (dm/dt)j */
	dmdt = pcol*qtmass/area*saij*hij*hij;
	
	/* correction due to self-encounter 
	   !!! this is a temporal value. The appropriate value will be examined later. */
	//	if(iself == 1){ 
	//	  dmdt *= (1.0+(ptmass*ph*ph*cbr2*cbr2)/(qtmass*hij*hij)*(pnum-1.0)/pnum);
	//	  iself = 2;
	//	}
	
	assert(pnum <= qnum);
	/* dDmi */
	idel = 0; /* the interloper is deleted if idel = 1 */
	if(qtmass > 0.1*mt0){
	  dDmi = qmass;
	  if(pnum == qnum){
	    idel = 1;	    
	  }

	  if(qmass < pmass*0.01){
	    dDmi = floor((pmass*0.01)/qmass)*qmass;
	  }

	  if(qtmass-dDmi*pnum < 0.1*mt0){
	    dDmi = qtmass/pnum;
	    idel = 1;	    
	  }

	}else{
	  dDmi = qtmass/pnum;
	  idel = 1;
	}
	
	/* Judge collision */
	RN = (double)drand48(); 
	if(RN < dmdt*dDPBHYB/dDmi){/* collision */
	  p->iColflag = 1;
	  printf("\n");
	  printf("!!! Collision !!!! pid %d %d qid %d %d \n",pid,p->iOrder,qid,q->iOrder);
	  if(idel){
	    q->iColflag = 3;
	  }else{
	    q->iColflag = 2;
	  }
	  
	  p->iOrderCol = q->iOrder;	    
	  p->dtCol = dDmi;
	  
	  break; /* only one collision for one planetesimal in a tracer during dDPBHYB */
	}
      }
      endcollision:
      if(TYPE_PBHYB ==2){ /* stirring start */
	qes = qmass/(qmass+pmass);
	qec = pmass/(qmass+pmass);

	if(p->iColor > SUBEMBRYO ||  (p->iColor == SUBEMBRYO && fabs(qa-pa) < drf)){

	  /* calculate PVS QVS, and PDF (PDF = QDF) */
	  CalcPstir(eij,iij,&pvs,&qvs,&pdf,&pb);
	  /* printf("pvs %g, qvs %g, pdf %g \n",pvs,qvs,pdf);*/
	 
	  qes *= qes;
	  qec *= qec;
	  x = 1.0/area*hij*hij*hij*hij*saij;
	  
	  qes *= x*qnum;
	  qec *= x*pnum; 

	  pdf /= (hij*hij);
	  if(qmass == pmass) pdf = 0.0;
          // pdf = 0.0; /* test purpose */
	  
	  prb0 +=  qes*pvs+qes*(qe2-pe2*pmass/qmass)*pdf; /* p e */
	  prb1 +=  qes*qvs+qes*(qi2-pi2*pmass/qmass)*pdf; /* p i */
	  prb2 +=  (qes*pvs + qes*qvs)*2.0/3.0*aij*aij; /* D for p*/

	  /* viscous stirring only for vb */
	  pvb0 +=  qes*pvs;
	  pvb1 +=  qes*qvs;
	  
	  // test: kick from subembryo is calculated by N-body routine

	  //if(p->iColor == SUBEMBRYO && fabs(qa-pa) < 10.0*aij*hij){
	  //  pvb2 += qtmass/area2/(1.0+vr2/27.0);
	  //}
	  
	  if(p->iColor > SUBEMBRYO){
	    q->rb[0] +=  qec*pvs+qec*(pe2-qe2*qmass/pmass)*pdf; /* q e */
	    q->rb[1] +=  qec*qvs+qec*(pi2-qi2*qmass/pmass)*pdf; /* q i */
	    q->rb[2] +=  (qec*pvs + qec*qvs)*2.0/3.0*aij*aij; 
	    q->vb[0] +=  qec*pvs;
	    q->vb[1] +=  qec*qvs;
	  }
	  	   	 	        
	  //p->rb[0] +=  qes*(-pe2*pmass/qmass)*pdf; /* p e */
	  //p->rb[1] +=  qes*(-pi2*pmass/qmass)*pdf; /* p i */
	  //q->rb[0] +=  qec*(-eij*qmass/pmass)*pdf; /* q e */
	  //q->rb[1] +=  qec*(-iij*qmass/pmass)*pdf; /* q i */
	  //p->vb[0] +=  qes*(eij)*pdf; /* p e */
	  //p->vb[1] +=  qes*(iij)*pdf; /* p i */
	  //q->vb[0] +=  qec*(pe2)*pdf; /* q e */
	  //q->vb[1] +=  qec*(pi2)*pdf; /* q i */
	}

	if(p->iColor == SUBEMBRYO && fabs(qa-pa) > drf){/* distant encounter */
	  x = aij/fabs(qa-pa);
	  hij *= hij;
	  qes *= qes*qnum;
	  qec *= qec;
	  pvs = cd1*hij*hij*hij*x*x*x/dtheta*(saij/(aij*aij)); /* note qes and pvs have diffent dimensions than those above */
	  qvs = cd2*hij*hij*hij*hij*iij*iij*x*x*x*x*x/dtheta*(saij/(aij*aij)); /* Note iij is redueced one */
	  
	  prb0 +=  qes*pvs;
	  prb1 +=  qes*qvs; 
	  prb2 +=  (pvs*qes + qvs*qes)*2.0/3.0*aij*aij;
	  //	  q->rb[0] +=  qec*pvs;
	  //q->rb[1] +=  qec*qvs;
	  //q->rb[2] +=  (qec*pvs + qec*qvs)*2.0/3.0*aij*aij; 
	  
	  pvb0 +=  qes*pvs;
	  pvb1 +=  qes*qvs;
	  //q->vb[0] +=  qec*pvs;
	  //q->vb[1] +=  qec*qvs;
	

	  /* da/dt due to torque (distant encounter) */
	  
	  //	  x = pa*hij/(qa-pa);
	  //		  pvb2 += -(qa-pa)/fabs(qa-pa)*24.0/(sqrt(pa)*dtheta)*hij*hij*qtmass/(ptmass+qtmass)*x*x*x*(x+hij); // factor modified to 24,  01/20/14
	  // if(dr > drf){
	  // pvb2 += qtmass/(area*(dr-drf)/drf)/(1.0+(eij*eij+iij*iij)*sqrt(eij*eij+iij*iij)/27.0);
	  //}
	  //	if(p->iColor == SUBEMBRYO && fabs(qa-pa) < 10.0*aij*hij){
	  // pvb2 += qtmass/area2;
	    ///(1.0+(eij*eij+iij*iij)*sqrt(eij*eij+iij*iij)/27.0);
	}

	if(p->iColor == SUBEMBRYO && fabs(qa-pa) < 10.0*aij*hij){
	  //pvb2 += qtmass/area2/(1.0+vr2/27.0);
	  pvb2 += qtmass/area2/(1.0+vr2/100.0);
	}

      }/* end TYPE_PBHYB ==2 */

	/* printf("pvs_p %g, qvs_p %g, D_p %g, pvs_q %g, qvs_q%g, D_q %g \n",p->rb[0],p->rb[1],p->rb[2],q->rb[0],q->rb[1],q->rb[2]);*/

    }
  } /* end of do loop */
  
  if(TYPE_PBHYB ==0){
    p->vb[1] = p->vb[0]; /* copy previous nn*/ 
    p->vb[0] =  nn;
    // printf("pid %d,nn %d \n",pid,nn);
  }

  if(TYPE_PBHYB ==2){ 

    //    if(p->iColor > SUBEMBRYO && iself){
    //  hij = ph*cbr2;
    //  eij = sqrt(2.0*pe2)/hij;
    //  iij = sqrt(2.0*pi2)/hij;
      // area = 4.0*M_PI*pr*dr; 
    //  x = 0.25/area*hij*hij*hij*hij*sqrt(pa)*(pnum-1.0); /*0.25 for equal mass */
      
    //  CalcPstir(eij,iij,&pvs,&qvs,&pdf);
    //  prb0 +=  x*pvs; /* de^2/dt for p*/
    //  prb1 +=  x*qvs;
    //  pvb0 +=  x*pvs; /* de^2/dt for p*/
    //  pvb1 +=  x*qvs;
    // }

    p->rb[0] += prb0;
    p->rb[1] += prb1;
    p->rb[2] += prb2;
    p->vb[0] += pvb0;
    p->vb[1] += pvb1;
    p->vb[2] += pvb2;
  }
  
}
  
void CalcPstir(double eij,double iij, double *ppvs, double *qqvs, double *ppdf, double *ppb){
  assert(fabs(eij) >= 0);
  assert(fabs(iij) >= 0);
  
  if(eij < 1.e-6)eij = 1.e-6;
  if(iij < 1.e-6)iij = 1.e-6;


  double e2 = eij*eij;
  double i2 = iij*iij;
  double k2 = 3.0/4.0/(1.0+i2/e2);
  double kk, ek, gam, lgam; 
  double c1,c2,c3;
  double pvs,qvs,pdf,pb;
  double csmall = 1.e-20;
  

  gam = iij*(e2+i2)/3.0;
  gam *= gam; 
  if(gam < csmall)gam = csmall;
  lgam = log(gam+1.0);

  // double cvs = (12.-2.5*exp(-i2/9.0))/12.0;
  // kk = rf(0.0,1.0-k2,1.0); /* first kind of elliptical integral K(k)*/
  // ek = kk-k2*rd(0.0,1.0-k2,1.0)/3.0; /* second kind E(k)*/

  calc_ellip(k2,&kk,&ek);

  c1 = 36.0/(M_PI*iij*sqrt(e2+i2));
  c2 = lgam;
  //-gam/(gam+1.0);

  //c2 = c2*1.3; //test

  //pvs = c1*c2*(5.0*kk-12.0*e2/(e2+4.0*i2)*ek);

  // double cvs;
  //cvs = (12.-2.5*exp(-i2/9.0))/12.0;
 
  pvs = c1*c2*(5.0*kk-12.0*e2/(e2+4.0*i2)*ek);
  qvs = c1*c2*(kk-12.0*i2/(e2+4.0*i2)*ek);
  pdf = c1*8.0/(e2+4.0*i2)*ek*lgam;  
  pb = -c1*c2*2.0/(eij*(1.0+4.0*i2/e2));


 
  c1 = lgam/gam;
  if(c1 < csmall)c1 = csmall;

  c2 = 10.0*gam*eij;
  if(c2 < csmall)c2 = csmall;
  c2 = log(c2+1.0)/(c2);

  c3 = 10.0*gam;
  if(c3 < csmall)c3 = csmall;
  c3 = log(c3+1.0)/(c3);

  if(c1 > 0){
    *ppvs = pvs + c1*75.4;
    *ppb = pb -c1*9.4;
  }else{    
    *ppvs = 75.4;
    *ppb = -9.4;
    /*printf("c1, %g eij %g,iij %g,k2 %g, kk %g,ek %g, pvs %g, qvs %g, pdf %g\n",c1,eij,iij,k2,kk,ek,pvs,qvs,pdf);*/
  }

  // *ppb = pb;
  if(*ppb < -9.4)*ppb = -9.4;

  if(c2>0){
    *qqvs = qvs + c2*(2.0*i2 + 5.0*e2*eij*i2);
  }else{
    *qqvs = (2.0*i2 + 5.0*e2*eij*i2);
  }
  if(c3>0){
    *ppdf = pdf + c3*10.0;
  }else{
    *ppdf = 10.0;
  }

  // very large eij and very small iij lead very large |pvs| and |qvs|
  // we set upper limits (let's use 300 for now) to them to avoid artificial jump in e and i
  if(fabs(*ppvs) > 300.0) *ppvs = 300.*(*ppvs)/fabs(*ppvs);
  if(fabs(*qqvs) > 300.0) *qqvs = 300.*(*qqvs)/fabs(*qqvs);
  if(fabs(*ppdf) > 300.0) *ppdf = 300.*(*ppdf)/fabs(*ppdf);


  //  if(*ppvs > 1000.0 || *qqvs > 1000.0 || *ppdf > 1000.0){
  //  printf("eij %g iij %g *ppvs %g,*qqvs %g, *ppdf %g c3 %g pdf %g, lgam %g\n",eij,iij,*ppvs,*qqvs,*ppdf,c3,pdf,lgam);
  //  assert(0);
  // }
    //assert(*ppvs < 100.0 && *qqvs < 100.0 && *ppdf < 100.0);

  //if(iij  < 1.0){
  //if(*ppvs < 20.0 || *ppdf < 0){
  // printf("eij %g,iij %g,k2 %g, kk %g,ek %g, pvs %g %g, qvs %g %g, pdf %g %g, pb %g %g\n",eij,iij,k2,kk,ek,pvs,*ppvs,qvs,*qqvs,pdf,*ppdf,pb,*ppb);
  // }
  //}
}


void CalcPcoll(double eij, double iij, double rp, double *ppcol, int TRGRAV){
  double ci = iij/eij;
  double k2 = 3.0/4.0/(1.0+ci*ci);
  double kk, ek, pch,pcm,pcl; 

  calc_ellip(k2,&kk,&ek);
 
  pcm = sqrt(1.0+ci*ci);
  ek *= (pcm/ci); /* FI/4 */
  kk /= (pcm*ci); /* GI/4 */
  ek *= rp*rp;
  kk *= 6.0*rp/(eij*eij); 

  pch = (ek + kk)*2.0/M_PI; /* pcoll_high  factor 2/pi added 031714 */
  pch *= pch;    /* pcoll_high^2 */ 
  pcl = 11.3*11.3*rp; /* pcoll_low^2 */
  // pcm = 137.0/(4.0*M_PI*eij*rp); /* pcoll_mid  mistakes */
  pcm = 147.0*rp/(4.0*M_PI*iij); /* pcoll_mid  corrected  032014  */

  pch = 1.0/sqrt(1.0/pch + 1.0/pcl);
  if(pcm < pch)pch = pcm;

  *ppcol = pch;
  
   if(TRGRAV==0)*ppcol =  (ek)*2.0/M_PI;; // no-gravity test
  // return(pch);

}


void calc_ellip(double k2, double *pkk, double *pek){
  /* calculate Complete Ellipitcal integrals, Kk and Ek, using the table 
   The returned values agree with the exact values with the precision of ~1.e-5 */

  double kkt[100] = {1.570796e+00,1.574746e+00,1.578740e+00,1.582780e+00,1.586868e+00,1.591003e+00,1.595188e+00,1.599423e+00,1.603710e+00,1.608049e+00,
		    1.612441e+00,1.616889e+00,1.621393e+00,1.625955e+00,1.630576e+00,1.635257e+00,1.640000e+00,1.644806e+00,1.649678e+00,1.654617e+00,
		    1.659624e+00,1.664701e+00,1.669850e+00,1.675073e+00,1.680373e+00,1.685750e+00,1.691208e+00,1.696749e+00,1.702374e+00,1.708087e+00,
		    1.713889e+00,1.719785e+00,1.725776e+00,1.731865e+00,1.738055e+00,1.744351e+00,1.750754e+00,1.757269e+00,1.763898e+00,1.770647e+00,
		    1.777519e+00,1.784519e+00,1.791650e+00,1.798918e+00,1.806328e+00,1.813884e+00,1.821593e+00,1.829460e+00,1.837491e+00,1.845694e+00,
		    1.854075e+00,1.862641e+00,1.871400e+00,1.880361e+00,1.889533e+00,1.898925e+00,1.908547e+00,1.918410e+00,1.928526e+00,1.938908e+00,
		    1.949568e+00,1.960521e+00,1.971783e+00,1.983371e+00,1.995303e+00,2.007598e+00,2.020279e+00,2.033369e+00,2.046894e+00,2.060882e+00,
		    2.075363e+00,2.090373e+00,2.105948e+00,2.122132e+00,2.138970e+00,2.156516e+00,2.174827e+00,2.193971e+00,2.214022e+00,2.235068e+00,
		    2.257205e+00,2.280549e+00,2.305232e+00,2.331409e+00,2.359264e+00,2.389016e+00,2.420933e+00,2.455338e+00,2.492635e+00,2.533335e+00,
		    2.578092e+00,2.627773e+00,2.683551e+00,2.747073e+00,2.820752e+00,2.908337e+00,3.016112e+00,3.155875e+00,3.354141e+00,3.695637e+00};
  double ekt[100] = {1.570796e+00,1.566862e+00,1.562913e+00,1.558948e+00,1.554969e+00,1.550973e+00,1.546962e+00,1.542936e+00,1.538893e+00,1.534833e+00,
		    1.530758e+00,1.526665e+00,1.522555e+00,1.518428e+00,1.514284e+00,1.510122e+00,1.505942e+00,1.501743e+00,1.497526e+00,1.493290e+00,
		    1.489035e+00,1.484761e+00,1.480466e+00,1.476152e+00,1.471818e+00,1.467462e+00,1.463086e+00,1.458688e+00,1.454269e+00,1.449827e+00,
		    1.445363e+00,1.440876e+00,1.436366e+00,1.431832e+00,1.427274e+00,1.422691e+00,1.418083e+00,1.413450e+00,1.408791e+00,1.404105e+00,
		    1.399392e+00,1.394652e+00,1.389883e+00,1.385086e+00,1.380259e+00,1.375402e+00,1.370515e+00,1.365596e+00,1.360645e+00,1.355661e+00,
		    1.350644e+00,1.345592e+00,1.340505e+00,1.335382e+00,1.330222e+00,1.325024e+00,1.319788e+00,1.314511e+00,1.309192e+00,1.303832e+00,
		    1.298428e+00,1.292979e+00,1.287484e+00,1.281942e+00,1.276350e+00,1.270707e+00,1.265013e+00,1.259263e+00,1.253458e+00,1.247595e+00,
		    1.241671e+00,1.235684e+00,1.229632e+00,1.223512e+00,1.217321e+00,1.211056e+00,1.204714e+00,1.198290e+00,1.191781e+00,1.185183e+00,
		    1.178490e+00,1.171697e+00,1.164798e+00,1.157787e+00,1.150656e+00,1.143396e+00,1.135998e+00,1.128451e+00,1.120742e+00,1.112856e+00,
		    1.104775e+00,1.096478e+00,1.087938e+00,1.079121e+00,1.069986e+00,1.060474e+00,1.050502e+00,1.039947e+00,1.028595e+00,1.015994e+00};

  int i;
  double mod;

  i = k2/0.01;
  assert(i<100);
  mod = k2/0.01-i*1.0;
 
  if(i<99){
    *pkk = kkt[i]*(1.0-mod) + kkt[i+1]*mod; 
    *pek = ekt[i]*(1.0-mod) + ekt[i+1]*mod; 
  }else{
    *pkk = kkt[99];
    *pek = ekt[99]; 
  }
}



#endif /* sm2d */

#endif /* symba */
