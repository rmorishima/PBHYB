#ifndef PARAMETERS_HINCLUDED
#define PARAMETERS_HINCLUDED

#include "cosmo.h"
#include <inttypes.h>

#ifdef PLANETS
typedef struct {
	int iOutcomes;
	double dDensity;
	double dBounceLimit;
	int iBounceOption;
	double dEpsN;
	double dEpsT;
        int bFixCollapse;	
	} COLLISION_PARAMS;

#ifdef gaptable
typedef struct{
  double r[1746];
  double rsig[1746];
  double p[1746];
} GAP_TABLE;
#endif

typedef struct{
  int iGasModel;     
  double dTau_diss;      
  double dGasp;     
  double dSigma10;      
  double dGasq;
  double dTemp1;
  double dalpha;   
  double dS0;   
  double dMd0; 
  int bWind;    /* rapid dispersion in the late stage ? */
  double t_trans;   /* rapid dispersion starting time */
  double s_trans;     /* s when t = t_trans  */
  int bDragEnhance;
  int iTypeI;        /* TypeI migration 0: non; 1: isothermal, 2: adiabatic, 3: Lyra (2010) model*/
  double fTI;
  double rcon;
  int iGasTable;      /*Table for gobal potential? */
  double dkappa; /* atmospheric opacity */
  double jd;          /* following params are used in Stepinski's disk model */ 
  double sij[4];
  double ti[5];
  double tij[4];
  double f;
  int inepo;
  int npgap; // number of gap opening planets, not parallelized
  double apgap[20];
  double k1[20];  // k  parameter from Kanagawa et al. 2016
  double k2[20];  // k' parameter
} GASDISK_PARAMS;

typedef struct{
  double fMt0;   // minimum mass of a subembryo       
  double fff;    // factor for full embryo;  default is 100
  double ffdr;   // factor for radial grid width (fff^-1/3< ffdr <=1)
  double fdtheta; // azimuthal grid size in pi (<=1)
  int    iTRGRAV; // switch for mutual gravity effects between tracers // use 2 for pebble accretion of tracers
  double fh0;     // h for mt0
  double fh1;     // h for mt0*fff
  double fDt;     // time step for the statistical routine in units of orbital integration >= 1
  int    iPebbleSupply; //pebble supply from outer boundary? use bBodySupply = 6 and daout
  double dM_peb;    // total mass of pebble
  double dTau_peb; // pebble decay time (calculated in master.c)
  double dMr_peb;  // mass of produced pebble tracer (calculated in master.c)
  double dSt_min;  // minimum stokes number; we force the pebble size to increase if St < dSt_min
  int iPbGrow;
  int iPlForm;
  int iGasAcc2Planet;
  double dapin;
  double dzmet;
  double dcpl;
  double dtau_em;
  double dmpl;
  double ded;
}HYBRID_PARAMS;

typedef struct { /* time-dependent quantities */
  double rout;
  double rij[4];
  double fSigma[5];
  double fTemp[5];
} STEPINSKI; 

#ifdef gastable
typedef struct {
  double dTime;
  double ar[150][51];
  double az[150][51];
  double zz[150][51];
  double Sigma[150];
  double h[150];
  double rr[150];  
} GASDISK_TABLE;
#endif

#endif

/*
** Don't even think about putting a pointer in here!!
*/
struct parameters {
    /*
    ** Parameters for PKDGRAV.
    */
    int nThreads;
    int bDiag;
    int bOverwrite;
    int bVWarnings;
    int bVStart;
    int bVStep;
    int bVRungStat;
    int bVDetails;
    int bPeriodic;
    int bParaRead;
    int bParaWrite;
    int bCannonical;
    int bStandard;
    int bHDF5;
    int bDoublePos;
    int bGravStep;
    int bEpsAccStep;
    int bSqrtPhiStep;
    int bAccelStep; /* true if bEpsAccStep or bSqrtPhiStep */
    int bDensityStep;
    int iTimeStepCrit;
    int nPartRhoLoc;
    int nPartColl;
    int nTruncateRung;
    int bDoDensity;
    int bDodtOutput;
    int bDoRungOutput;
    int bDoGravity;
#ifdef HERMITE
    int bHermite;
    int bAarsethStep;
#endif
    int bAntiGrav;
    int nBucket;
    int iOutInterval;
    int iCheckInterval;
    int iLogInterval;
    int iOrder;
    int bEwald;
    int bEwaldKicking;
    int iEwOrder;
    int nReplicas;
    uint64_t iStartStep;
    uint64_t nSteps;
    int nSmooth;
    int iMaxRung;
    int nRungVeryActive;
    int nPartVeryActive;
    int nGrowMass;
    int iWallRunTime;
    int bPhysicalSoft;  
    int bSoftMaxMul;
    int bVariableSoft;
    int nSoftNbr;
    int bSoftByType;
    int bDoSoftOutput;
    double dEta;
    double dExtraStore;
    double dSoft;
    double dSoftMax;
    double dDelta;
    double dEwCut;
    double dEwhCut;
    double dTheta;
    double dTheta2;
    double daSwitchTheta;
    double dPeriod;
    double dxPeriod;
    double dyPeriod;
    double dzPeriod;
    double dPreFacRhoLoc;
    CSM csm;
    double dRedTo;
    double dCentMass;
    char achDigitMask[256];
    char achInFile[256];
    char achOutName[256];
    char achOutPath[256];
    char achDataSubPath[256];
    char achOutTypes[256];
    char achCheckTypes[256];
    double dGrowDeltaM;
    double dGrowStartT;
    double dGrowEndT;
    double dFracNoTreeSqueeze;
    double dFracNoDomainDecomp;
    double dFracNoDomainDimChoice;
    int    bRungDD;
    double dRungDDWeight;
    /*
    ** Additional parameters for group finding.
    */
    int	nFindGroups;	
    int	nMinMembers;	
    double dTau;
    int bTauAbs;
    int	nBins;	
    int	bUsePotmin;	
    int	nMinProfile;	
    double fBinsRescale;
    double fContrast;
    double Delta;
    double binFactor;
    int bLogBins; 
#ifdef RELAXATION
    int	bTraceRelaxation;	
#endif
#ifdef PLANETS	
  int bHeliocentric;
  int bCollision;
  int iCollLogOption;
  char achCollLog[256];
  char achCollLog2[256];
  COLLISION_PARAMS CP;
  GASDISK_PARAMS GP;
  HYBRID_PARAMS HY;
  int iGravDirect;
  int bBodySupply;
  double dain;
  double daout;
  double dRSunc;
#ifdef SYMBA
  int bSymba;
  int N0;
#endif
#endif /* PLANETS */
    };

#endif
