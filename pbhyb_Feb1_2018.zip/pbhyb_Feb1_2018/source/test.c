#include <stdio.h>
#include <limits.h>

int main() {
  double aa,bb,aa0;
  
  int i;
  aa = 5.0;

  printf("%f,%f \n",aa,aa*bb);
  //  for (i=0;i<100;++i) {
  // aa /= 2.0;
  // bb *= 2.0;
   
  bb = ((int)aa)/2;
  bb *= 1.0; 
  aa -= bb;
 
  /* if (aa < INT_MAX){
      aa0 = aa;
      aa = ((int)aa)*1.0;
      bb *= aa0/aa;
      }*/

    printf("%f,%f, %f \n",aa,aa*bb,bb);
    //}

  // printf("%f %ld %f\n", aa,cc,bb);
  printf("%d %ld \n", INT_MAX, LONG_MAX);
  return 0;
}
