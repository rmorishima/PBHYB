#include <math.h>
#include <assert.h>
#include "constants.h"
#include "helio.h"
#include "delaunay.h"

void heltodel(double mu,struct helio *h,struct delaunay *d);
void deltohel(double mu,struct delaunay *d,struct helio *h);
