#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
/*#include <float.h>
#include <limits.h>
#include <inttypes.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>*/
#include <rpc/types.h>
#include <rpc/xdr.h>
#include "../analysis/ssio.h"

#ifndef SINGLE

#define FLOAT			double
#define FLOAT_MAXVAL	HUGE

#else

#define FLOAT			float
#define FLOAT_MAXVAL	HUGE

#endif

#define MISS	0
#define MERGE	1
#define BOUNCE	2
#define FRAG	4
#define ESCAPE	8
#define SUNCOLLIDE	16


#define ME 3.00374E-6

void readcoll(int idm, int *pidm0, double *pt0, double t1, int first);


//typedef struct {
//  int iPid;
//  int iOrder;
//  int iIndex;
//  int iOrgIdx;
//} PARTICLE_ID;

typedef struct {
  //  PARTICLE_ID id;
  FLOAT fMass;
  FLOAT fRadius;
  FLOAT r[3];
  FLOAT v[3];
  FLOAT w[3];
#ifdef HERMITE
  FLOAT a[3];
  FLOAT ad[3];
#endif
#ifdef SYMBA
  FLOAT drmin;
  int   iOrder_VA[30]; /* iOrder's of particles within 3 hill radius*/
  int   i_VA[30];    /* pointers of particles */
  int   n_VA;       /* number of particles */
  double  hill;       /* hill radius */ 
#endif
  int iColor;
  int iOrgIdx;
  double nump;
  FLOAT dt;
  int iRung;
} COLLIDERL;

void
CollisionDataPBHYB(XDR *xdrs, COLLIDERL *c1){
   int i;

  (void) xdr_int(xdrs,&c1->iColor);
  (void) xdr_int(xdrs,&c1->iOrgIdx);			
  (void) xdr_double(xdrs,&c1->fMass);
  (void) xdr_double(xdrs,&c1->fRadius);
  (void) xdr_double(xdrs,&c1->nump);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c1->r[i]);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c1->v[i]);
  
}


int main(int argc, char *argv[])
{

  double t1,t0;
  int idm = 15279; // id of the particle for which you want a collision log 
  int idm0,first,rr;
  
  idm0 = idm;
  t1 = 1.e30;

  do{
    rr = 0;
    first = 1;
    readcoll(idm,&idm0,&t0,t1,first);
    printf("//// \n");
    printf("idm %d,idm0 %d, t0 %g, t1 %g \n",idm,idm0,t0/(2.0*M_PI),t1/(2.0*M_PI));
    printf("//// \n");
    if(idm ==idm0)t0 = 0.0;
    first = 0;
    readcoll(idm,&idm0,&t0,t1,first);
    if(idm0<idm){
      idm = idm0;
      t1 = t0;
      rr = 1;
    }
  }while(rr==1);
  
  
  // printf("idm %d,idm0 %d, t0 %g, t1 %g \n",idm,idm0,t0/(2.0*M_PI),t1/(2.0*M_PI));

}

void readcoll(int idm, int *pidm0, double *pt0, double t1, int first)
{
  FILE *fp;
  XDR xdrs;
  int cmax = 100;
  COLLIDERL c1in[cmax],c2in[cmax];
  COLLIDERL c1out[cmax],c2out[cmax];
  COLLIDERL *c1,*c2;
  double r,v2,summ,Etot,a1;
  
  double dTime,nd[cmax];
  int n,n2,nsp,nin,nout,iorg1,iorg2;
  long nl = 0;
  FILE *fpb;

  fp = fopen("ss.coll_PBHYB.bin","r");
  if(fp == NULL) return;   
  xdrstdio_create(&xdrs,fp,XDR_DECODE);

  if(first == 0){
    fpb = fopen("pbhyb_coll.dat","w");
    if(fpb == NULL) return;  
  }
  
  do{
    if (!xdr_int(&xdrs,&nsp)) { //nsp; number of splitting particles, usually 1 except in tracersplit in pkd.c
      xdr_destroy(&xdrs);
      (void) fclose(fp);
      return;
    }
    nl ++;
 
    for(n=0;n<nsp;++n){
      (void)xdr_double(&xdrs,&dTime);
      (void) xdr_int(&xdrs,&nin);
      (void) xdr_int(&xdrs,&nout);   
      (void) xdr_double(&xdrs,&(nd[n]));

      assert(nin <=2);
      assert(nout <=2);
	
      CollisionDataPBHYB(&xdrs,&(c1in[n]));
      if(nin ==2) CollisionDataPBHYB(&xdrs,&(c2in[n]));
      CollisionDataPBHYB(&xdrs,&(c1out[n]));
      if(nout ==2) CollisionDataPBHYB(&xdrs,&(c2out[n]));
      //  printf("aaa n %d c1in %d c1out %d \n",n,c1in[n].iOrgIdx,c1out[n].iOrgIdx);
    }
   
    if(nin == 1 && nout ==2){
	//     printf("nin %d nout %d \n",nin,nout);  (void) xdr_int(&xdrs,&iorg2);
	//  (void) xdr_int(&xdrs,&iorg1);
	for(n=0;n<nsp;++n){
	  (void) xdr_int(&xdrs,&iorg2);
	  (void) xdr_int(&xdrs,&iorg1);
	  
	  //assert(iorg1 >=0 && iorg2 >= 0);
	  if(first == 1 && dTime <= t1 && (iorg1 == idm || iorg2 == idm)){	    
	    if(iorg1 < idm) {
	      // this part identifies spiltting immediately after merging and assinment of the same id to split particle as the collider id
	      *pidm0 = iorg1;
	      *pt0 = dTime;
	       printf("t = %.4e iorg1 %d iorg2 %d \n",dTime/(2.0*M_PI),iorg1,iorg2);
	    }
	  }
	  
	  for(n2=0;n2<nsp;++n2){
	    //printf("n2 %d, c1out %d \n",n2,c1out[n2].iOrgIdx);
	    if(c1out[n2].iOrgIdx == iorg1){
	      c2out[n2].iOrgIdx = iorg2;
	      break;
	    }
	  }
	  assert(c2out[n2].iOrgIdx >=0); /* fail to find c2out[n].iOrgIdx */	  	 
	}
      }
          
    for(n=0;n<nsp;++n){

     
      if(c2in[n].iOrgIdx == idm && c1in[n].iOrgIdx < idm && dTime > *pt0 && dTime <= t1){
	*pidm0 = c1in[n].iOrgIdx;
	*pt0 = dTime;
	printf("t = %.4e iorg1 %d \n",dTime/(2.0*M_PI),*pidm0);
      }

      if(first ==0 && c1in[n].iOrgIdx == idm && dTime >= *pt0 && dTime <= t1 && nd[n] > 0){
	c1 = &(c1in[n]);
	c2 = &(c2in[n]);

	r = sqrt(c1->r[0]*c1->r[0]+c1->r[1]*c1->r[1]+c1->r[2]*c1->r[2]);
	v2 = c1->v[0]*c1->v[0]+c1->v[1]*c1->v[1]+c1->v[2]*c1->v[2];
	summ = 1.0+c1->fMass/c1->nump;
	Etot = 0.5*v2 - summ/r;
	a1 = -0.5/Etot;
	
	printf("%.4e, %d %d %.4e %.4e %.4e %.4e \n",dTime/(2.0*M_PI),c1in[n].iOrgIdx,c2in[n].iOrgIdx,c1in[n].fMass/c1in[n].nump,a1,c2in[n].fMass/c2in[n].nump,nd[n]);
      } 
      // if(c1in[n].iOrgIdx == idm || c2in[n].iOrgIdx == idm){
	    
	    // fprintf(fpb,"%.4e, %d %d %.4e %.4e %4.e \n",dTime/(2.0*M_PI),c1in[n].iOrgIdx,c2in[n].iOrgIdx,c1in[n].fMass/c1in[n].nump,c2in[n].fMass/c2in[n].nump,nd[n]);
      //}   
    }
    

    

  }while(1);     
}
