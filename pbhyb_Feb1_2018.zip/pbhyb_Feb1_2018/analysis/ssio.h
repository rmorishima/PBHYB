#ifndef SSIO_HINCLUDED
#define SSIO_HINCLUDED

/*
 ** ssio.h -- DCR 98-09-16
 ** ======
 ** Header file specific to Solar System data I/O routines.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>	/* for MAXPATHLEN */
#include <rpc/rpc.h>	/* for XDR routines */
//#include <stdint.h>

#ifndef MAXPATHLEN
#define MAXPATHLEN 256
#endif

#ifndef N_DIM
#define N_DIM 3
#endif

/*
 ** Following structures intended for use with xdr I/O routines. Note that
 ** internal representations may differ from format written to disk. As a
 ** result, for now use hardwired sizes for seeking. Is there an xdr routine
 ** to figure this out automatically?...
 */

typedef struct ss_head {
	double	time;
        int             n_data;   
        double          dEcoll; /* kinetic energy change due to collisions */
        double          dEgas; /* kinetic energy change due to gas */
        double          dEstir; /* kinetic energy change due to stirring (used for PBHYB)*/
        double          dSunMass; /*Sun's mass*/   
	} SSHEAD;

#define SSHEAD_SIZE 44	/* XDR assumes 8-byte doubles and 4-byte ints */

typedef struct ss_data {
        double	mass; /* mass of tracer for color = TRACER*/
	double	radius;
	double	pos[N_DIM];
	double	vel[N_DIM];
	double	spin[N_DIM];
        double  dls;
        double  gasmass;
        double  tcheck; // planetesimal formation time or gas accretion starting time
	int		color;
	int		org_idx;
        double       nump;
	} SSDATA;

#define SSDATA_SIZE 128	/* XDR assumes 8-byte doubles, 4-byte ints and 8-byte uint64_t*/

typedef struct ssio {
	FILE *fp;
	XDR xdrs;
	} SSIO;

#define SSIO_READ	0
#define SSIO_WRITE	1
#define SSIO_UPDATE	2

#define SS_EXT ".ss"

int ssioNewExt(const char *infile, const char *inext,
			   char *outfile, const char *outext);
int ssioOpen(const char *filename, SSIO *ssio, u_int mode);
int ssioHead(SSIO *ssio, SSHEAD *head);
int ssioData(SSIO *ssio, SSDATA *data);
int ssioClose(SSIO *ssio);
int ssioSetPos(SSIO *ssio, u_int pos);
void ssioRewind(SSIO *ssio);


/* Object color identifiers */
#define SUN			1	/* Yellow */
#define GIANT			2	/* Red */
#define PLANETESIMAL         	3	/* Green */
#define TEST			9	/* Blue (test particle) */
#define PEBBLE                  7
#define TRACER                  6
#define SUBEMBRYO               5

//#define mpebble (1.e4/M_SUN) /* 1.e7 g */
#define mpe0 (1.e-8/M_SUN) /* 1.e-5 g ; or 0.1 mm*/

/*#define RESERVED_COLOR(c) ((c) == SUN || (c) == JUPITER)*/

/* Filename for list of particles with rejected initial positions */

#define REJECTS_FILE "rejects.out"

#endif

