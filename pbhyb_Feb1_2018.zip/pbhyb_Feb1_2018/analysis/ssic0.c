/*
 ** ssic.c -- DCR 97-08-06
 ** ======
 ** Generates Solar System initial conditions.
 */

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>		/* for getpid(), and getopt() if needed */
#include <sys/types.h>	/* ditto (for IRIX) */
#include <stdint.h>

#include "rdpar.h"
#include "vector.h"
#include "delaunay.h"
#include "helio.h"
#include "boolean.h"
#include "ss.h"
#include "ssio.h"

#ifdef sparc
#ifdef sun
#undef sun /* sheesh */
#endif
#endif



/*#define TILT_RING*/ /*DEBUG used to tilt a portion of the disk at the start*/

#ifdef TILT_RING
#define TILT_R 1.275
#define TILT_DR 0.025
#define TILT_I 0.0125
#endif

/* Definitions */

#define RAYLEIGH 0
#define GAUSSIAN 1

typedef struct {

  /* Following data read in from parameter file... */
  
  double central_mass;
  BOOLEAN heliocentric;
  
  int n,dst_fnc,nice_model, p_color;
  double total_mass,density,radius,scaling,r_inner,r_outer,surf_den_exp,size_exp,mass_ratio;
  double ecc_dsp,inc_dsp,ecc_max,inc_max;
  
  BOOLEAN tilt;
  char planet_data[MAXPATHLEN];
  
  double time;
  BOOLEAN adjust_com;
  char output_file[MAXPATHLEN];
  
  /* Following derived from supplied parameters... */
  
  int n_data, n_planets;
  double nump;
  double mass,red_hill,esc_vel, m0;
  
} PARAMS;

static double ran(int),raydev(void),gasdev(void);

static void
output_data(PARAMS *p,SSDATA *data)
{
	SSIO ssio;
	SSHEAD head;
	int i;

	if (ssioOpen(p->output_file,&ssio,SSIO_WRITE)) {
		(void) fprintf(stderr,"Unable to open \"%s\"\n",p->output_file);
		exit(1);
		}

	head.time = p->time;
	head.n_data = p->n_data;
	/*head.n_planets = p->n_planets;*/
	head.dEcoll = 0.0;
	head.dEgas = 0.0;
	head.dEstir = 0.0;
	head.dSunMass = p->central_mass;

	(void) ssioHead(&ssio,&head);

	for (i=0;i<p->n_data;i++) {
		data[i].org_idx = i; /* easiest time to store this */
		(void) ssioData(&ssio,&data[i]);
		}

	(void) ssioClose(&ssio);

	}

static void
add_mom(SSDATA *data,VECTOR mom_pos,VECTOR mom_vel)
{
	VECTOR v;

	COPY_VEC(data->pos,v);
	SCALE_VEC(v,data->mass);
	ADD_VEC(mom_pos,v,mom_pos);
	COPY_VEC(data->vel,v);
	SCALE_VEC(v,data->mass);
	ADD_VEC(mom_vel,v,mom_vel);
	}

static void
get_com(SSDATA *data,int n,VECTOR com_pos,VECTOR com_vel,double *mass)
{
	int i;

	ZERO_VEC(com_pos);
	ZERO_VEC(com_vel);

	*mass = 0;

	for (i=0;i<n;i++) {
		add_mom(&data[i],com_pos,com_vel);
		*mass += data[i].mass;
		}

	NORM_VEC(com_pos,*mass);
	NORM_VEC(com_vel,*mass);
	}

static void
sub_com(SSDATA *data,int n,VECTOR com_pos,VECTOR com_vel)
{
	int i;

	for (i=0;i<n;i++) {
		SUB_VEC(data[i].pos,com_pos,data[i].pos);
		SUB_VEC(data[i].vel,com_vel,data[i].vel);
		}
	}

static void
calc_ang_mom(SSDATA *data, int n, VECTOR ang_mom)
{
	VECTOR v;
	int i;

	ZERO_VEC(ang_mom);

	for (i=0;i<n;i++) {
		CROSS(data[i].pos,data[i].vel,v);
		SCALE_VEC(v,data[i].mass);
		ADD_VEC(ang_mom,v,ang_mom);
		}
	}

static void
tilt(PARAMS *p,SSDATA *data)
{
	SSDATA *ptr;
	MATRIX r,r0;
	VECTOR zp,z,x,u;
	double cth,sth;
	int i;

	calc_ang_mom(data,p->n_planets,zp);
	NORM_VEC(zp,MAG(zp));
	SET_VEC(z,0,0,1);

	(void) printf("Inclination of invariable plane to ecliptic = %f deg\n",
				  acos(zp[Z])*(double)RAD_TO_DEG);

	/* Construct rotation matrix */
				  
	CROSS(z,zp,x);
	COPY_VEC(x,u);
	NORM_VEC(u,MAG(u));

	cth = DOT(z,zp);
	sth = MAG(x);

	UNIT_MAT(r);
	SCALE_MAT(r,cth);

	VecToMat(u,u,r0);
	SCALE_MAT(r0,(1 - cth));

	ADD_MAT(r,r0,r);

	SKEW_SYM_MAT(u,r0);
	SCALE_MAT(r0,sth);

	ADD_MAT(r,r0,r);

	/* Rotate planet positions and velocities */

	for (i=0;i<p->n_planets;i++) {
		ptr = &data[i];
		Transform(r,ptr->pos,u);
		COPY_VEC(u,ptr->pos);
		Transform(r,ptr->vel,u);
		COPY_VEC(u,ptr->vel);
		}
	}

static void
conv_orb_elem(double mu,double a,double e,double i,double lop,
			  double lan,double mean_anom,VECTOR pos,VECTOR vel)
{
	/* Wrapper for Stadel's Delaunay to heliocentric coordinates converter */

	void deltohel(double, struct delaunay *, struct helio *);

	struct delaunay input;
	struct helio output;

	input.mea = mean_anom;
	input.lop = lop;
	input.lan = lan;
	input.sma = a;
	input.ecc = e;
	input.inc = i;

	deltohel(mu,&input,&output);

	SET_VEC(pos,output.x,output.y,output.z);
	SET_VEC(vel,output.vx,output.vy,output.vz);

	}

static double
radius(double m,double p)
{
	return pow(m/(4*PI*p/3),1.0/3);
	}

static void
gen_planets(PARAMS *p,SSDATA *data)
{
	SSDATA *ptr;
	double t,mean_anom,period;
	int i;

	/*
	 * Heliocentric orbital elements of the planets, epoch 1980.0
	 * [Table 7 of Practical Astronomy with your Calculator, 2nd ed.].
	 *
	 */

	typedef struct {
		double	mass;	/* mass in M_SUN */
		double	radius;	/* radius in AU */	
		double	a;		/* semi-major axis in AU */
		double	e;		/* eccentricity */
		double	i;		/* inclination in deg */
		double	lop;	/* longitude of perihelion in deg */
		double	lan;	/* longitude of ascending node in deg */
		double	lng;	/* longitude at epoch in deg */
		int		color;
		} ELEM_T;

	ELEM_T elem[p->n_planets];	

	if (strlen(p->planet_data)){
	  FILE *fp;
	  if (!(fp = fopen(p->planet_data,"r"))) {
	    (void) fprintf(stderr,"Unable to open \"%s\"\n",p->planet_data);
	    exit(1);
	  }
	  
	  (void) printf("Reading planet data...");
	  
	  /* inverse masses, extra Earth stuff, and time */
	
	  for (i=0;i<p->n_planets;i++) {
	    fscanf(fp,"%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%d",&elem[i].mass,&elem[i].radius,&elem[i].a,&elem[i].e,&elem[i].i,&elem[i].lop,&elem[i].lan,&elem[i].lng,&elem[i].color);
	  }
	}else{
	 
	  /* Current elements 
	    ELEM_T elem0[4] = {
	    {9.5480e-4, 4.7727e-4,  5.202561, 0.0484658, 1.3041819, 14.0095493, 100.2520175, 146.966365 , GIANT},
	    {2.8588e-4, 1.5e-4   ,  9.554747, 0.0556155, 2.4893741, 92.6653974, 113.4888341, 165.322242 , GIANT},
	    {4.355e-5 , 1.7e-4   , 19.21814 , 0.0463232, 0.7729895, 172.7363288, 73.8768642, 228.0708551, GIANT},
	    {5.1777e-5, 1.62e-4  , 30.10957 , 0.0090021, 1.7716017, 47.8672148, 131.5606494, 260.3578998, GIANT}
	  };*/

	    ELEM_T elem0[4] = {
	    {9.5480e-4, 4.7727e-4,  5.202561, 0.0484658, 1.3041819, 14.0095493, 100.2520175, 146.966365 , GIANT},
	    {2.8588e-4, 1.5e-4   ,  9.554747, 0.0556155, 2.4893741, 92.6653974, 113.4888341, 165.322242 , GIANT},
	    {2.7e-6 , 4.e-5   , 1.3 , 0.05,   0.5, 172.7363288, 73.8768642, 228.0708551, GIANT},
	    {5.1777e-5, 1.62e-4  , 30.10957 , 0.0090021, 1.7716017, 47.8672148, 131.5606494, 260.3578998, GIANT}
	    };
	  
	  if (p->nice_model == 1){/* Replace by Nice Model */
	    ELEM_T elem0[4] = {
	      {9.5480e-4, 4.7727e-4,    5.45, 0.0, 0.0,14.0095493, 100.2520175, 146.966365, GIANT},
	      {2.8588e-4, 1.5e-4,  8.18, 0.0, 0.5,92.6653974, 113.4888341, 165.322242, GIANT},
	      {4.355e-5 , 1.7e-4,  19.21814 , 0.0463232, 0.7729895,172.7363288,  73.8768642, 228.0708551, GIANT},
	      {5.1777e-5, 1.62e-4, 30.10957 , 0.0090021, 1.7716017,47.8672148, 131.5606494, 260.3578998, GIANT}
	    };
	  }

	  if (p->nice_model == 2){/* More eccentric */
	    ELEM_T elem0[4] = {
	      {9.5480e-4, 4.7727e-4,  5.202561, 0.1, 1.3041819,14.0095493, 100.2520175, 146.966365, GIANT},
	      {2.8588e-4, 1.5e-4,  9.554747, 0.0556155, 2.4893741,92.6653974, 113.4888341, 165.322242 , GIANT},
	      {4.355e-5 , 1.7e-4, 19.21814 , 0.0463232, 0.7729895,172.7363288,  73.8768642, 228.0708551, GIANT},
	      {5.1777e-5, 1.62e-4, 30.10957 , 0.0090021, 1.7716017,47.8672148, 131.5606494, 260.3578998, GIANT}
	    };
	  }

	  if (p->nice_model == 3){/* Replace by Nice Model */
	    ELEM_T elem0[4] = {
	      {9.5480e-4, 4.7727e-4,  5.45, 0.05, 0.0,14.0095493, 100.2520175, 146.966365, GIANT},
	      {2.8588e-4, 1.5e-4,  8.18, 0.05, 0.5,92.6653974, 113.4888341, 165.322242, GIANT},
	      {4.355e-5 , 1.7e-4, 19.21814 , 0.0463232, 0.7729895,172.7363288,  73.8768642, 228.0708551, GIANT},
	      {5.1777e-5, 1.62e-4, 30.10957 , 0.0090021, 1.7716017,47.8672148, 131.5606494, 260.3578998, GIANT}
	    };
	  }
	  	for (i=0;i<p->n_planets;i++) {
		  elem[i].mass = elem0[i].mass;
		  elem[i].radius = elem0[i].radius;
		  elem[i].a = elem0[i].a;
		  elem[i].e = elem0[i].e;
		  elem[i].i = elem0[i].i;
		  elem[i].lop = elem0[i].lop;
		  elem[i].lan = elem0[i].lan;
		  elem[i].lng = elem0[i].lng;
		  elem[i].color = elem0[i].color;
		}
	
		
	} 	 

	/* Giant planets */

	t = 100*ran(0);		/*DEBUG between 0 and 100 tropical years since 1980 */

	for (i=0;i<p->n_planets;i++) {
		ptr = &data[i];
		ptr->mass = elem[i].mass;
		ptr->radius = elem[i].radius;
		ptr->color = elem[i].color;
		ptr->nump = 1.0; /* an embryo has only one body in a particle */
		/*	printf("%e %i %e %i \n",ptr->mass,ptr->color,elem[i].mass,elem[i].color); */
		ZERO_VEC(ptr->spin);

		/* Convert from degrees to radians */

		elem[i].i	*= DEG_TO_RAD;
		elem[i].lop	*= DEG_TO_RAD;
		elem[i].lan	*= DEG_TO_RAD;
		elem[i].lng	*= DEG_TO_RAD;

		/* Use random time for mean anomaly to get initial pos & vel */
		
		period = elem[i].a*sqrt(elem[i].a); /* orbital period in yr */

		mean_anom = TWO_PI*t/period + elem[i].lng - elem[i].lop;

		conv_orb_elem(p->central_mass + ptr->mass,elem[i].a,elem[i].e,
					  elem[i].i,elem[i].lop,elem[i].lan,mean_anom,
					  ptr->pos,ptr->vel);

		ptr->dls = 0.0; /* added 012314 */
		}
	}

static void
gen_planetesimal(PARAMS *p,SSDATA *data)
{
  static double q,a,b, k,c,d; 
  static BOOLEAN first_call = TRUE;
  
  double f,sma,ecc=0,inc=0;
  double mass, rad;
 
	if (first_call) {
		q = p->surf_den_exp + 2;
		a = pow(p->r_inner,q);
		b = pow(p->r_outer,q);
		if(p->size_exp){
		k =  p->size_exp + 1;	 
		c = pow(p->m0,k); 
		d = pow(p->m0*p->mass_ratio,k);
		}
		first_call = FALSE;
		}

	if(p->size_exp){ 
	  /* calculate mass in MKS */
	  f = ran(0);
	  mass = pow((1 - f)*c + f*d,1/k);
	  rad = radius(mass,1000*p->density); /* density only for size distribution*/ 
	  rad *= p->scaling;
	  mass /= M_SCALE;
	  rad /= L_SCALE;
	  data->mass = mass;
	  data->radius = rad;
	}else{	  
	  data->mass = p->mass;
	  data->radius = p->radius;     
	}

	data->color = p->p_color;

	data->nump = p->nump;
	
	double pmass,pradius,vesc,vkep,edp,hill;
	pmass = data->mass/data->nump;
	pradius = data->radius/pow(data->nump,1.0/3.0);
	vesc = sqrt(2.0*pmass/pradius);
	hill = pow(pmass/3.0,1.0/3.0)/1.25;

	ZERO_VEC(data->spin);

	/*
	 * Semi-major axis (strategy: the surface density is assumed to be a
	 * kind of "average" formed by the planetesimal semi-major axes,
	 * rather than the exact value formed by the instantaneous positions).
	 *
	 */

	f = ran(0);
	sma = pow((1 - f)*a + f*b,1/q);
	
	/*
	 * Eccentricity & inclination (strategy: assume uncorrelated and
	 * use user-supplied distribution function and dispersions).
	 *
	 */

	vkep = sqrt(1.0/sma);
	edp = vesc/vkep/1.25;  

	do {
		switch (p->dst_fnc) {
		case RAYLEIGH:
			ecc = raydev()*p->ecc_dsp;
			assert(ecc >= 0.0);
			break;
		case GAUSSIAN:
			do
				ecc = gasdev()*p->ecc_dsp;
			while (ecc < 0);
			break;
		case 2:
		  ecc = raydev()*edp*p->ecc_dsp;
		  assert(ecc >= 0.0);
		  break;
		case 3:
		  ecc = raydev()*hill*p->ecc_dsp;
		  assert(ecc >= 0.0);
		  break;
		default:
			assert(0);
			}
		}
	while (ecc > p->ecc_max);

	do {
		switch (p->dst_fnc) {
		case RAYLEIGH:
			inc = raydev()*p->inc_dsp;
			assert(inc >= 0.0);
			break;
		case GAUSSIAN:
			do
				inc = gasdev()*p->inc_dsp;
			while (inc < 0);
			break;
		case 2:
		  inc = raydev()*edp*p->inc_dsp;
		  assert(inc >= 0.0);
		  break;
		case 3:
		  inc = raydev()*hill*p->inc_dsp;
		  assert(inc >= 0.0);
		  break;

		default:
			assert(0);
			}
		}
	while (inc > p->inc_max);

	/*
	 * Convert to instantaneous position and velocity, using uniform
	 * random longitude of perihelion, longitude of ascending node, and
	 * instantaneous longitude (valid if ecc & inc are small).
	 *
	 */

#ifdef TILT_RING
	if (fabs(sma - TILT_R) < TILT_DR) {
		conv_orb_elem(p->central_mass + data->mass,sma,ecc,TILT_I + inc,
					  TWO_PI*ran(0),0,TWO_PI*ran(0),data->pos,data->vel);
		}
	else
		conv_orb_elem(p->central_mass + data->mass,sma,ecc,inc,TWO_PI*ran(0),
					  TWO_PI*ran(0),TWO_PI*ran(0),data->pos,data->vel);
#else
	conv_orb_elem(p->central_mass + data->mass,sma,ecc,inc,TWO_PI*ran(0),
				  TWO_PI*ran(0),TWO_PI*ran(0),data->pos,data->vel);
#endif

	data->dls = 0.0; /* added 012314 */

	}

static void
gen_planetesimals(PARAMS *p,SSDATA *data)
{
	SSDATA *d;
	int i;
	
	for (i=0;i<p->n;i++) {
		d = &data[i];
		gen_planetesimal(p,d);
		}
	}


static void
generate(PARAMS *p,SSDATA *data)
{
	SSDATA *sun,*planets,*planetesimals,*ptr;
	VECTOR com_pos,com_vel;
	double total_mass;
	int i;

	/* Get handy pointers */

	if (p->heliocentric) {
		sun = NULL;
		planetesimals = data;
		}
	else {
		sun = data;
		planetesimals = sun + 1;
		}

		planets = planetesimals + p->n;

	/* Start with the Sun in the heliocentric frame */

	if (!p->heliocentric) {
		ZERO_VEC(sun->pos);
		ZERO_VEC(sun->vel);
		ZERO_VEC(sun->spin);
		sun->mass = 1;
		sun->radius = R_SUN/L_SCALE;
		sun->color = SUN;
		}

	/* Add planets, and planetesimals as appropriate */

	if (p->n_planets) {
	  /*if (strlen(p->planet_data))	get_planets(p,planets); else */
	  gen_planets(p,planets);
	}

	if (p->n) gen_planetesimals(p,planetesimals);

	/*
	 * Must now tilt the planets so the planetesimal disk lies in the
	 * invariable plane defined by the net angular momenta of the planets.
	 *
	 */

	if (p->tilt) tilt(p,planets);     

	/* Get planetesimal moments and estimate of mass centering error */

	if (p->n) {
		get_com(planetesimals,p->n,com_pos,com_vel,&total_mass);
		(void) printf("Planetesimal c-o-m (pos,vel) offset mag = (%e,%e)\n",
					  MAG(com_pos),MAG(com_vel));
		SCALE_VEC(com_pos,total_mass);
		SCALE_VEC(com_vel,total_mass);
		}
	else {
		ZERO_VEC(com_pos);
		ZERO_VEC(com_vel);
		total_mass = 0;
		}

	/* Now shift everything so centre-of-mass is at origin */

	if (p->adjust_com) {		
		if (!p->heliocentric)
			total_mass += sun->mass;

		for (i=0;i<p->n_planets;i++) {
			ptr = &planets[i];
			add_mom(ptr,com_pos,com_vel);
			total_mass += ptr->mass;
			}

		NORM_VEC(com_pos,total_mass);
		NORM_VEC(com_vel,total_mass);

		sub_com(data,p->n_data,com_pos,com_vel);
		}
	}


static void
get_params(PARAMS *p){

  double k, ra, ra_max;
  double nnump,rad_pl;
  double vesc, vr,vh;

	/* Read in supplied parameters */

	OpenPar("ssic.par");

	/* central object */

	ReadDbl("Central mass",&p->central_mass);
	assert(p->central_mass >= 0.0);
	ReadInt("Use heliocentric frame?",&p->heliocentric);

	/* planetesimals */

	ReadInt("Number of particles",&p->n);
	assert(p->n >= 0);

	if (p->n) {
	        ReadInt("Color",			&p->p_color);
		assert(p->p_color == PLANETESIMAL || p->p_color == TRACER || p->p_color ==TEST);
		ReadDbl("Total mass",						&p->total_mass);
		assert(p->total_mass > 0.0);
		ReadDbl("Planetesimal density",				&p->density);
		assert(p->density > 0.0);
		//ReadUi6("Number of planetesimals in a particle",	&p->nump);
		ReadDbl("Number of planetesimals in a particle",	&p->nump);	
		nnump = p->nump;
		assert(p->nump >= 1.0);
		if (p->p_color != TRACER) assert(p->nump == 1.0);
		ReadDbl("Inner orbital radius",				&p->r_inner);
		assert(p->r_inner > 0.0);
		ReadDbl("Outer orbital radius",				&p->r_outer);
		assert(p->r_outer >= p->r_inner);
		ReadDbl("Projected surface density exp.",	&p->surf_den_exp);
		assert(p->surf_den_exp != -2.0);
		ReadDbl("Size distribution exp.",	        &p->size_exp);
	
		assert(p->size_exp != -2.0);
		assert(p->size_exp == 0.0 || p->density > 0);	
		if(p->p_color == TRACER){
		  assert(p->size_exp == 0.0);
		}

		ReadDbl("Mass ratio",	                        &p->mass_ratio);
		assert(p->mass_ratio > 1.0);
		ReadDbl("Eccentricity dispersion",			&p->ecc_dsp);
		assert(p->ecc_dsp >= 0.0);
		ReadDbl("Inclination dispersion",			&p->inc_dsp);
		assert(p->inc_dsp >= 0.0);
		ReadDbl("Maximum eccentricity",				&p->ecc_max);
		assert(p->ecc_max >= 0.0 && p->ecc_max <= 1.0);
		ReadDbl("Maximum inclination",				&p->inc_max);
		assert(p->inc_max >= 0.0 && p->inc_max <= 90.0);
		ReadInt("Distribution functions",			&p->dst_fnc);
		assert(p->dst_fnc == RAYLEIGH || p->dst_fnc == GAUSSIAN || p->dst_fnc <= 3);	
		}


	/* planets */

	ReadInt("Number of planets",&p->n_planets);
	assert(p->n_planets >= 0);

	p->tilt = FALSE;
	if (p->n_planets) {
	  if (p->n) ReadInt("Align invariable plane?",&p->tilt);
	  ReadStr("Planet data file name",p->planet_data,MAXPATHLEN);
	}
	ReadInt("Nice Model",			&p->nice_model);
	assert(p->nice_model >= 0 && p->nice_model <= 3);

	/* miscellaneous */

	ReadDbl("Start time",				&p->time);
	ReadInt("Adjust c-o-m to origin?",	&p->adjust_com);
	ReadStr("Output file name",			p->output_file,MAXPATHLEN);

	ClosePar();

	/* Calculate remaining parameters */
	if(p->p_color == PLANETESIMAL){
	  (void) printf("%i planet%s, %i planetesimal%s\n",
			p->n_planets,(p->n_planets==1?"":"s"),p->n,(p->n==1?"":"s"));
	}

	if(p->p_color == TEST){
	  (void) printf("%i planet%s, %i test particle%s\n",
			p->n_planets,(p->n_planets==1?"":"s"),p->n,(p->n==1?"":"s"));
	}
	if(p->p_color == TRACER){
	  (void) printf("%i planet%s, %i tracer%s %f planetesimal%s in a tracer \n",
			p->n_planets,(p->n_planets==1?"":"s"),p->n,(p->n==1?"":"s"),p->nump,(p->nump==1?"":"s"));
	}

	p->n_data = p->n_planets + p->n; /* planets + planetsimals */

	if (!p->heliocentric) ++p->n_data; /* add Sun */

	if (p->n) {
		p->mass = (p->total_mass*M_EARTH/p->n); /* equal mass planetesimals; mass in kg */
		(void) printf("Mean particle mass = %e g = %g M_Sun\n",1000*p->mass,
					  p->mass/M_SCALE);
		(void) printf("Mean planetesimal mass = %e g = %g M_Sun\n",1000*p->mass/nnump,
					  p->mass/M_SCALE/nnump);
		if (p->r_outer > p->r_inner)
			(void) printf("Mean surface density = %g g/cm^2\n",
						  1000*p->mass*p->n/
						  (PI*(SQ(p->r_outer) - SQ(p->r_inner))*SQ(AU)*10000));	

		if(p->size_exp != 0.0){ 
		  (void) printf("Size distribution index %e  \n", p->size_exp);
		  /* calculate mass in MKS */
		  k =  p->size_exp;
		  ra = p->mass_ratio;  
		  ra_max = pow(p->n,-1.0/(1.0+k));
		  if(ra > ra_max){
		    (void) printf("Mass ratio %e is reduced to %e \n",ra, ra_max);
		    ra = ra_max;
		  }	 
		  /* lowest mass*/
		  p->m0 = p->mass*(2.0+k)/(1.0+k)*(1.0-pow(ra,1.0+k))/(1.0-pow(ra,2.0+k)); 
		  /* largest mass  (p->mass is used)*/
		  p->mass = p->m0*ra;
		  (void) printf("largest bodies mass is = %g g, %g M_sun\n",1000*p->mass, p->mass/M_SCALE);
		  (void) printf("smallest bodies mass is = %g g, %g M_sun\n",1000*p->m0, p->m0/M_SCALE);
		}else{
		  (void) printf("Identical mass of planetesimals \n");
		}
		/*

		 * IMPORTANT NOTE: Kokubo & Ida (1998) define the reduced Hill radius
		 * in terms of the SUM of the two masses involved, in this case twice
		 * the planetesimal mass ASSUMING EQUAL-MASS PLANETESIMALS. It's
		 * important to be consistent for the initial eccentricity and
		 * inclination dispersion scaling.
		 */
		/*p->red_hill = pow(2*p->mass/(3*p->central_mass*M_SUN),1.0/3);
		(void) printf("Reduced Hill radius = %g\n",p->red_hill);
		(void) printf("Hill radius at 1 AU = %g km\n",0.001*p->red_hill*AU);*/

		/* modified 040413 */
		/* p->ecc_dsp *= p->red_hill;
		   p->inc_dsp *= p->red_hill;*/
		
		if (p->ecc_max > 0.2)
			(void) fprintf(stderr,"WARNING: Large maximum eccentricity\n");
		if (p->inc_max > 10)
			(void) fprintf(stderr,"WARNING: Large maximum inclination\n");
		p->inc_max *= DEG_TO_RAD;
		(void) printf("Predicted velocity dispersion = %g\n",
					  sqrt(SQ(p->ecc_dsp) + SQ(p->inc_dsp)));

		/* printf("%g %g %g \n",p->density,p->mass,p->size_exp,radius(p->mass,1000*p->density));*/

		if(!p->size_exp){
		  if (p->density){
		    p->radius = radius(p->mass,1000*p->density);
		    rad_pl = radius(p->mass/nnump,1000*p->density);
		  }else if (p->radius < 0){
		    p->radius *= -1000; /* radius in meter */
		  }else{
		    p->radius *= L_SCALE; /* for now */
		  }
		  p->radius /= L_SCALE; /* radius in AU */
		  p->mass /= M_SCALE;
		  /* p->radius *= p->scaling;*/		  
		  (void) printf("Radius = %g km\n",p->radius*L_SCALE/1000.0);
		  (void) printf("Radius of planetesimals = %g km\n",rad_pl/1000.0);
		  
		  vesc =sqrt(2.0*(p->mass*M_SCALE/nnump)*G/rad_pl);
		  vh = pow(p->mass/nnump/3.0,1.0/3.0)*sqrt(G*M_SUN/((p->r_inner+p->r_outer)/2.0*AU));

		  if (p->dst_fnc == 2){
		    vr = vesc;
		  }else if (p->dst_fnc == 3){
		    vr = vh;
		  }else{
		    vr = 1.25*p->ecc_dsp*sqrt(G*M_SUN/((p->r_inner+p->r_outer)/2.0*AU));
		  }
		  (void) printf("Escape vel = %g m/s, Random vel = %g m/s \n",vesc,vr);

		}else{
		  (void) printf("Radius of largest body= %g km\n",radius(p->mass,1000*p->density)/1000.0);
		  (void) printf("Radius of smallest body= %g km\n",radius(p->m0,1000*p->density)/1000.0);
		}
		
		if (p->scaling != 1) (void) printf(" (scaled)");		

		}

	p->time *= (JUL_YR/T_SCALE);
	}

int
main(int argc,char *argv[])
{
	PARAMS params;
	SSDATA *data = NULL;
	int seed,usage=0,c;

	/* Disable stdout buffering */

	setbuf(stdout,(char *) NULL);

	/* Generate a random number seed */

	seed = getpid();

	/* Check arguments */

	while ((c = getopt(argc,argv,"s:")) != EOF)
		switch (c) {	
		case 's':
			seed = atoi(optarg);
			if (seed <= 0) usage = 1;
			break;
		default:
			usage = 1;
			}

	if (usage || optind < argc) {
		(void) fprintf(stderr,"Usage: %s [ -f ] [ -r ] [ -s seed ]\nwhere seed > 0 is random number generator seed\n",argv[0]);
		exit(1);
		}

	/* Get model parameters */

	get_params(&params);

	/* Generate initial conditions */

	(void) ran(seed); /* seed */

	if (!(data = (SSDATA *) malloc(params.n_data*sizeof(SSDATA)))) {
		(void) fprintf(stderr,"Unable to allocate data memory\n");
		exit(1);
		}

	generate(&params,data);

	/* Save data */

	output_data(&params,data);

	/* All done */

	free((void *) data);

	return 0;
	}

/* NRiC 2nd ed */

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

static double
ran(int seed)
{
	static long idum;

	int j;
	long k;
	static long iy=0;
	static long iv[NTAB];
	float temp;

	if (!iy) {
		assert(seed > 0);
		idum = seed;
		(void) printf("Random number seed = %li\n",idum);
		for (j=NTAB+7;j>=0;j--) {
			k=idum/IQ;
			idum=IA*(idum-k*IQ)-IR*k;
			if (idum < 0) idum += IM;
			if (j < NTAB) iv[j] = idum;
			}
		iy=iv[0];
		}
	k=idum/IQ;
	idum=IA*(idum-k*IQ)-IR*k;
	if (idum < 0) idum += IM;
	j=iy/NDIV;
	iy=iv[j];
	iv[j] = idum;
	if ((temp=AM*iy) > RNMX) return RNMX;
	else return (double) temp;
	}

#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX

static double
raydev(void)
{
	/* based on expdev(), but for Rayleigh distribution */

	double dum;

	do
		dum = ran(0);
	while (dum == 0);
	/*return sqrt(-2.0*log(dum)); mod 082513 */
	return sqrt(-log(dum)); 
	}

static double
gasdev(void)
{
	static int iset=0;
	static double gset;
	float fac,rsq,v1,v2;

	if (iset == 0) {
		do {
			v1=2.0*ran(0)-1.0;
			v2=2.0*ran(0)-1.0;
			rsq=v1*v1+v2*v2;
			} while (rsq >= 1.0 || rsq == 0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;
		iset=1;
		return (double) v2*fac;
		} else {
			iset=0;
			return (double) gset;
			}
	}

/* ssic.c */
