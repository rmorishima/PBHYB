#include "ss.h"
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "vector.h"
#include "ssio.h"

/* me2pkd.c 

   First make input file by 
 # planetz3m/bin/element7 
   output data file and time are specified in element.in:
   ) List the input files, one per line
   xv4.out
   minimum interval between outputs (days) =  input time
   it creates an ascii data file named element7.out
   then enter
 # me2pkd element7.out 
   It creates a ss format file named pkdgrav.out.
 # mv pkdgrav.out to the directory of a run of pkdgrav   
 # ssa pkdgrav.out
 # ssp
*/ 


/* #define#  INFILE  "pkdplanet.in" */
#define  OUTFILE "pkdgrav.out"
#define  rho    5.04988E6 /* (3g/cm^3)/(M_sun/AU^3) */
#define  factor 1  /* f */
#define  sfac   0.4*pow((3.0/(4.0*PI*rho)),(2.0/3.0))*GAUSS_K*pow(factor,1.5)

int no_mass_wgt = 0; /*DEBUG hack for TEST particles*/


int main (int argc, char *argv[])
{
	FILE *fp = NULL;
        SSIO ssio;
        SSHEAD h;
	SSDATA *data;
	SSDATA *d;

	int i, j;

	if(!(argv[1] == NULL)){
 	      printf("Input file is %s\n",argv[1]);
 	    }else{
 	      printf("Enter input file name!!\n"); 
 	      exit(0);
 	    } 

     /* Open input file */
     if (!(fp = fopen(argv[1],"r"))){
        (void)fprintf(stderr,"Unable to open %s for writing\n", OUTFILE);     
        return 1; 
     }else{
      
       fscanf(fp,"%lf %d \n", &h.time, &h.n_data);
       printf("Time=%eyears, N_body=%d \n",h.time, h.n_data);

       h.time /= (T_SCALE/JUL_YR);

       if (ssioOpen(OUTFILE,&ssio,SSIO_WRITE)) {
		(void) fprintf(stderr,"Unable to open \"%s\"\n",OUTFILE);
		return 1;
		}

	(void) ssioHead(&ssio,&h);

       data = (SSDATA *) malloc(h.n_data*sizeof(SSDATA));
       assert(data != NULL);

       for (i=0;i<h.n_data;++i) {
		d = &(data)[i];
       fscanf(fp,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %d %d\n",        
	      &d->mass,&d->radius,&d->pos[0],&d->pos[1],&d->pos[2],&d->vel[0],
	      &d->vel[1],&d->vel[2],&d->spin[0],&d->spin[1],&d->spin[2],
	      &d->color,&d->org_idx); 
  
         
       for (j = 0; j<N_DIM; j++){
         d->vel[j] /= GAUSS_K;
         d->spin[j] /= GAUSS_K*d->mass*d->radius*d->radius;
	   }

       /* printf("%d %e %e \n",d->org_idx,d->mass,d->spin[2]); */

        (void) ssioData(&ssio,d);
       }
       fclose(fp);
       (void) ssioClose(&ssio);
       printf("Output file is %s\n",OUTFILE);

     } 
      

 

}
