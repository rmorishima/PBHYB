#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
/*#include <float.h>
#include <limits.h>
#include <inttypes.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>*/
#include <rpc/types.h>
#include <rpc/xdr.h>

#ifndef SINGLE

#define FLOAT			double
#define FLOAT_MAXVAL	HUGE

#else

#define FLOAT			float
#define FLOAT_MAXVAL	HUGE

#endif

#define MISS	0
#define MERGE	1
#define BOUNCE	2
#define FRAG	4
#define ESCAPE	8
#define SUNCOLLIDE	16


#define ME 3.00374E-6

typedef struct {
  int iPid;
  int iOrder;
  int iIndex;
  int iOrgIdx;
} PARTICLE_ID;

typedef struct {
  PARTICLE_ID id;
  FLOAT fMass;
  FLOAT fRadius;
  FLOAT r[3];
  FLOAT v[3];
  FLOAT w[3];
#ifdef HERMITE
  FLOAT a[3];
  FLOAT ad[3];
#endif
#ifdef SYMBA
  FLOAT drmin;
  int   iOrder_VA[30]; /* iOrder's of particles within 3 hill radius*/
  int   i_VA[30];    /* pointers of particles */
  int   n_VA;       /* number of particles */
  double  hill;       /* hill radius */ 
#endif
  int iColor;
  FLOAT dt;
  int iRung;
} COLLIDER;

void
CollisionData(XDR *xdrs, COLLIDER *c1, COLLIDER *c2){
  int i;
  
  /* info for c1*/
  (void) xdr_int(xdrs,&c1->iColor);
  (void) xdr_int(xdrs,&c1->id.iOrgIdx);			
  (void) xdr_double(xdrs,&c1->fMass);
  (void) xdr_double(xdrs,&c1->fRadius);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c1->r[i]);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c1->v[i]);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c1->w[i]);
  
  /* info for c2*/
  (void) xdr_int(xdrs,&c2->iColor);
  (void) xdr_int(xdrs,&c2->id.iOrgIdx);			
  (void) xdr_double(xdrs,&c2->fMass);
  (void) xdr_double(xdrs,&c2->fRadius);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c2->r[i]);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c2->v[i]);
  for (i=0;i<3;i++)
    (void)xdr_double(xdrs,&c2->w[i]);
}


int main(int argc, char *argv[])
{
  FILE *fp,*fimp;
  XDR xdrs;
  COLLIDER *c1,*c2;
  COLLIDER c1out,c2out;
  
  double L_EM = 3.9e-12;
  double dTime;
  int iOutcome;
  
  double lx,ly,lz,x,y,z,vx,vy,vz,L_imp,a,d,v,v_esc,mt,ms;
  double r, v2,summ, Etot,a1,a2, dtb;
  int id1,id2;
  /*printf("enter msrCollInitial, dTime_Start = %e \n",dTime_Start);*/
  
  dtb = 0.0;
  fp = fopen("ss.coll.bin","r");
  fimp = fopen("imp.dat","w");

  if(fp == NULL) return;     
  xdrstdio_create(&xdrs,fp,XDR_DECODE);
  
  do{
    if (!xdr_double(&xdrs,&dTime)) {
      xdr_destroy(&xdrs);
      (void) fclose(fp);
      return;
    }
    
   
    (void) xdr_int(&xdrs,&iOutcome); 
    CollisionData(&xdrs, &c1out, &c2out);
    c1 = &c1out;
    c2 = &c2out;
     	
	r = sqrt(c1->r[0]*c1->r[0]+c1->r[1]*c1->r[1]+c1->r[2]*c1->r[2]);
	v2 = c1->v[0]*c1->v[0]+c1->v[1]*c1->v[1]+c1->v[2]*c1->v[2];
	summ = 1.0+c1->fMass;
	Etot = 0.5*v2 - summ/r;
	a1 = -0.5/Etot;

	r = sqrt(c2->r[0]*c2->r[0]+c2->r[1]*c2->r[1]+c2->r[2]*c2->r[2]);
	v2 = c2->v[0]*c2->v[0]+c2->v[1]*c2->v[1]+c2->v[2]*c2->v[2];
	summ = 1.0+c2->fMass;
	Etot = 0.5*v2 - summ/r;
	a2 = -0.5/Etot;

	a = (a1*c1->fMass + a2*c2->fMass)/(c1->fMass + c2->fMass);

	x = c1->r[0] - c2->r[0];
	y = c1->r[1] - c2->r[1];
	z = c1->r[2] - c2->r[2];
	vx = c1->v[0] - c2->v[0];
	vy = c1->v[1] - c2->v[1];
	vz = c1->v[2] - c2->v[2];

	mt = (c1->fMass+c2->fMass);
	/* smaller mass */
	if(c1->fMass <= c2->fMass){
	  ms = c1->fMass;
	}else{
	  ms = c2->fMass;
	}
      	id1 = c1->id.iOrgIdx;
       	id2 = c2->id.iOrgIdx;

	d = sqrt(x*x + y*y + z*z);
	d = d/(c1->fRadius+c2->fRadius);
	v = sqrt(vx*vx + vy*vy + vz*vz);
	v_esc = sqrt(2*mt/(c1->fRadius+c2->fRadius));
	v = v/v_esc;
	
	lx = y*vz-z*vy;
	ly = z*vx-x*vz;
	lz = x*vy-y*vx;
	
	L_imp = (c1->fMass*c2->fMass)/mt*sqrt(lx*lx+ly*ly+lz*lz)/L_EM;
	
	if(iOutcome == MERGE)
	  {
	    

	    /*if((L_imp > 0.5) && (mt/ME > 0.5) && (c2->iColor != 2) && (c1->iColor != 2)){
	    fprintf(fimp,"GI %.4e %.4e %.4e %.4e %.4e  %.4e %.4e\n", dTime/(2.0*M_PI), mt,c1->fMass,c2->fMass, L_imp, a, v); 
	  }*/
	    fprintf(fimp,"%.4e %d %.5e %.8e %.8e %.8e %.8e %.8e %.8e %d %.5e %.8e %.8e %.8e %.8e %.8e %.8e \n", 
		    dTime/(2.0*M_PI),c1->id.iOrgIdx,c1->fMass,c1->r[0],c1->r[1],c1->r[2],
		    c1->v[0],c1->v[1],c1->v[2],c2->id.iOrgIdx,c2->fMass,c2->r[0],c2->r[1],c2->r[2],
		    c2->v[0],c2->v[1],c2->v[2]);
	    
	    if(dtb > dTime){
	      printf("Time is not in order  \n");
	      printf("time = %.4e, id1 %i, id2 %i \n", dTime/(2.0*M_PI),c1->id.iOrgIdx,c2->id.iOrgIdx);
	    }
	      dtb = dTime;

	    /*if(id1==441 || id2==441)
	  {
	  printf("%.4e %.4e %.4e %.4e %.4e %.4e  %.4e %.4e\n", dTime/(2.0*M_PI), mt, ms/mt, c1->fMass,c2->fMass, L_imp, a, v);	  
	  }*/


	/* collision with Jupiter*/
	if(c2->iColor == 2){
	  printf("J coll, T=%.4e yr, id1=%d, M1=%.4e, a1=%.4e\n", dTime/(2.0*M_PI),c1->id.iOrgIdx, c1->fMass/ME,a1);
	}else if(c1->iColor == 2){
	  printf("J coll, T=%.4e yr, id2=%d, M2=%.4e a2=%.4e\n", dTime/(2.0*M_PI),c2->id.iOrgIdx, c2->fMass/ME,a2);
	}
    
      }/* MERGE */
    
   
    /* Escape */
    if(iOutcome == ESCAPE){
      printf("Escape, T=%.4e yr, id1=%d, M1=%.4e, a1=%.4e\n", dTime/(2.0*M_PI),c1->id.iOrgIdx, c1->fMass/ME,a1);
    }

    /* Collision with Sun */
    if(iOutcome == SUNCOLLIDE){
      printf("Sun coll, T=%.4e yr, id1=%d, M1=%.4e, a1=%.4e \n", dTime/(2.0*M_PI),c1->id.iOrgIdx, c1->fMass/ME,a1);
    }


  }while(1);     
}
