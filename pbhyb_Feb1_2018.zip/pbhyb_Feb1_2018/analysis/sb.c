/*
 ** selectbody.c -- read a binary position file and output selected bodies to a new binary file 
 */

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>		/* for getpid(), and getopt() if needed */
#include <sys/types.h>	/* ditto (for IRIX) */

#include "rdpar.h"
#include "vector.h"
#include "delaunay.h"
#include "helio.h"
#include "boolean.h"
#include "ss.h"
#include "ssio.h"

#ifdef sparc
#ifdef sun
#undef sun /* sheesh */
#endif
#endif

/*#define TILT_RING*/ /*DEBUG used to tilt a portion of the disk at the start*/

#ifdef TILT_RING
#define TILT_R 1.275
#define TILT_DR 0.025
#define TILT_I 0.0125
#endif

/* Definitions */

#define RAYLEIGH 0
#define GAUSSIAN 1

typedef struct {

	/* Following data read in from parameter file... */

	double central_mass;
	BOOLEAN heliocentric;

	int n,dst_fnc,snow_line,nice_model;
	double total_mass,density,radius,scaling,r_inner,r_outer,surf_den_exp;
	double ecc_dsp,inc_dsp,ecc_max,inc_max;

	double seed_mass,seed_density,seed_radius,seed_scaling;
	double seed_sma,seed_ecc,seed_inc,seed_gap_scale;
	
	BOOLEAN tilt;
	char planet_data[MAXPATHLEN];

	double time;
	BOOLEAN adjust_com,softening;
	char output_file[MAXPATHLEN];

	/* Following derived from supplied parameters... */

	int n_data, n_planets;
	double mass,red_hill,esc_vel,seed_half_gap;
       
	} PARAMS;

static double ran(int);

static void
output_data(SSDATA *data, SSHEAD *h)
{
	SSIO ssio;
	SSHEAD head;
	int i;
	int n_data = 0;
	double r[30000];
	double r_cri = 8.0;
	double m_cri = 7.7e-5;
        char ofile[] = "ssic.ss";
       
	for (i=0;i<h->n_data;i++) {	
	  r[i] = sqrt(data[i].pos[0]*data[i].pos[0] + data[i].pos[1]*data[i].pos[1] + data[i].pos[2]*data[i].pos[2]);
	  if(r[i] < r_cri && data[i].mass > m_cri)n_data ++; 
	}

	if (ssioOpen(ofile,&ssio,SSIO_WRITE)) {
		(void) fprintf(stderr,"Unable to open \"%s\"\n",ofile);
		exit(1);
		}

	head.time = h->time;
	/*	head.n_data = h->n_data;*/
	head.n_data = n_data;
	head.dEcoll = 0.0;
	head.dEgas = 0.0;
	head.dEstir = 0.0;
	head.dSunMass = h->dSunMass;

	printf("%e %d %e \n", h->time, h->n_data,h->dSunMass);

	(void) ssioHead(&ssio,&head);

	/* output planetesimals data */ 
	for (i=0;i<h->n_data;i++) {
	  if(r[i] < r_cri && data[i].mass > m_cri){
	    (void) ssioData(&ssio,&data[i]);
	  }
	}
	
	/* add gas giants
	for (i=0;i<p->n_planets;i++) {
	  data[i+h->n_data].org_idx = p->n + i;
	  (void) ssioData(&ssio,&data[i+h->n_data]);
	}*/


	(void) ssioClose(&ssio);

}

static void
add_mom(SSDATA *data,VECTOR mom_pos,VECTOR mom_vel)
{
	VECTOR v;

	COPY_VEC(data->pos,v);
	SCALE_VEC(v,data->mass);
	ADD_VEC(mom_pos,v,mom_pos);
	COPY_VEC(data->vel,v);
	SCALE_VEC(v,data->mass);
	ADD_VEC(mom_vel,v,mom_vel);
	}

static void
get_com(SSDATA *data,int n,VECTOR com_pos,VECTOR com_vel,double *mass)
{
	int i;

	ZERO_VEC(com_pos);
	ZERO_VEC(com_vel);

	*mass = 0;

	for (i=0;i<n;i++) {
		add_mom(&data[i],com_pos,com_vel);
		*mass += data[i].mass;
		}

	NORM_VEC(com_pos,*mass);
	NORM_VEC(com_vel,*mass);
	}

static void
sub_com(SSDATA *data,int n,VECTOR com_pos,VECTOR com_vel)
{
	int i;

	for (i=0;i<n;i++) {
		SUB_VEC(data[i].pos,com_pos,data[i].pos);
		SUB_VEC(data[i].vel,com_vel,data[i].vel);
		}
	}

static void
calc_ang_mom(SSDATA *data, int n, VECTOR ang_mom)
{
	VECTOR v;
	int i;

	ZERO_VEC(ang_mom);

	for (i=0;i<n;i++) {
		CROSS(data[i].pos,data[i].vel,v);
		SCALE_VEC(v,data[i].mass);
		ADD_VEC(ang_mom,v,ang_mom);
		}
	}

static void
tilt(PARAMS *p,SSDATA *data)
{
	SSDATA *ptr;
	MATRIX r,r0;
	VECTOR zp,z,x,u;
	double cth,sth;
	int i;

	calc_ang_mom(data,p->n_planets,zp);
	NORM_VEC(zp,MAG(zp));
	SET_VEC(z,0,0,1);

	(void) printf("Inclination of invariable plane to ecliptic = %f deg\n",
				  acos(zp[Z])*(double)RAD_TO_DEG);

	/* Construct rotation matrix */
				  
	CROSS(z,zp,x);
	COPY_VEC(x,u);
	NORM_VEC(u,MAG(u));

	cth = DOT(z,zp);
	sth = MAG(x);

	UNIT_MAT(r);
	SCALE_MAT(r,cth);

	VecToMat(u,u,r0);
	SCALE_MAT(r0,(1 - cth));

	ADD_MAT(r,r0,r);

	SKEW_SYM_MAT(u,r0);
	SCALE_MAT(r0,sth);

	ADD_MAT(r,r0,r);

	/* Rotate planet positions and velocities */

	for (i=0;i<p->n_planets;i++) {
		ptr = &data[i];
		Transform(r,ptr->pos,u);
		COPY_VEC(u,ptr->pos);
		Transform(r,ptr->vel,u);
		COPY_VEC(u,ptr->vel);
		}
	}

static void
conv_orb_elem(double mu,double a,double e,double i,double lop,
			  double lan,double mean_anom,VECTOR pos,VECTOR vel)
{
	/* Wrapper for Stadel's Delaunay to heliocentric coordinates converter */

	void deltohel(double, struct delaunay *, struct helio *);

	struct delaunay input;
	struct helio output;

	input.mea = mean_anom;
	input.lop = lop;
	input.lan = lan;
	input.sma = a;
	input.ecc = e;
	input.inc = i;

	deltohel(mu,&input,&output);

	SET_VEC(pos,output.x,output.y,output.z);
	SET_VEC(vel,output.vx,output.vy,output.vz);

	}

static double
radius(double m,double p)
{
	return pow(m/(4*PI*p/3),1.0/3);
	}


static void
gen_planets(PARAMS *p,SSDATA *planets)
{
	SSDATA *ptr;
	double t,mean_anom;
	int i;

	/*
	 * Heliocentric orbital elements of the planets, epoch 1980.0
	 * [Table 7 of Practical Astronomy with your Calculator, 2nd ed.].
	 *
	 */


	typedef struct {
		double	mass;	/* mass in M_SUN */
		double	radius;	/* radius in AU */
		double	period;	/* period in TROP_YR */
		double	a;		/* semi-major axis in AU */
		double	e;		/* eccentricity */
		double	i;		/* inclination in deg */
		double	lop;	/* longitude of perihelion in deg */
		double	lan;	/* longitude of ascending node in deg */
		double	lng;	/* longitude at epoch in deg */
		int		color;
		} ELEM_T;

      

       	/* Current elements */
       
	  ELEM_T elem[MAX_NUM_PLANETS] = {
	    {9.5480e-4, 4.7727e-4,  11.86224,  5.202561, 0.0484658, 0.0,
	     14.0095493, 100.2520175, 146.966365 , GIANT},
	    {2.8588e-4, 1.5e-4   ,  29.45771,  9.554747, 0.0556155, 1.0,
	     92.6653974, 113.4888341, 165.322242 , GIANT},
	    {4.355e-5 , 1.7e-4   ,  84.01247, 19.21814 , 0.0463232, 0.7729895,
	     172.7363288,  73.8768642, 228.0708551, GIANT},
	    {5.1777e-5, 1.62e-4  , 164.79558, 30.10957 , 0.0090021, 1.7716017,
	     47.8672148, 131.5606494, 260.3578998, GIANT}
	  };
	    
	if (p->nice_model == 1){/* Replace by Nice Model */	      
	    printf("Nice Model %d \n",p->nice_model);
	    elem[0].a = 5.45;
	    elem[0].e = 0.0;
	    elem[0].i = 0.0;
	    elem[1].a = 8.18;
	    elem[1].e = 0.0;
	    elem[1].i = 0.5;	    	   	   
	  }
	    
	if (p->nice_model == 2){/* More eccentric */
	  printf("e_j = 0.1 %d \n",p->nice_model);
	  elem[0].e = 0.1;
	}

	if (p->nice_model == 3){/* More eccentric */
	  printf("Eccentric Nice Model %d \n",p->nice_model);
	    elem[0].a = 5.45;
	    elem[0].e = 0.05;
	    elem[0].i = 0.0;
	    elem[1].a = 8.18;
	    elem[1].e = 0.05;
	    /*	    elem[1].e = 0.0;  accidentaly,  e_s seemed to be 0 in morishima et al. 2010*/
	    elem[1].i = 0.5;
	}


	/*assert(p->central_mass == 1.0);*/

	/* Giant planets */

	t = 100*ran(0);		/*DEBUG between 0 and 100 tropical years since 1980 */

	(void) printf("ok02 %d \n",p->n_planets);

	for (i=0;i<p->n_planets;i++) {
		ptr = &planets[i];
	
		ptr->mass = elem[i].mass;
	
		ptr->radius = elem[i].radius;
		ptr->color = elem[i].color;
	
		ZERO_VEC(ptr->spin);

		/* Convert from degrees to radians */

		elem[i].i	*= DEG_TO_RAD;
		elem[i].lop	*= DEG_TO_RAD;
		elem[i].lan	*= DEG_TO_RAD;
		elem[i].lng	*= DEG_TO_RAD;

		/* Use random time for mean anomaly to get initial pos & vel */

		mean_anom = TWO_PI*t/elem[i].period + elem[i].lng - elem[i].lop;
	
		conv_orb_elem(p->central_mass + ptr->mass,elem[i].a,elem[i].e,
					  elem[i].i,elem[i].lop,elem[i].lan,mean_anom,
					  ptr->pos,ptr->vel);	
		}
}

int read_data(char *filename, SSHEAD **head, SSDATA **data,SSDATA **sun)
{
	SSIO ssio;
	SSHEAD *h;
	SSDATA *d;
	int i,n,n_planets,n_data,n_test;
	double time;
	n_data = n = n_planets = n_test = 0;
	
	*head = NULL;
	*data = *sun = NULL;
      
	if (ssioOpen(filename,&ssio,SSIO_READ)) {
		(void) fprintf(stderr,"Unable to open \"%s\"\n",filename);
		return 1;
		}

	/* This fixes the poiters, *head and h */
	*head = (SSHEAD *) malloc(sizeof(SSHEAD));
	h = *head;

	(void) ssioHead(&ssio,h);

	/* *head = &h;*/

	n_data = h->n_data;
	time = h->time;	
	time *= (T_SCALE/JUL_YR); /* get time in Julian years */
	

	(void) printf("time %e Julian yr, n_data = %i -- ",time,n_data);
	/*(void) printf("time %e Julian yr, n_data = %i -- ",(*head)->time,(*head)->n_data);*/

	if (n_data <= 0) {
		(void) fprintf(stderr,"Missing or corrupted data -- skipped\n");
		return 1;
		}

	*data = (SSDATA *) malloc(n_data*sizeof(SSDATA));
	assert(*data != NULL);

	for (i=0;i<n_data;++i) {
		d = &(*data)[i];
		(void) ssioData(&ssio,d);
		switch (d->color) {
		case SUN:
			assert(*sun == NULL);
			*sun = d;
			break;
		case GIANT:	
		        ++n_planets;
			break;	
		case PLANETESIMAL:
			++n;
			break;
		case TEST:
		        ++n_test;
			break; 
		default:
			(void) fprintf(stderr,"Unknown object (item %i, color %i) in "
						   "data file! Aborting...\n",i,d->color);
			return 1;
			}
		}

	(void) printf("%s%i planet%s, %i planetesimal%s\n",(*sun?"Sun,":""),
				  n_planets,(n_planets==1?"":"s"),n,(n==1?"":"s"));


	(void) ssioClose(&ssio);

	/*if (!*sun)
	  (void) fprintf(stderr,"Sun not found...assuming heliocentric coords...\n");*/

	return 0;
	}



int
main(int argc,char *argv[])
{
	PARAMS params;
	SSDATA *data,*sun,*planets;
	SSHEAD *head = NULL;
	int seed,force=0,rejects=0,usage=0,c;
       
	/* Disable stdout buffering */

	setbuf(stdout,(char *) NULL);

	/* Generate a random number seed */

	seed = getpid();

	/* Check arguments */
	while (!usage && ((c = getopt(argc,argv,"frs:")) != EOF))
		switch (c) {
		case 'f':
			force = 1;
			break;
		case 'r':
			rejects = 1;
			break;
		case 's':
			seed = atoi(optarg);
			if (seed <= 0) usage = 1;
			break;
		default:
			usage = 1;
		}

	if (optind == argc) usage = 1;

	/*(void) fprintf(stderr,"%d, %d, %d \n", optind, argc, usage);*/


	if (usage) {
		(void) fprintf(stderr,"Usage: %s [ -f ] [ -r ] [ -s seed ]\nwhere seed > 0 is random number generator seed\n",argv[0]);
		exit(1);
		}

	/* Get model parameters 

	get_params(&params);*/
       

	/*(void) ran(seed); seed */

	if(!(argv[optind] == NULL)){
	  printf("Input file is %s\n",argv[optind]);	
	  read_data(argv[optind],&head,&data,&sun);
	}else{
	  printf("Enter input file name!!\n"); 
	  exit(0);
	} 

	/*	planets = data + head->n_data;
	printf("ok05 %d \n",head->n_data);
	gen_planets(&params,planets);*/


	/* printf("ok1 %d %d %d %d\n",head->n_data, planets,data,head); */
	/* Save data */

	output_data(data,head);

	printf("ok2 \n");
	/* All done */


	return 0;
	}

/* NRiC 2nd ed */

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

static double
ran(int seed)
{
	static long idum;

	int j;
	long k;
	static long iy=0;
	static long iv[NTAB];
	float temp;

	if (!iy) {
		assert(seed > 0);
		idum = seed;
		(void) printf("Random number seed = %li\n",idum);
		for (j=NTAB+7;j>=0;j--) {
			k=idum/IQ;
			idum=IA*(idum-k*IQ)-IR*k;
			if (idum < 0) idum += IM;
			if (j < NTAB) iv[j] = idum;
			}
		iy=iv[0];
		}
	k=idum/IQ;
	idum=IA*(idum-k*IQ)-IR*k;
	if (idum < 0) idum += IM;
	j=iy/NDIV;
	iy=iv[j];
	iv[j] = idum;
	if ((temp=AM*iy) > RNMX) return RNMX;
	else return (double) temp;
	}

#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX

/* ssic.c */
