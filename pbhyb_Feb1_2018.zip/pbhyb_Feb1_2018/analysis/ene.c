/*
**   ene.c
**   reading ss style position files and calculate  
**   the total kinetic and potential energies 
**   
*/  
#include "ssio.h"
#include "ss.h"
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "vector.h"

#define OUTFILE "ene.out"

int no_mass_wgt = 0; /*DEBUG hack for TEST particles*/

static int read_data(char *filename, FILE *fp, double *time,int *n_data,SSDATA **data,SSDATA **sun)
{
	SSIO ssio;
	SSHEAD h;
	SSDATA *d;
	double dEcoll, dEgas, dSunMass;
	int i,n,n_planets,n_test;

	*n_data = n = n_planets = n_test = 0;
	*data = *sun  = NULL;


	if (ssioOpen(filename,&ssio,SSIO_READ)) {
		(void) fprintf(stderr,"Unable to open %s\n",filename);
		return 1;
		}

	(void) ssioHead(&ssio,&h);

	*time = h.time;
	*n_data = h.n_data;
	dEcoll = h.dEcoll;
	dEgas = h.dEgas;
	/*printf("dEgas = %e \n", dEgas);*/ 
	dSunMass = h.dSunMass;
	*time *= (T_SCALE/JUL_YR); /* get time in Julian years */ 

	(void) printf("time %e Julian yr, n_data = %i -- ",*time,*n_data);

	if (*n_data <= 0) {
		(void) fprintf(stderr,"Missing or corrupted data -- skipped\n");
		return 1;
		}

	ssioSetPos(&ssio,SSHEAD_SIZE);

	*data = (SSDATA *) malloc(*n_data*sizeof(SSDATA));
	assert(*data != NULL);

	for (i=0;i<*n_data;++i) {
		d = &(*data)[i];
		(void) ssioData(&ssio,d);
		switch (d->color) {
		case SUN:
			assert(*sun == NULL);
			*sun = d;
			break;
		case GIANT:		
			++n_planets;
			break;
		case PLANETESIMAL:
			++n;
			break;
		case SUBEMBRYO:
			++n;
			break;
		case TRACER:
			++n;
			break;
		case TEST:
			++n_test;		
			break;
		default:
			(void) fprintf(stderr,"Unknown object (item %i, color %i, mass %e)"
						   "Aborting...\n",i,d->color,d->mass);
			++n;
			break;
			/* return 1; */
			}
		}

	(void) printf("%s%i planet%s, %i planetesimal%s\n",(*sun?"Sun,":""),
				  n_planets,(n_planets==1?"":"s"),n,(n==1?"":"s"));

	if (n_test) (void) printf("%i test particle%s\n",n_test,(n_test==1?"":"s"));

	(void) ssioClose(&ssio);

	/* if (!*sun)
	   (void) fprintf(stderr,"Sun not found...assuming heliocentric coords...\n");*/

        /* velocity of the mass center*/  
        double vc[3],vi[3],rc[3],ri[3],mt, vi2, rij[3], r,r2,moi;
	double E_total, T, U, R, L, Lx, Ly, Lz;
        int j, k;
	double msun;

	/*for (i=0;i<*n_data;++i) {
	  (void) fprintf(stderr,"pos = %e %e %e \n", (*data)[i].pos[0], (*data)[i].pos[1],(*data)[i].pos[2]);
	  }*/

	for (k=0;k<3;++k){
        vc[k] = 0.0;
	rc[k] = 0.0;
        vi[k] = 0.0;
        ri[k] = 0.0;
        }
	mt = 0.0; 
        T = 0.0;
        U = 0.0;
        R = 0.0;	
	L = 0.0;
	Lx = 0.0;
	Ly = 0.0;
	Lz = 0.0;

        for (i=0;i<*n_data;++i) {
	  for (k=0;k<3;++k){
	    vc[k] += ((*data)[i].mass)*((*data)[i].vel[k]);
	    rc[k] += ((*data)[i].mass)*((*data)[i].pos[k]);
	    
	    }
          mt += (*data)[i].mass; 
	}
	/* sun's mass */       
  	
	mt += dSunMass; 
	if(dSunMass != 1.0)printf("delta_SunMass = %e \n",dSunMass - 1.0);

	for (k=0;k<3;++k){
	    vc[k] /= mt;
	    rc[k] /= mt;
	    }
	  /*(void) fprintf(stderr,"vc = %e, %e, %e \n", vc[0], vc[1], vc[2]);*/
  
        for (i=0;i<*n_data;++i) {

	  vi2 = 0.0;
          /* velocity in inertial frame */         
          for (k=0;k<3;++k){
	    /*vi[k] =  (*data)[i].vel[k]; democratic coodinate */
	    vi[k] =  (*data)[i].vel[k] - vc[k];
	    ri[k] =  (*data)[i].pos[k] - rc[k];	   
	    vi2 += vi[k]*vi[k];	
	    }          
	  Lx +=  (*data)[i].mass*(ri[1]*vi[2] - ri[2]*vi[1]); 
	  Ly +=  (*data)[i].mass*(ri[2]*vi[0] - ri[0]*vi[2]); 
	  Lz +=  (*data)[i].mass*(ri[0]*vi[1] - ri[1]*vi[0]); 

	  T += 0.5*(*data)[i].mass*vi2;

	  /* mutual gravity except sun */
          for (j=i+1;j<*n_data;++j) {
	    // if((*data)[i].color != TEST || (*data)[j].color != TEST){
	    if((*data)[i].color <= SUBEMBRYO  || (*data)[j].color <= SUBEMBRYO){
	      r2 = 0.0;
	      r = 0.0;
	      
	      for (k=0;k<3;++k){
		rij[k] =  (*data)[i].pos[k]-(*data)[j].pos[k];             
		r2 += rij[k]*rij[k];                  
	      }
	      
	      r = sqrt(r2);                 
	      if(r < 1.e-7){
		(void) fprintf(stderr,"i = %i, j = %i, r= %e \n", i, j, r);
	      }
	      U += -((*data)[i].mass)*((*data)[j].mass)/r;      
	    }
	  }
	  
          /* sun's gravity*/
	  r2 = 0.0;
	  r = 0.0;
	  for (k=0;k<3;++k){
            r2 += ((*data)[i].pos[k])*((*data)[i].pos[k]);              
            }
            r = sqrt(r2); 
            U += -(*data)[i].mass*dSunMass/r;
	}



        /* sun's kinetic energy and angular momentum*/
	for (k=0;k<3;++k){
            T += 0.5*dSunMass*vc[k]*vc[k];              
            }

	Lx +=  dSunMass*(rc[1]*vc[2] - rc[2]*vc[1]); 
	Ly +=  dSunMass*(rc[2]*vc[0] - rc[0]*vc[2]); 
	Lz +=  dSunMass*(rc[0]*vc[1] - rc[1]*vc[0]); 


	/* rotational energy */  
	for (i=0;i<*n_data;++i) {
          moi = 0.4*((*data)[i].mass)*((*data)[i].radius)*((*data)[i].radius);
	  Lx += moi*(*data)[i].spin[0];
	  Ly += moi*(*data)[i].spin[1];
 	  Lz += moi*(*data)[i].spin[2];

          for (k=0;k<3;++k){
            R += moi*(*data)[i].spin[k]*(*data)[i].spin[k]; 
	    } 
	}
	    R *= 0.5;

	    E_total = T+U+R-dEcoll-dEgas;

	    L = sqrt(Lx*Lx+Ly*Ly+Lz*Lz);
	       
	(void) fprintf(stderr,"T = %e, U = %e, R = %e, dEcoll = %e, dEgas = %e \n", T, U, R,dEcoll,dEgas);
	(void) fprintf(stderr,"T+U+R-dEcoll-dEgas = %.16e \n",E_total);

	(void) fprintf(fp,"%e %i %.16e %e %e %e %e %e %.16e %e %e %.16e \n",
		       *time,*n_data,E_total,T,U,R,dEcoll,dEgas,L,Lx,Ly,Lz);

	return 0;
	}

int main (int argc, char *argv[])
{
     FILE *fp = NULL;
     FILE *fplog = NULL;

     SSDATA *data, *sun;
     double time;
     int n_data, i;
  
     if(!(argv[1] == NULL)){
       printf("Input file is %s\n",argv[1]);
     }else{
       printf("Enter input file name!!\n"); 
       exit(0);
     } 
   
    	if (!(fp = fopen(OUTFILE,"w"))) {
		(void) fprintf(stderr,"Unable to open %s for writing\n",OUTFILE);
		return 1;
		}   
            
     for (i=1;i<argc;++i){
       /*printf("%s\n",argv[i]);*/ 
     if (!read_data(argv[i],fp,&time,&n_data,&data,&sun)){ 
       /*(void)fprintf(stderr,"Reading suceeded\n");*/    
	}
     if(data)
       free((void *) data);
     }
      
     (void) fclose(fp);

 /* Logfile 
 **	fplog = fopen("logfile","w");
 **     fprintf(fplog,"# ");
 **	for (i=0;i<argc;++i) fprintf(fplog,"%s ",argv[i]);
 **	fprintf(fplog,"\n");
 */  
	return 0;
     }
