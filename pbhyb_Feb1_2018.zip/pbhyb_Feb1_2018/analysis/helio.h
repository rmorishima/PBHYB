#ifndef HELIO_HINCLUDED
#define HELIO_HINCLUDED

struct helio {
	double x;
	double y;
	double z;
	double vx;
	double vy;
	double vz;
	};

#endif
