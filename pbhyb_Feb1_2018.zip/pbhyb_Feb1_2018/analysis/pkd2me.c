/*
**   pkd2me.c
**   Converting particle data format for Pkdplanet to 
**   that for Mercury 
**   
**   Normalization note
**              mass   length   time            G        
**   PKDGRAV   m_sun    AU     OMEGA^{-1}       1
**   Mercury   m_sun    AU     day =86400s   GAUSS_K^2
**   
**   Therefore, v_mercury = GAUSS_K*v_pkdgrav 
**              t_mercury = GAUSS_K^{-1}*t_pkdgrav
**   GAUSS_K = 86400*OMEGA = 0.01720209895
**   is the Gaussian gravitaional constant defiend in ss.h
**
**   In PKDGRAV spin represents the spin frequency vector (data->spin[]=w[]) 
**   whereas it is the spin angular momentum in Mercury. Further, physical 
**   radii of planetesimals are enhanced in PKDGRAV by a factor f. 
**   We normalize spin frequencies by the critcal frequency, then we convert 
**   it to the spin angular momentunm normalized by the critical angular 
**   momentum.   
**   s_me = w_pkd*s_me_crit/w_pkd_crit 
**        = w_pkd*0.4*m*(3*m/4*pi*rho)^{2/3}*GAUSS_K*f^{1.5}
*/  

#include "ss.h"
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "vector.h"
#include "ssio.h"

/* #define#  INFILE  "pkdplanet.in" */
#define  OUTFILE "mercury.out"
#define  rho    5.04988E6 /* (3g/cm^3)/(M_sun/AU^3) */
#define  factor 1  /* f */
#define  sfac   0.4*pow((3.0/(4.0*PI*rho)),(2.0/3.0))*GAUSS_K*pow(factor,1.5)

int no_mass_wgt = 0; /*DEBUG hack for TEST particles*/

static int read_data(char *filename,double *time,int *n_data,SSDATA **data,SSDATA **sun)
{
	SSIO ssio;
	SSHEAD h;
	SSDATA *d;
	int i,n,n_planets,n_test;

	*n_data = n = n_planets = n_test = 0;
	*data = *sun = NULL;

	if (ssioOpen(filename,&ssio,SSIO_READ)) {
		(void) fprintf(stderr,"Unable to open %s\n",filename);
                  printf("ok2");
		return 1;
		}

	(void) ssioHead(&ssio,&h);

	*time = h.time;
	*n_data = h.n_data;

	*time *= (T_SCALE/JUL_YR); /* get time in Julian years */ 

	(void) printf("time %e Julian yr, n_data = %i -- ",*time,*n_data);

	if (*n_data <= 0) {
		(void) fprintf(stderr,"Missing or corrupted data -- skipped\n");
		return 1;
		}

	*data = (SSDATA *) malloc(*n_data*sizeof(SSDATA));
	assert(*data != NULL);

	for (i=0;i<*n_data;++i) {
		d = &(*data)[i];
		(void) ssioData(&ssio,d);
		switch (d->color) {
		case SUN:
			assert(*sun == NULL);
			*sun = d;
			break;
		case GIANT:		
			++n_planets;
			break;	
		case PLANETESIMAL:
			++n;
			break;
		case TEST:
			++n_test;		
			break;
		default:
			(void) fprintf(stderr,"Unknown object (item %i, color %i) in "
						   "data file! Aborting...\n",i,d->color);
			return 1;
			}
		}

	(void) printf("%s%i planet%s, %i planetesimal%s\n",(*sun?"Sun,":""),
				  n_planets,(n_planets==1?"":"s"),n,(n==1?"":"s"));

	if (n_test) (void) printf("%i test particle%s\n",n_test,(n_test==1?"":"s"));

	(void) ssioClose(&ssio);

	if (!*sun)
		(void) fprintf(stderr,"Sun not found...assuming heliocentric coords...\n");

	return 0;
	}

static int convert(FILE *filename2,double time,int n_data,SSDATA *data,SSDATA *sun)
{
  SSDATA *d;
  double time2;
  int i,n,n_p;
  double sfacc;

  n = n_p = 0;  
  (void) fprintf(filename2,")O+_06 Big-body initial data (WARNING: Do not delete this line!!) \n");
  (void) fprintf(filename2,") Lines beginning with ) are ignored.\n");
  (void) fprintf(filename2,")----------------------------------------------------\n");

  /* Data file style for PKDGRAV is Cartesian */
  (void) fprintf(filename2," style (Cartesian, Asteroidal, Cometary) = Cartesian \n");

  /*time2 = time/GAUSS_K;*/
  time2 = 365.25*time;/* now time is in unit of a year (see get time Julian ... in the above) */
 
  (void) fprintf(filename2," epoch (in days) = %e \n", time2); 

  (void) fprintf(filename2,")----------------------------------------------------\n"); 
  
	for (i=0;i<n_data;++i) {
		d = &(data)[i];
		switch (d->color) {
		case SUN:			
			break;
		case GIANT:	        	
		  /*   printf("Jupiter's pointer %u\n",d);	*/
		        ++n_p;
                        printf("GIANT's pointer %p\n",d);
			(void) fprintf(filename2,"GIANT%d m=%e r=3.0 d=1.33\n",n_p, d->mass);  
       			break;	
		case PLANETESIMAL:
		  /*printf("Planetesimal %d's pointer %u\n",n, d);*/
                        ++n; 
		        (void) fprintf(filename2,"Par%d m=%e r=3.0 d=2.0\n",n, d->mass);
                    	break;
                         
		}
		/*(void)fprintf(stderr,"%e %e \n",d->pos[0], data[i].pos[0]);*/ 
		(void) fprintf(filename2,"%e %e %e \n", d->pos[0], d->pos[1], d->pos[2]);
		(void) fprintf(filename2,"%e %e %e \n", GAUSS_K*d->vel[0], GAUSS_K*d->vel[1], GAUSS_K*d->vel[2]);
                sfacc =  sfac*pow(d->mass,5.0/3.0);
		(void) fprintf(filename2,"%e %e %e \n",d->spin[0]*sfacc,d->spin[1]*sfacc,d->spin[2]*sfacc);
                }
         
	return 0;
}


int main (int argc, char *argv[])
{
     FILE *fp = NULL;
     FILE *fplog = NULL;

     SSDATA *data, *sun;
     double time;
     int n_data, i;
  
     if(!(argv[1] == NULL)){
       printf("Input file is %s\n",argv[1]);
     }else{
       printf("Enter input file name!!\n"); 
       exit(0);
     } 
       printf("sfac = %e \n",sfac); 
     /* Better to abort than accidentally overwrite file */
     if (fp == fopen(OUTFILE,"r")){
        (void) fprintf(stderr,"Output file %s already exits\n", OUTFILE);
        printf("ok1");
        (void) fclose(fp);     
        return 1; 
     }

     /* Open output file */
     if (!(fp == fopen(OUTFILE,"w"))){
        (void)fprintf(stderr,"Unable to open %s for writing\n", OUTFILE);     
        return 1; 
     }

   
               
     /* Read pkdgrav data and convert into mercury input style */ 
     if (!read_data(argv[1],&time,&n_data,&data,&sun)){ 
        (void)fprintf(stderr,"Reading suceeded\n");   
	convert(fp,time,n_data,data,sun); 
        
         
      /*  return 0; */ 
	}
       
        fclose(fp);
        
 /* Logfile 
 **	fplog = fopen("logfile","w");
 **     fprintf(fplog,"# ");
 **	for (i=0;i<argc;++i) fprintf(fplog,"%s ",argv[i]);
 **	fprintf(fplog,"\n");
 */ 
	return 0;
     }
